import json
import os
from collections import Counter


def choisir_fichier():
    fichiers = sorted(
        [f for f in os.listdir() if f.lower().endswith(".json")]
    )

    if not fichiers:
        print("Aucun fichier JSON trouvé.")
        return None

    print("\n=== Fichiers disponibles ===")
    for i, fichier in enumerate(fichiers, 1):
        print(f"[{i}] {fichier}")

    while True:
        try:
            choix = int(input("\nChoisissez un fichier : "))
            if 1 <= choix <= len(fichiers):
                return fichiers[choix - 1]
        except ValueError:
            pass

        print("Choix invalide.")


def charger_json(fichier):
    with open(fichier, "r", encoding="utf-8") as f:
        return json.load(f)

def afficher_stats_level(comptes):
    compteur = Counter()
    compteur_temp = Counter()

    for compte in comptes:
        level = compte.get("level")

        if isinstance(level, int):
            compteur[level] += 1

            if compte.get("banned_temp") is True:
                compteur_temp[level] += 1

    print("\n📊 Stats par niveau :")

    total = 0
    total_temp = 0

    for level in sorted(compteur.keys(), reverse=True):
        nb = compteur[level]
        nb_temp = compteur_temp[level]

        total += nb
        total_temp += nb_temp

        print(f"  Level {level:<2} → {nb} comptes ({nb_temp} temporaire)")

    print(f"\nTotal : {total} comptes ({total_temp} temporaire)")

def main():
    fichier = choisir_fichier()
    if not fichier:
        return

    comptes = charger_json(fichier)

    print(f"\nFichier sélectionné : {fichier}")
    afficher_stats_level(comptes)


if __name__ == "__main__":
    main()