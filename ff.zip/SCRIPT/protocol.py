# -*- coding: utf-8 -*-
"""
Protocole FreeFire (login, passerelle TCP, matchs UDP).

Code extrait tel quel de l'ancien Main.py. Les seules différences :
  - `bot_state` vient de ffbot.hooks (pont vers le moteur de panels) ;
  - chemins de fichiers relatifs au dossier du projet ;
  - points d'accroche : limite de matchs parallèles (can_start_match),
    début/fin de match, erreurs de passerelle, rafraîchissement du profil ;
  - mode de jeu (game_mode) : Lone Wolf, Battle Royale ou Clash Squad. Les trois modes suivent la même
    logique : dès qu'un match est trouvé il est joué en arrière-plan (UDP) et une nouvelle recherche part
    aussitôt, sans attendre la fin de la partie (matchs en parallèle).
  - Battle Royale : une partie n'est jamais quittée avant sa fin réelle (sinon « Abandonné » en jeu),
    même quand la session du compte s'arrête (voir UNINTERRUPTIBLE_MODES).
  - limite globale de matchs simultanés (MAX_TOTAL_MATCHES) : au-delà, les parties ne sont plus créditées.
"""
# ==================== STANDARD IMPORTS ====================
import sys
import asyncio
import httpx
import random
import json
import socket
import struct
import time
import os
import uuid
import itertools
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple, Any

if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        if hasattr(sys.stderr, 'reconfigure'):
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# ==================== ORIGINAL IMPORTS ====================
from google_play_scraper import app as play_scraper
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from protobuf_decoder.protobuf_decoder import Parser
from message_ids import MESSAGE_ID_TO_NAME
import thunderFF_pb2
import ban_pb2

# ==================== ENGINE HOOKS ====================
from ffbot.hooks import bot_state
from ffbot.models import AccountBanned

# ==================== CONFIGURATION ====================
_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOKEN_CACHE_FILE = os.path.join(_ROOT_DIR, "token_cache.json")
DEVICES_FILE = os.path.join(_ROOT_DIR, "devices.json")  # 🔥 NEW: Persistent device storage
TOKEN_CACHE_TTL = 1200

# 🔥 Match control
START_MATCH_INTERVAL = 3.0
NEW_MATCH_DELAY = 3.0
# Matchs simultanés sur toute la machine (tous comptes, 0 = illimité ; MAX_TOTAL_MATCHES dans .env).
# Mesuré sur l'historique : l'EXP totale culmine vers 50-90 parties en parallèle ; au-delà de ~120,
# les parties ne sont plus créditées et l'EXP totale est divisée par deux.
try:
    MAX_TOTAL_MATCHES = int(os.environ.get("MAX_TOTAL_MATCHES", "60"))
except ValueError:
    MAX_TOTAL_MATCHES = 60
MAX_MATCH_DURATION = 700
MATCH_IDLE_TIMEOUT = 8.0
PRIORITY_REGIONS = ["BD","IND", "SG", "TH", "PH", "VN", "MY", "ID", "HK", "TW"]

# 🔥 Modes de jeu : "lone_wolf" | "br" | "clash_squad", tous en matchs parallèles
#    (match trouvé -> joué en arrière-plan, nouvelle recherche aussitôt, sans attendre la fin de la partie)
MODE_TAGS = {"lone_wolf": "LONE WOLF", "br": "BR", "clash_squad": "CLASH SQUAD"}
# (mode_id, map_id) du paquet UDP de chargement ; mêmes valeurs que les champs 5.7 / 5.8 du paquet « match trouvé »
MATCH_MODE_IDS = {"lone_wolf": (43, 11), "br": (1, 1), "clash_squad": (15, 1)}
SERVER_MAP_MODES = ("br", "clash_squad")   # mode / carte relus dans le paquet « match trouvé » (5.7 / 5.8)
HANDSHAKE_TIMEOUT = 25.0
# BR : quitter la partie avant d'être éliminé la marque « Abandonné » dans l'historique du jeu.
# Le bot ne la quitte donc qu'à sa fin réelle ; les bornes ci-dessous ne servent que de filet de sécurité.
BR_MAX_MATCH_DURATION = 1500     # au-delà de toute partie BR (~15 min) : jamais de sortie en cours de partie
BR_MATCH_IDLE_TIMEOUT = 60.0     # silence du serveur UDP : une coupure réseau / un pic de charge ne fait pas quitter
BR_HANDSHAKE_TIMEOUT = 60.0      # le joueur est déjà inscrit dans la partie : on insiste avant de renoncer
# mode -> (durée max. d'un match, silence max. du serveur UDP avant de considérer le match fini, délai de connexion)
MATCH_TIMING = {
    "lone_wolf": (MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "br": (BR_MAX_MATCH_DURATION, BR_MATCH_IDLE_TIMEOUT, BR_HANDSHAKE_TIMEOUT),
    "clash_squad": (MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),   # comme le script Clash Squad d'origine
}
# Modes dont les parties ne sont jamais coupées par l'arrêt de la session (passer le compte, arrêt du panel,
# objectif atteint, watchdog) : elles continuent en arrière-plan jusqu'à leur fin réelle.
UNINTERRUPTIBLE_MODES = ("br",)

# Commandes UDP (message_ids.py)
RUDP_MATCH_END = 103
RUDP_DEAD = 107     # BR : peut concerner un autre joueur de la partie -> fin seulement s'il désigne notre compte
# Seules commandes auxquelles play_game réagit : les autres paquets (état de la partie) ne sont pas déchiffrés
_UDP_CONTROL_CMDS = frozenset({1, 2, 3, 100, 101, RUDP_MATCH_END, RUDP_DEAD})

# 🔥 Cache invalidation thresholds
MAX_CONSECUTIVE_PARSE_FAILURES = 5.0     
NON_MATCH_RECONNECT_DELAY = 1.0


# ==================== ULTRA SAFE PERSISTENT DEVICE RANDOMIZER ====================
def get_device_for_account(account_identifier: str) -> dict:
    """
    Ensures 1 ID = 1 Specific Device.
    It loads saved devices from devices.json. If the account isn't found, 
    it generates a new profile and saves it permanently for this ID.
    """
    devices = {}
    if os.path.exists(DEVICES_FILE):
        try:
            with open(DEVICES_FILE, "r", encoding="utf-8") as f:
                devices = json.load(f)
        except Exception:
            pass
            
    acc_key = str(account_identifier)
    
    if acc_key in devices:
        return devices[acc_key]
        
    # Generate new device profile for this account
    device_list = [
        ("Samsung", "SM-G998B", "Adreno (TM) 660", "Android OS 12 / API-31"),
        ("Xiaomi", "2201122G", "Adreno (TM) 730", "Android OS 13 / API-33"),
        ("Realme", "RMX3700", "Mali-G710", "Android OS 14 / API-34"),
        ("OnePlus", "CPH2451", "Adreno (TM) 740", "Android OS 13 / API-33"),
        ("OPPO", "CPH2611", "Adreno (TM) 720", "Android OS 14 / API-34"),
        ("Vivo", "V2203", "Mali-G710", "Android OS 12 / API-31"),
        ("Poco", "M2102J20SG", "Adreno (TM) 660", "Android OS 13 / API-33"),
    ]
    brand, model, gpu, os_ver = random.choice(device_list)
    
    new_device = {
        "unique_device_id": f"Google|{str(uuid.uuid4())}",
        "brand": brand,
        "model": model,
        "gpu_renderer": gpu,
        "system_software": os_ver,
        "screen_width": random.choice([1080, 1440, 720, 1280]),
        "screen_height": random.choice([2400, 3200, 1600, 2400]),
        "screen_dpi": str(random.randint(300, 420)),
        "memory": random.randint(2800, 6500),
        "processor_details": f"ARM64 FP ASIMD AES VMH | {random.randint(2200, 3200)} | {random.randint(6, 12)}",
        "client_ip": f"{random.randint(103, 223)}.{random.randint(10, 250)}.{random.randint(10, 250)}.{random.randint(10, 250)}"
    }
    
    devices[acc_key] = new_device
    
    try:
        with open(DEVICES_FILE, "w", encoding="utf-8") as f:
            json.dump(devices, f, indent=4)
    except Exception as e:
        print_error(f"Failed to save device mapping: {e}")
        
    return new_device


# ==================== CLOUDFLARE DNS RESOLVER & SOCKET OPTIMIZERS ====================
CLOUDFLARE_PRIMARY_DNS = "1.1.1.1"
CLOUDFLARE_SECONDARY_DNS = "1.0.0.1"
_DNS_CACHE: Dict[str, Tuple[str, float]] = {}
_DNS_CACHE_TTL = 300.0  # 5 minutes DNS cache

async def resolve_host_cloudflare(hostname: str) -> str:
    if not hostname:
        return hostname

    parts = hostname.split('.')
    if len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
        return hostname

    now = time.time()
    if hostname in _DNS_CACHE:
        ip, exp = _DNS_CACHE[hostname]
        if now < exp:
            return ip

    def _query_cloudflare(server_ip: str) -> Optional[str]:
        s = None
        try:
            tx_id = random.randint(1000, 65535)
            header = struct.pack(">HHHHHH", tx_id, 0x0100, 1, 0, 0, 0)
            qname = b"".join(bytes([len(part)]) + part.encode('ascii') for part in hostname.split('.')) + b"\x00"
            query_pkt = header + qname + struct.pack(">HH", 1, 1)

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1.2)
            s.sendto(query_pkt, (server_ip, 53))
            resp, _ = s.recvfrom(1024)

            if len(resp) >= 12:
                ancount = struct.unpack(">H", resp[6:8])[0]
                if ancount > 0:
                    offset = 12 + len(qname) + 4
                    for _ in range(ancount):
                        if offset >= len(resp):
                            break
                        if (resp[offset] & 0xC0) == 0xC0:
                            offset += 2
                        else:
                            while offset < len(resp) and resp[offset] != 0:
                                offset += 1 + resp[offset]
                            offset += 1
                        if offset + 10 > len(resp):
                            break
                        rtype, rclass, ttl, rdlen = struct.unpack(">HHIH", resp[offset:offset+10])
                        offset += 10
                        if rtype == 1 and rdlen == 4 and offset + 4 <= len(resp):
                            return socket.inet_ntoa(resp[offset:offset+4])
                        offset += rdlen
        except Exception:
            pass
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass
        return None

    loop = asyncio.get_running_loop()
    ip = await loop.run_in_executor(None, _query_cloudflare, CLOUDFLARE_PRIMARY_DNS)
    if not ip:
        ip = await loop.run_in_executor(None, _query_cloudflare, CLOUDFLARE_SECONDARY_DNS)
    if not ip:
        try:
            ip_info = await loop.getaddrinfo(hostname, None, family=socket.AF_INET)
            if ip_info:
                ip = ip_info[0][4][0]
        except Exception:
            ip = hostname

    if ip:
        _DNS_CACHE[hostname] = (ip, now + _DNS_CACHE_TTL)
    return ip or hostname


def optimize_tcp_socket(sock: socket.socket):
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
    except Exception:
        pass


def optimize_udp_socket(sock: socket.socket):
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 131072)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 131072)
        if hasattr(socket, 'SIO_UDP_CONNRESET') and os.name == 'nt':
            try:
                sock.ioctl(socket.SIO_UDP_CONNRESET, False)
            except Exception:
                pass
    except Exception:
        pass


# ==================== NETWORK & CRYPTO ====================
client = httpx.AsyncClient(
    verify=False,
    timeout=10.0,
    limits=httpx.Limits(max_connections=100, max_keepalive_connections=50)
)

headers = {
    'User-Agent': 'UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'gzip',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Expect': '100-continue',
    'X-Unity-Version': '2018.4.12f1',
    'X-GA-SV': '1789535859',
    'X-GA': 'v1 1',
    'ReleaseVersion': 'OB55'
}

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'

CRC7_TABLE = bytes([
    0, 9, 18, 27, 36, 45, 54, 63, 72, 65, 90, 83, 108, 101, 126, 119,
    25, 16, 11, 2, 61, 52, 47, 38, 81, 88, 67, 74, 117, 124, 103, 110,
    50, 59, 32, 41, 22, 31, 4, 13, 122, 115, 104, 97, 94, 87, 76, 69,
    43, 34, 57, 48, 15, 6, 29, 20, 99, 106, 113, 120, 71, 78, 85, 92,
    100, 109, 118, 127, 64, 73, 82, 91, 44, 37, 62, 55, 8, 1, 26, 19,
    125, 116, 111, 102, 89, 80, 75, 66, 53, 60, 39, 46, 17, 24, 3, 10,
    86, 95, 68, 77, 114, 123, 96, 105, 30, 23, 12, 5, 58, 51, 40, 33,
    79, 70, 93, 84, 107, 98, 121, 112, 7, 14, 21, 28, 35, 42, 49, 56,
    65, 72, 83, 90, 101, 108, 119, 126, 9, 0, 27, 18, 45, 36, 63, 54,
    88, 81, 74, 67, 124, 117, 110, 103, 16, 25, 2, 11, 52, 61, 38, 47,
    115, 122, 97, 104, 87, 94, 69, 76, 59, 50, 41, 32, 31, 22, 13, 4,
    106, 99, 120, 113, 78, 71, 92, 85, 34, 43, 48, 57, 6, 15, 20, 29,
    37, 44, 55, 62, 1, 8, 19, 26, 109, 100, 127, 118, 73, 64, 91, 82,
    60, 53, 46, 39, 24, 17, 10, 3, 116, 125, 102, 111, 80, 89, 66, 75,
    23, 30, 5, 12, 51, 58, 33, 40, 95, 86, 77, 68, 123, 114, 105, 96,
    14, 7, 28, 21, 42, 35, 56, 49, 70, 79, 84, 93, 98, 107, 112, 121,
])

_DELTA = 0x9E3779B9
_ROUNDS = 16
_FIELD_SIZES = {0: 1, 1: 2, 2: 2, 3: 1, 4: 2}
_FIELD_NAMES = {0: "sendOption", 1: "cmd", 2: "orderId", 3: "flags", 4: "length"}

sai_tail_dul = bytes.fromhex(
    "0101030101045452000103000100000410312e3133302e3232"
    "1432303139313231303430ca0163736f7665727365612e737472"
    "6f6e67686f6c642e66726565666972656d6f62696c652e636f6d"
    "3b302e302e302e303b33342e3132362e37362e34353b33342e38"
    "372e3137372e31343b33342e38372e3137302e3233303b33352e"
    "3138352e3138332e353700000000000001000000000000000000"
    "0000000100000000000100000000000100b8eeec91c5d7ffde110200"
)

class Colors:
    HEADER = '\033[95m'
    GREEN = '\033[92m'
    FAIL = '\033[91m'
    WARNING = '\033[93m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    WHITE = '\033[97m'
    ENDC = '\033[0m'

# Sorties console du protocole : désactivées par défaut (CONSOLE_MODE=debug pour les réactiver).
CONSOLE_VERBOSE = False


def print_colored(text, color=Colors.WHITE):
    if not CONSOLE_VERBOSE:
        return
    try:
        print(f"{color}{text}{Colors.ENDC}")
    except Exception:
        try:
            print(f"{color}{text.encode('ascii', errors='replace').decode('ascii')}{Colors.ENDC}")
        except Exception:
            pass

def print_success(text):
    print_colored(f"[+] {text}", Colors.GREEN)
    try:
        bot_state.log(text, "success")
    except Exception:
        pass

def print_error(text):
    print_colored(f"[-] {text}", Colors.FAIL)
    try:
        bot_state.log(text, "error")
    except Exception:
        pass

def print_warning(text):
    print_colored(f"[!] {text}", Colors.WARNING)
    try:
        bot_state.log(text, "warning")
    except Exception:
        pass

def print_info(text):
    print_colored(f"[i] {text}", Colors.CYAN)
    try:
        bot_state.log(text, "info")
    except Exception:
        pass

def _proto_int(value, default):
    """Entier positif d'un champ varint décodé ; `default` s'il est absent ou illisible."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default

def get_proto_field(d, key, default=None):
    if not d or not isinstance(d, dict):
        return default
    if key in d:
        val = d[key].get('data')
        return val if val is not None else default
    if str(key) in d:
        val = d[str(key)].get('data')
        return val if val is not None else default
    return default


# ==================== PER-ACCOUNT MATCH COUNTER ====================
_match_counters: Dict[str, int] = {}
_match_counter_lock = asyncio.Lock()

async def _inc_match(uid: str) -> int:
    async with _match_counter_lock:
        _match_counters[uid] = _match_counters.get(uid, 0) + 1
        return _match_counters[uid]

async def _dec_match(uid: str) -> int:
    async with _match_counter_lock:
        if uid in _match_counters and _match_counters[uid] > 0:
            _match_counters[uid] -= 1
        return _match_counters.get(uid, 0)

async def _get_match_count(uid: str) -> int:
    async with _match_counter_lock:
        return _match_counters.get(uid, 0)

async def _get_total_match_count() -> int:
    async with _match_counter_lock:
        return sum(_match_counters.values())


# ==================== LIMITE GLOBALE (MAX_TOTAL_MATCHES) ====================
_searching: Set[str] = set()      # comptes dont un StartMatch attend encore son match
_gateway_uids: Set[str] = set()   # comptes qui cherchent des matchs (functional_lone_wolf en cours)

async def _has_match_slot(uid: str) -> bool:
    """Place libre sous MAX_TOTAL_MATCHES (matchs en cours + recherches des autres comptes),
    dans la limite d'une part équitable par compte pour qu'aucun compte ne prenne toutes les places."""
    if MAX_TOTAL_MATCHES <= 0:
        return True
    async with _match_counter_lock:
        total = sum(_match_counters.values())
        own = _match_counters.get(uid, 0)
    if total + len(_searching) - (uid in _searching) >= MAX_TOTAL_MATCHES:
        return False
    return own < -(-MAX_TOTAL_MATCHES // max(1, len(_gateway_uids)))


# ==================== PARTIES PROTÉGÉES (BR) ====================
# Références fortes : une partie protégée survit à la session (passerelle) qui l'a lancée.
_background_matches: Set[asyncio.Task] = set()

def _keep_running(task: asyncio.Task):
    _background_matches.add(task)
    task.add_done_callback(_background_matches.discard)

async def _stop_matches(play_matches: List[asyncio.Task]):
    """Arrêt de la passerelle : coupe les parties interruptibles, laisse finir les parties protégées (BR)."""
    running = [m for m in play_matches if not m.done()]
    play_matches.clear()
    kept = [m for m in running if m in _background_matches]
    cut = [m for m in running if m not in _background_matches]
    if kept:
        print_warning(f"[FUNCTIONAL] {len(kept)} partie(s) BR en cours : elles continuent jusqu'à leur fin (pas d'abandon)")
    if cut:
        print_warning(f"[FUNCTIONAL] Cancelled — cancelling {len(cut)} UDP matches")
        for m in cut:
            m.cancel()
        await asyncio.gather(*cut, return_exceptions=True)

async def stop_background_matches():
    """Arrêt du serveur : coupe aussi les parties protégées (avant la fermeture du stockage)."""
    tasks = [t for t in _background_matches if not t.done()]
    for t in tasks:
        t.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


# ==================== TOKEN CACHE ====================
_token_cache_memo: Dict[str, Any] = {}
_token_cache_memo_time: float = 0.0
_TOKEN_CACHE_MEMO_TTL = 5.0

def _json_serializer(obj):
    if isinstance(obj, (bytes, bytearray)):
        return {"__bytes_hex__": bytes(obj).hex()}
    raise TypeError(f"Type {type(obj)} not serializable")

def _json_deserializer(obj):
    if isinstance(obj, dict):
        if "__bytes_hex__" in obj and len(obj) == 1:
            try:
                return bytes.fromhex(obj["__bytes_hex__"])
            except Exception:
                return b""
        return {k: _json_deserializer(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_deserializer(x) for x in obj]
    return obj

_token_cache_mtime: float = -1.0


def _load_token_cache() -> Dict[str, Any]:
    """Cache mémoire : le fichier n'est relu (et re-parsé) que s'il a été modifié sur le disque."""
    global _token_cache_memo, _token_cache_memo_time, _token_cache_mtime
    now = time.time()
    try:
        mtime = os.path.getmtime(TOKEN_CACHE_FILE)
    except OSError:
        return {}
    if mtime == _token_cache_mtime:
        return _token_cache_memo
    try:
        with open(TOKEN_CACHE_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
        if not content:
            return {}
        data = json.loads(content)
        if not isinstance(data, dict):
            raise ValueError("Cache root must be dict")
        parsed = _json_deserializer(data)
        _token_cache_memo = parsed
        _token_cache_memo_time = now
        _token_cache_mtime = mtime
        return parsed
    except Exception as e:
        print_error(f"Token cache corrupt → deleting: {e}")
        try:
            os.remove(TOKEN_CACHE_FILE)
        except Exception:
            pass
        return {}

def _save_token_cache(cache: Dict[str, Any]):
    global _token_cache_memo, _token_cache_memo_time
    try:
        tmp_file = TOKEN_CACHE_FILE + ".tmp"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(cache, f, separators=(",", ":"), default=_json_serializer)
        os.replace(tmp_file, TOKEN_CACHE_FILE)
        global _token_cache_mtime
        _token_cache_memo = cache
        _token_cache_memo_time = time.time()
        _token_cache_mtime = os.path.getmtime(TOKEN_CACHE_FILE)
    except Exception as e:
        print_error(f"Token cache save error: {e}")

def cache_get(uid: str) -> Optional[Dict]:
    cache = _load_token_cache()
    entry = cache.get(str(uid))
    if not entry:
        return None
    if time.time() - entry.get("cached_at", 0) > TOKEN_CACHE_TTL:
        print_info(f"[CACHE] UID {uid} expired. Re-login needed.")
        cache_invalidate(uid)
        return None
    if str(entry.get("account_id", "")).isdigit():
        entry["account_id"] = int(entry["account_id"])
    if not isinstance(entry.get("login_payload_data"), (bytes, bytearray)):
        print_warning(f"[CACHE] UID {uid} missing payload → invalidating")
        cache_invalidate(uid)
        return None
    return entry

def cache_set(uid: str, account_data: Dict):
    cache = _load_token_cache()
    entry = dict(account_data)
    entry["cached_at"] = time.time()
    cache[str(uid)] = entry
    _save_token_cache(cache)
    print_success(f"[CACHE] Saved credentials for UID {uid}")

def cache_invalidate(uid: str):
    cache = _load_token_cache()
    if str(uid) in cache:
        del cache[str(uid)]
        _save_token_cache(cache)
        print_warning(f"[CACHE] Invalidated: {uid}")

def cached_sessions() -> Dict[str, Dict]:
    """Sessions de token_cache.json, en lecture seule (sans invalidation : le token de jeu reste valable ~8 h
    après le délai de cache). Sert à la carte de profil (ffbot.profile_card)."""
    return _load_token_cache()


# ==================== ENCRYPTION & PROTOBUF ====================

async def aes_encrypt(payload, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(payload, AES.block_size))

async def get_playstore_version():
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None,
        lambda: play_scraper('com.dts.freefireth', lang='hi', country='id')
    )
    return result.get("version")

async def version_config():
    app_version = await get_playstore_version()
    api_url = (
        "https://version.ggwhitehawk.com/live/ver.php"
        f"?version={app_version}"
        "&lang=hi&device=android&channel=android"
        "&appstore=googleplay&region=BD"
        "&whitelist_version=1.3.0&whitelist_sp_version=1.0.0"
    )
    try:
        response = await client.get(api_url)
        response.raise_for_status()
        data = response.json()
        server_url = data.get("server_url")
        remote_version = data.get("remote_version")
        latest_release_version = data.get("latest_release_version")
        if not server_url or not remote_version or not latest_release_version:
            print_error(f"[LOGIN] Configuration de version incomplète : {str(data)[:160]}")
            return None
        return latest_release_version, remote_version, server_url
    except Exception as e:
        print_error(f"[LOGIN] Configuration de version (ver.php) inaccessible : {e!r}"[:300])
        return None

async def get_access_token(uid, password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    hdrs = {
        "Host": "100067.connect.garena.com",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-G998B Build/SP1A.210812.016)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close"
    }
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }
    last_error = ""
    for attempt in range(5):
        try:
            response = await client.post(url, headers=hdrs, data=data)
            last_error = f"HTTP {response.status_code} {' '.join(response.text.split())[:120]}"
            if response.status_code == 200:
                response_data = response.json()
                open_id = response_data.get("open_id")
                access_token = response_data.get("access_token")
                platform = response_data.get("platform", 4)
                if open_id and access_token:
                    return open_id, access_token, platform
            if response.status_code == 429:
                await asyncio.sleep(1)
                continue
        except Exception as e:
            last_error = repr(e)
        await asyncio.sleep(0.5)
    print_error(f"[LOGIN] Token invité (guest/token/grant) refusé pour l'UID {uid} : {last_error}"[:300])
    return None

async def parse_results(parsed_results):
    result_dict = {}
    for result in parsed_results:
        field_data = {"wire_type": result.wire_type}
        if result.wire_type == "varint":
            field_data["data"] = result.data
        elif result.wire_type == "string":
            field_data["data"] = result.data
        elif result.wire_type == "bytes":
            field_data["data"] = result.data
        elif result.wire_type == "length_delimited":
            field_data["data"] = await parse_results(result.data.results)
        result_dict[result.field] = field_data
    return result_dict

async def decode_protobuf(data):
    parsed_results = Parser().parse(data)
    parsed_results_dict = await parse_results(parsed_results)
    return json.dumps(parsed_results_dict)


import nexxthug_pb2

async def build_majorlogin_payload(open_id, access_token, platform, client_version, device_info):
    """
    Aligné sur la capture réelle (proto JSON + DECRYPTED HEX).
    """
    version_code = client_version

    game_data = nexxthug_pb2.thug4ff()

    # --- En-tête / identification ---
    game_data.timestamp      = str(datetime.now())[:-7]
    game_data.game_name      = "free fire"
    game_data.game_version   = 1
    game_data.version_code   = version_code           # ex: "1.132.8"

    # --- OS / device ---
    game_data.os_info             = "Android OS 9 / API-28 (SP1A.210812.016/G998BXXU4BULF)"
    game_data.device_type         = "Handheld"
    game_data.device_form_factor  = "Handheld"
    game_data.device_model        = "samsung SM-G998B"
    game_data.dpi                 = "240"
    game_data.os_architecture     = "32"
    game_data.build_number        = "2019121229"

    # --- Réseau ---
    game_data.network_provider            = "Bouygues Telecom"
    game_data.connection_type             = "WIFI"
    game_data.secondary_network_provider  = "Bouygues Telecom"
    game_data.secondary_connection_type   = "WIFI"
    game_data.ip_address                  = "165.169.250.93"

    # --- CPU/GPU/RAM ---
    game_data.cpu_info          = "ARMv7 VFPv3 NEON | 2000 | 4"
    game_data.total_ram         = 3940
    game_data.gpu_name          = "Adreno (TM) 540"
    game_data.gpu_version       = "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)"
    game_data.graphics_backend  = "OpenGLES2"
    game_data.max_texture_units = 4095
    game_data.rendering_api     = platform
    game_data.gpu_features      = '{"cur_rate":null,"support_etc2":false}'   # field 96

    # --- Écran ---
    game_data.screen_width  = 1600
    game_data.screen_height = 900

    # --- Locale / compte ---
    game_data.language  = "fr"
    game_data.city      = "Saint-Denis"                     # field 90
    game_data.user_id   = "Google|c4d8782a-ea5d-43cc-9691-4c0fb66be40d"
    game_data.unique_id = "7428b253defc164018c604a1ebbfebdf" # field 57

    # --- Auth (issus du token endpoint) ---
    game_data.open_id      = open_id
    game_data.access_token = access_token

    # --- Plateforme (string côté serveur) ---
    game_data.platform_type = str(platform)   # field 23 = string
    game_data.field_99      = str(platform)
    game_data.field_100     = str(platform)

    # --- Champs numériques hérités ---
    game_data.field_60 = 128886
    game_data.field_61 = 112142
    game_data.field_62 = 7998
    game_data.field_63 = 5777
    game_data.field_64 = 118712
    game_data.field_65 = 128886
    game_data.field_66 = 118712
    game_data.field_67 = 128886
    game_data.field_70 = platform            # laissé si tu veux, absent de la capture
    game_data.field_73 = 3

    # --- APK / libs ---
    game_data.library_path = "/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/lib/arm"
    game_data.field_76     = 1
    game_data.apk_info     = ("b8e0cd5e295eee42f5860d3c86e483dd|"
                              "/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/base.apk")
    game_data.field_78 = 3
    game_data.field_79 = 1
    game_data.field_85 = 3

    # --- Champs bytes/obfusqués ---
    game_data.encoded_field_89 = "\u0017T\u0011\u0017\u0002\b\u000eUMQ\bEZ\u0003@ZK;Z\u0002\u000eV\ri[QVi\u0003\ro\t\u0007e"
    game_data.field_92      = 7450
    game_data.marketplace   = "android"
    game_data.encryption_key = ("KqsHTwLedr3dtLEWR8yCTMXtD+L7kqV4dI6m6F1j/Kjjexiqo4bQ2WOHRre6SnMVQ8"
                                "KHVdvMlGZ4GJVCibXLibS/gfVp2PxMgG9lA6TpTciXCFak")
    game_data.total_storage = 111207

    game_data.field_97  = 1
    game_data.field_98  = 1

    # --- Nouveaux champs de la capture ---
    game_data.unknown_102    = bytes.fromhex(
        "44004640510f5f05195c544c59074c0a413c0b540e035c240d4306311704025340390b5437"
    )
    game_data.field_104      = 61270
    game_data.field_105      = 1
    game_data.hot_update_urls = (
        "https://dl-bs.ggpolarbear.com/live/ABHotUpdates/|"
        "https://core-bs.ggpolarbear.com/live/ABHotUpdates/|"
        "211c933168f55902c7dfbfd8c4e2957d"
    )
    game_data.client_version = "1.05c0d0667db2c845"

    payload = game_data.SerializeToString()
    return await aes_encrypt(payload, AES_KEY, AES_IV)

# ==================== DÉTECTION DE BAN (champ 13 de la réponse MajorLogin) ====================
def _read_varint(data, index):
    """Lit un varint à partir de `index` ; retourne (valeur, nouvel_index)."""
    shift = value = 0
    while index < len(data):
        b = data[index]
        index += 1
        value |= (b & 0x7F) << shift
        if not (b & 0x80):
            return value, index
        shift += 7
        if shift > 63:
            break
    return None, index


def _extract_ban_bytes(raw: bytes) -> Optional[bytes]:
    """Repère le tag du champ 13 (wire type 2 => 0x6A) et renvoie les octets du sous-message BanInfo."""
    if not raw:
        return None
    for i in range(len(raw)):
        if raw[i] != 0x6A:
            continue
        length, pos = _read_varint(raw, i + 1)
        if length is None or length <= 0 or length > 4096:
            continue
        end = pos + length
        if end > len(raw):
            continue
        return raw[pos:end]
    return None


def detect_ban(response_content: bytes) -> Optional[AccountBanned]:
    """Analyse la réponse MajorLogin d'un compte sans token : renvoie AccountBanned si un ban est trouvé, sinon None."""
    try:
        ban_bytes = _extract_ban_bytes(response_content)
        if not ban_bytes:
            return None
        info = ban_pb2.BanInfo()
        info.ParseFromString(ban_bytes)
        reason = info.reason or ""
        duration = int(info.duration_seconds or 0)
        timestamp = int(info.timestamp or 0)
        # Un BanInfo vide (tous champs à zéro) n'est pas un ban
        if not reason and duration == 0 and timestamp == 0:
            return None
        if duration > 0:
            d, h = duration // 86400, (duration % 86400) // 3600
            m = (duration % 3600) // 60
            parts = [f"{d}j" if d else "", f"{h}h" if (d or h) else "", f"{m}m"]
            remaining = " ".join(p for p in parts if p)
            label = f"banni temporairement ({remaining} restants)"
            return AccountBanned(label, permanent=False, duration_s=duration, reason=reason)
        return AccountBanned("banni définitivement", permanent=True, duration_s=0, reason=reason)
    except Exception:
        return None


async def send_majorlogin(data, release_version, server_url):
    try:
        url = f"{server_url}MajorLogin"
        req_headers = headers.copy()
        req_headers["ReleaseVersion"] = release_version
        response = await client.post(url, headers=req_headers, data=data)
        if response.status_code != 200:
            return None
        response_content = response.content
        if len(response_content) < 40:
            return None

        # 1. Direct parse
        res_proto = thunderFF_pb2.MajorLoginRes()
        try:
            res_proto.ParseFromString(response_content)
            if res_proto.region and res_proto.token:
                return res_proto
        except Exception:
            pass

        # 2. OB55 64-byte header offset check
        if len(response_content) > 64:
            try:
                res_proto = thunderFF_pb2.MajorLoginRes()
                res_proto.ParseFromString(response_content[64:])
                if res_proto.region and res_proto.token:
                    return res_proto
            except Exception:
                pass

        # 3. Dynamic offset search for OB55 compatibility
        for offset in range(min(128, len(response_content))):
            try:
                candidate = thunderFF_pb2.MajorLoginRes()
                candidate.ParseFromString(response_content[offset:])
                if candidate.region and candidate.token:
                    return candidate
            except Exception:
                pass

        # Aucune adresse avec token : le compte est peut-être banni. On analyse les octets bruts
        # (indépendant du parsing protobuf, qui peut échouer sur une réponse de ban) avant d'abandonner.
        ban = detect_ban(response_content)
        if ban is not None:
            raise ban

        res_proto = thunderFF_pb2.MajorLoginRes()
        try:
            res_proto.ParseFromString(response_content)
        except Exception:
            pass
        return res_proto
    except AccountBanned:
        raise
    except Exception:
        return None

async def send_getlogin(data, base_url, token, release_version):
    try:
        url = f"{base_url.rstrip('/')}/GetLoginData"
        req_headers = headers.copy()
        req_headers["ReleaseVersion"] = release_version
        req_headers['Authorization'] = f"Bearer {token}"
        req_headers['Host'] = "clientbp.ppmainecoonghj.com"
        response = await client.post(url, headers=req_headers, data=data)
        if response.status_code != 200:
            print_error(f"GetLoginData : HTTP {response.status_code}")    # login, ou relevé d'EXP
            return None
        response_content = response.content

        res_proto = thunderFF_pb2.GetLoginDataRes()
        parsed_successfully = False
        try:
            res_proto.ParseFromString(response_content)
            if res_proto.functional_addrs or res_proto.informational_addrs:
                parsed_successfully = True
        except Exception:
            pass

        if not parsed_successfully:
            for offset in range(min(128, len(response_content))):
                try:
                    candidate = thunderFF_pb2.GetLoginDataRes()
                    candidate.ParseFromString(response_content[offset:])
                    if candidate.functional_addrs or candidate.informational_addrs:
                        res_proto = candidate
                        break
                except Exception:
                    pass

        dict_res = {}
        try:
            parsed = Parser().parse(response_content.hex())
            dict_res = await parse_results(parsed)
        except Exception:
            pass

        return res_proto, dict_res
    except Exception as e:
        print_error(f"GetLoginData : {e!r}")
        return None

async def build_tcp_startup_packet(account_id, token, server_time, key, iv, region="BD", typ='OnLine'):
    uid_hex = f"{int(account_id):016x}"
    timestamp_hex = f"{int(server_time):08x}"
    encode_token = token.encode()
    encrypted_packet = (await aes_encrypt(encode_token, key, iv)).hex()
    encrypted_packet_length = f"{len(encrypted_packet) // 2:08x}"
    reg = str(region).upper() if region else "BD"
    if typ == 'OnLine':
        prefix = '7119' if reg == 'BD' else ('7114' if reg == 'IND' else '7115')
        return f"{prefix}{uid_hex}{timestamp_hex}00000000{encrypted_packet_length}{encrypted_packet}"
    else:  # ChaT / Informational
        prefix = '9219' if reg == 'BD' else ('9214' if reg == 'IND' else '9215')
        return f"{prefix}{uid_hex}{timestamp_hex}{encrypted_packet_length}{encrypted_packet}"

async def send_keep_alive(region="BD"):
    """Send 2-byte keep-alive pulse to maintain connection in OB55"""
    try:
        reg = str(region).upper() if region else "BD"
        ka_hex = "0219" if reg == "BD" else ("0214" if reg == "IND" else "0215")
        return bytes.fromhex(ka_hex)
    except Exception:
        return bytes.fromhex("0219")

# Paquets StartMatch déchiffrés, un par mode. Champs de « main » (2) : 1 = cartes proposées, 2 = mode,
# 7 = IDC1-3 (région réécrite), 12 = bloc client (12.8 = version, réécrite).
#   Lone Wolf     : mode 43, carte 11 (paquet d'origine).
#   Battle Royale : mode 1, carte 1 ; capture du client officiel 1.132.9 (05/10, compte SAC).
#                   Le champ 12.1 (128 caractères) est arrivé tronqué d'un caractère à la copie :
#                   un « 0 » a été réinséré en 16e position pour que le paquet soit décodable.
#   Clash Squad   : mode 15, carte 1 ; capture du client officiel 1.132.9 (05/10, compte SAC, en-tête 0313).
_START_MATCH_LONE_WOLF = bytes.fromhex("080112800a0a010b102b3a110a044944433110aa011a064555524f50453a100a044944433210311a064555524f504540014a0801090a0b1219202758016291090a8001303838463832424630324139363736373032303130313030303030303030303030303136303030313030313530303032323246393745454530463030303030303436373632353134303030303030303030303030303030303030303030303030303030303030303030303030303066663030303030303030636163666131366410241afb02735d5e571400024a775d45414d1a041b1c001f11010449715f4243481a001e1d071c1703004b1a4066785c524570735c51486775421b5c5a4c07504042685a63610816054e19025e75196001477c015165406370195f5547404e4550640103020f1304064863754268676c755f65576e40467e5f0a417a4701026d675d6e73670b1108495a4c6a0b78470b740065645e525a057258425f584a447d4e6759440c11044e7c596d7f4b625f7d04055a47505c4e1d6b5b4107447d7201057d7f0f14084e430457674f7e517d72015172415d027473577c4d615f79535256780911030f4d5e027a797f614165067806505d53777750475e75064257076500460817014e741e7e5078487e7a7c465e7669767153497064605a7376677773550d160148037e18675966787f4c42607a645f577e7b441b460776026b18685d0b110205490060020f70676175654674706671797f41067346677c4e06585e780f15074c57047b40517075415f6364027259674b5b0166407f7340600407770a22047a5d5c52300b3a0a167305067162727516134208312e3133302e3232480350015ae90403626253513635686e556f4e36416456324b796f566c636f477776484f624e56526c4d727073504b4f43654177616848494176795556497273743752737149734a7a786b3247525268377a2f637664626d504f6a73552f79626d38547a4c69586d2f474351696d494b53486833447955726f39515152756c34545350626d6d624b7949565937545671577059455372323646572f59624578507338514f706d317372785455736c30796a434144444d4f34616a654b615753366361496c554b4963797a494e396d52516f715277687939797257476d337a644345337a6a61436f492f5a585233656f65365a42647a64677654636b6b665733356e4d4c6a6a565072564b6433523172756174394e50514150724a5546627859696c4c5a3859707336654d5447666b6649793574666a526c314d4648706b51774c6373374439656378566c41636f374e664f6d2b30654756466c4434744478706771385533595973587645384842502f70666c767a737138316a32524f4d7857437556445442492f684735625462773166456e4249725162762b636144775147696f74554e316d4c4b77734379456f4766706746614251457645672b736a764c4c78704743334c304a5344532f74526169504354553344374e6249306547516651622f5a466f4c36455630775a324d6f583932414c572f5049752f56634663584e70596b356f7966326151416a536971486a2f363276354843644f525551303578754e6171795251625653704654303137655237675255636b4966366c6f447476342b514e4a4670766d74757077707774396a5a5974437a4b56743657726d6e36785837706658456251555434684f3758a201050803108703a201050804108103a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815")
#_START_MATCH_BR =  bytes.fromhex("080112ab0b0a010110013a0e0a044944433110b8171a035341433a0e0a044944433210b8171a035341433a0e0a044944433310b8171a0353414340014a0f01030407090a0b1216191a201d2729580162920a0a80013038424633334234384233394630423030323033313530313131313130303030303037303030303330303644303032323833394433383334304432453243463134363736323531343131303130343036333865383438646330653734386333663661613034643831303030303030666630363036303430326361636661313664109f021ab9037e585852130902480458510d010604530f54570f000a0d04020f0709050d030c020c045703540b571707084f7d5c4443491002180710100903480756767007596142627e7e65494e70625870770e770c627b0a7b790b1a02447b5965517e51794c76677f765256747e4b5f78585c5a5b5556634f0f1750565d4c1e677f1d7f42440745646a664407434c574e5a4c64134b7c4f47016b7b7e52466a1e420f0d1b03074a4f5956447e665b68776e445a41524b017b784c79765a6a507b575b0a13004e4001691c536266186a0176476c534053437d5c49137c1f594140790c17054c13744c527f421740555f7f566846414a5e5a03040e644002465f700e1b08486669797e1b436d621750596e7b424b7a7373185269017f434a07000b1a02004d7a5c5879067a456918560251026a746179640a0001550774625d5509150a4f701a0553636b03704012015e055c610559471f590a7413771f60000511004a5f4a7f50437d697903656f0c4169687202634c511b4543047f74710a130a0248477e0513505d457e5f7e465d6c674a43410607407c0743507c4f70091405445d4245507b5e5f5f76425a47591d6d745041577d614f1d0d62634405220478565d5d300c3a0913510104067c6b171c4207312e3133322e39480350015aad05036262535136796c7a32673030416456324b796f566c545259504a79415968455968394a7256346e537a32595835514f6776586c4f6141706d74334c6869546c38464b4a783731704a323361724a33585172507847694b4a737a4f446547456a36457443786c6f424e744a336f484d654673315479786b714169665048674b774a6267524f41765756593476362b39332b4c354e43306e31485133396975466a5a4a55516c665a624645736244577257564e765479354d37467377574a4c6a654d70736c4e6e6b397179454a4b426c2b4f70386370652b6f306e6c4468345a305554355177734f3741516479676837424130374739617046696b465a77686c5975704b6f6d745277796e7878394349446d76666135662f5939554847347a6c794b4933496b6358677a594b7534305153327857363561746a30616f36572f303674667475736e33366d7a586941675a7a58695a507a2f2f5439617333424739576e79696f35756c426545376842382b65673137514942596e416a76774c4d79525a62784a4e316f44386b727267703072376a6936666f6a62624d7a445754662f43595658714c5364687a334a4c4732686939386c3959754b512b31693147542b6372656650733874542f396e7a626b4e6d4776613757714b7a68326f52546e4a49614134534b696c6551676d574f6f584d66346c4c75324b6e646a77613467384d6168535171437a6273484d466759494d2f476b53496f4d6d3058727a743143432f56786c39754e51332f6a5752684445747a514c6e743037656632614f4849375073453675547444634c6f4f52546d65674b4972576771357779613170444d4e5534717479623562484b35466d7475687653535934694539475576666f42476c7877594e426e73346a6c38417a6263386b3051334f79382b6a655a6b466d5463684e4e6f4459354b642b6b3da201050803108a03a201050804108703a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815aa0115615f31353537383038373630303234303631333532")


_START_MATCH_BR = bytes.fromhex("080112c30b0a010110013a150a044944433410ffffffffffffffffff011a0255533a150a044944433110ffffffffffffffffff011a0255533a150a044944433210ffffffffffffffffff011a0255533a150a044944433310ffffffffffffffffff011a02555340014a0f01030407090a0b1216191a201d2729580162fe090a80013038303238303037343945344443413130323031303030303030303030303034303030353030303130303030303030303535453431423039304630303030303034363736323531343030303030303030303030303030303030303030303030303030303030303030303030303030666630303030303030306361636661313664102b1ab9037e585c5d130108490b50560d01020b53075e5600080d0d04060007010f0c0c04050c04530c54035d160800487d5c404c4918081908181709034c08567e7a06566945627e7a6a49467a635778700e77086d7b027178041205447b5d6a51765b78437e607f7656597476415e77505b5a5b5159634705165f5e5a4c1e63701d774845084d636a66400843445d4f554463134b78404709617a715a416a1e46000d13090645475e56447a695b607d6f4b5246524b0574784473775562577b575f05130844410e611b536262176a097c46635b4753437953491b761e564947790c130a4c1b7e4d5d7745174051507f5e62474e42595a030001644808475078091b084c696971741a4c656517505d617b4a417b7c7b1f5269057043420d01041205004d7e5358710c7b4a611f5602550d6a7c6b786b02070155037b62555f081a0248701a015c636309714f1a065e05586e05514d1e56027313771b6f000d1b0145574d7f504772697109646004466968760d63445b1a4a4b037f747505130208494876021350594a7e5774475264604a434509074876064c587b4f700d1b054c57434a587c5e5f5b7942524d58126573504153726147170c6d6b43052204775e5a5d300c3a0a140c75516d7f7b6b101c4207312e3133322e39480350015a99050362625351362f76717949386b416456324b796f566c66774e615a46484354753348684458446c4e636875315735664d4866343970453938373776355a37566771443041464c6563745473734c6f5a3767766a725441646a6435646e65426c7964656a657144427833364954645148434e5049646e7634322f37514557736e4c70714b68586c774476564c3278774b4f78435131374a51304678553659544838637563705144535456475359314443556e724f5a2b436d647677334c464f5953577068623133636d4d314a39746c37596a4b6f575a624871513438355538374d37696a65416348754155696f6e58714e39636e4d44454536414f71553133766b5a774d322b646f53344477385854656748594a61566141347a47467259574e5465783679564959735669325977427a74615a5563556e4e34756e4968714276616b6e324b6a727859415444395872564469582f57376c32563554333034786a756b46516b5958496e35656341426a545a335a2b393077557661464e2b5068486a507039524e41554e5349767a2b53466f6a714d61654a667836546e2f617350757a327539422f6e6d477350724e61726841524a3768614536436e356750446d424544704e72746b723867386f6e7a744335716f5a46307671776e473877346a576c6e337936795a6d43503573566637636f65565375585a6475387a2b696831686d6b323251515232613848716746647a48427477754d426d4c49674f6d524c55434656586d4d54382b4b4d6a775a676c71305678534c6e7273756359342f316c7351386253464f6f582f614864663245342f6f3157703769446b316f4778304869612b633378744c66494a31577445424e46425235363668444f665755767a37705147796244776e307a7467374134366e7045735a62673d3da201050803108a03a201050804108703a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815aa0115615f31353537383038373630303234303631333532")



_START_MATCH_CLASH_SQUAD = bytes.fromhex("080112aa0b0a0101100f3a160a044944433110ffffffffffffffffff011a035341433a160a044944433210ffffffffffffffffff011a035341433a160a044944433310ffffffffffffffffff011a0353414340014a0f01030407090a0b1216191a201d2729580162f9090a8001303830333830313734383833393733423032303130303030303030303030303030303036303030313030303530303030343043413338333430463030303030303436373632353134303030303030303030303030303030303030303030303030303030303030303030303030303066663030303030303030636163666131366410381ab9037e585852130902480458510d010604530f54570f000a0d04020f0709050d030c020c045703540b571707084f7d5c4443491002180710100903480756767007596142627e7e65494e70625870770e770c627b0a7b790b1a02447b5965517e51794c76677f765256747e4b5f78585c5a5b5556634f0f1750565d4c1e677f1d7f42440745646a664407434c574e5a4c64134b7c4f47016b7b7e52466a1e420f0d1b03074a4f5956447e665b68776e445a41524b017b784c79765a6a507b575b0a13004e4001691c536266186a0176476c534053437d5c49137c1f594140790c17054c13744c527f421740555f7f566846414a5e5a03040e644002465f700e1b08486669797e1b436d621750596e7b424b7a7373185269017f434a07000b1a02004d7a5c5879067a456918560251026a746179640a0001550774625d5509150a4f701a0553636b03704012015e055c610559471f590a7413771f60000511004a5f4a7f50437d697903656f0c4169687202634c511b4543047f74710a130a0248477e0513505d457e5f7e465d6c674a43410607407c0743507c4f70091405445d4245507b5e5f5f76425a47591d6d745041577d614f1d0d62634405220478565d5d300c3a0913510104067c6b171c4207312e3133322e39480350015a9505036262535136787635707a6762416456324b796f566c56417276654f45575642464756755a41366675544a766e7176303156744f744a5779564b6b78497a436a76685731705873416535465544395a7142634f735a353747306a64542f33536d4e39696843366979387338713974464b72542b6169473644584a4830676c44485564304437444a4336465671596646514753567770695831392b413869647a4e6538325631427032356442473871447a645754447a684a365576596f3272623145425a44506643676c68326748795773784b6a6e56366847426c56376943614f34707a423257736c4b327a4e65527a46454c6b3875704c515635365a7062774834356d6a52443654667431454c6c3738736872704753746a3348727965634a7165734d6547646b356f6c355045325a526863357750564b693267546769712f556936307a4b70514837722b63775456575a42396f7939396f79724f394a646c775a646464424554784b31394135376e396d78573834335059684539352f304c4b676d4e614d426c336c496b6461754b325546786f63464a34382b396d3966704c486b6f504e5977706162685135544161344c34427359576872366c41702f675379512f2f48434b5a6d682f70464d514b7131546a4e4b6942366d39397478627a7a766a594b574e535645694a504e34334879494561764175545a6350726d6c6a57304f462b576a3277394234356e6f45456e75684f39384e576949366a35386c356a46557a35443738764f54387a6733477a44305767396f6676386a76664252426c4f6653366a4e776b6d6a6649784b777432504f4b6e4e7744754f4f7a51775537417946476658694b3375666543494d43416f78707268583544363635573779444746486a426f7079726e64306d665164557863a201050803108a03a201050804108703a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815aa0115615f31353537383038373630303234303631333532")



_START_MATCH_PAYLOADS = {"lone_wolf": _START_MATCH_LONE_WOLF, "br": _START_MATCH_BR,
                         "clash_squad": _START_MATCH_CLASH_SQUAD}

# Paquets StartMatch stockés par serveur dans match_packets.json (un jeu par serveur, par mode), utilisés
# seulement si le fichier contient "enabled": true. Par défaut ce sont les gabarits ci-dessus
# (_START_MATCH_PAYLOADS), comme fast-old-ui : avec ceux du fichier, les matchs arrivaient en rafales
# et rapportaient moins d'EXP. Si le serveur du compte n'y figure pas, on prend ceux du serveur par
# défaut (BD) ; fichier absent ou illisible : gabarits intégrés. Cadrage, en-têtes et région inchangés.
MATCH_PACKETS_FILE = os.path.join(_ROOT_DIR, "match_packets.json")
_US_REGIONS = {"US", "BR", "SAC", "NA"}
_match_packets_memo: Optional[Dict[str, Any]] = None
_match_packets_mtime: float = -1.0


def _region_to_server(region) -> str:
    """Bucket serveur d'une région, aligné sur le choix d'URL du login (US = US/BR/SAC/NA)."""
    reg = str(region).upper() if region else "BD"
    if reg in _US_REGIONS:
        return "US"
    if reg == "IND":
        return "IND"
    return "BD"


def _load_match_packets() -> Optional[Dict[str, Any]]:
    """Charge match_packets.json en mémoire (relu seulement si le fichier change)."""
    global _match_packets_memo, _match_packets_mtime
    try:
        mtime = os.path.getmtime(MATCH_PACKETS_FILE)
    except OSError:
        _match_packets_memo = None
        return None
    if _match_packets_memo is not None and mtime == _match_packets_mtime:
        return _match_packets_memo
    try:
        with open(MATCH_PACKETS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict) or not isinstance(data.get("servers"), dict):
            return None
        _match_packets_memo = data
        _match_packets_mtime = mtime
        return data
    except Exception as e:
        print_error(f"match_packets.json illisible : {e}")
        return None


def _start_match_payload(region, mode: str) -> bytes:
    """Paquet StartMatch déchiffré pour (serveur du compte, mode) : gabarit intégré, sauf si match_packets.json
    est activé ("enabled": true), avec alors repli serveur par défaut puis gabarit intégré."""
    data = _load_match_packets()
    if data and data.get("enabled") is True:
        servers = data.get("servers", {})
        default = str(data.get("default_server", "BD"))
        for key in (_region_to_server(region), default):
            hx = (servers.get(key) or {}).get(mode)
            if hx:
                try:
                    return bytes.fromhex(hx)
                except ValueError:
                    pass
    return _START_MATCH_PAYLOADS[mode]


def _region_header(region):
    # En-tête par région, repris tel quel du script Battle Royale
    reg = str(region).upper() if region else "BD"
    return "031900" if reg == "BD" else ("031400" if reg == "IND" else "031500")


async def _send_start_match(mode, header, region, client_version, writer, key, iv):
    proto = thunderFF_pb2.StartMatch()
    proto.ParseFromString(_start_match_payload(region, mode))
    for entry in proto.main.region_list:
        entry.region = region
    if hasattr(proto.main, 'client_version'):
        proto.main.client_version.remote_version = client_version
    packet = proto.SerializeToString()
    encrypted_packet = (await aes_encrypt(packet, key, iv)).hex()
    packet_length = len(encrypted_packet) // 2
    hex_length = hex(packet_length)[2:]
    hex_length = hex_length if len(hex_length) > 1 else "0" + hex_length
    final_packet = header + "0" * (6 - len(hex_length)) + hex_length + encrypted_packet
    writer.write(bytes.fromhex(final_packet))
    await writer.drain()


async def start_game_lone_wolf(region, client_version, writer, key, iv):
    await _send_start_match("lone_wolf", "031400", region, client_version, writer, key, iv)

async def start_game_battle_royale(region, client_version, writer, key, iv):
    await _send_start_match("br", _region_header(region), region, client_version, writer, key, iv)

async def start_game_clash_squad(region, client_version, writer, key, iv):
    await _send_start_match("clash_squad", _region_header(region), region, client_version, writer, key, iv)

START_GAME_BY_MODE = {"lone_wolf": start_game_lone_wolf, "br": start_game_battle_royale,
                      "clash_squad": start_game_clash_squad}


async def has_ssan_zig(n):
    z = (n << 1) & 0xFFFFFFFFFFFFFFFF
    out = bytearray()
    while z >= 0x80:
        out.append((z & 0x7F) | 0x80)
        z >>= 7
    out.append(z)
    return bytes(out)

async def uleb_encode(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            break
    return bytes(out)

async def tea_enc(v0, v1, k0, k1, k2, k3):
    s = 0
    for _ in range(_ROUNDS):
        s = (s + _DELTA) & 0xFFFFFFFF
        v0 = (v0 + (((((v1 << 4) & 0xFFFFFFFF) + k0) & 0xFFFFFFFF ^
                      ((v1 + s) & 0xFFFFFFFF) ^
                      (((v1 >> 5) + k1) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        v1 = (v1 + (((((v0 << 4) & 0xFFFFFFFF) + k2) & 0xFFFFFFFF ^
                      ((v0 + s) & 0xFFFFFFFF) ^
                      (((v0 >> 5) + k3) & 0xFFFFFFFF)))) & 0xFFFFFFFF
    return v0, v1

async def tea_dec(v0, v1, k0, k1, k2, k3):
    s = (_DELTA * _ROUNDS) & 0xFFFFFFFF
    for _ in range(_ROUNDS):
        v1 = (v1 - (((((v0 << 4) & 0xFFFFFFFF) + k2) & 0xFFFFFFFF ^
                      ((v0 + s) & 0xFFFFFFFF) ^
                      (((v0 >> 5) + k3) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        v0 = (v0 - (((((v1 << 4) & 0xFFFFFFFF) + k0) & 0xFFFFFFFF ^
                      ((v1 + s) & 0xFFFFFFFF) ^
                      (((v1 >> 5) + k1) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        s = (s - _DELTA) & 0xFFFFFFFF
    return v0, v1

async def tea_cbc_encrypt(padded, key_bytes):
    k0, k1, k2, k3 = (struct.unpack_from("<I", key_bytes, o)[0] for o in (0, 4, 8, 12))
    out = bytearray(len(padded))
    prev_cipher = bytearray(8)
    prev_intermediate = bytearray(8)
    for i in range(0, len(padded), 8):
        xored = bytearray(8)
        for j in range(8):
            xored[j] = padded[i + j] ^ prev_cipher[j]
        e0, e1 = await tea_enc(
            struct.unpack_from("<I", xored, 0)[0],
            struct.unpack_from("<I", xored, 4)[0],
            k0, k1, k2, k3,
        )
        enc = bytearray(8)
        struct.pack_into("<I", enc, 0, e0)
        struct.pack_into("<I", enc, 4, e1)
        for j in range(8):
            out[i + j] = enc[j] ^ prev_intermediate[j]
        prev_cipher[:] = out[i:i + 8]
        prev_intermediate[:] = xored
    return bytes(out)

async def build_padded(content):
    pad_len = (8 - (len(content) + 10) % 8) % 8
    return bytes([pad_len, 0, 0]) + b"\x00" * pad_len + content + b"\x00" * 7

async def encode_header(layout, send_option, cmd, order_id, flags, length, k, v80):
    out = bytearray()
    for code in layout:
        value = {0: send_option, 1: cmd, 2: order_id, 3: flags, 4: length}[code]
        if _FIELD_SIZES[code] == 1:
            out.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            out.append(v & 0xFF)
            out.append((v >> 8) & 0xFF)
    return bytes(out)

async def crc7_buff(crc, buf):
    c = crc & 0x7F
    for b in buf:
        c = CRC7_TABLE[((2 * (c & 0xFF)) ^ (b & 0xFF)) & 0xFF] & 0x7F
    return c & 0x7F

async def sv_frame(msg_key, layout, send_option, cmd, order_id, flags, content, key, encrypted=True):
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = await tea_cbc_encrypt(await build_padded(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0]) + await encode_header(layout, send_option, cmd, order_id, flags, len(body), k, v80)
    packet = bytearray(hdr + body)
    packet[1] = await crc7_buff(0, bytes(packet[2:])) & 0x7F
    return bytes(packet)

async def build_match_startup_packets(token, udp_key, match_code, account_id, block_val,
                                      server_ip="", region="BD", client_version="1.132.6",
                                      client_version_code="2019121229", access_token="",
                                      mode_id=43, map_id=11):
    token = token.strip()
   
    udp_key = bytes.fromhex(udp_key)
    match_code = [int(ch) for ch in str(match_code).strip()]
    
    # OB55 splits JWT match token at 660 bytes
    thunder_jwt = token[:660] if len(token) > 660 else token
    sharma_jwt = token[660:] if len(token) > 660 else ""
    encoded_thunder_jwt = thunder_jwt.encode() if isinstance(thunder_jwt, str) else thunder_jwt
    encoded_sharma_jwt = sharma_jwt.encode() if isinstance(sharma_jwt, str) else sharma_jwt
    
    garena420 = await has_ssan_zig(len(encoded_thunder_jwt)) + encoded_thunder_jwt
    
    # OB55 Sharma payload structure matching Wireshark capture
    reg = str(region).upper() if region else "BD"
    csoversea_block = bytes.fromhex(
        "ca0163736f7665727365612e7374726f6e67686f6c642e66726565666972656d6f62696c652e636f6d"
        "3b302e302e302e303b33342e3132362e37362e34353b33342e38372e3137372e31343b33342e38372e"
        "3137302e3233303b33352e3138352e3138332e35370000000000000100000000000000000000000001"
        "00000800000100000000000100a8a2d7bebd8d8bdf110200"
    )
    
    mid = bytes.fromhex('0000000001000102030101') + await has_ssan_zig(len(reg)) + reg.encode()
    mid += bytes.fromhex('0001030003000004')
    mid += await has_ssan_zig(len(client_version)) + client_version.encode()
    mid += await has_ssan_zig(len(client_version_code)) + client_version_code.encode()
    mid += csoversea_block
    
    clean_ip = server_ip.split(':')[0] if server_ip else "0.0.0.0"
    mid += await has_ssan_zig(len(clean_ip)) + clean_ip.encode()
    
    clean_acc_tok = access_token.strip() if access_token else ""
    if clean_acc_tok:
        mid += await has_ssan_zig(len(clean_acc_tok)) + clean_acc_tok.encode()
        
    mid += await has_ssan_zig(len(encoded_sharma_jwt)) + encoded_sharma_jwt
    
    tg_garena420 = (
        await uleb_encode(int(account_id)) +
        await uleb_encode(int(block_val)) +
        await uleb_encode(1) +
        await uleb_encode(int(mode_id)) +
        await uleb_encode(int(block_val)) +
        await uleb_encode(int(map_id)) +
        mid
    )
    
    process = await sv_frame(0x5E, match_code, 2, 447, 0, 1, garena420, udp_key)
    loading = await sv_frame(0x5A, match_code, 2, 448, 1, 1, tg_garena420, udp_key)
    return process.hex(), loading.hex()

async def produce_xor_key(secret_key):
    k = secret_key[0] if secret_key and len(secret_key) > 0 else 10
    return k, ((k << 8) | k) & 0xFFFF

async def parse_layout(layout):
    if isinstance(layout, str):
        return [int(ch) for ch in layout.strip()]
    return list(layout)

async def tea_cbc_decrypt(body, key_bytes):
    k0, k1, k2, k3 = (struct.unpack_from("<I", key_bytes, o)[0] for o in (0, 4, 8, 12))
    out = bytearray(len(body))
    prev_intermediate = bytearray(8)
    prev_cipher = bytearray(8)
    xored = bytearray(8)
    dec = bytearray(8)
    for i in range(0, len(body), 8):
        for j in range(8):
            xored[j] = body[i + j] ^ prev_intermediate[j]
        d0, d1 = await tea_dec(
            struct.unpack_from("<I", xored, 0)[0],
            struct.unpack_from("<I", xored, 4)[0],
            k0, k1, k2, k3
        )
        struct.pack_into("<I", dec, 0, d0)
        struct.pack_into("<I", dec, 4, d1)
        for j in range(8):
            out[i + j] = dec[j] ^ prev_cipher[j]
        prev_cipher[:] = body[i:i + 8]
        prev_intermediate[:] = dec
    return bytes(out)

async def build_hello_packet(text, key, layout):
    data = text.encode("utf-8")
    if len(data) > 25:
        raise ValueError(f"Text is too long ({len(data)} bytes)")
    content = b"\x10\x00\x00\x00" + data + b"\x00" * (29 - 4 - len(data))
    k, v80 = await produce_xor_key(key)
    layout = await parse_layout(layout)
    padded = await build_padded(content)
    enc_body = await tea_cbc_encrypt(padded, key)
    header_bytes = await encode_header(layout, 1, 1, 0, 1, len(enc_body), k, v80)
    packet = bytearray([0x63, 0x00]) + header_bytes + enc_body
    packet[1] = await crc7_buff(0, packet[2:]) & 0x7F
    return bytes(packet).hex()

async def classify(frame):
    cmd = frame["cmd"]
    msg_name = MESSAGE_ID_TO_NAME.get(cmd, f"UNKNOWN_{cmd}")
    if msg_name == "UDP_HELLO":
        return "HELLO"
    if msg_name == "UDP_ACK":
        return "ACK"
    if msg_name == "UDP_PING":
        return "PING"
    if msg_name == "RUDP_JOIN_MATCH":
        return "JOIN_MATCH"
    if msg_name.startswith("RUDP_"):
        return msg_name
    if msg_name.startswith("UDP_"):
        return msg_name
    return "DATA"

async def build_packet(msg_key, layout, send_option, cmd, order_id, flags, content, key, encrypted=True):
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = await tea_cbc_encrypt(await build_padded(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0])
    for code in layout:
        value = {0: send_option, 1: cmd, 2: order_id, 3: flags, 4: len(body)}[code]
        if _FIELD_SIZES[code] == 1:
            hdr.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            hdr.append(v & 0xFF)
            hdr.append((v >> 8) & 0xFF)
    packet = bytearray(hdr + body)
    packet[1] = await crc7_buff(0, bytes(packet[2:])) & 0x7F
    return bytes(packet)

async def layouts_from_mask(mask):
    ru = [int(c) for c in str(mask).strip()]
    nr = [c for c in ru if c != 2]
    return ru, nr

async def reply_for(frame, key, mask, ack_key=0x68, ping_key=0x6D, hello_key=0x5B, ack_style="short"):
    ru, nr = await layouts_from_mask(mask)
    typ = await classify(frame)
    if typ == "HELLO":
        if ack_style == "echo":
            content = frame["content"] if frame["content"] else b"\x10\x00\x00\x00"
            return typ, await build_packet(hello_key, nr, 1, 1, None, 1, content, key)
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, b"\x01\x00", key)
    if typ == "ACK":
        content = frame["content"] if frame["content"] else b"\x01\x00"
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, content, key)
    if typ == "PING":
        c = frame["content"]
        counter = c[:4] if len(c) >= 4 else c
        return typ, await build_packet(ping_key, nr, 0, 3, None, 0, counter + b"\x00\x00\x00", key, encrypted=False)
    if typ == "JOIN_MATCH":
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, b"\x02\x00", key)
    return typ, None

async def keepalive_ping(sock, ip, port, key_bytes, mask, stop_event):
    nr = (await layouts_from_mask(mask))[1]
    ping_keys = [0x66, 0x6D, 0x69, 0x6C, 0x6B, 0x6E, 0x6F, 0x70]
    loop = asyncio.get_event_loop()
    i = 0
    while not stop_event.is_set():
        pk = ping_keys[i % len(ping_keys)]
        counter = int(time.time() * 1000) & 0xFFFFFFFF
        pkt = await build_packet(pk, nr, 0, 3, None, 0, struct.pack("<I", counter) + b"\x00\x00\x00", key_bytes, encrypted=False)
        try:
            await loop.sock_sendto(sock, pkt, (ip, port))
        except Exception:
            pass
        i += 1
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=3.0)
        except asyncio.TimeoutError:
            pass

async def try_header(buf, layout, k, v80):
    off = 2
    out = {}
    for code in layout:
        size = _FIELD_SIZES[code]
        if off + size > len(buf):
            return None
        out[_FIELD_NAMES[code]] = (buf[off] ^ k) if size == 1 else ((buf[off] | (buf[off + 1] << 8)) ^ v80) & 0xFFFF
        off += size
    out["headerLen"] = off
    return out

async def oicq_unpad(padded):
    if not padded or len(padded) < 8:
        return None
    if not all(padded[-1 - i] == 0 for i in range(7)):
        return None
    pad_len = padded[0] & 0x07
    s = 3 + pad_len
    e = len(padded) - 7
    return padded[s:e] if s < e else b""

async def decode_packet(packet, key, mask=None):
    data = bytes(packet) if isinstance(packet, bytes) else bytes.fromhex(packet)
    if len(data) < 8:
        return None
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    crc_ok = (data[1] & 0x7F) == await crc7_buff(0, data[2:])
    candidates = []
    if mask:
        ru, nr = await layouts_from_mask(mask)
        layouts = [("RUDP", ru), ("nonRUDP", nr)]
    else:
        layouts = [("RUDP", list(p)) for p in itertools.permutations([0, 1, 2, 3, 4])]
        layouts += [("nonRUDP", list(p)) for p in itertools.permutations([0, 1, 3, 4])]
    for kind, layout in layouts:
        f = await try_header(data, layout, k, v80)
        if not f:
            continue
        if f["flags"] > 7 or f["sendOption"] > 7:
            continue
        if f["length"] != len(data) - f["headerLen"]:
            continue
        body = data[f["headerLen"]:f["headerLen"] + f["length"]]
        content = None
        padded = None
        if f["flags"] & 1:
            if len(body) < 8 or len(body) % 8 != 0:
                continue
            padded = await tea_cbc_decrypt(body, key)
            content = await oicq_unpad(padded)
            if content is None:
                continue
        else:
            content = body
        score = (1 if crc_ok else 0) + (1 if content is not None else 0)
        candidates.append({
            "kind": kind, "layout": layout, "headerLen": f["headerLen"],
            "msgKey": data[0], "cmd": f["cmd"], "flags": f["flags"],
            "sendOption": f["sendOption"], "orderId": f.get("orderId"),
            "length": f["length"], "content": content, "crcOk": crc_ok,
            "padded": padded, "score": score, "total": len(data),
        })
    if not candidates:
        return None
    candidates.sort(key=lambda c: (c["kind"] == "RUDP" or c["kind"] == "nonRUDP", c["score"]), reverse=True)
    return candidates[0]

async def peek_cmds(packet, key, mask):
    """Commandes possibles d'un paquet d'après son seul en-tête (mêmes contrôles que decode_packet, corps non
    déchiffré). Si aucune n'est utile, decode_packet ne peut pas renvoyer de paquet utile : on évite le TEA en
    Python pur (1 à 4 ms par paquet d'état), qui sature la boucle quand plusieurs parties BR tournent en parallèle."""
    data = bytes(packet)
    if len(data) < 8:
        return []
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    cmds = []
    for layout in await layouts_from_mask(mask):
        f = await try_header(data, layout, k, v80)
        if not f or f["flags"] > 7 or f["sendOption"] > 7 or f["length"] != len(data) - f["headerLen"]:
            continue
        if f["flags"] & 1 and (f["length"] < 8 or f["length"] % 8 != 0):
            continue
        cmds.append(f["cmd"])
    return cmds

def _varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)

def _mentions_account(content, *account_ids) -> bool:
    """Le paquet désigne-t-il l'un de ces comptes ? (identifiant en texte, varint, zigzag ou entier 64 bits)"""
    if not content:
        return False
    for acc in account_ids:
        try:
            acc = int(acc)
        except (TypeError, ValueError):
            continue
        if acc <= 0:
            continue
        patterns = [str(acc).encode(), _varint(acc), _varint(acc << 1),
                    acc.to_bytes(8, "little"), acc.to_bytes(8, "big")]
        if acc < 1 << 32:
            patterns += [acc.to_bytes(4, "little"), acc.to_bytes(4, "big")]
        if any(p in content for p in patterns):
            return True
    return False


# ============================================================
# play_game — UDP MATCH (FIXED & DNS OPTIMIZED)
# ============================================================
async def play_game(server_ip_port, thunder, sharma, udp_key, match_code,
                    account_id, player_region, client_version, key, iv,
                    match_index: int, owner_uid=None, mode="lone_wolf"):
    match_start_time = time.time()
    ping_task = None
    sock = None
    ping_stop = asyncio.Event()
    # Compteurs indexés sur le compte propriétaire (celui qui a incrémenté _inc_match),
    # même si l'id renvoyé dans le paquet de match diffère.
    uid_str = str(owner_uid or account_id)
    completed_cleanly = False
    is_br = mode == "br"
    max_duration, idle_timeout, handshake_timeout = MATCH_TIMING.get(mode, MATCH_TIMING["lone_wolf"])

    try:
        ip, port = server_ip_port.split(":")
        port = int(port)
        resolved_ip = await resolve_host_cloudflare(ip)

        loop = asyncio.get_event_loop()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        optimize_udp_socket(sock)
        sock.setblocking(False)
        
        udp_key_bytes = bytes.fromhex(udp_key)
        hello_packet = await build_hello_packet(f"{account_id}_2585", udp_key_bytes, match_code)
        await loop.sock_sendto(sock, bytes.fromhex(hello_packet), (resolved_ip, port))

        ack_state = "waiting_for_hello_reply"
        thunder_sent = False
        sharma_sent = False
        join_match_received = False
        local_closed = False
        send_lock = asyncio.Lock()

        ping_task = asyncio.create_task(
            keepalive_ping(sock, resolved_ip, port, udp_key_bytes, match_code, ping_stop)
        )
        last_activity = time.time()
        MAX_IDLE_BEFORE_HELLO_RESEND = 7.0

        print_colored(
            f"🎮 [MATCH #{match_index}] [{MODE_TAGS.get(mode, mode)}] UDP started → {server_ip_port} (DNS: {resolved_ip})",
            Colors.MAGENTA
        )

        async def send_thunder_sharma_inline():
            nonlocal ack_state, thunder_sent, sharma_sent
            if thunder_sent:
                return
            async with send_lock:
                if thunder_sent:
                    return
                try:
                    await loop.sock_sendto(sock, bytes.fromhex(thunder), (resolved_ip, port))
                    thunder_sent = True
                    await asyncio.sleep(0.1)
                    prepare_ack = await build_packet(
                        0x68, (await layouts_from_mask(match_code))[1],
                        0, 2, None, 1, b"\x01\x00", udp_key_bytes
                    )
                    await loop.sock_sendto(sock, prepare_ack, (resolved_ip, port))
                    await asyncio.sleep(0.2)
                    await loop.sock_sendto(sock, bytes.fromhex(sharma), (resolved_ip, port))
                    sharma_sent = True
                    ack_state = "thunder_sharma_sent"
                    print_success(f"[MATCH #{match_index}] Thunder+Sharma sent!")
                except Exception as e:
                    print_error(f"[MATCH #{match_index}] send error: {e}")

        while not local_closed:
            if time.time() - match_start_time > max_duration:
                # BR : borne de sécurité au-delà d'une partie complète, comptée comme terminée (comme le script BR)
                completed_cleanly = is_br
                break
            try:
                response, server_addr = await asyncio.wait_for(
                    loop.sock_recvfrom(sock, 65535), timeout=1.5
                )
                if response:
                    last_activity = time.time()
                    frame = None
                    if any(c in _UDP_CONTROL_CMDS for c in await peek_cmds(response, udp_key_bytes, match_code)):
                        frame = await decode_packet(response, udp_key_bytes, match_code)
                    if frame:
                        ptype = await classify(frame)

                        if frame['cmd'] == RUDP_MATCH_END or (
                                frame['cmd'] == RUDP_DEAD
                                and (not is_br or _mentions_account(frame['content'], account_id, owner_uid))):
                            print_success(
                                f"[MATCH #{match_index}] Completed (cmd {frame['cmd']})"
                            )
                            completed_cleanly = True
                            local_closed = True
                            continue

                        if frame['cmd'] == 101:
                            try:
                                ack_pkt = await build_packet(
                                    0x68, (await layouts_from_mask(match_code))[1],
                                    0, 2, None, 1, b"\x01\x00", udp_key_bytes
                                )
                                await loop.sock_sendto(sock, ack_pkt, server_addr)
                            except Exception:
                                pass
                            continue

                        if ptype in ["ACK", "PING", "HELLO", "JOIN_MATCH"]:
                            if ptype == "HELLO" and ack_state == "waiting_for_hello_reply":
                                typ, reply = await reply_for(
                                    frame, udp_key_bytes, match_code, ack_style="short"
                                )
                                if reply:
                                    await loop.sock_sendto(sock, reply, server_addr)
                                ack_state = "ack_sent_waiting"
                            elif ptype == "ACK":
                                if ack_state == "waiting_for_hello_reply":
                                    typ, reply = await reply_for(frame, udp_key_bytes, match_code)
                                    if reply:
                                        await loop.sock_sendto(sock, reply, server_addr)
                                    ack_state = "ready_to_send_thunder"
                                elif ack_state == "ack_sent_waiting":
                                    ack_state = "ready_to_send_thunder"
                                else:
                                    typ, reply = await reply_for(frame, udp_key_bytes, match_code)
                                    if reply:
                                        await loop.sock_sendto(sock, reply, server_addr)
                            elif ptype == "PING":
                                typ, reply = await reply_for(frame, udp_key_bytes, match_code)
                                if reply:
                                    await loop.sock_sendto(sock, reply, server_addr)
                            elif ptype == "JOIN_MATCH" and not join_match_received:
                                typ, reply = await reply_for(frame, udp_key_bytes, match_code)
                                if reply:
                                    await loop.sock_sendto(sock, reply, server_addr)
                                    join_match_received = True
            except asyncio.TimeoutError:
                if ack_state == "ready_to_send_thunder" and not thunder_sent:
                    await send_thunder_sharma_inline()
                elif ack_state == "waiting_for_hello_reply":
                    if (time.time() - last_activity) > MAX_IDLE_BEFORE_HELLO_RESEND:
                        try:
                            pkt = await build_hello_packet(
                                f"{account_id}_2585", udp_key_bytes, match_code
                            )
                            await loop.sock_sendto(sock, bytes.fromhex(pkt), (resolved_ip, port))
                        except Exception:
                            pass
                        last_activity = time.time()
                    if (time.time() - match_start_time) > handshake_timeout:
                        print_warning(f"[MATCH #{match_index}] Handshake timeout")
                        break
                elif ack_state == "thunder_sharma_sent":
                    if (time.time() - last_activity) > idle_timeout:
                        print_success(f"[MATCH #{match_index}] Finished naturally")
                        completed_cleanly = True
                        break
                continue
            except BlockingIOError:
                await asyncio.sleep(0.05)
            except OSError:
                await asyncio.sleep(0.5)
                continue
            except Exception:
                await asyncio.sleep(0.5)
                continue

            if ack_state == "ready_to_send_thunder" and not thunder_sent:
                await send_thunder_sharma_inline()

        return f"match #{match_index} finished"
    except Exception as e:
        print_error(f"[MATCH #{match_index}] error: {e}")
        return f"match #{match_index} error"
    finally:
        try:
            bot_state.match_finished(uid_str, completed_cleanly, time.time() - match_start_time, mode)
        except Exception:
            pass
        ping_stop.set()
        if ping_task:
            ping_task.cancel()
            try:
                await ping_task
            except asyncio.CancelledError:
                pass
        if sock:
            try:
                sock.close()
            except Exception:
                pass
        remaining = await _dec_match(uid_str)
        total = await _get_total_match_count()
        print_info(
            f"[MATCH #{match_index}] Closed. "
            f"UID active: {remaining} | Total active: {total}"
        )
        try:
            bot_state.update_status(uid_str, "IN_MATCH" if remaining > 0 else "ONLINE", remaining)
        except Exception:
            pass


# ============================================================
# 🔥 functional_lone_wolf — TRUE Parallel + Smart Cache + DNS
#    Utilisé pour les trois modes (Lone Wolf, Battle Royale, Clash Squad)
# ============================================================
async def functional_lone_wolf(addrs, starter_packet, account_region, client_version,
                                key, iv, account_id="", account_data=None,
                                max_reconnects=10):
    reconnects = 0
    ip, port = addrs.split(":")
    play_matches: List[asyncio.Task] = []
    no_response_count = 0
    search_attempts = 0
    last_start_time = 0.0
    search_mode = "lone_wolf"   # mode de la dernière recherche envoyée (le match trouvé est joué dans ce mode)
    uid_str = str(account_id)

    consecutive_parse_failures = 0

    current_token = starter_packet
    current_key = key
    current_iv = iv
    current_account_data = account_data

    _gateway_uids.add(uid_str)
    try:
        while True:
            _searching.discard(uid_str)
            if not await _has_match_slot(uid_str):
                # MAX_TOTAL_MATCHES atteint : on attend hors ligne qu'un match se termine
                active = await _get_match_count(uid_str)
                bot_state.update_status(uid_str, "IN_MATCH" if active else "ONLINE", active)
                while not await _has_match_slot(uid_str):
                    await asyncio.sleep(1.0)

            writer = None
            try:
                if current_account_data:
                    fresh = None
                    if current_account_data.get('auth_type') == 'guest' and current_account_data.get('auth_uid'):
                        fresh = cache_get(str(current_account_data['auth_uid']))
                    elif current_account_data.get('auth_type') == 'token' and current_account_data.get('auth_token'):
                        fresh = cache_get(f"tok_{current_account_data['auth_token'][:20]}")

                    if fresh:
                        current_account_data = fresh
                        current_key = fresh['aes_ak']
                        current_iv = fresh['iv_i']
                        current_token = await build_tcp_startup_packet(
                            fresh['account_id'],
                            fresh['token'],
                            fresh['server_time'],
                            current_key,
                            current_iv,
                            region=fresh.get('region', account_region),
                            typ='OnLine'
                        )
                    else:
                        print_warning(f"[FUNCTIONAL] Cache miss for {uid_str} → re-login needed")
                        try:
                            if current_account_data.get('auth_uid'):
                                cache_invalidate(str(current_account_data['auth_uid']))
                            if current_account_data.get('auth_token'):
                                cache_invalidate(f"tok_{current_account_data['auth_token'][:20]}")
                        except Exception:
                            pass
                        raise ConnectionError("Cache expired, triggering fresh login")

                resolved_ip = await resolve_host_cloudflare(ip)
                reader, writer = await asyncio.open_connection(resolved_ip, int(port))
                
                raw_sock = writer.get_extra_info('socket')
                if raw_sock:
                    optimize_tcp_socket(raw_sock)
                
                writer.write(bytes.fromhex(current_token))
                await writer.drain()

                # Send initial keepalive pulse right after connecting in OB55
                try:
                    init_ka = await send_keep_alive(account_region)
                    if init_ka and writer and not writer.is_closing():
                        writer.write(init_ka)
                        await asyncio.wait_for(writer.drain(), timeout=3)
                except Exception:
                    pass

                print_success(f"[FUNCTIONAL] TCP Gateway Connected for UID: {uid_str} (DNS: {resolved_ip})")
                bot_state.gateway_connected(uid_str)
                reconnects = 0
                no_response_count = 0
                last_start_time = 0.0

                async def send_start_match():
                    nonlocal search_attempts, last_start_time, search_mode
                    _searching.add(uid_str)
                    search_attempts += 1
                    current_region = "BD"
                    # Mode du panel ; en Lone Wolf, un compte sous le niveau 3 joue en BR jusqu'à y arriver
                    search_mode = bot_state.game_mode(uid_str)
                    if search_mode not in START_GAME_BY_MODE:
                        search_mode = "lone_wolf"
                    tag = MODE_TAGS.get(search_mode, search_mode)
                    print_info(f"[{tag}] Sending StartMatch #{search_attempts} region: {current_region}")
                    try:
                        await asyncio.sleep(random.uniform(0.3, 0.6))
                        await START_GAME_BY_MODE[search_mode](
                            current_region, client_version, writer,
                            current_key, current_iv
                        )
                        print_success(f"[{tag}] StartMatch packet sent")
                        active = await _get_match_count(uid_str)
                        try:
                            bot_state.update_status(uid_str, "SEARCHING", active)
                        except Exception:
                            pass
                    except Exception as e:
                        print_error(f"start_game ({tag}) error: {e}")
                    last_start_time = asyncio.get_running_loop().time()

                if bot_state.can_start_match(uid_str, await _get_match_count(uid_str)) and await _has_match_slot(uid_str):
                    await send_start_match()

                while True:
                    play_matches[:] = [m for m in play_matches if not m.done()]

                    active_count = await _get_match_count(uid_str)
                    try:
                        bot_state.update_status(
                            uid_str,
                            "ONLINE" if active_count == 0 else "IN_MATCH",
                            active_count
                        )
                    except Exception:
                        pass

                    now = asyncio.get_running_loop().time()
                    if (now - last_start_time >= bot_state.tuning(uid_str, "start_interval_s", START_MATCH_INTERVAL)
                            and bot_state.can_start_match(uid_str, active_count)
                            and await _has_match_slot(uid_str)):
                        await send_start_match()

                    try:
                        data = await asyncio.wait_for(reader.read(8192), timeout=0.5)
                    except asyncio.TimeoutError:
                        no_response_count += 1
                        if no_response_count > 80:
                            print_warning(f"[FUNCTIONAL] Gateway silent ({uid_str}). Reconnecting...")
                            raise ConnectionError("Gateway idle timeout")
                        continue

                    if not data:
                        raise ConnectionError("Connection closed by server")

                    hex_data = data.hex()
                    packet_length = len(data)
                    no_response_count = 0

                    if hex_data.startswith("0300") and 10 < packet_length < 30:
                        print_info("Match starting, please wait...")
                        continue

                    if hex_data.startswith("0300") and packet_length >= 300:
                        print_colored("=" * 60, Colors.GREEN)
                        print_colored(f"MATCH FOUND! Loading...", Colors.GREEN)
                        print_colored("=" * 60, Colors.GREEN)

                        try:
                            res = json.loads(await decode_protobuf(hex_data[10:]))
                            token = None
                            udp_key = None
                            match_code = None
                            server_ip_port = None
                            match_account_id = None
                            block_val = None

                            if '42' in res and 'data' in res['42']:
                                match_code = res['42']['data']
                            if '5' in res and 'data' in res['5']:
                                res_field5 = res['5']['data']
                                server_ip_port = res_field5.get('2', {}).get('data')
                                udp_key = res_field5.get('3', {}).get('data')
                                token = res_field5.get('4', {}).get('data')
                                if '42' in res_field5:
                                    match_code = res_field5['42']['data']
                            if '1' in res and 'data' in res['1']:
                                match_account_id = res['1']['data']
                            if '5' in res and 'data' in res['5']:
                                block_val = res['5']['data'].get('1', {}).get('data')

                            effective_acc_id = match_account_id or account_id or "BD_BOT"

                            if token and udp_key and match_code and server_ip_port:
                                acc_tok = ""
                                if current_account_data:
                                    acc_tok = current_account_data.get('access_token', '') or ""
                                mode_id, map_id = MATCH_MODE_IDS.get(search_mode, MATCH_MODE_IDS["lone_wolf"])
                                if search_mode in SERVER_MAP_MODES:
                                    # BR / Clash Squad : mode et carte choisis par le serveur (5.7 / 5.8 du match trouvé)
                                    res_field5 = res.get('5', {}).get('data') or {}
                                    mode_id = _proto_int(res_field5.get('7', {}).get('data'), mode_id)
                                    map_id = _proto_int(res_field5.get('8', {}).get('data'), map_id)
                                thunder, sharma = await build_match_startup_packets(
                                    token, udp_key, match_code, effective_acc_id, block_val or 0,
                                    server_ip=server_ip_port,
                                    region=account_region,
                                    client_version=client_version,
                                    access_token=acc_tok,
                                    mode_id=mode_id,
                                    map_id=map_id
                                )

                                match_index = await _inc_match(uid_str)
                                _searching.discard(uid_str)
                                bot_state.match_started(uid_str, match_index, server_ip_port, search_mode)
                                total = await _get_total_match_count()
                                print_colored(
                                    f"🚀 [MATCH #{match_index}] UDP starting → {server_ip_port} (background)",
                                    Colors.CYAN
                                )
                                print_success(
                                    f"[FUNCTIONAL] UDP task started. "
                                    f"UID active: {match_index} | Total: {total}"
                                )

                                new_match = asyncio.create_task(
                                    play_game(
                                        server_ip_port,
                                        thunder,
                                        sharma,
                                        udp_key,
                                        match_code,
                                        effective_acc_id,
                                        "BD",
                                        client_version,
                                        current_key,
                                        current_iv,
                                        match_index=match_index,
                                        owner_uid=uid_str,
                                        mode=search_mode
                                    )
                                )
                                play_matches.append(new_match)
                                if search_mode in UNINTERRUPTIBLE_MODES:
                                    _keep_running(new_match)

                                consecutive_parse_failures = 0

                                # Tous les modes : le match continue en arrière-plan (UDP), sans attendre
                                # la fin de la partie -> passerelle relancée et nouvelle recherche aussitôt.
                                try:
                                    writer.close()
                                    await writer.wait_closed()
                                except Exception:
                                    pass

                                print_info(
                                    f"[OFFLINE] {NEW_MATCH_DELAY}s offline → "
                                    f"reload token → new StartMatch"
                                )
                                await asyncio.sleep(bot_state.tuning(uid_str, "relaunch_delay_s", NEW_MATCH_DELAY))
                                reconnects = 0
                                break 

                            else:
                                consecutive_parse_failures += 1
                                print_warning(
                                    f"[FUNCTIONAL] Non-match big packet "
                                    f"(#{consecutive_parse_failures}/{MAX_CONSECUTIVE_PARSE_FAILURES}) "
                                    f"→ reconnecting"
                                )

                                if consecutive_parse_failures >= MAX_CONSECUTIVE_PARSE_FAILURES:
                                    print_error(
                                        f"[FUNCTIONAL] {MAX_CONSECUTIVE_PARSE_FAILURES}x parse failures "
                                        f"→ invalidating cache for fresh login"
                                    )
                                    if current_account_data:
                                        try:
                                            if current_account_data.get('auth_uid'):
                                                cache_invalidate(str(current_account_data['auth_uid']))
                                            if current_account_data.get('auth_token'):
                                                cache_invalidate(f"tok_{current_account_data['auth_token'][:20]}")
                                        except Exception:
                                            pass
                                    consecutive_parse_failures = 0

                                try:
                                    writer.close()
                                    await writer.wait_closed()
                                except Exception:
                                    pass
                                await asyncio.sleep(NON_MATCH_RECONNECT_DELAY)
                                break

                        except Exception as e:
                            print_error(f"[FUNCTIONAL] Match packet error: {e}")
                            consecutive_parse_failures += 1
                            if consecutive_parse_failures >= MAX_CONSECUTIVE_PARSE_FAILURES:
                                if current_account_data:
                                    try:
                                        if current_account_data.get('auth_uid'):
                                            cache_invalidate(str(current_account_data['auth_uid']))
                                        if current_account_data.get('auth_token'):
                                            cache_invalidate(f"tok_{current_account_data['auth_token'][:20]}")
                                    except Exception:
                                        pass
                                consecutive_parse_failures = 0
                            try:
                                writer.close()
                                await writer.wait_closed()
                            except Exception:
                                pass
                            await asyncio.sleep(NON_MATCH_RECONNECT_DELAY)
                            break

                    if 30 <= packet_length <= 40:
                        continue

            except asyncio.CancelledError:
                await _stop_matches(play_matches)
                raise
            except Exception as e:
                print_error(f"[FUNCTIONAL] TCP state ({uid_str}): {e}")
                bot_state.gateway_error(uid_str, str(e))

                play_matches[:] = [m for m in play_matches if not m.done()]

                if writer:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass

                if "Cache expired" in str(e):
                    print_warning(f"[FUNCTIONAL] Triggering re-login for {uid_str}")
                    break

                reconnects += 1
                if reconnects > max_reconnects:
                    print_error("[FUNCTIONAL] Max reconnects reached, retrying...")
                    reconnects = 0
                    await asyncio.sleep(3)
                    continue

                await asyncio.sleep(min(reconnects, 2))

    except asyncio.CancelledError:
        await _stop_matches(play_matches)
        raise
    finally:
        _searching.discard(uid_str)
        _gateway_uids.discard(uid_str)


async def informational(addrs, starter_packet, key, iv, region="BD", max_reconnects=3):
    reconnects = 0
    ip, port = addrs.split(":")
    while True:
        writer = None
        ping_task = None
        try:
            resolved_ip = await resolve_host_cloudflare(ip)
            reader, writer = await asyncio.open_connection(resolved_ip, int(port))
            
            raw_sock = writer.get_extra_info('socket')
            if raw_sock:
                optimize_tcp_socket(raw_sock)
                
            writer.write(bytes.fromhex(starter_packet))
            await writer.drain()
            reconnects = 0

            # Initial keepalive right after connecting
            try:
                init_ka = await send_keep_alive(region)
                if init_ka and writer and not writer.is_closing():
                    writer.write(init_ka)
                    await asyncio.wait_for(writer.drain(), timeout=3)
            except Exception:
                pass

            async def info_keepalive():
                ka_bytes = await send_keep_alive(region)
                while True:
                    await asyncio.sleep(5)
                    try:
                        if writer and not writer.is_closing():
                            writer.write(ka_bytes)
                            await writer.drain()
                    except Exception:
                        break

            ping_task = asyncio.create_task(info_keepalive())

            while True:
                data = await reader.read(8192)
                if not data:
                    raise ConnectionError("Connection closed")
        except asyncio.CancelledError:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            raise
        except Exception:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            reconnects += 1
            if reconnects > max_reconnects:
                await asyncio.sleep(3)
                reconnects = 0
            else:
                await asyncio.sleep(1)


# ==================== ACCOUNT PROCESSORS ====================

def _register_credentials(account_data: Dict):
    try:
        acc_id = str(account_data['account_id'])
        bot_state.account_credentials[acc_id] = account_data
        if account_data.get('auth_uid'):
            bot_state.account_credentials[str(account_data['auth_uid'])] = account_data
        if account_data.get('auth_token'):
            bot_state.account_credentials[f"tok_{account_data['auth_token'][:20]}"] = account_data
    except Exception:
        pass


async def refresh_account_profile(account_data_or_uid: Any):
    try:
        if isinstance(account_data_or_uid, str):
            uid = str(account_data_or_uid)
            account_data = bot_state.account_credentials.get(uid)
        else:
            account_data = account_data_or_uid
            uid = str(account_data.get('account_id'))

        if not account_data:
            return

        url = account_data.get('server_url')
        token = account_data.get('token')
        release_version = account_data.get('release_version')
        payload = account_data.get('login_payload_data')

        if not (url and token and release_version and payload):
            return

        res = await send_getlogin(payload, url, token, release_version)
        if res:
            res_proto, dict_res = res
            level = int(get_proto_field(dict_res, 6, 1))
            exp = int(get_proto_field(dict_res, 7, 0))
            likes = int(get_proto_field(dict_res, 8, 0))
            nickname = res_proto.nickname or get_proto_field(dict_res, 4, "")

            acc_id = str(account_data['account_id'])
            bot_state.update_profile(acc_id, level=level, exp=exp, likes=likes, nickname=nickname)
            print_info(f"[EXP-REFRESH] UID {acc_id} -> Level: {level}, EXP: {exp}")
    except Exception as e:
        print_error(f"refresh_account_profile error: {e}")


async def process_account_uid_pass(uid: str, password: str) -> Optional[Dict]:
    cached = cache_get(uid)
    if cached:
        print_success(f"[CACHE HIT] UID {uid} loaded from token_cache.json (no login)")
        acc_id = str(cached['account_id'])
        bot_state.register_account(
            uid=acc_id,
            nickname=cached.get('nickname', f"Player_{acc_id}"),
            region=cached.get('region', 'BD'),
            level=cached.get('level', 1),
            exp=cached.get('exp', 0),
            likes=cached.get('likes', 0)
        )
        _register_credentials(cached)
        return cached

    print_info(f"[LOGIN] Full login for UID {uid}...")
    try:
        verconfig_res = await version_config()
        if verconfig_res is None:
            return None
        release_version, client_version, server_url = verconfig_res
        
        tokengrant_response = await get_access_token(uid, password)
        if tokengrant_response is None:
            return None
        open_id, access_token, platform = tokengrant_response
        
        # 🔥 1ta id 1ta Device Injection
        device_info = get_device_for_account(uid)
        
        login_payload_data = await build_majorlogin_payload(open_id, access_token, platform, client_version, device_info)
        majorlogin_response = await send_majorlogin(login_payload_data, release_version, server_url)
        if majorlogin_response is None:
            return None
        getlogin_result = await send_getlogin(login_payload_data, majorlogin_response.url, majorlogin_response.token, release_version)
        if getlogin_result is None:
            return None
        res_proto, dict_res = getlogin_result

        acc_id = str(majorlogin_response.account_id)
        level = int(get_proto_field(dict_res, 6, 1))
        exp = int(get_proto_field(dict_res, 7, 0))
        likes = int(get_proto_field(dict_res, 8, 0))
        nickname = res_proto.nickname or get_proto_field(dict_res, 4, f"Player_{acc_id}")
        region = majorlogin_response.region or get_proto_field(dict_res, 3, "BD")

        bot_state.register_account(uid=acc_id, nickname=nickname, region=region, level=level, exp=exp, likes=likes)

        account_data = {
            'account_id': majorlogin_response.account_id,
            'nickname': nickname,
            'region': region,
            'level': level,
            'exp': exp,
            'likes': likes,
            'open_id': open_id,
            'access_token': access_token,
            'platform': str(platform),
            'token': majorlogin_response.token,
            'server_time': majorlogin_response.server_time,
            'aes_ak': majorlogin_response.aes_ak,
            'iv_i': majorlogin_response.iv_i,
            'functional_addrs': res_proto.functional_addrs or get_proto_field(dict_res, 14),
            'informational_addrs': res_proto.informational_addrs or get_proto_field(dict_res, 32),
            'release_version': release_version,
            'client_version': client_version,
            'server_url': majorlogin_response.url,
            'login_payload_data': login_payload_data,
            'auth_type': 'guest',
            'auth_uid': uid,
            'auth_password': password
        }
        _register_credentials(account_data)
        cache_set(uid, account_data)
        return account_data
    except AccountBanned:
        raise
    except Exception as e:
        print_error(f"process_account_uid_pass error: {e}")
        return None


async def process_account_token(access_token: str) -> Optional[Dict]:
    cache_key = f"tok_{access_token[:20]}"
    cached = cache_get(cache_key)
    if cached:
        print_success(f"[CACHE HIT] Token {access_token[:10]}... loaded from cache")
        acc_id = str(cached['account_id'])
        bot_state.register_account(
            uid=acc_id,
            nickname=cached.get('nickname', f"Player_{acc_id}"),
            region=cached.get('region', 'BD'),
            level=cached.get('level', 1),
            exp=cached.get('exp', 0),
            likes=cached.get('likes', 0)
        )
        _register_credentials(cached)
        return cached

    print_info("[LOGIN] Full login with Access Token...")
    try:
        verconfig_res = await version_config()
        if verconfig_res is None:
            return None
        release_version, client_version, server_url = verconfig_res

        import requests
        url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
        hdrs = {
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "close",
            "Content-Type": "application/x-www-form-urlencoded",
            "Host": "100067.connect.garena.com",
            "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)"
        }
        resp = await asyncio.to_thread(requests.get, url, headers=hdrs, timeout=10)
        data = resp.json()

        if 'error' in data:
            return None

        open_id = data.get('open_id')
        platform = data.get('platform', 4)

        if not open_id:
            return None

        # 🔥 1ta id 1ta Device Injection (using unique open_id as the key)
        device_info = get_device_for_account(open_id)

        login_payload_data = await build_majorlogin_payload(open_id, access_token, str(platform), client_version, device_info)
        if not login_payload_data:
            return None

        majorlogin_response = await send_majorlogin(login_payload_data, release_version, server_url)
        if majorlogin_response is None:
            return None

        getlogin_result = await send_getlogin(
            login_payload_data,
            majorlogin_response.url,
            majorlogin_response.token,
            release_version
        )
        if getlogin_result is None:
            return None

        res_proto, dict_res = getlogin_result
        acc_id = str(majorlogin_response.account_id)
        level = int(get_proto_field(dict_res, 6, 1))
        exp = int(get_proto_field(dict_res, 7, 0))
        likes = int(get_proto_field(dict_res, 8, 0))
        nickname = res_proto.nickname or get_proto_field(dict_res, 4, f"Player_{acc_id}")
        region = majorlogin_response.region or get_proto_field(dict_res, 3, "BD")

        bot_state.register_account(uid=acc_id, nickname=nickname, region=region, level=level, exp=exp, likes=likes)

        account_data = {
            'account_id': majorlogin_response.account_id,
            'nickname': nickname,
            'region': region,
            'level': level,
            'exp': exp,
            'likes': likes,
            'open_id': open_id,
            'access_token': access_token,
            'token': majorlogin_response.token,
            'server_time': majorlogin_response.server_time,
            'aes_ak': majorlogin_response.aes_ak,
            'iv_i': majorlogin_response.iv_i,
            'functional_addrs': res_proto.functional_addrs or get_proto_field(dict_res, 14),
            'informational_addrs': res_proto.informational_addrs or get_proto_field(dict_res, 32),
            'release_version': release_version,
            'client_version': client_version,
            'server_url': majorlogin_response.url,
            'login_payload_data': login_payload_data,
            'platform': platform,
            'auth_type': 'token',
            'auth_token': access_token
        }
        _register_credentials(account_data)
        cache_set(cache_key, account_data)
        return account_data
    except AccountBanned:
        raise
    except Exception as e:
        print_error(f"process_account_token error: {e}")
        return None


async def run_account_worker(account_data: Dict, label: str):
    acc_id = str(account_data['account_id'])
    informational_task = None
    exp_task = None
    try:
        reg = account_data.get('region', 'BD')
        tcp_packet_online = await build_tcp_startup_packet(
            account_data['account_id'],
            account_data['token'],
            account_data['server_time'],
            account_data['aes_ak'],
            account_data['iv_i'],
            region=reg,
            typ='OnLine'
        )

        tcp_packet_chat = await build_tcp_startup_packet(
            account_data['account_id'],
            account_data['token'],
            account_data['server_time'],
            account_data['aes_ak'],
            account_data['iv_i'],
            region=reg,
            typ='ChaT'
        )

        informational_task = asyncio.create_task(
            informational(
                account_data['informational_addrs'],
                tcp_packet_chat,
                account_data['aes_ak'],
                account_data['iv_i'],
                region=reg
            )
        )

        async def exp_refresher():
            while True:
                await asyncio.sleep(bot_state.tuning(acc_id, "exp_refresh_s", 90))
                fresh = bot_state.account_credentials.get(acc_id)
                if fresh:
                    await refresh_account_profile(fresh)

        exp_task = asyncio.create_task(exp_refresher())

        functional_task = asyncio.create_task(
            functional_lone_wolf(
                account_data['functional_addrs'],
                tcp_packet_online,
                account_data['region'],
                account_data['client_version'],
                account_data['aes_ak'],
                account_data['iv_i'],
                account_id=acc_id,
                account_data=account_data
            )
        )

        await functional_task

    except asyncio.CancelledError:
        raise
    except Exception as e:
        print_error(f"run_account_worker error for {label}: {e}")
    finally:
        for t in (informational_task, exp_task):
            if t and not t.done():
                t.cancel()
        for t in (informational_task, exp_task):
            if t:
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass

