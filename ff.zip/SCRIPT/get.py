# -*- coding: utf-8 -*-
"""
Décode un message protobuf 'Lokesh' (schéma app.proto) depuis une chaîne hexadécimale,
sans avoir besoin d'importer output_pb2.
"""

import re
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
from google.protobuf.json_format import MessageToDict


# ---------------------------------------------------------------------------
# 1) Descripteur sérialisé (contenu de output.proto)
# ---------------------------------------------------------------------------
_SERIALIZED_FILE_DESCRIPTOR = (
    b'\n\x0coutput.proto\x12\tapp.proto"\xfc\x03\n\x06Lokesh'
    b'\x12\x12\n\naccount_id\x18\x01 \x01(\x03'
    b'\x12\x0e\n\x06region\x18\x02 \x01(\t'
    b'\x12\r\n\x05place\x18\x03 \x01(\t'
    b'\x12\x10\n\x08location\x18\x04 \x01(\t'
    b'\x12\x0e\n\x06status\x18\x05 \x01(\t'
    b'\x12\r\n\x05token\x18\x08 \x01(\t'
    b'\x12\n\n\x02id\x18\t \x01(\x05'
    b'\x12\x0b\n\x03\x61pi\x18\n \x03(\x0c'
    b'\x12\x0e\n\x06number\x18\x0c \x01(\x05'
    b'\x12#\n\x08\x61imguard\x18\x0f \x01(\x0b\x32\x11.app.proto.Lokesh'
    b'\x12\x0c\n\x04\x61rea\x18\x10 \x01(\t'
    b'\x12\x11\n\tmain_area\x18\x12 \x01(\t'
    b'\x12\x0c\n\x04\x63ity\x18\x13 \x01(\t'
    b'\x12\x0c\n\x04name\x18\x14 \x01(\t'
    b'\x12\x11\n\ttimestamp\x18\x15 \x01(\x03'
    b'\x12\x0e\n\x06\x62inary\x18\x16 \x01(\x0c'
    b'\x12\x13\n\x0b\x62inary_data\x18\x17 \x01(\x0c'
    b'\x12\x0f\n\x07\x66ield24\x18\x18 \x01(\t'
    b'\x12*\n\x07\x66ield25\x18\x19 \x01(\x0b\x32\x19.app.proto.Lokesh.Field25'
    b'\x12\x0f\n\x07\x66ield27\x18\x1b \x01(\x0c'
    b'\x1a"\n\x12\x44\x65\x63rypted_Payloads\x12\x0c\n\x04type\x18\x01 \x01(\x05'
    b'\x1aY\n\x07\x46ield25'
    b'\x12\x0e\n\x06\x66ield1\x18\x01 \x01(\x0c'
    b'\x12\x0e\n\x06\x66ield2\x18\x02 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield5\x18\x05 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield6\x18\x06 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield7\x18\x07 \x01(\x05'
    b'\x62\x06proto3'
)


# ---------------------------------------------------------------------------
# 2) Construction dynamique de la classe Lokesh
# ---------------------------------------------------------------------------
_pool = descriptor_pool.DescriptorPool()

_file_proto = descriptor_pb2.FileDescriptorProto()
_file_proto.ParseFromString(_SERIALIZED_FILE_DESCRIPTOR)
_pool.Add(_file_proto)

Lokesh = message_factory.GetMessageClass(
    _pool.FindMessageTypeByName("app.proto.Lokesh")
)


# ---------------------------------------------------------------------------
# 3) Fonctions utilitaires
# ---------------------------------------------------------------------------
def _bytes_to_hex_recursive(value):
    """Convertit récursivement les bytes en hexadécimal pour l'affichage."""
    if isinstance(value, bytes):
        return value.hex()
    if isinstance(value, dict):
        return {k: _bytes_to_hex_recursive(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_bytes_to_hex_recursive(v) for v in value]
    return value


def extraire_lokesh_depuis_hex(hex_content: str) -> dict:
    """
    Prend une chaîne hexadécimale, trouve le message Lokesh qu'elle contient
    (en testant tous les offsets possibles) et retourne un dictionnaire
    avec toutes les données connues.
    """
    hex_clean = "".join(hex_content.split())
    data = bytes.fromhex(hex_clean)

    derniere_erreur = None

    for offset in range(len(data)):
        try:
            msg = Lokesh()
            msg.ParseFromString(data[offset:])

            # Critère de validité : au moins un champ "signature" non vide
            if msg.token or msg.account_id or msg.region:
                # Compatibilité protobuf 4.25+ / plus ancien
                try:
                    result = MessageToDict(
                        msg,
                        preserving_proto_field_name=True,
                        always_print_fields_with_no_presence=True,
                    )
                except TypeError:
                    result = MessageToDict(
                        msg,
                        preserving_proto_field_name=True,
                        including_default_value_fields=True,
                    )

                result = _bytes_to_hex_recursive(result)

                # Ajout des champs inconnus (non déclarés dans le schéma)
                inconnus = {}
                for field in msg.UnknownFields():
                    inconnus[field.field_number] = list(field.data)
                if inconnus:
                    result["_unknown_fields"] = inconnus

                return result
        except Exception as e:
            derniere_erreur = e
            continue

    raise ValueError(
        f"Aucun message Lokesh valide trouvé. Dernière erreur : {derniere_erreur}"
    )


def recuperer_jwt_token(hex_content: str) -> str:
    """
    Récupère uniquement le JWT token contenu dans le champ 'token' du message Lokesh.
    """
    data = extraire_lokesh_depuis_hex(hex_content)
    token = data.get("token")
    if not token:
        raise ValueError("Le champ 'token' est vide ou absent.")
    return token


_JWT_RE = re.compile(rb'eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*')


def extraire_jwt_direct(hex_content: str) -> str:
    """
    Fallback : extrait le JWT directement depuis les bytes, sans protobuf.
    """
    data = bytes.fromhex("".join(hex_content.split()))
    match = _JWT_RE.search(data)
    if not match:
        raise ValueError("Aucun JWT trouvé.")
    return match.group(0).decode("ascii")


# ---------------------------------------------------------------------------
# 4) Exemples d'utilisation
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import google.protobuf
    print("Version protobuf :", google.protobuf.__version__)

    hex_exemples = {
        "Exemple 1": (
            "4ecc0861a14f48f82cb0185a25caddeef55042b4f840c6f2866880befb93be01d0c98a6cb9dd9d524368d37ffcf231f015f4abe7269ca1dd60fe740beca6ac0708e1eae9da431a025347220252452a046c6976653a024d453a0255533a0353414342af0665794a68624763694f694a49557a49314e694973496e4e326369493649694973496e523563434936496b705856434a392e65794a6859324e766457353058326c6b496a6f784f4445334e5459314d7a49784e797769626d6c6a61323568625755694f694a6d65554a30575535314e544a765347707153324a5761485658546a424d524755724f55553949697769626d3930615639795a576470623234694f694a5452794973496d787659327466636d566e61573975496a6f69496977695a5868305a584a7561577866615751694f69497a597a4d335a6a45774d5463325a544a6d5a4451324d7a59344d6d49794f4749785a574a6a4d4455314d434973496d563464475679626d467358335235634755694f6a5173496e427359585266615751694f6a4573496d4e7361575675644639325a584e7a61573975496a6f694d5334784d7a49754d794973496d4e7361575675644639325a584e7a6157397558324e765a4755694f6949794d4445354d5449774e7a6332496977695a5731306247463062334a6663324e76636d55694f6a45774d43776961584e665a57313062474630623349694f6e527964575573496d4e7664573530636e6c665932396b5a534936496c4a46496977695a5868305a584a756157786664576c6b496a6f334f4445324e444d794f4455354c434a795a57646659585a6864474679496a6f784d4449774d4441774d446373496e4e7664584a6a5a5349364d4377696247396a613139795a5764706232356664476c745a5349364d437769593278705a57353058335235634755694f6a4973496e4e705a323568644856795a5639745a4455694f6949334e444934596a49314d32526c5a6d4d784e6a51774d54686a4e6a41305954466c596d4a6d5a574a6b5a694973496e567a6157356e58335a6c636e4e70623234694f6a4573496e4a6c624756686332566659326868626d356c62434936496d46755a484a766157646b4c434a795a57786c59584e6c58335a6c636e4e70623234694f694a50516a5531496977695a586877496a6f784e7a67354e7a45774d44597966512e5a445f6b77304a4264634f523151396a62456448396a73506c3333715573336d4734616d314a5f4e7844514880e10160647a0208019a010b5361696e742d44656e6973a801eebcb1d506b20110105df8237cf7f77f020a001840205201ba011021658b2d7ce6f67f2002005041204000da012058426276585846434a7832664f45566e657a4a4969577764696b6655376d6953"
        ),
        "Exemple 2": (
            "ecfca28ecc566bbfbc7c82dcff6d14652c0696fa4fbc9837ca1ea7fa1f123cfc2b162c1e83f901f8f1c27bfacc9166160c3fad6a8b8467159718bce615192f0c08daa0aedb4312035341431a03534143220241522a046c69766542c20665794a68624763694f694a49557a49314e694973496e4e3263694936496a49694c434a30655841694f694a4b5631516966512e65794a6859324e766457353058326c6b496a6f784f4445334e6a63334e44497a4e437769626d6c6a61323568625755694f694a6d65554a30575535314e54413253464972644746464e57517a596e4d3056305631546c453949697769626d3930615639795a576470623234694f694a5451554d694c434a7362324e7258334a6c5a326c7662694936496c4e4251794973496d563464475679626d467358326c6b496a6f69596a6b34596a4d3259324d314d6d4d794e7a51794d574d315a475a6d4e444e6d595452695a546b33595455694c434a6c6548526c636d3568624639306558426c496a6f304c434a776247463058326c6b496a6f784c434a6a62476c6c626e5266646d567963326c7662694936496a45754d544d794c6a4d694c434a6a62476c6c626e5266646d567963326c76626c396a6232526c496a6f694d6a41784f5445794d4463334e694973496d5674645778686447397958334e6a62334a6c496a6f784d444173496d6c7a583256746457786864473979496a7030636e566c4c434a6a6233567564484a3558324e765a4755694f694a4255694973496d563464475679626d4673583356705a4349364e7a67784e7a59324e5445784d437769636d566e5832463259585268636949364d5441794d4441774d4441334c434a7a62335679593255694f6a4173496d787659327466636d566e6157397558335270625755694f6a45334f446b324f44497a4e444173496d4e7361575675644639306558426c496a6f794c434a7a6157647559585231636d566662575131496a6f694e7a51794f4749794e544e6b5a575a6a4d5459304d444534597a59774e4745785a574a695a6d56695a4759694c434a3163326c755a3139325a584a7a61573975496a6f784c434a795a57786c59584e6c58324e6f595735755a5777694f694a68626d527962326c6b49697769636d56735a57467a5a5639325a584a7a61573975496a6f69543049314e534973496d5634634349364d5463344f5463784d5445304f58302e327478346d33673474625166503153612d526e553239774b46567566726d745778417151555964446b41734880e101522468747470733a2f2f636c69656e742e75732e66726565666972656d6f62696c652e636f6d60647a02080182015d63736f7665727365612e7374726f6e67686f6c642e66726565666972656d6f62696c652e636f6d3b33342e3132362e37362e34353b33342e38372e3137372e31343b33342e38372e3137302e3233303b33352e3138352e3138332e35379a010c4275656e6f73204169726573a2010142a801adc5b1d506b20110df31c8fd5cdffb7f020224084a000101ba0110ee09bbf37cfcfa7a2103240051400100c2015d63736f7665727365612e7374726f6e67686f6c642e66726565666972656d6f62696c652e636f6d3b33342e3132362e37362e34353b33342e38372e3137372e31343b33342e38372e3137302e3233303b33352e3138352e3138332e3537ca010d0a035341431001280130013801da012058426276585846434a7832664f45566e657a4a4969577764696b6655376d6953"
        ),
    }

    for nom, hex_str in hex_exemples.items():
        print("=" * 70)
        print(nom)
        print("=" * 70)

        # Fallback direct (toujours fiable)
        try:
            jwt_direct = extraire_jwt_direct(hex_str)
            print("JWT (direct) :", jwt_direct)
        except Exception as e:
            print("JWT direct échoué :", e)

        # Parsing protobuf complet
        try:
            donnees = extraire_lokesh_depuis_hex(hex_str)
            print("\n--- Toutes les données ---")
            for k, v in donnees.items():
                print(f"{k} : {v}")
        except Exception as e:
            print("Parsing protobuf échoué :", e)

        print()