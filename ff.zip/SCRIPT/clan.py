
import json
import time
import requests
from pathlib import Path

# Configuration
API_URL = "https://controle.thug4ff.xyz/joinclan"
CLAN_ID = "2067771439"

INPUT_FILE = Path("F3_SAC.json")
RESULT_FILE = Path("join_clan_results.json")

DELAY = 1  # Pause entre les comptes, en secondes


def main():
    if not INPUT_FILE.exists():
        print(f"[ERROR] Fichier introuvable : {INPUT_FILE}")
        return

    try:
        with INPUT_FILE.open("r", encoding="utf-8") as f:
            accounts = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        print(f"[ERROR] Lecture du JSON impossible : {e}")
        return

    if not isinstance(accounts, list):
        print("[ERROR] Le JSON doit contenir une liste de comptes.")
        return

    results = []

    total = len(accounts)
    success = 0
    failed = 0

    print(f"Comptes charges : {total}")
    print(f"Clan ID : {CLAN_ID}")
    print("-" * 45)

    with requests.Session() as session:
        for index, account in enumerate(accounts, start=1):
            uid = str(account.get("uid", "unknown"))
            token = account.get("access_token")

            result = {
                "uid": uid,
                "nickname": account.get("nickname"),
                "status": "failed",
                "message": ""
            }

            if not token:
                result["message"] = "access_token manquant"
                failed += 1
                results.append(result)
                print(f"[{index}/{total}] {uid} : token manquant")
                continue

            try:
                # Le endpoint fourni utilise des paramètres URL.
                # Vérifie que cette méthode correspond bien à son API.
                response = session.get(
                    API_URL,
                    params={
                        "clan_id": CLAN_ID,
                        "access_token": token
                    },
                    timeout=20
                )

                # Ne considère pas un HTTP 200 comme une réussite
                # sans vérifier la réponse métier de l'API.
                try:
                    data = response.json()
                except ValueError:
                    data = {}

                result["http_status"] = response.status_code

                # À adapter au format réel de réponse de l'API.
                result["message"] = (
                    data.get("message")
                    or data.get("msg")
                    or f"HTTP {response.status_code}"
                )

                print(
                    f"[{index}/{total}] {uid} : "
                    f"HTTP {response.status_code} - "
                    f"{result['message']}"
                )

                # Succès provisoire uniquement si le serveur renvoie
                # un HTTP 2xx ; confirme aussi le résultat métier.
                if response.ok:
                    result["status"] = "check_response"
                else:
                    result["status"] = "failed"
                    failed += 1

            except requests.RequestException as e:
                result["message"] = str(e)
                failed += 1
                print(f"[{index}/{total}] {uid} : erreur réseau")

            results.append(result)
            time.sleep(DELAY)

    with RESULT_FILE.open("w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=4)

    print("-" * 45)
    print(f"Termine : {total} comptes traites")
    print(f"Erreurs HTTP/reseau : {failed}")
    print(f"Resultats : {RESULT_FILE.resolve()}")
    print("Attention : les réponses HTTP 2xx ne prouvent pas")
    print("que tous les comptes ont rejoint le clan.")


if __name__ == "__main__":
    main()
