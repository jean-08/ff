import asyncio
import aiohttp
import json
import time
import os

# Active le support des couleurs ANSI sur Windows 10+
os.system("")

# =========================
# CONFIG
# =========================
API_BASE = "http://raw.thug4ff.xyz/checkk"
API_KEY = "notfreenow"
TIMEOUT = 50
CONCURRENT_TASKS = 5
RETRY_ATTEMPTS = 5
RETRY_DELAY = 1  # secondes

# =========================
# COULEURS ANSI
# =========================
GREEN  = "\033[92m"   # vert   -> working (banned_temp = false)
YELLOW = "\033[93m"   # jaune  -> ban temporaire (banned_temp = true)
RED    = "\033[91m"   # rouge  -> ban permanent
RESET  = "\033[0m"

working_accounts = []
failed_accounts = []
seen_uids = set()
total_processed = 0
total_accounts = 0
permanent_banned_count = 0
temporary_banned_count = 0

# =========================
# SAFE LEVEL
# =========================
def safe_level(value):
    try:
        lvl = int(value)
        if 0 < lvl <= 100:
            return lvl
    except:
        pass
    return None

# =========================
# APPEL API
# =========================
async def fetch_account_data(session, uid):
    """
    Appelle l'API checkk pour un uid donné.
    Retourne un dict avec les données ou None en cas d'échec.
    """
    url = f"{API_BASE}?uid={uid}&key={API_KEY}"
    try:
        async with session.get(url, timeout=TIMEOUT) as resp:
            if resp.status != 200:
                return None
            try:
                data = await resp.json()
            except:
                text = await resp.text()
                print(f"[⚠️] JSON invalide pour UID {uid} -> {text[:120]}")
                return None

            # Vérifier le statut de la réponse
            if data.get("status") != 200 or data.get("msg") != "id_found":
                return {"error": data.get("msg", "id_not_found")}

            return data.get("data", {})
    except asyncio.TimeoutError:
        return None
    except Exception as e:
        # print(f"[⚠️] Erreur réseau pour UID {uid} : {e}")
        return None

# =========================
# WORKER
# =========================
async def worker(queue, session):
    global working_accounts, failed_accounts, total_processed
    global permanent_banned_count, temporary_banned_count

    while True:
        acc = await queue.get()
        uid = str(acc.get("account_id", "")).strip()
        password = str(acc.get("password", "")).strip()

        if not uid or uid in seen_uids:
            queue.task_done()
            continue

        seen_uids.add(uid)

        api_data = None
        for attempt in range(RETRY_ATTEMPTS):
            result = await fetch_account_data(session, uid)
            if result is not None and "error" not in result:
                api_data = result
                break
            if attempt < RETRY_ATTEMPTS - 1:
                print(f"[{total_processed+1}/{total_accounts}] [🔄] RETRY {attempt+1}/{RETRY_ATTEMPTS} -> {uid}")
                await asyncio.sleep(RETRY_DELAY)

        if api_data:
            # Mettre à jour le compte avec les données de l'API
            acc_copy = acc.copy()
            acc_copy["level"] = api_data.get("level", acc.get("level"))
            acc_copy["nickname"] = api_data.get("nickname", acc.get("nickname"))

            # Gestion du ban
            ban_info_api = api_data.get("ban_info", {})
            status_text = api_data.get("status_text", "")

            if status_text != "not_banned":
                if ban_info_api.get("is_permanent"):
                    # ===== BAN PERMANENT (ROUGE) =====
                    permanent_banned_count += 1
                    acc_copy["banned_temp"] = False
                    acc_copy["ban_info"] = {
                        "reason": "Permanent ban",
                        "ban_date": "N/A",
                        "ban_type": "ban_permanent"
                    }
                    acc_copy["remaining_time"] = None
                    working_accounts.append(acc_copy)
                    print(f"{RED}[{total_processed+1}/{total_accounts}] [⛔] PERM -> UID {uid} "
                          f"| lvl {acc_copy['level']} | nick: {acc_copy['nickname']}{RESET}")
                else:
                    # ===== BAN TEMPORAIRE (JAUNE) =====
                    temporary_banned_count += 1
                    acc_copy["banned_temp"] = True
                    remaining_sec = ban_info_api.get("remaining_seconds", 0)
                    days = remaining_sec // 86400
                    hours = (remaining_sec % 86400) // 3600
                    mins = (remaining_sec % 3600) // 60
                    secs = remaining_sec % 60
                    remaining_str = f"{days}d {hours}h {mins}m {secs}s"
                    acc_copy["ban_info"] = {
                        "reason": "Temporary ban",
                        "ban_date": "N/A",
                        "ban_type": "ban_temporary"
                    }
                    acc_copy["remaining_time"] = remaining_str
                    working_accounts.append(acc_copy)
                    print(f"{YELLOW}[{total_processed+1}/{total_accounts}] [🟡] TEMP -> UID {uid} "
                          f"| lvl {acc_copy['level']} | nick: {acc_copy['nickname']} "
                          f"| time: {remaining_str}{RESET}")
            else:
                # ===== WORKING (VERT) =====
                acc_copy["banned_temp"] = False
                acc_copy["ban_info"] = None
                acc_copy["remaining_time"] = None
                working_accounts.append(acc_copy)
                print(f"{GREEN}[{total_processed+1}/{total_accounts}] [✅] UID {uid} "
                      f"-> lvl {acc_copy['level']} | nick: {acc_copy['nickname']}{RESET}")
        else:
            failed_accounts.append({
                "uid": uid,
                "password": password,
                "reason": f"Échec après {RETRY_ATTEMPTS} tentatives"
            })
            print(f"{RED}[{total_processed+1}/{total_accounts}] [❌] FAIL -> {uid}{RESET}")

        total_processed += 1
        queue.task_done()

# =========================
# SAUVEGARDE
# =========================
def save_results(output_file, base_name):
    global working_accounts

    # Charger les données existantes si le fichier existe
    try:
        with open(output_file, "r", encoding="utf-8") as f:
            existing_data = json.load(f)
            if not isinstance(existing_data, list):
                existing_data = []
    except:
        existing_data = []

    existing_dict = {}
    for acc in existing_data:
        if isinstance(acc, dict) and acc.get("uid"):
            existing_dict[str(acc["uid"])] = acc

    added = 0
    for acc in working_accounts:
        uid = str(acc["uid"])
        if uid not in existing_dict:
            added += 1
        existing_dict[uid] = acc

    final_data = list(existing_dict.values())

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(final_data, f, indent=4, ensure_ascii=False)

    print(f"\n💾 Sauvegardé -> {output_file}")
    print(f"➕ Ajoutés -> {added}")
    print(f"📦 Total -> {len(final_data)}")

    return final_data

def save_failed(base_name, failed_list):
    if not failed_list:
        print("✅ Aucun échec à enregistrer.")
        return

    fail_file = f"failed_{base_name}.json"
    try:
        with open(fail_file, "w", encoding="utf-8") as f:
            json.dump(failed_list, f, indent=4, ensure_ascii=False)
        print(f"💾 Échecs sauvegardés -> {fail_file} ({len(failed_list)} comptes)")
    except Exception as e:
        print(f"⚠️ Erreur sauvegarde échecs : {e}")

# =========================
# STATS
# =========================
def print_stats(final_data):
    global permanent_banned_count, temporary_banned_count

    level_stats = {}
    level_temp_counts = {}  # pour compter les bannis temporaires par niveau
    temp_banned_in_final = 0

    for acc in final_data:
        lvl = safe_level(acc.get("level")) or 0
        level_stats[lvl] = level_stats.get(lvl, 0) + 1
        if acc.get("banned_temp"):
            temp_banned_in_final += 1
            level_temp_counts[lvl] = level_temp_counts.get(lvl, 0) + 1

    print(f"\n{RED}⛔ Bannis permanents : {permanent_banned_count}{RESET}")
    print(f"{YELLOW}⏳ Bannis temporaires : {temporary_banned_count}{RESET}")
    print(f"{GREEN}✅ Comptes normaux : {len(final_data) - temp_banned_in_final}{RESET}")
    print("\n📊 Stats par niveau :")
    for lvl in sorted(level_stats.keys(), reverse=True):
        total = level_stats[lvl]
        temp = level_temp_counts.get(lvl, 0)
        print(f"  Level {lvl} → {total}   comptes ( Ban Temp : {temp})")

# =========================
# SÉLECTION FICHIER
# =========================
def select_json_file():
    files = [f for f in os.listdir('.') if f.endswith('.json') and os.path.isfile(f)]
    if not files:
        print("❌ Aucun fichier .json trouvé dans le dossier courant.")
        file_name = input("Entrez le chemin complet du fichier : ").strip()
        if not file_name:
            print("Aucun fichier fourni. Fin.")
            return None
        return file_name

    print("\n📂 Fichiers JSON disponibles :")
    for i, f in enumerate(files, 1):
        print(f"  {i}. {f}")
    while True:
        try:
            choix = input("Choisissez le numéro du fichier : ").strip()
            idx = int(choix) - 1
            if 0 <= idx < len(files):
                return files[idx]
            else:
                print("Numéro invalide.")
        except ValueError:
            print("Veuillez entrer un nombre.")

# =========================
# MAIN
# =========================
async def main():
    global total_accounts

    file_name = select_json_file()
    if not file_name:
        return

    base_name = file_name.rsplit(".", 1)[0] if "." in file_name else file_name

    if not os.path.exists(file_name):
        print(f"❌ Fichier {file_name} introuvable.")
        return

    try:
        with open(file_name, "r", encoding="utf-8", errors="ignore") as f:
            accounts = json.load(f)
            if not isinstance(accounts, list):
                print("❌ Le JSON doit contenir une liste.")
                return
    except Exception as e:
        print(f"❌ Erreur de lecture JSON : {e}")
        return

    queue = asyncio.Queue()
    for acc in accounts:
        await queue.put(acc)

    total_accounts = queue.qsize()
    print(f"📦 {total_accounts} comptes chargés.\n")

    timeout = aiohttp.ClientTimeout(total=TIMEOUT)
    connector = aiohttp.TCPConnector(limit=CONCURRENT_TASKS, ssl=False)

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        tasks = [
            asyncio.create_task(worker(queue, session))
            for _ in range(CONCURRENT_TASKS)
        ]

        await queue.join()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    output_file = file_name.replace(".json", "_updated.json")
    final_data = save_results(output_file, base_name)
    save_failed(base_name, failed_accounts)

    print(f"\n✅ Comptes mis à jour : {len(working_accounts)}")
    print(f"❌ Échecs : {len(failed_accounts)}")
    print(f"📦 Total traité : {total_processed}/{total_accounts}")

    # Statistiques par niveau
    print_stats(final_data)

# =========================
# RUN
# =========================
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Arrêté par l'utilisateur.")