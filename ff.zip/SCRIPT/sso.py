#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║    ███████╗ ██████╗  ██████╗ ██████╗ ███████╗██╗  ██╗       ║
║    ██╔════╝██╔════╝ ██╔═══██╗██╔══██╗██╔════╝╚██╗██╔╝       ║
║    ███████╗██║  ███╗██║   ██║██║  ██║█████╗   ╚███╔╝        ║
║    ╚════██║██║   ██║██║   ██║██║  ██║██╔══╝   ██╔██╗        ║
║    ███████║╚██████╔╝╚██████╔╝██████╔╝███████╗██╔╝ ██╗       ║
║    ╚══════╝ ╚═════╝  ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝       ║
║                                                               ║
║              🚀 SGCODEX TOOL v2.0 🚀                         ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"""

import requests
import os
import sys
import time
import random
import json
from datetime import datetime

# ============ COLORS ============
class Colors:
    # Main colors
    BLACK = '\033[0;30m'
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[0;33m'
    BLUE = '\033[0;34m'
    PURPLE = '\033[0;35m'
    CYAN = '\033[0;36m'
    WHITE = '\033[0;37m'
    
    # Bold colors
    BOLD_BLACK = '\033[1;30m'
    BOLD_RED = '\033[1;31m'
    BOLD_GREEN = '\033[1;32m'
    BOLD_YELLOW = '\033[1;33m'
    BOLD_BLUE = '\033[1;34m'
    BOLD_PURPLE = '\033[1;35m'
    BOLD_CYAN = '\033[1;36m'
    BOLD_WHITE = '\033[1;37m'
    BOLD_GOLD = '\033[1;33m'  # Ajout de BOLD_GOLD (jaune en gras)
    
    # Background colors
    BG_BLACK = '\033[40m'
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_YELLOW = '\033[43m'
    BG_BLUE = '\033[44m'
    BG_PURPLE = '\033[45m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'
    
    # Effects
    DIM = '\033[2m'
    ITALIC = '\033[3m'
    UNDERLINE = '\033[4m'
    BLINK = '\033[5m'
    REVERSE = '\033[7m'
    HIDDEN = '\033[8m'
    RESET = '\033[0m'

    # Custom theme colors
    PRIMARY = '\033[38;5;51m'
    SECONDARY = '\033[38;5;93m'
    ACCENT = '\033[38;5;196m'
    GOLD = '\033[38;5;220m'
    SILVER = '\033[38;5;248m'
    DARK = '\033[38;5;235m'
    TEAL = '\033[38;5;30m'
    LIME = '\033[38;5;118m'
    CORAL = '\033[38;5;203m'
    
    # Ajout des versions bold pour les couleurs personnalisées
    BOLD_PRIMARY = '\033[1;38;5;51m'
    BOLD_SECONDARY = '\033[1;38;5;93m'
    BOLD_GOLD = '\033[1;38;5;220m'

# ============ ANIMATIONS ============
class Animations:
    @staticmethod
    def typing_effect(text, delay=0.05):
        """Typing animation effect"""
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)
        print()

    @staticmethod
    def matrix_rain(lines=10):
        """Matrix-style rain effect"""
        chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()"
        for _ in range(lines):
            line = ""
            for _ in range(50):
                if random.random() > 0.7:
                    line += Colors.GREEN + random.choice(chars) + Colors.RESET
                else:
                    line += " "
            print(line)
            time.sleep(0.05)

    @staticmethod
    def spinner_animation(duration=2, text="Loading"):
        """Spinner animation"""
        spinner = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        end_time = time.time() + duration
        i = 0
        while time.time() < end_time:
            sys.stdout.write(f'\r{Colors.PRIMARY}{spinner[i % len(spinner)]}{Colors.RESET} {Colors.WHITE}{text}{Colors.RESET}')
            sys.stdout.flush()
            time.sleep(0.1)
            i += 1
        print(f'\r{Colors.GREEN}✓{Colors.RESET} {Colors.WHITE}Done!{Colors.RESET}')

    @staticmethod
    def pulse_animation(text, duration=3):
        """Pulse/breathing animation"""
        colors = [Colors.PRIMARY, Colors.SECONDARY, Colors.ACCENT, Colors.GOLD]
        end_time = time.time() + duration
        while time.time() < end_time:
            for color in colors:
                sys.stdout.write(f'\r{color}{text}{Colors.RESET}')
                sys.stdout.flush()
                time.sleep(0.2)

    @staticmethod
    def progress_bar_animated(duration=3, text="Processing"):
        """Animated progress bar with glow effect"""
        bar_length = 40
        symbols = ['█', '▓', '▒', '░']
        colors = [Colors.GREEN, Colors.CYAN, Colors.PURPLE, Colors.GOLD]
        
        for i in range(bar_length + 1):
            progress = int((i / bar_length) * 100)
            filled = i
            empty = bar_length - i
            
            bar = ""
            for j in range(bar_length):
                if j < filled:
                    color = colors[j % len(colors)]
                    bar += f"{color}{symbols[j % len(symbols)]}{Colors.RESET}"
                else:
                    bar += f"{Colors.DIM}░{Colors.RESET}"
            
            sys.stdout.write(f'\r{Colors.BOLD_WHITE}[{Colors.RESET}{bar}{Colors.BOLD_WHITE}]{Colors.RESET} {Colors.BOLD_YELLOW}{progress}%{Colors.RESET} {Colors.DIM}{text}{Colors.RESET}')
            sys.stdout.flush()
            time.sleep(duration / bar_length)
        print()

    @staticmethod
    def wave_effect(text, duration=2):
        """Wave animation effect"""
        wave_chars = ['~', '≈', '≋', '~']
        end_time = time.time() + duration
        while time.time() < end_time:
            for char in wave_chars:
                sys.stdout.write(f'\r{Colors.PRIMARY}{char}{Colors.RESET} {Colors.WHITE}{text}{Colors.RESET}')
                sys.stdout.flush()
                time.sleep(0.15)

    @staticmethod
    def fire_effect(duration=3):
        """Fire/flame animation"""
        fire_chars = ['🔥', '⚡', '✨', '🌟', '💫']
        end_time = time.time() + duration
        while time.time() < end_time:
            for char in fire_chars:
                sys.stdout.write(f'\r{Colors.BOLD_RED}{char}{Colors.RESET} {Colors.GOLD}SGCODEX{Colors.RESET} {Colors.BOLD_RED}{char}{Colors.RESET}')
                sys.stdout.flush()
                time.sleep(0.2)

# ============ SGCODEX BANNER ============
def show_sgcodex_banner():
    """Display SGCODEX banner with animations"""
    banner = f"""
{Colors.BOLD_BLUE}╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║    {Colors.BOLD_RED}███████╗ ██████╗  ██████╗ ██████╗ ███████╗██╗  ██╗{Colors.RESET}       ║
║    {Colors.BOLD_RED}██╔════╝██╔════╝ ██╔═══██╗██╔══██╗██╔════╝╚██╗██╔╝{Colors.RESET}       ║
║    {Colors.BOLD_RED}███████╗██║  ███╗██║   ██║██║  ██║█████╗   ╚███╔╝ {Colors.RESET}        ║
║    {Colors.BOLD_RED}╚════██║██║   ██║██║   ██║██║  ██║██╔══╝   ██╔██╗ {Colors.RESET}        ║
║    {Colors.BOLD_RED}███████║╚██████╔╝╚██████╔╝██████╔╝███████╗██╔╝ ██╗{Colors.RESET}       ║
║    {Colors.BOLD_RED}╚══════╝ ╚═════╝  ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝{Colors.RESET}       ║
║                                                               ║
║              {Colors.BOLD_GOLD}🚀 SGCODEX TOOL v2.0 🚀{Colors.RESET}                         ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝{Colors.RESET}
    """
    print(banner)

# ============ API URL ============
API_URL = "https://frux-sso-api-v45n.vercel.app/api/send-register-code"

# ============ SEND REGISTER CODE ============
def send_register_code(email):
    try:
        print(f"\n{Colors.BOLD_SECONDARY}╔════════════════════════════════════════════════════╗{Colors.RESET}")
        print(f"{Colors.BOLD_SECONDARY}║{Colors.RESET} {Colors.BOLD_GOLD}📤 SENDING REGISTER CODE{Colors.RESET}                         {Colors.BOLD_SECONDARY}║{Colors.RESET}")
        print(f"{Colors.BOLD_SECONDARY}╚════════════════════════════════════════════════════╝{Colors.RESET}")
        
        print(f"\n{Colors.BOLD_PRIMARY}📧 Email:{Colors.RESET} {Colors.BOLD_WHITE}{email}{Colors.RESET}")
        
        # Show animated progress
        Animations.progress_bar_animated(2, "Generating credentials")
        
        headers = {
            "User-Agent": "SGCODEX-BOT/2.0",
            "Content-Type": "application/json",
            "X-Client": "SGCODEX-TOOL"
        }
        
        response = requests.post(API_URL, json={"email": email}, headers=headers, timeout=30)
        data = response.json()
        
        if data.get('success'):
            print(f"\n{Colors.BOLD_GREEN}╔════════════════════════════════════════════════════╗{Colors.RESET}")
            print(f"{Colors.BOLD_GREEN}║{Colors.RESET} {Colors.BOLD_GREEN}✅ CODE SENT SUCCESSFULLY!{Colors.RESET}                      {Colors.BOLD_GREEN}║{Colors.RESET}")
            print(f"{Colors.BOLD_GREEN}╚════════════════════════════════════════════════════╝{Colors.RESET}")
            
            # Success animation
            Animations.fire_effect(2)
            
            print(f"\n{Colors.BOLD_GOLD}📊 DETAILS:{Colors.RESET}")
            print(f"{Colors.DIM}──────────────────────────────────────────{Colors.RESET}")
            print(f"{Colors.BOLD_PRIMARY}📧 Email{Colors.RESET}      : {Colors.WHITE}{data.get('email')}{Colors.RESET}")
            print(f"{Colors.BOLD_GOLD}👤 Username{Colors.RESET}   : {Colors.WHITE}{data.get('username')}{Colors.RESET}")
            print(f"{Colors.BOLD_SECONDARY}📊 Status{Colors.RESET}     : {Colors.GREEN}{data.get('status_code')}{Colors.RESET}")
            print(f"{Colors.BOLD_RED}📝 Response{Colors.RESET}  : {Colors.WHITE}{data.get('response')}{Colors.RESET}")
            print(f"{Colors.DIM}──────────────────────────────────────────{Colors.RESET}")
            
            # Celebration animation
            Animations.wave_effect("🎉 Success! 🎉", 1.5)
            
        else:
            print(f"\n{Colors.BOLD_RED}╔════════════════════════════════════════════════════╗{Colors.RESET}")
            print(f"{Colors.BOLD_RED}║{Colors.RESET} {Colors.BOLD_RED}❌ OPERATION FAILED!{Colors.RESET}                            {Colors.BOLD_RED}║{Colors.RESET}")
            print(f"{Colors.BOLD_RED}╚════════════════════════════════════════════════════╝{Colors.RESET}")
            print(f"\n{Colors.RED}Error: {data.get('error', 'Unknown error')}{Colors.RESET}")
            if data.get('status_code'):
                print(f"{Colors.GOLD}Status Code: {data.get('status_code')}{Colors.RESET}")
            
    except requests.exceptions.Timeout:
        print(f"\n{Colors.BOLD_RED}❌ Timeout! Server not responding.{Colors.RESET}")
    except requests.exceptions.ConnectionError:
        print(f"\n{Colors.BOLD_RED}❌ Connection Error! Check your internet.{Colors.RESET}")
    except Exception as e:
        print(f"\n{Colors.BOLD_RED}❌ Error: {e}{Colors.RESET}")

# ============ MAIN FUNCTION ============
def main():
    os.system('clear' if os.name == 'posix' else 'cls')
    
    # Show banner with animation
    show_sgcodex_banner()
    
    # Matrix intro animation
    print(f"\n{Colors.GREEN}Initializing SGCODEX...{Colors.RESET}")
    Animations.matrix_rain(5)
    
    # Check internet with animated spinner
    print(f"\n{Colors.BOLD_PRIMARY}[✓]{Colors.RESET} {Colors.PRIMARY}Checking connection...{Colors.RESET}")
    Animations.spinner_animation(2, "Connecting to server")
    
    try:
        requests.get("https://www.google.com", timeout=5)
        print(f"\r{Colors.BOLD_GREEN}[✓]{Colors.RESET} {Colors.GREEN}Internet connected!{Colors.RESET}     ")
        Animations.pulse_animation("🌐 Connection Established", 1)
    except:
        print(f"\r{Colors.BOLD_RED}[✗]{Colors.RESET} {Colors.RED}No internet connection!{Colors.RESET}")
        sys.exit(1)
    
    # Get email with enhanced UI
    print(f"\n{Colors.DIM}{'═'*50}{Colors.RESET}")
    Animations.typing_effect(f"{Colors.BOLD_GOLD}📧 EMAIL INPUT{Colors.RESET}", 0.02)
    print(f"{Colors.DIM}{'═'*50}{Colors.RESET}")
    
    Animations.pulse_animation("📝 Enter your email address", 1)
    email = input(f"\n{Colors.BOLD_PRIMARY}[?]{Colors.RESET} {Colors.WHITE}Email:{Colors.RESET} ").strip()
    
    if not email or "@" not in email:
        print(f"\n{Colors.BOLD_RED}[!] Invalid email!{Colors.RESET}")
        sys.exit(1)
    
    # Confirm with styled prompt
    print(f"\n{Colors.DIM}{'─'*50}{Colors.RESET}")
    Animations.typing_effect(f"{Colors.BOLD_GOLD}📌 CONFIRMATION{Colors.RESET}", 0.02)
    print(f"{Colors.DIM}{'─'*50}{Colors.RESET}")
    
    print(f"{Colors.BOLD_SECONDARY}📧 Target:{Colors.RESET} {Colors.BOLD_WHITE}{email}{Colors.RESET}")
    Animations.wave_effect("Ready to send code", 1)
    
    confirm = input(f"\n{Colors.BOLD_PRIMARY}[?]{Colors.RESET} Send code (y/n): ").strip().lower()
    
    if confirm != 'y':
        print(f"\n{Colors.BOLD_GOLD}[!] Cancelled!{Colors.RESET}")
        Animations.spinner_animation(1, "Exiting")
        sys.exit(0)
    
    # Send code with enhanced UI
    print(f"\n{Colors.DIM}{'═'*50}{Colors.RESET}")
    Animations.typing_effect(f"{Colors.BOLD_GREEN}🚀 EXECUTING{Colors.RESET}", 0.02)
    print(f"{Colors.DIM}{'═'*50}{Colors.RESET}")
    
    Animations.spinner_animation(2, "Preparing request")
    send_register_code(email)
    
    # End with SGCODEX branding
    print(f"\n{Colors.DIM}{'═'*50}{Colors.RESET}")
    Animations.fire_effect(2)
    print(f"\n{Colors.BOLD_GREEN}✨ Thanks for using SGCODEX Tool! ✨{Colors.RESET}")
    print(f"{Colors.BOLD_GOLD}🌟 Version 2.0 - Enhanced Edition{Colors.RESET}")
    print(f"\n{Colors.DIM}Press Enter to exit...{Colors.RESET}", end="")
    input()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.BOLD_GOLD}[!] Interrupted!{Colors.RESET}")
        Animations.spinner_animation(1, "Exiting")
        sys.exit(0)