import json
import requests
from datetime import datetime

INPUT_FILE = 'SLAIF_SAC_accounts.json'
OUTPUT_FILE = 'SLAIF_SAC_accounts_level_sorted.json'
API_URL = 'http://raw.thug4ff.xyz/check'

def fetch_level(account_id, api_key='notfreenow'):
    """
    Interroge l'API pour récupérer le niveau d'un compte.
    Retourne le niveau (int) ou None en cas d'erreur.
    """
    try:
        params = {'uid': account_id, 'key': api_key}
        resp = requests.get(API_URL, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        level = data.get('data', {}).get('level')
        return level
    except Exception as e:
        print(f"Erreur pour account_id {account_id} : {e}")
        return None

def main():
    # 1. Charger les données
    try:
        with open(INPUT_FILE, 'r', encoding='utf-8') as f:
            accounts = json.load(f)
        print(f"Chargé {len(accounts)} comptes depuis {INPUT_FILE}")
    except FileNotFoundError:
        print(f"Fichier {INPUT_FILE} non trouvé, arrêt.")
        return

    # 2. Pour chaque compte, récupérer le level avec logs
    print("\n--- Début de la récupération des niveaux ---")
    for idx, acc in enumerate(accounts, 1):
        account_id = acc.get('account_id')
        if account_id is None:
            print(f"Compte {idx} sans account_id, ignoré.")
            continue
        level = fetch_level(account_id)
        acc['level'] = level
        # Log détaillé
        if level is not None:
            print(f"account_id: {account_id} -> level: {level}")
        else:
            print(f"account_id: {account_id} -> level: NON DISPONIBLE (erreur ou introuvable)")
    print("--- Fin de la récupération ---\n")

    # 3. Trier par niveau décroissant (les None en dernier)
    # La clé de tri : (est_None, niveau) avec est_None False pour les niveaux existants
    accounts_sorted = sorted(
        accounts,
        key=lambda x: (x.get('level') is None, x.get('level', -1) if x.get('level') is not None else -1),
        reverse=False  # On veut d'abord les non-None, puis les None; mais on veut les plus hauts niveaux en premier.
        # Correction : on trie d'abord par est_None (False avant True), puis par niveau descendant.
    )
    # Pour avoir les plus hauts niveaux en premier, on trie par (-level, est_None)
    # On va plutôt utiliser une clé composite:
    accounts_sorted = sorted(
        accounts,
        key=lambda x: (
            0 if x.get('level') is not None else 1,  # les non-None en premier
            -x.get('level') if x.get('level') is not None else 0  # niveau décroissant
        )
    )

    # 4. Écrire le nouveau fichier JSON
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(accounts_sorted, f, indent=4, ensure_ascii=False)

    print(f"Fichier généré : {OUTPUT_FILE}")

    # 5. Afficher tous les comptes triés avec leur niveau
    print("\n--- Liste complète des comptes triés par niveau (du plus haut au plus bas) ---")
    for acc in accounts_sorted:
        level = acc.get('level')
        account_id = acc.get('account_id')
        if level is not None:
            print(f"account_id: {account_id} | level: {level}")
        else:
            print(f"account_id: {account_id} | level: NON DISPONIBLE")

if __name__ == '__main__':
    main()