import asyncio
import aiohttp
import json
import time
from itertools import cycle
import os

os.system("")

GREEN  = "\033[92m"   # vert   -> working (banned_temp = false)
YELLOW = "\033[93m"   # jaune  -> ban temporaire (banned_temp = true)
RED    = "\033[91m"   # rouge  -> ban permanent
RESET  = "\033[0m"

# =========================
# CONFIG
# =========================
APIS = [
    "http://pjwt1.thug4ff.xyz/tok",
    "http://pjwt2.thug4ff.xyz/tok",
    "http://pjwt3.thug4ff.xyz/tok",
    "http://pjwt4.thug4ff.xyz/tok",
    "http://pjwt5.thug4ff.xyz/tok",
    

    # "http://127.0.0.1:7010/tok",
    # "http://127.0.0.1:7011/tok",
    # "http://127.0.0.1:7012/tok",
    # "http://127.0.0.1:7013/tok",
    # "http://127.0.0.1:7014/tok",
]

APIS0 = [
    "httpS://5-jwt-activate.vercel.app/token",
    "httpS://5-jwt-activate-v2.vercel.app/token",
]

TIMEOUT = 80
CONCURRENT_TASKS = 30
RETRY_ATTEMPTS = 8
RETRY_DELAY = 1  # secondes entre chaque tentative

SORT_BY = "level"  # sera défini interactivement

working_accounts = []
failed_accounts = []
permanent_banned_accounts = []  # liste pour les bannis permanents avec détails
api_cycle = cycle(APIS)
seen_uids = set()
permanent_banned_count = 0
temporary_banned_count = 0
total_processed = 0
total_accounts = 0

# =========================
# SAFE LEVEL
# =========================
def safe_level(value):
    try:
        lvl = int(value)
        if 0 < lvl <= 100:
            return lvl
    except:
        pass
    return None

# =========================
# FETCH DATA
# =========================
async def fetch_data(session, url):
    try:
        async with session.get(url, timeout=TIMEOUT) as resp:
            try:
                return await resp.json()
            except:
                text = await resp.text()
                print(f"[⚠️] JSON ERROR -> {text[:100]}")
                return None
    except asyncio.TimeoutError:
        return None
    except Exception:
        return None

# =========================
# TENTATIVE UNIQUE DE CHECK
# =========================
async def attempt_check(account, session):
    uid = str(account.get("uid", "")).strip()
    password = str(account.get("password", "")).strip()

    if not uid or not password:
        return {"status": "fail", "reason": "UID ou mot de passe vide"}

    api = next(api_cycle)
    url = f"{api}?uid={uid}&password={password}&wallet=True"

    data = await fetch_data(session, url)

    if not data:
        return {"status": "fail", "reason": "Pas de réponse (timeout/erreur)"}

    # BAN PERMANENT - On sauvegarde TOUS les détails de la réponse
    if data.get("ban_type") == "ban_permanent":
        return {
            "status": "permanent_ban",
            "reason": data.get("reason", "Inconnu"),
            "full_response": data,   # réponse API complète
            "data": data,            # alias pour affichage / cohérence
            "uid": uid,
            "password": password
        }

    is_temp_banned = False
    ban_info = None
    token = None
    level1 = None

    # BAN TEMPORAIRE
    if data.get("ban_type") == "ban_temporary":
        is_temp_banned = True
        ban_info = {
            "reason": data.get("reason", "Unknown"),
            "ban_date": data.get("ban_date", "N/A"),
            "ban_type": "ban_temporary"
        }

    # ERREUR DE LOGIN (sauf si temp ban)
    if data.get("status_code") != 200 and not is_temp_banned:
        return {"status": "fail", "reason": data.get("reason", "Status code != 200")}

    if data.get("error") and not is_temp_banned:
        return {"status": "fail", "reason": data.get("error", "Champ error présent")}

    # TOKEN
    token = data.get("token_access")
    if not token or token == "N/A":
        if not is_temp_banned:
            return {"status": "fail", "reason": "Pas de token valide"}
        else:
            token = None

    # LEVEL
    level1 = safe_level(data.get("level"))

    # CONSTRUCTION DU COMPTE SAUVEGARDÉ
    account_data = {
        "diamonds": data.get("diamonds", 0),
        "coins": data.get("coins", 0),
        "uid": uid,
        "server": data.get("server", "Unknown"),
        "password": password,
        "level": level1,
        "account_id": data.get("account_id", ""),
        "access_token": token,
        "nickname": data.get("nickname", ""),
        "banned_temp": is_temp_banned,
        "ban_info": ban_info,
        "open_id": data.get("open_id"),
        "remaining_time": data.get("remaining_time")  # temps restant pour le ban temporaire
    }

    # Retourner un statut approprié
    if is_temp_banned:
        return {
            "status": "temporary_ban",
            "data": account_data,
            "reason": data.get("reason", "Temporaire")
        }
    else:
        return {"status": "success", "data": account_data}

# =========================
# WORKER AVEC RÉESSAIS
# =========================
async def worker(queue, session):
    global permanent_banned_count, temporary_banned_count, working_accounts, failed_accounts, permanent_banned_accounts, total_processed

    while True:
        acc = await queue.get()
        uid = str(acc.get("uid", "")).strip()

        if not uid or uid in seen_uids:
            queue.task_done()
            continue

        seen_uids.add(uid)

        success = False
        for attempt in range(RETRY_ATTEMPTS):
            result = await attempt_check(acc, session)

            if result["status"] == "success":
                # Formatage du niveau pour l'affichage
                level_display = result['data'].get('level')
                if level_display is not None and level_display < 10:
                    level_display = f"0{level_display}"
                else:
                    level_display = str(level_display) if level_display is not None else "N/A"

                working_accounts.append(result["data"])
                print(f"{GREEN} [{total_processed+1}/{total_accounts}]  WORK -> {uid} |{result['data'].get('server', 'N/A')}| lvl {level_display} | nick : {result['data'].get('nickname', 'N/A')} {RESET}")
                success = True
                break

            elif result["status"] == "temporary_ban":
                temporary_banned_count += 1
                working_accounts.append(result["data"])   # on les garde quand même

                # Formatage du niveau pour l'affichage
                level_display = result['data'].get('level')
                if level_display is not None and level_display < 10:
                    level_display = f"0{level_display}"
                else:
                    level_display = str(level_display) if level_display is not None else "N/A"

                print(f"{YELLOW} [{total_processed+1}/{total_accounts}]  TEMP -> {uid} |{result['data'].get('server', 'N/A')}| lvl {level_display} | nick : {result['data'].get('nickname', 'N/A')}| time: {result['data'].get('remaining_time')} {RESET}")
                success = True
                break

            elif result["status"] == "permanent_ban":
                permanent_banned_count += 1

                resp = result.get("full_response", {}) or {}

                # Sauvegarde du compte banni permanent avec TOUS les détails
                permanent_banned_accounts.append({
                    "uid":            result.get("uid", uid),
                    "password":       result.get("password", acc.get("password", "")),
                    "reason":         result["reason"],
                    "ban_type":       resp.get("ban_type"),
                    "ban_date":       resp.get("ban_date"),
                    "ban_expire":     resp.get("ban_expire"),
                    "remaining_time": resp.get("remaining_time"),
                    "server":         resp.get("server"),
                    "nickname":       resp.get("nickname"),
                    "level":          safe_level(resp.get("level")),
                    "api_timestamp":  resp.get("timestamp"),
                    "timestamp":      time.time(),
                    "full_response":  resp,
                    "account_id" : resp.get("account_id")
                })

                # Affichage (on lit le level depuis la réponse API, pas depuis result['data'])
                lvl_perm = safe_level(resp.get("level"))
                if lvl_perm is not None and lvl_perm < 10:
                    lvl_perm_disp = f"0{lvl_perm}"
                else:
                    lvl_perm_disp = str(lvl_perm) if lvl_perm is not None else "N/A"
    
                print(
                    f"{RED} [{total_processed+1}/{total_accounts}]  PERM -> {uid} "
                    f"|{resp.get('server', 'N/A')}| lvl {lvl_perm_disp} "
                    f"| nick : {resp.get('nickname', 'N/A')} "
                    f"| reason: {result['reason']} "
                    f"| date: {resp.get('ban_date', 'N/A')} {RESET}"
                )
                success = True   # on ne réessaie pas
                break

            else:  # fail
                if attempt < RETRY_ATTEMPTS - 1:
                    print(f"[{total_processed+1}/{total_accounts}] [🔄] RETRY {attempt+1}/{RETRY_ATTEMPTS} -> {uid} | {result['reason']}{RESET}")
                    await asyncio.sleep(RETRY_DELAY)
                else:
                    # Échec définitif
                    failed_accounts.append({
                        "uid": uid,
                        "password": acc.get("password", ""),
                        "reason": result.get("reason", "Inconnu")
                    })
                    print(f" [{total_processed+1}/{total_accounts}] [❌] FAIL (after {RETRY_ATTEMPTS} attempts) -> {uid} | {result['reason']}{RESET}")

        total_processed += 1
        queue.task_done()

# =========================
# SAUVEGARDE DES RÉSULTATS (working + txt)
# =========================
def save_results(output_file, base_name):
    global working_accounts

    try:
        with open(output_file, "r", encoding="utf-8") as f:
            existing_data = json.load(f)
            if not isinstance(existing_data, list):
                existing_data = []
    except:
        existing_data = []

    existing_dict = {}
    for acc in existing_data:
        if isinstance(acc, dict) and acc.get("uid"):
            existing_dict[str(acc["uid"])] = acc

    added = 0
    for acc in working_accounts:
        uid = str(acc["uid"])
        if uid not in existing_dict:
            added += 1
        existing_dict[uid] = acc

    # Tri
    if SORT_BY == "diamonds":
        final_data = sorted(
            existing_dict.values(),
            key=lambda x: (
                x.get("banned_temp", False),
                -(x.get("diamonds", 0))
            )
        )
    else:
        final_data = sorted(
            existing_dict.values(),
            key=lambda x: -(safe_level(x.get("level")) or 0)
        )

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(final_data, f, indent=4, ensure_ascii=False)

    print(f"\n💾 Saved -> {output_file}")
    print(f"➕ Added -> {added}")
    print(f"📦 Total -> {len(final_data)}")

    # Fichier .txt
    txt_file = base_name + ".txt"
    try:
        with open(txt_file, "w", encoding="utf-8") as f:
            for acc in final_data:
                uid = str(acc.get("uid", ""))
                password = str(acc.get("password", ""))
                accesstoken = str(acc.get("access_token", "") or "")
                openid = str(acc.get("open_id", "") or "")
                f.write(f"{uid}:{password}:{accesstoken}:{openid}\n")
        print(f"📄 .txt généré -> {txt_file}")
    except Exception as e:
        print(f"⚠️ Erreur .txt : {e}")

    return final_data

# =========================
# SAUVEGARDE DES BANNIS PERMANENTS
# =========================
def save_permanent_banned(base_name, permanent_list):
    if not permanent_list:
        print("✅ Aucun banni permanent à enregistrer.")
        return

    perm_file = f"banned_{base_name}.json"
    try:
        with open(perm_file, "w", encoding="utf-8") as f:
            json.dump(permanent_list, f, indent=4, ensure_ascii=False)
        print(f"💾 Bannis permanents sauvegardés dans {perm_file} ({len(permanent_list)} comptes)")



    except Exception as e:
        print(f"⚠️ Erreur lors de la sauvegarde des bannis permanents : {e}")

# =========================
# SAUVEGARDE DES ÉCHECS
# =========================
def save_failed(base_name, failed_list):
    if not failed_list:
        print("✅ Aucun échec à enregistrer.")
        return

    fail_file = f"failed_{base_name}.json"
    try:
        with open(fail_file, "w", encoding="utf-8") as f:
            json.dump(failed_list, f, indent=4, ensure_ascii=False)
        print(f"💾 Échecs sauvegardés dans {fail_file} ({len(failed_list)} comptes)")
    except Exception as e:
        print(f"⚠️ Erreur lors de la sauvegarde des échecs : {e}")

# =========================
# STATS
# =========================
def print_stats(final_data):
    global permanent_banned_count, temporary_banned_count

    level_stats = {}
    level_temp_counts = {}  # pour compter les bannis temporaires par niveau
    temp_banned_in_final = 0

    for acc in final_data:
        lvl = safe_level(acc.get("level")) or 0
        level_stats[lvl] = level_stats.get(lvl, 0) + 1
        if acc.get("banned_temp"):
            temp_banned_in_final += 1
            level_temp_counts[lvl] = level_temp_counts.get(lvl, 0) + 1

    print(f"\n⛔ Bannis permanents (sauvegardés séparément) : {permanent_banned_count}")
    print(f"⏳ Bannis temporaires (sauvegardés) : {temporary_banned_count}")
    print(f"✅ Comptes normaux : {len(final_data) - temp_banned_in_final}")
    print("\n📊 Stats par niveau :")
    for lvl in sorted(level_stats.keys(), reverse=True):
        total = level_stats[lvl]
        temp = level_temp_counts.get(lvl, 0)
        print(f"  Level {lvl} → {total}   comptes ( Ban Temp : {temp})")

# =========================
# SÉLECTION DU FICHIER JSON
# =========================
def select_json_file():
    files = [f for f in os.listdir('.') if f.endswith('.json') and os.path.isfile(f)]
    if not files:
        print("❌ Aucun fichier .json trouvé dans le dossier courant.")
        file_name = input("Entrez le chemin complet du fichier : ").strip()
        if not file_name:
            print("Aucun fichier fourni. Fin.")
            return None
        return file_name

    print("\n📂 Fichiers JSON disponibles :")
    for i, f in enumerate(files, 1):
        print(f"  {i}. {f}")
    while True:
        try:
            choix = input("Choisissez le numéro du fichier : ").strip()
            idx = int(choix) - 1
            if 0 <= idx < len(files):
                return files[idx]
            else:
                print("Numéro invalide.")
        except ValueError:
            print("Veuillez entrer un nombre.")

# =========================
# MAIN
# =========================
async def main():
    global SORT_BY, working_accounts, failed_accounts, permanent_banned_accounts, total_accounts

    # 1. Sélection du fichier JSON
    file_name = select_json_file()
    if not file_name:
        return

    base_name = file_name.rsplit(".", 1)[0] if "." in file_name else file_name

    # 2. Choix du tri
    print("\n🔍 Choisissez le critère de tri pour le fichier de sortie :")
    print("  1. Niveau (défaut)")
    print("  2. Diamants (plus grand → plus petit)")
    choix = input("Votre choix (1/2) : ").strip()
    SORT_BY = "diamonds" if choix == "2" else "level"
    print(f"✅ Tri par {SORT_BY} sélectionné.\n")

    # 3. Chargement des comptes
    if not os.path.exists(file_name):
        print(f"❌ Fichier {file_name} introuvable.")
        return

    try:
        with open(file_name, "r", encoding="utf-8", errors="ignore") as f:
            accounts = json.load(f)
            if not isinstance(accounts, list):
                print("❌ Le JSON doit contenir une liste.")
                return
    except Exception as e:
        print(f"❌ Erreur de lecture JSON : {e}")
        return

    queue = asyncio.Queue()
    for acc in accounts:
        await queue.put(acc)

    total_accounts = queue.qsize()
    print(f"📦 {total_accounts} comptes chargés.\n")

    # 4. Lancement des workers
    timeout = aiohttp.ClientTimeout(total=TIMEOUT)
    connector = aiohttp.TCPConnector(limit=CONCURRENT_TASKS, ssl=False)

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        tasks = [
            asyncio.create_task(worker(queue, session))
            for _ in range(CONCURRENT_TASKS)
        ]

        await queue.join()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    # 5. Sauvegarde des résultats
    output_file = file_name.replace(".json", "_UP.json")
    final_data = save_results(output_file, base_name)

    # 6. Sauvegarde des bannis permanents (avec TOUS les détails)
    save_permanent_banned(base_name, permanent_banned_accounts)

    # 7. Sauvegarde des échecs
    save_failed(base_name, failed_accounts)

    # 8. Statistiques
    print(f"\n✅ Comptes traités avec succès : {len(working_accounts)}")
    print(f"⛔ Bannis permanents : {len(permanent_banned_accounts)}")
    print_stats(final_data)

# =========================
# RUN
# =========================
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Arrêté par l'utilisateur.")