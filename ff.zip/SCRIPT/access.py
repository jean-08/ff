import json
import os

# Dossier où se trouve le script
folder = os.path.dirname(os.path.abspath(__file__))

# Récupérer tous les fichiers JSON du dossier
json_files = [
    f for f in os.listdir(folder)
    if f.lower().endswith(".json")
]

# Trier les fichiers
json_files.sort()

if not json_files:
    print("❌ Aucun fichier JSON trouvé dans ce dossier.")
    exit()

# Afficher les fichiers disponibles
print("\n=== FICHIERS JSON DISPONIBLES ===")

for i, filename in enumerate(json_files, start=1):
    print(f"[{i}] {filename}")

# Demander le choix
while True:
    try:
        choice = int(input("\nChoisis le fichier par son numéro : "))

        if 1 <= choice <= len(json_files):
            break

        print("❌ Numéro invalide.")

    except ValueError:
        print("❌ Entre uniquement un numéro.")

# Fichier sélectionné
filename = json_files[choice - 1]
filepath = os.path.join(folder, filename)

print(f"\n📂 Fichier sélectionné : {filename}")

try:
    # Charger le JSON
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Vérifier que le JSON contient une liste
    if not isinstance(data, list):
        print("❌ Le fichier JSON doit contenir une liste de comptes.")
        exit()

    # Récupérer tous les access_token
    access_tokens = [
        str(item["access_token"])
        for item in data
        if isinstance(item, dict) and "access_token" in item
    ]

    # Séparer par virgules
    result = ",".join(access_tokens)

    print("\n=== ACCESS TOKENS ===")
    print(result)

    # Sauvegarder
    output = os.path.join(folder, "access_tokens.txt")

    with open(output, "w", encoding="utf-8") as f:
        f.write(result)

    print(f"\n✅ {len(access_tokens)} access_token(s) récupéré(s).")
    print(f"💾 Sauvegardé dans : {output}")

except json.JSONDecodeError:
    print("❌ Le fichier sélectionné contient un JSON invalide.")

except Exception as e:
    print(f"❌ Erreur : {e}")