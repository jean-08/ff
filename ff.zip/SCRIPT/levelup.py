import os
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

API_URL = "http://panel.thug4ff.xyz:6052/level_up"
API_KEY = "setra"

MAX_WORKERS = 10
TIMEOUT = 60


def scanner_fichiers_json():
    """Retourne tous les fichiers JSON du dossier courant."""

    fichiers = [
        f for f in os.listdir(".")
        if f.lower().endswith(".json")
    ]

    # Éviter de proposer les fichiers de résultats précédents
    fichiers = [
        f for f in fichiers
        if not f.startswith("LEVEL_UP_RESULT_")
    ]

    return sorted(fichiers)


def charger_comptes(filename):
    """Charge les comptes depuis un fichier JSON."""

    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, list):
            return data

        # Si le JSON contient par exemple {"accounts": [...]}
        if isinstance(data, dict):
            for key in ["accounts", "comptes", "data"]:
                if isinstance(data.get(key), list):
                    return data[key]

        print("❌ Le fichier JSON ne contient pas une liste de comptes.")
        return []

    except json.JSONDecodeError as e:
        print(f"❌ JSON invalide : {e}")
        return []

    except Exception as e:
        print(f"❌ Erreur lecture fichier : {e}")
        return []


def check_level_up(account):
    """Vérifie le Level Up d'un compte."""

    uid = str(account.get("uid", "")).strip()
    password = str(account.get("password", "")).strip()

    if not uid or not password:
        return {
            "account": account,
            "success": False,
            "error": "uid ou password manquant"
        }

    params = {
        "key": API_KEY,
        "uid": uid,
        "password": password
    }

    try:
        response = requests.get(
            API_URL,
            params=params,
            timeout=TIMEOUT
        )

        if response.status_code != 200:
            return {
                "account": account,
                "success": False,
                "error": f"HTTP {response.status_code}"
            }

        try:
            result = response.json()
        except Exception:
            return {
                "account": account,
                "success": False,
                "error": "Réponse API non-JSON"
            }

        # Ajouter les informations retournées par l'API
        return {
            "account": account,
            "result": result,
            "success": True
        }

    except requests.Timeout:
        return {
            "account": account,
            "success": False,
            "error": "Timeout"
        }

    except requests.RequestException as e:
        return {
            "account": account,
            "success": False,
            "error": str(e)
        }

    except Exception as e:
        return {
            "account": account,
            "success": False,
            "error": str(e)
        }


def extraire_count(result):
    """
    Récupère le nombre de Level Up depuis la réponse API.

    On essaie plusieurs formats possibles.
    """

    if not isinstance(result, dict):
        return 0

    # Format attendu
    count = result.get("count")

    if count is not None:
        try:
            return int(count)
        except:
            pass

    # Autre possibilité
    if result.get("level_up_available") is True:
        shop_items = result.get("shop_items", [])

        if isinstance(shop_items, list):
            return len(shop_items)

        return 1

    return 0


def main():

    print("=" * 60)
    print("       LEVEL UP SCANNER")
    print("=" * 60)

    fichiers = scanner_fichiers_json()

    if not fichiers:
        print("❌ Aucun fichier JSON trouvé dans ce dossier.")
        return

    print("\n📂 Fichiers JSON disponibles :\n")

    for i, fichier in enumerate(fichiers, 1):
        print(f" [{i}] {fichier}")

    print()

    while True:
        choix = input("👉 Choisis le fichier JSON : ").strip()

        try:
            index = int(choix) - 1

            if 0 <= index < len(fichiers):
                filename = fichiers[index]
                break

        except ValueError:
            pass

        print("❌ Choix invalide.")

    print(f"\n📄 Fichier sélectionné : {filename}")

    comptes = charger_comptes(filename)

    if not comptes:
        print("❌ Aucun compte trouvé.")
        return

    print(f"👤 Comptes trouvés : {len(comptes)}")
    print()
    print("🚀 Vérification des Level Up...")
    print("-" * 60)

    comptes_level_up = []

    success_count = 0
    error_count = 0

    # Vérification parallèle
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:

        futures = [
            executor.submit(check_level_up, account)
            for account in comptes
        ]

        for i, future in enumerate(as_completed(futures), 1):

            result = future.result()

            if not result["success"]:
                error_count += 1

                account = result["account"]

                print(
                    f"[{i}/{len(comptes)}] "
                    f"❌ {account.get('uid', '?')} "
                    f"→ {result['error']}"
                )

                continue

            success_count += 1

            account = result["account"]
            api_result = result["result"]

            count = extraire_count(api_result)

            level_up_available = (
                api_result.get("level_up_available", False)
                if isinstance(api_result, dict)
                else False
            )

            nickname = account.get("nickname", "Unknown")
            level = account.get("level", "?")
            uid = account.get("uid", "?")

            if level_up_available and count > 0:

                # On copie le compte original
                account_result = dict(account)

                # Informations du check
                account_result["level_up_available"] = True
                account_result["level_up_count"] = count
                account_result["level_up_result"] = api_result

                comptes_level_up.append(account_result)

                print(
                    f"[{i}/{len(comptes)}] "
                    f"✅ {nickname} | "
                    f"UID: {uid} | "
                    f"Level: {level} | "
                    f"Level Up: {count}"
                )

            else:

                print(
                    f"[{i}/{len(comptes)}] "
                    f"⚪ {nickname} | "
                    f"UID: {uid} | "
                    f"Level: {level} | "
                    f"Level Up: 0"
                )

    # Trier du plus grand nombre de Level Up au plus petit
    comptes_level_up.sort(
        key=lambda x: x.get("level_up_count", 0),
        reverse=True
    )

    # Nom du fichier résultat
    output_file = f"LEVEL_UP_RESULT_{len(comptes_level_up)}.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(
            comptes_level_up,
            f,
            indent=4,
            ensure_ascii=False
        )

    print()
    print("=" * 60)
    print("                 RÉSULTAT")
    print("=" * 60)

    print(f"👤 Total comptes       : {len(comptes)}")
    print(f"✅ Requêtes réussies   : {success_count}")
    print(f"❌ Erreurs             : {error_count}")
    print(f"🎁 Avec Level Up       : {len(comptes_level_up)}")
    print(f"⚪ Sans Level Up       : {len(comptes) - len(comptes_level_up)}")

    print()
    print("🏆 TOP LEVEL UP")
    print("-" * 60)

    for i, account in enumerate(comptes_level_up, 1):

        print(
            f"{i:>3}. "
            f"{account.get('nickname', 'Unknown')} | "
            f"Level {account.get('level', '?')} | "
            f"Level Up: {account.get('level_up_count', 0)} | "
            f"UID: {account.get('uid', '?')}"
        )

    print()
    print(f"💾 Résultat sauvegardé dans : {output_file}")
    print("=" * 60)


if __name__ == "__main__":
    main()