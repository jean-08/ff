#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
activator.py — Active les comptes enregistrés (choix région + TCP).
                 Lit registered_accounts.json (généré par generator.py).
"""

import base64, json, os, sys, ssl, gzip, struct, re, time
import urllib.request, urllib.error, urllib.parse
import asyncio, aiohttp
from datetime import datetime
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

# ─── SSL ─────────────────────────────────────────────────────────────────
_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode    = ssl.CERT_NONE

# ─── AES-128-CBC (encrypt + decrypt) ────────────────────────────────────
_SBOX = (
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
)
_RCON = (0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36)

def _xtime(a): return ((a<<1)^0x1b)&0xFF if a&0x80 else (a<<1)&0xFF
def _mix_single(a):
    t = a[0]^a[1]^a[2]^a[3]; u = a[0]
    return [a[0]^_xtime(a[0]^a[1])^t, a[1]^_xtime(a[1]^a[2])^t,
            a[2]^_xtime(a[2]^a[3])^t, a[3]^_xtime(a[3]^u)^t]

def _aes_key_expansion(key):
    Nk, Nr = 4, 10
    w = [0]*(4*(Nr+1))
    for i in range(Nk):
        w[i] = (key[4*i]<<24)|(key[4*i+1]<<16)|(key[4*i+2]<<8)|key[4*i+3]
    for i in range(Nk, 4*(Nr+1)):
        t = w[i-1]
        if i % Nk == 0:
            t = ((_SBOX[(t>>16)&0xFF]<<24)|(_SBOX[(t>>8)&0xFF]<<16)|
                 (_SBOX[t&0xFF]<<8)|_SBOX[(t>>24)&0xFF])
            t ^= _RCON[i//Nk-1]<<24
        w[i] = w[i-Nk]^t
    rk = []
    for r in range(Nr+1):
        k = bytearray(16)
        for j in range(4):
            v = w[r*4+j]
            k[j*4]=(v>>24)&0xFF; k[j*4+1]=(v>>16)&0xFF
            k[j*4+2]=(v>>8)&0xFF; k[j*4+3]=v&0xFF
        rk.append(bytes(k))
    return rk

def _aes_encrypt_block(block, rk):
    Nr = 10
    s = bytearray(b^k for b,k in zip(block, rk[0]))
    for rnd in range(1, Nr):
        s = bytearray(_SBOX[b] for b in s)
        s[1],s[5],s[9],s[13]  = s[5],s[9],s[13],s[1]
        s[2],s[6],s[10],s[14] = s[10],s[14],s[2],s[6]
        s[3],s[7],s[11],s[15] = s[15],s[3],s[7],s[11]
        for c in range(4):
            col   = [s[c*4+r] for r in range(4)]
            mixed = _mix_single(col)
            for r in range(4): s[c*4+r] = mixed[r]
        s = bytearray(b^k for b,k in zip(s, rk[rnd]))
    s = bytearray(_SBOX[b] for b in s)
    s[1],s[5],s[9],s[13]  = s[5],s[9],s[13],s[1]
    s[2],s[6],s[10],s[14] = s[10],s[14],s[2],s[6]
    s[3],s[7],s[11],s[15] = s[15],s[3],s[7],s[11]
    return bytes(b^k for b,k in zip(s, rk[Nr]))

_INV_SBOX = [0]*256
for _i, _v in enumerate(_SBOX): _INV_SBOX[_v] = _i

def _aes_decrypt_block(block, rk):
    Nr = 10
    s = bytearray(b^k for b,k in zip(block, rk[Nr]))
    for rnd in range(Nr-1, 0, -1):
        s[3],s[7],s[11],s[15] = s[15],s[3],s[7],s[11]
        s[2],s[6],s[10],s[14] = s[10],s[14],s[2],s[6]
        s[1],s[5],s[9],s[13]  = s[5],s[9],s[13],s[1]
        s = bytearray(_INV_SBOX[b] for b in s)
        s = bytearray(b^k for b,k in zip(s, rk[rnd]))
        for c in range(4):
            col = [s[c*4+r] for r in range(4)]
            u = _xtime(_xtime(col[0]^col[2]))
            v = _xtime(_xtime(col[1]^col[3]))
            col[0]^=u; col[1]^=v; col[2]^=u; col[3]^=v
            mixed = _mix_single(col)
            for r in range(4): s[c*4+r] = mixed[r]
    s[3],s[7],s[11],s[15] = s[15],s[3],s[7],s[11]
    s[2],s[6],s[10],s[14] = s[10],s[14],s[2],s[6]
    s[1],s[5],s[9],s[13]  = s[5],s[9],s[13],s[1]
    s = bytearray(_INV_SBOX[b] for b in s)
    return bytes(b^k for b,k in zip(s, rk[0]))

def _pkcs7_pad(data, bs=16):
    p = bs - (len(data) % bs)
    return data + bytes([p]*p)

def _aes_cbc_encrypt(data, key, iv):
    data = _pkcs7_pad(data)
    rk   = _aes_key_expansion(key)
    out  = bytearray(); prev = iv
    for i in range(0, len(data), 16):
        blk = bytes(d^p for d,p in zip(data[i:i+16], prev))
        out.extend(_aes_encrypt_block(blk, rk))
        prev = out[-16:]
    return bytes(out)

def _aes_cbc_decrypt(data, key, iv):
    rk  = _aes_key_expansion(key)
    out = bytearray(); prev = iv
    for i in range(0, len(data), 16):
        blk = data[i:i+16]
        out.extend(_aes_decrypt_block(blk, rk))
        prev = blk
    if out and 1 <= out[-1] <= 16: out = out[:-out[-1]]
    return bytes(out)

def aes_encrypt(data): return _aes_cbc_encrypt(data, AES_KEY, AES_IV)
def aes_encrypt_hex(h): return aes_encrypt(bytes.fromhex(h))
def aes_decrypt(data): return _aes_cbc_decrypt(data, AES_KEY, AES_IV)

# ─── Config ─────────────────────────────────────────────────────────────
hex_key  = "32656534343831396539623435393838343531343130363762323831363231383734643064356437616639643866376530306331653534373135623764316533"
HMAC_KEY = bytes.fromhex(hex_key)
AES_KEY  = bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56])
AES_IV   = bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])

USER_AGENT = "GarenaMSDK/4.0.41(SM-S908E ;Android 9;en;US;app 1.123.1 2019120270;)"
OB = "OB55"

# Régions / langues
REGION_LANG = {
    "PK":"ur","BD":"bn","IND":"hi","BR":"pt","US":"en","SAC":"es","NA":"en","SG":"en",
    "ID":"id","TW":"zh","TH":"th","VN":"vi","RU":"ru","ME":"ar","CIS":"ru","EU":"en",
}
REGION_URLS = {r: "https://clientbp.ppmainecoonghj.com/" for r in REGION_LANG}
REGION_URLS.update({
    "IND":"https://client.ind.freefiremobile.com/",
    "BR":"https://client.us.freefiremobile.com/",
    "EU":"https://client.us.freefiremobile.com/",
    "TH":"https://clientbp.common.ggbluefox.com/",
})
REGION_LOGIN_URLS = {r: "https://loginbp.ppmainecoonghj.com/" for r in REGION_LANG}
LOGIN_URL_DEFAULT = "https://loginbp.ppmainecoonghj.com/"

# ─── Proto helpers ──────────────────────────────────────────────────────
def _enc_varint(n):
    buf = bytearray()
    while True:
        b = n & 0x7F; n >>= 7
        if n: b |= 0x80
        buf.append(b)
        if not n: break
    return bytes(buf)

def _dec_varint(data, pos):
    res = 0; sh = 0
    while pos < len(data):
        b = data[pos]; res |= (b&0x7F)<<sh; pos += 1
        if not (b & 0x80): break
        sh += 7
    return res, pos

def _make_bytes_field(n, v):
    if isinstance(v, str): v = v.encode("utf-8")
    return _enc_varint((n<<3)|2) + _enc_varint(len(v)) + v

def _make_int32_field(n, v):
    if v < 0: v += 1<<64
    return _enc_varint((n<<3)|0) + _enc_varint(v)

def _make_int64_field(n, v):
    if v < 0: v += 1<<64
    return _enc_varint((n<<3)|0) + _enc_varint(v)

def _make_varint_field(n, v): return _make_int32_field(n, v)

def _decode_proto(data):
    result = {}; pos = 0; L = len(data)
    while pos < L:
        tag, pos = _dec_varint(data, pos)
        fn, wt = tag>>3, tag&7
        if wt == 0:
            val, pos = _dec_varint(data, pos)
            result[str(fn)] = {"wire_type":"varint","data":val}
        elif wt == 2:
            vlen, pos = _dec_varint(data, pos)
            chunk = data[pos:pos+vlen]; pos += vlen
            try:    result[str(fn)] = {"wire_type":"string","data":chunk.decode('utf-8')}
            except: result[str(fn)] = {"wire_type":"bytes","data":chunk.hex()}
        elif wt == 1:
            val = struct.unpack_from('<Q', data, pos)[0]; pos += 8
            result[str(fn)] = {"wire_type":"64bit","data":val}
        elif wt == 5:
            val = struct.unpack_from('<I', data, pos)[0]; pos += 4
            result[str(fn)] = {"wire_type":"32bit","data":val}
        else: break
    return result

def _get_field(parsed, *fns, default=None):
    if not isinstance(parsed, dict): return default
    for fn in fns:
        k = str(fn)
        if k in parsed:
            v = parsed[k].get("data") if isinstance(parsed[k], dict) else None
            if v is not None and v != "": return v
    return default

def _safe_int(v, d=0):
    if v is None or v == "": return d
    if isinstance(v, bool): return int(v)
    if isinstance(v, int):  return v
    if isinstance(v, str):
        try: return int(v)
        except: return d
    return d

def get_ff_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# ─── JWT ────────────────────────────────────────────────────────────────
JWT_RE = re.compile(rb'eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*')

def extraire_jwt_depuis_hex(hex_content):
    raw = bytes.fromhex("".join(hex_content.split()))
    m = JWT_RE.search(raw)
    if not m: raise ValueError("No JWT")
    return m.group(0).decode("ascii")

def decode_jwt_payload(jwt):
    try:
        part = jwt.split(".")[1]
        part += "=" * ((4 - len(part) % 4) % 4)
        return json.loads(base64.urlsafe_b64decode(part).decode())
    except Exception:
        return {}

def decode(token):
    p = decode_jwt_payload(token)
    return p.get("lock_region", "N/A"), p.get("account_id", "N/A")

# ─── HTTP ───────────────────────────────────────────────────────────────
def _http_post(url, data, headers, timeout=12):
    if isinstance(data, str): data = data.encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        r = urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx)
        raw = r.read()
        if r.headers.get("Content-Encoding") == "gzip": raw = gzip.decompress(raw)
        return r.status, raw
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.headers.get("Content-Encoding") == "gzip":
            try: raw = gzip.decompress(raw)
            except: pass
        return e.code, raw

# ─── Lokesh (proto dynamique) ───────────────────────────────────────────
_SERIALIZED_FILE_DESCRIPTOR = (
    b'\n\x0coutput.proto\x12\tapp.proto"\xfc\x03\n\x06Lokesh'
    b'\x12\x12\n\naccount_id\x18\x01 \x01(\x03'
    b'\x12\x0e\n\x06region\x18\x02 \x01(\t'
    b'\x12\r\n\x05place\x18\x03 \x01(\t'
    b'\x12\x10\n\x08location\x18\x04 \x01(\t'
    b'\x12\x0e\n\x06status\x18\x05 \x01(\t'
    b'\x12\r\n\x05token\x18\x08 \x01(\t'
    b'\x12\n\n\x02id\x18\t \x01(\x05'
    b'\x12\x0b\n\x03\x61pi\x18\n \x03(\x0c'
    b'\x12\x0e\n\x06number\x18\x0c \x01(\x05'
    b'\x12#\n\x08\x61imguard\x18\x0f \x01(\x0b\x32\x11.app.proto.Lokesh'
    b'\x12\x0c\n\x04\x61rea\x18\x10 \x01(\t'
    b'\x12\x11\n\tmain_area\x18\x12 \x01(\t'
    b'\x12\x0c\n\x04\x63ity\x18\x13 \x01(\t'
    b'\x12\x0c\n\x04name\x18\x14 \x01(\t'
    b'\x12\x11\n\ttimestamp\x18\x15 \x01(\x03'
    b'\x12\x0e\n\x06\x62inary\x18\x16 \x01(\x0c'
    b'\x12\x13\n\x0b\x62inary_data\x18\x17 \x01(\x0c'
    b'\x12\x0f\n\x07\x66ield24\x18\x18 \x01(\t'
    b'\x12*\n\x07\x66ield25\x18\x19 \x01(\x0b\x32\x19.app.proto.Lokesh.Field25'
    b'\x12\x0f\n\x07\x66ield27\x18\x1b \x01(\x0c'
    b'\x1a"\n\x12\x44\x65\x63rypted_Payloads\x12\x0c\n\x04type\x18\x01 \x01(\x05'
    b'\x1aY\n\x07\x46ield25'
    b'\x12\x0e\n\x06\x66ield1\x18\x01 \x01(\x0c'
    b'\x12\x0e\n\x06\x66ield2\x18\x02 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield5\x18\x05 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield6\x18\x06 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield7\x18\x07 \x01(\x05'
    b'\x62\x06proto3'
)
_pool = descriptor_pool.DescriptorPool()
_file_proto = descriptor_pb2.FileDescriptorProto()
_file_proto.ParseFromString(_SERIALIZED_FILE_DESCRIPTOR)
_pool.Add(_file_proto)
Lokesh = message_factory.GetMessageClass(
    _pool.FindMessageTypeByName("app.proto.Lokesh")
)

def _parse_lokesh(raw):
    if not raw: return None
    for offset in range(0, min(len(raw), 200)):
        try:
            msg = Lokesh(); msg.ParseFromString(raw[offset:])
            if msg.status == "live" and msg.token.startswith("eyJ"): return msg
        except Exception: continue
    for offset in range(0, min(len(raw), 200)):
        try:
            msg = Lokesh(); msg.ParseFromString(raw[offset:])
            if msg.token or msg.status or len(msg.api) > 0: return msg
        except Exception: continue
    return None

# ─── Major Login flow ───────────────────────────────────────────────────
def _build_major_login_proto(access_token, open_id, lang, region):
    buf = bytearray()
    buf += _make_bytes_field(3, get_ff_timestamp())
    buf += _make_bytes_field(4, "free fire")
    buf += _make_int32_field(5, 1)
    buf += _make_bytes_field(7, "1.132.7")
    buf += _make_bytes_field(8, "Android OS 9 / API-28 (SP1A.210812.016/G998BXXU4BULF)")
    buf += _make_bytes_field(9, "Handheld")
    buf += _make_bytes_field(10, "Bouygues Telecom")
    buf += _make_bytes_field(11, "WIFI")
    buf += _make_int32_field(12, 1334)
    buf += _make_int32_field(13, 750)
    buf += _make_bytes_field(14, "240")
    buf += _make_bytes_field(15, "ARMv7 VFPv3 NEON | 2000 | 4")
    buf += _make_int32_field(16, 7966)
    buf += _make_bytes_field(17, "Adreno (TM) 540")
    buf += _make_bytes_field(18, "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)")
    buf += _make_bytes_field(19, "Google|c4d8782a-ea5d-43cc-9691-4c0fb66be40d")
    buf += _make_bytes_field(20, "165.169.250.93")
    buf += _make_bytes_field(21, lang)
    buf += _make_bytes_field(22, open_id)
    buf += _make_bytes_field(23, "4")
    buf += _make_bytes_field(24, "Handheld")
    buf += _make_bytes_field(25, "samsung SM-G998B")
    buf += _make_bytes_field(29, access_token)
    buf += _make_int32_field(30, 1)
    buf += _make_bytes_field(41, "Bouygues Telecom")
    buf += _make_bytes_field(42, "WIFI")
    buf += _make_bytes_field(57, "7428b253defc164018c604a1ebbfebdf")
    for n, v in RESERVED:
        buf += _make_int32_field(n, v)
    buf += _make_int32_field(73, 1)
    buf += _make_bytes_field(74, "/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/lib/arm")
    buf += _make_int32_field(76, 1)
    buf += _make_bytes_field(77, "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/base.apk")
    buf += _make_int32_field(78, 3)
    buf += _make_int32_field(79, 1)
    buf += _make_bytes_field(81, "32")
    buf += _make_bytes_field(83, "2019121229")
    buf += _make_int32_field(85, 3)
    buf += _make_bytes_field(86, "OpenGLES2")
    buf += _make_int32_field(87, 4095)
    buf += _make_int32_field(88, 4)
    buf += _make_bytes_field(90, region)
    buf += _make_int32_field(92, 6515)
    buf += _make_bytes_field(93, "android")
    buf += _make_bytes_field(94, "KqsHT1PIyjSauiv/YuX65n6JG770W1FmNFCqzMfj6dzqWXwOJ2S6GFtvItNilb1gtFB+vmRVdtQhr/ZX0wxuyC+xm2ob5DlI1c+QLV0emeBQnKd9")
    buf += _make_int32_field(95, 111207)
    buf += _make_bytes_field(96, '{"cur_rate":null,"support_etc2":false}')
    buf += _make_int32_field(97, 1)
    buf += _make_int32_field(98, 1)
    buf += _make_bytes_field(99, "4")
    buf += _make_bytes_field(100, "4")
    buf += _make_bytes_field(102, _make_int32_field(8, 4))
    buf += _make_int32_field(104, 22150)
    buf += _make_int32_field(105, 1)
    buf += _make_bytes_field(106, HOT_UPDATE_URL)
    buf += _make_bytes_field(107, HOT_UPDATE_HASH)
    return bytes(buf)

RESERVED = [
    (60, 128886), (61, 117349), (62, 7934),  (63, 5827),
    (64, 123918), (65, 128886), (66, 123918),(67, 128886),
]
HOT_UPDATE_URL = (
    "https://dl-bs.ggpolarbear.com/live/ABHotUpdates/|"
    "https://core-bs.ggpolarbear.com/live/ABHotUpdates/|"
    "211c933168f55902c7dfbfd8c4e2957d"
)
HOT_UPDATE_HASH = "c8e41b7a93f02d56e1a94c7b8203f5d1"

def major_login(access_token, open_id, lang, region="", retries=3):
    url = "https://loginbp.ppmainecoonghj.com/MajorLogin"
    headers = {
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept": "*/*", "Accept-Encoding": "deflate, gzip",
        "X-Ga-Sv": "1789534056", "Authorization": "Bearer ",
        "X-Ga": "v1 1", "Releaseversion": OB,
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Unity-Version": "2018.4.12f1",
    }
    proto = _build_major_login_proto(access_token, open_id, lang, region)
    enc = aes_encrypt(proto)
    for _ in range(retries):
        try:
            status, content = _http_post(url, enc, headers, 12)
            if status == 200: return status, content.hex()
        except Exception as e:
            print(f"  [RETRY] MajorLogin: {e}")
        time.sleep(0.5)
    return None, None

def _build_get_login_data_proto(access_token, open_id, lang, region):
    buf = bytearray()
    buf += _make_bytes_field(3, get_ff_timestamp())
    buf += _make_bytes_field(4, "free fire")
    buf += _make_int32_field(5, 1)
    buf += _make_bytes_field(7, "1.132.7")
    buf += _make_bytes_field(8, "Android OS 9 / API-28 (SP1A.210812.016/G998BXXU4BULF)")
    buf += _make_bytes_field(9, "Handheld")
    buf += _make_bytes_field(10, "Bouygues Telecom")
    buf += _make_bytes_field(11, "WIFI")
    buf += _make_int32_field(12, 1334)
    buf += _make_int32_field(13, 750)
    buf += _make_bytes_field(14, "240")
    buf += _make_bytes_field(15, "ARMv7 VFPv3 NEON | 2000 | 4")
    buf += _make_int32_field(16, 7966)
    buf += _make_bytes_field(17, "Adreno (TM) 540")
    buf += _make_bytes_field(18, "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)")
    buf += _make_bytes_field(19, "Google|c4d8782a-ea5d-43cc-9691-4c0fb66be40d")
    buf += _make_bytes_field(20, "165.169.250.93")
    buf += _make_bytes_field(21, lang)
    buf += _make_bytes_field(22, open_id)
    buf += _make_bytes_field(23, "4")
    buf += _make_bytes_field(24, "Handheld")
    buf += _make_bytes_field(25, "samsung SM-G998B")
    buf += _make_bytes_field(29, access_token)
    buf += _make_int32_field(30, 1)
    buf += _make_bytes_field(41, "Bouygues Telecom")
    buf += _make_bytes_field(42, "WIFI")
    buf += _make_bytes_field(57, "7428b253defc164018c604a1ebbfebdf")
    for n, v in RESERVED:
        buf += _make_int32_field(n, v)
    buf += _make_int32_field(73, 1)
    buf += _make_bytes_field(74, "/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/lib/arm")
    buf += _make_int32_field(76, 1)
    buf += _make_bytes_field(77, "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/base.apk")
    buf += _make_int32_field(78, 3)
    buf += _make_int32_field(79, 1)
    buf += _make_bytes_field(81, "32")
    buf += _make_bytes_field(83, "2019121229")
    buf += _make_int32_field(85, 3)
    buf += _make_bytes_field(86, "OpenGLES2")
    buf += _make_int32_field(87, 4095)
    buf += _make_int32_field(88, 4)
    buf += _make_bytes_field(90, region)
    buf += _make_int32_field(92, 6515)
    buf += _make_bytes_field(93, "android")
    buf += _make_bytes_field(94, "KqsHT1PIyjSauiv/YuX65n6JG770W1FmNFCqzMfj6dzqWXwOJ2S6GFtvItNilb1gtFB+vmRVdtQhr/ZX0wxuyC+xm2ob5DlI1c+QLV0emeBQnKd9")
    buf += _make_int32_field(95, 111207)
    buf += _make_bytes_field(96, '{"cur_rate":null,"support_etc2":false}')
    buf += _make_int32_field(97, 1)
    buf += _make_int32_field(98, 1)
    buf += _make_bytes_field(99, "0")
    buf += _make_bytes_field(100, "4")
    buf += _make_bytes_field(102, _make_int32_field(8, 4))
    buf += _make_int32_field(103, 1)
    buf += _make_int32_field(104, 22150)
    buf += _make_int32_field(105, 1)
    buf += _make_bytes_field(106, HOT_UPDATE_URL)
    buf += _make_bytes_field(107, HOT_UPDATE_HASH)
    return bytes(buf)

def get_login_data(jwt, access_token, open_id, region):
    base = REGION_URLS.get(region.upper(), "https://clientbp.ppmainecoonghj.com/")
    url = base + "GetLoginData"
    lang = REGION_LANG.get(region.upper(), "en")
    proto = _build_get_login_data_proto(access_token, open_id, lang, region)
    enc = aes_encrypt(proto)
    headers = {
        "Authorization": f"Bearer {jwt}",
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept": "*/*", "Accept-Encoding": "deflate, gzip",
        "X-Ga-Sv": "1789534056", "X-Ga": "v1 1", "Releaseversion": OB,
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Unity-Version": "2018.4.12f1",
    }
    for _ in range(3):
        try:
            status, content = _http_post(url, enc, headers, 12)
            if status == 200: return content
        except Exception as e:
            print(f"  [RETRY] GetLoginData: {e}")
        time.sleep(0.5)
    return None

def _build_newbie_choice_proto(game_uid, choice=1, slot=3):
    buf = bytearray()
    buf += _make_int64_field(1, game_uid)
    buf += _make_int32_field(2, choice)
    buf += _make_int32_field(3, slot)
    return bytes(buf)

def choose_newbie_choice(jwt, game_uid):
    url = "https://loginbp.ppmainecoonghj.com/ChooseNewbieChoice"
    enc = aes_encrypt(_build_newbie_choice_proto(game_uid))
    headers = {
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Connection": "close", "Accept-Encoding": "gzip", "X-GA-SV": 1790070907,
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Bearer {jwt}", "X-Unity-Version": "2018.4.12f1",
        "X-GA": "v1 1", "ReleaseVersion": OB,
    }
    return _http_post(url, enc, headers, 12)

def choose_region(jwt, region_code):
    base = REGION_LOGIN_URLS.get(region_code.upper(), LOGIN_URL_DEFAULT)
    url = base + "ChooseRegion"
    payload = _make_bytes_field(1, region_code) + _make_int32_field(2, 1)
    enc = aes_encrypt(payload)
    headers = {
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Connection": "close", "Accept-Encoding": "gzip",
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Bearer {jwt}", "X-Unity-Version": "2018.4.12f1",
        "X-GA": "v1 1", "ReleaseVersion": OB,
    }
    return _http_post(url, enc, headers, 12)

def ping(token="", region=""):
    url = "https://clientbp.ppmainecoonghj.com/Ping"
    host = url.split("/")[2]
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": f"Bearer {token}" if token else "Bearer",
        "Connection": "close",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": host, "ReleaseVersion": OB,
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)",
        "X-GA": "v1 1", "X-Unity-Version": "2018.4.12f1",
    }
    enc = bytes.fromhex("1a725b2c56ec52ba7d09623454c0a003")
    try:
        return _http_post(url, enc, headers, 12)
    except Exception:
        return None, None

# ─── Ports extraction ───────────────────────────────────────────────────
def _bytes_to_str(v):
    if v is None or v == "": return ""
    if isinstance(v, (bytes, bytearray)):
        try:    return v.decode("utf-8")
        except: return v.hex()
    return str(v)

def extract_ports_from_response(raw, key_bytes, iv_bytes):
    if not raw: return {"online":"", "account":""}
    if not isinstance(raw, (bytes, bytearray)):
        try: raw = bytes(raw)
        except Exception: return {"online":"", "account":""}

    if raw:
        first = raw[0]
        if (first & 0x07) in (0, 2) and len(raw) > 4:
            try:
                p = _decode_proto(bytes(raw))
                o = _get_field(p, 14, default=b"")
                a = _get_field(p, 32, default=b"")
                if o or a:
                    return {"online": _bytes_to_str(o), "account": _bytes_to_str(a)}
            except Exception: pass

    for k, v in ((key_bytes, iv_bytes), (AES_KEY, AES_IV)):
        if not k or not v or len(k) != 16 or len(v) != 16: continue
        try:
            dec = _aes_cbc_decrypt(bytes(raw), k, v)
            if not dec: continue
            p = _decode_proto(dec)
            o = _get_field(p, 14, default=b"")
            a = _get_field(p, 32, default=b"")
            if o or a:
                return {"online": _bytes_to_str(o), "account": _bytes_to_str(a)}
        except Exception: continue
    return {"online":"", "account":""}

# ─── Auth token 0x0115 ──────────────────────────────────────────────────
def build_auth_token(bot_uid, jwt_token, timestamp):
    uid_hex = format(int(bot_uid), "x")
    pad = {7:"000000000",8:"00000000",9:"0000000",10:"000000"}.get(len(uid_hex), "0000000")
    ts_hex = format(int(timestamp), "x")
    if len(ts_hex) % 2: ts_hex = "0"+ts_hex
    enc = aes_encrypt(jwt_token.encode("utf-8"))
    return f"0115{pad}{uid_hex}{ts_hex}00000{format(len(enc),'x')}{enc.hex()}"

# ─── TCP Activator ──────────────────────────────────────────────────────
class FastGuestActivator:
    def __init__(self, account):
        self.account = account

    async def connect_and_activate(self):
        acc = self.account
        online = acc.get("online_ipport", "")
        chat   = acc.get("account_ipport", "")
        if not online or not chat: return False
        try:
            oip, oport = online.split(":")
            cip, cport = chat.split(":")
        except Exception: return False

        auth = build_auth_token(
            _safe_int(acc.get("account_uid")),
            acc["jwt_final"],
            _safe_int(acc.get("timestamp")),
        )
        try:
            ol_r, ol_w = await asyncio.wait_for(asyncio.open_connection(oip, int(oport)), 5)
            ol_w.write(bytes.fromhex(auth)); await ol_w.drain()
            ch_r, ch_w = await asyncio.wait_for(asyncio.open_connection(cip, int(cport)), 5)
            ch_w.write(bytes.fromhex(auth)); await ch_w.drain()
            await asyncio.sleep(1)
            try: ol_w.close(); await ol_w.wait_closed()
            except: pass
            try: ch_w.close(); await ch_w.wait_closed()
            except: pass
            return True
        except Exception as e:
            print(f"  [ACT] {acc['uid']} error: {e}")
            return False

# ─── Activation complète d'un compte ────────────────────────────────────
def activate_one(acc, region):
    lang = REGION_LANG.get(region.upper(), "en")
    access_token = acc["access_token"]
    open_id      = acc["open_id"]
    account_uid  = acc.get("account_uid", 0)

    # 1. MajorLogin initial → JWT
    status, lh = major_login(access_token, open_id, lang, region)
    if status != 200 or not lh:
        print(f"  [FAIL] {acc['uid']} MajorLogin #{1}"); return None
    try:
        jwt = extraire_jwt_depuis_hex(lh)
    except Exception:
        jwt = ""

    if not jwt:
        print(f"  [FAIL] {acc['uid']} no JWT"); return None

    # 2. Newbie choice
    if account_uid:
        try: choose_newbie_choice(jwt, account_uid)
        except Exception: pass

    # 3. ChooseRegion
    reg_up = region.upper()
    r_region = "EUROPE" if reg_up == "EU" else ("RU" if reg_up == "CIS" else reg_up)
    try: choose_region(jwt, r_region)
    except Exception: pass

    # 4. Ping
    ping()

    # 5. MajorLogin sync → Lokesh
    status, lh2 = major_login(access_token, open_id, lang, region)
    if status != 200 or not lh2:
        print(f"  [FAIL] {acc['uid']} MajorLogin #2"); return None

    msg = _parse_lokesh(bytes.fromhex(lh2))
    if msg is None:
        print(f"  [FAIL] {acc['uid']} Lokesh parse"); return None

    jwt_final = msg.token
    timestamp = msg.timestamp
    region_resp = msg.region

    api = None
    for item in msg.api:
        if isinstance(item, bytes):
            try: s = item.decode("utf-8")
            except UnicodeDecodeError: continue
            if s.startswith("http"):
                api = s; break

    def _to_bytes(v):
        if not v: return b""
        try:
            if isinstance(v, bytes): return v
            if isinstance(v, str):
                try: return bytes.fromhex(v)
                except Exception:
                    return base64.b64decode(v + "="*((4-len(v)%4)%4))
        except Exception: pass
        return b""

    key_bytes = _to_bytes(msg.binary) if msg.binary else AES_KEY
    iv_bytes  = _to_bytes(msg.binary_data) if msg.binary_data else AES_IV

    # 6. GetLoginData → ports
    raw_getlogin = get_login_data(jwt, access_token, open_id, region_resp or region)
    ports = extract_ports_from_response(raw_getlogin, key_bytes, iv_bytes) if raw_getlogin else {"online":"","account":""}

    _, account_id_out = decode(jwt_final) if jwt_final else (None, "N/A")

    return {
        "uid": acc["uid"],
        "password": acc["password"],
        "open_id": open_id,
        "access_token": access_token,
        "name": acc.get("name", ""),
        "account_uid": account_id_out,
        "region": (region_resp or region).upper(),
        "jwt_final": jwt_final,
        "timestamp": timestamp,
        "online_ipport":  ports.get("online", ""),
        "account_ipport": ports.get("account", ""),
    }

# ─── MAIN ───────────────────────────────────────────────────────────────
INPUT_JSON = "registered_accounts.json"

def banner():
    os.system("cls" if os.name == "nt" else "clear")
    print("=" * 65)
    print("  ACTIVATOR — Free Fire Region Select + TCP 1-sec")
    print("  registered_accounts.json → activated_<region>.txt")
    print("=" * 65 + "\n")
from pprint import pprint
def main():
    banner()
    if not os.path.exists(INPUT_JSON):
        print(f"  ❌ Fichier introuvable : {INPUT_JSON}")
        print(f"     Lance d'abord generator.py")
        return

    with open(INPUT_JSON, "r", encoding="utf-8") as f:
        accounts = json.load(f)

    if not accounts:
        print("  ❌ Aucun compte dans le fichier.")
        return

    print(f"  {len(accounts)} compte(s) disponible(s).")
    print(f"  Régions : {', '.join(REGION_LANG)}\n")

    region = input("  Choisis une région : ").strip().upper()
    if region not in REGION_LANG:
        print(f"  ⚠️  Région inconnue → BD par défaut")
        region = "BD"

    try:
        limit = int(input(f"  Combien de comptes activer ? [Enter={len(accounts)}] : ").strip() or len(accounts))
    except ValueError:
        limit = len(accounts)

    accounts = accounts[:limit]

    activated = []
    for i, acc in enumerate(accounts, 1):
        print(f"\n  [{i}/{len(accounts)}] → {acc['uid']}")
        res = activate_one(acc, region)
        pprint(res)
        print()
        if res:
            activated.append(res)
            with open(f"activated_{region}.txt", "a", encoding="utf-8") as f:
                f.write(f"{res['uid']}:{res['password']}\n")
            print(f"  ✅ Online={res['online_ipport']} | Account={res['account_ipport']}")

    # Phase TCP
    if not activated:
        print("\n  Aucun compte à activer.")
        return

    print(f"\n  ─── Phase TCP ───")
    async def run_all():
        sem = asyncio.Semaphore(100)
        async def run(acc):
            async with sem:
                bot = FastGuestActivator(acc)
                ok = await bot.connect_and_activate()
                if ok:
                    print(f"  🔌 {acc['uid']} connected")
        await asyncio.gather(*(run(a) for a in activated))
    try:
        asyncio.run(run_all())
    except KeyboardInterrupt:
        pass

    print(f"\n  ✅ Terminé. {len(activated)} compte(s) activé(s).")
    print(f"  → activated_{region}.txt\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n  Interrompu.")