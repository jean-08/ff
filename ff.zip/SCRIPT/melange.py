
import json
import os
import random

# ============================================================
# CONFIGURATION
# ============================================================

dossier = "."
prefixe_sortie = "N_VENDU_SAC"


# ============================================================
# RÉCUPÉRER TOUS LES FICHIERS JSON
# ============================================================

fichiers_json = [
    f
    for f in os.listdir(dossier)
    if f.lower().endswith(".json")
    and os.path.isfile(os.path.join(dossier, f))
    and not f.startswith(f"{prefixe_sortie}_")
]

# Ajouter aussi les fichiers de sortie précédents
fichiers_json.extend(
    f
    for f in os.listdir(dossier)
    if f.lower().endswith(".json")
    and os.path.isfile(os.path.join(dossier, f))
    and f.startswith(f"{prefixe_sortie}_")
)

# Supprimer les éventuels doublons dans la liste des fichiers
fichiers_json = list(dict.fromkeys(fichiers_json))

print("=" * 60)
print("SCAN DES FICHIERS JSON")
print("=" * 60)

if not fichiers_json:
    print("Aucun fichier JSON trouvé.")
    exit()

print(f"Fichiers trouvés : {len(fichiers_json)}")

for fichier in fichiers_json:
    print(f"   • {fichier}")

print()


# ============================================================
# STOCKER LES COMPTES UNIQUES
# ============================================================

comptes_uniques = {}
total_comptes_lus = 0


# ============================================================
# LECTURE DE TOUS LES FICHIERS JSON
# ============================================================

for fichier in fichiers_json:
    chemin = os.path.join(dossier, fichier)

    try:
        with open(chemin, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            print(f"{fichier} ignoré : le JSON n'est pas une liste.")
            continue

        print(f"Lecture : {fichier} ({len(data)} comptes)")
        total_comptes_lus += len(data)

        for item in data:
            if not isinstance(item, dict):
                continue

            uid = item.get("uid")
            password = item.get("password")

            if not uid or not password:
                continue

            cle = (str(uid), str(password))

            if cle not in comptes_uniques:
                comptes_uniques[cle] = item.copy()

    except json.JSONDecodeError as e:
        print(f"JSON invalide dans {fichier} : {e}")

    except Exception as e:
        print(f"Erreur avec {fichier} : {e}")


# ============================================================
# CONVERTIR EN LISTE
# ============================================================

liste_comptes = list(comptes_uniques.values())


# ============================================================
# MÉLANGER TOUS LES COMPTES
# ============================================================

random.shuffle(liste_comptes)


# ============================================================
# NOM DE SORTIE AUTOMATIQUE
# ============================================================

nombre_comptes = len(liste_comptes)
fichier_sortie = f"{prefixe_sortie}_{nombre_comptes}.json"


# ============================================================
# SAUVEGARDER
# ============================================================

with open(fichier_sortie, "w", encoding="utf-8") as out:
    json.dump(
        liste_comptes,
        out,
        indent=4,
        ensure_ascii=False
    )


# ============================================================
# STATISTIQUES
# ============================================================

doublons = total_comptes_lus - len(liste_comptes)

print()
print("=" * 60)
print("RÉSULTAT")
print("=" * 60)

print(f"Comptes lus        : {total_comptes_lus}")
print(f"Doublons supprimés : {doublons}")
print(f"Comptes uniques    : {nombre_comptes}")
print(f"Fichier créé       : {fichier_sortie}")

print()
print("=" * 60)
print("TERMINÉ")
print("=" * 60)
