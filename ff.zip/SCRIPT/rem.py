import json
import os
import re


# ============================================================
# CONFIGURATION
# ============================================================

# Fichier JSON de sortie
JSON_SUFFIX = "_filtred.json"

# Fichier TXT de sortie
TXT_SUFFIX = "_remaining_sorted.txt"


# ============================================================
# SÉLECTION DU FICHIER JSON
# ============================================================

def select_json_file():
    """
    Scanne le dossier courant et permet de choisir
    un fichier JSON par numéro.
    """

    files = [
        f for f in os.listdir(".")
        if f.lower().endswith(".json")
        and os.path.isfile(f)
        and not f.endswith(JSON_SUFFIX)
    ]

    if not files:
        print("❌ Aucun fichier .json trouvé dans le dossier courant.")

        file_name = input(
            "Entrez le chemin complet du fichier JSON : "
        ).strip()

        if not os.path.isfile(file_name):
            print("❌ Fichier introuvable.")
            return None

        return file_name

    print("\n" + "=" * 70)
    print("📂 FICHIERS JSON DISPONIBLES")
    print("=" * 70)

    for i, f in enumerate(files, 1):
        print(f"  {i}. {f}")

    print("=" * 70)

    while True:
        try:
            choix = input("Choisissez le numéro du fichier : ").strip()

            idx = int(choix) - 1

            if 0 <= idx < len(files):
                return files[idx]

            print("❌ Numéro invalide.")

        except ValueError:
            print("❌ Veuillez entrer un nombre.")


# ============================================================
# PARSING DU REMAINING_TIME
# ============================================================

def parse_remaining_time(value):
    """
    Convertit :

        6d 10h 8m 24s
        10h 8m 24s
        8m 24s
        24s

    en secondes.

    Les valeurs invalides ou None sont placées à la fin.
    """

    if value is None:
        return float("inf")

    value = str(value).strip()

    if not value:
        return float("inf")

    days = 0
    hours = 0
    minutes = 0
    seconds = 0

    match = re.findall(
        r"(\d+)\s*([dhms])",
        value.lower()
    )

    if not match:
        return float("inf")

    for number, unit in match:
        number = int(number)

        if unit == "d":
            days = number

        elif unit == "h":
            hours = number

        elif unit == "m":
            minutes = number

        elif unit == "s":
            seconds = number

    total_seconds = (
        days * 86400
        + hours * 3600
        + minutes * 60
        + seconds
    )

    return total_seconds


# ============================================================
# FORMATAGE DU REMAINING_TIME
# ============================================================

def format_remaining_time(value):
    """
    Retourne une valeur propre pour l'affichage TXT.
    """

    if value is None:
        return "N/A"

    value = str(value).strip()

    if not value:
        return "N/A"

    return value


# ============================================================
# CHARGEMENT JSON
# ============================================================

def load_json(file_name):

    print("\n📖 Chargement du fichier...")

    try:
        with open(
            file_name,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            data = json.load(f)

    except json.JSONDecodeError as e:

        print(f"❌ JSON invalide : {e}")
        return None

    except Exception as e:

        print(f"❌ Erreur lors de la lecture : {e}")
        return None

    if not isinstance(data, list):

        print("❌ Le JSON doit contenir une liste de comptes.")

        return None

    print(f"✅ {len(data):,} comptes chargés.")

    return data


# ============================================================
# TRI PAR REMAINING_TIME
# ============================================================

def sort_accounts(accounts):

    print("\n⏳ Tri des comptes par remaining_time...")

    sorted_accounts = sorted(
        accounts,
        key=lambda account: parse_remaining_time(
            account.get("remaining_time")
        )
    )

    print("✅ Tri terminé.")

    return sorted_accounts


# ============================================================
# GÉNÉRATION DU JSON
# ============================================================

def save_json(sorted_accounts, input_file):

    base_name = os.path.splitext(input_file)[0]

    output_file = base_name + JSON_SUFFIX

    try:

        with open(
            output_file,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                sorted_accounts,
                f,
                indent=4,
                ensure_ascii=False
            )

        print(f"\n💾 JSON sauvegardé :")
        print(f"   {output_file}")

        return output_file

    except Exception as e:

        print(f"❌ Erreur sauvegarde JSON : {e}")

        return None


# ============================================================
# GÉNÉRATION DU LOG TXT
# ============================================================

def generate_txt_log(sorted_accounts, input_file):

    base_name = os.path.splitext(input_file)[0]

    txt_file = base_name + TXT_SUFFIX

    print("\n" + "=" * 90)
    print("📋 LOG DES COMPTES TRIÉS")
    print("=" * 90)

    lines = []

    for index, account in enumerate(sorted_accounts, 1):

        remaining = format_remaining_time(
            account.get("remaining_time")
        )

        level = account.get("level")

        if level is None:
            level = "?"

        uid = account.get("uid")

        if uid is None:
            uid = ""

        nickname = account.get("nickname")

        if nickname is None:
            nickname = ""

        # Format demandé
        line = (
            f"{index}. "
            f"{remaining:<18} | "
            f"Level {str(level):<3} | "
            f"{uid} | "
            f"{nickname}"
        )

        print(line)

        lines.append(line)

    print("=" * 90)

    try:

        with open(
            txt_file,
            "w",
            encoding="utf-8"
        ) as f:

            f.write("\n".join(lines))

        print("\n📝 TXT sauvegardé :")
        print(f"   {txt_file}")

        return txt_file

    except Exception as e:

        print(f"❌ Erreur sauvegarde TXT : {e}")

        return None


# ============================================================
# STATISTIQUES
# ============================================================

def show_statistics(sorted_accounts):

    total = len(sorted_accounts)

    with_remaining = 0
    without_remaining = 0

    for account in sorted_accounts:

        value = account.get("remaining_time")

        if value is None or str(value).strip() == "":
            without_remaining += 1
        else:
            with_remaining += 1

    print("\n" + "=" * 70)
    print("📊 STATISTIQUES")
    print("=" * 70)

    print(f"📦 Total comptes       : {total:,}")
    print(f"⏳ Avec remaining_time : {with_remaining:,}")
    print(f"❓ Sans remaining_time : {without_remaining:,}")

    if total > 0:

        first = sorted_accounts[0]
        last = sorted_accounts[-1]

        print("\n🥇 PLUS PETIT remaining_time :")
        print(
            f"   {format_remaining_time(first.get('remaining_time'))}"
        )

        print("\n🔴 DERNIER COMPTE :")
        print(
            f"   {format_remaining_time(last.get('remaining_time'))}"
        )

    print("=" * 70)


# ============================================================
# MAIN
# ============================================================

def main():

    print("\n")
    print("=" * 70)
    print("      SORT TRI DES COMPTES PAR REMAINING_TIME")
    print("=" * 70)

    # --------------------------------------------------------
    # 1. Sélection du fichier
    # --------------------------------------------------------

    file_name = select_json_file()

    if not file_name:
        return

    print(f"\n📁 Fichier sélectionné : {file_name}")

    # --------------------------------------------------------
    # 2. Chargement
    # --------------------------------------------------------

    accounts = load_json(file_name)

    if accounts is None:
        return

    if len(accounts) == 0:

        print("⚠️ Le fichier ne contient aucun compte.")

        return

    # --------------------------------------------------------
    # 3. Tri
    # --------------------------------------------------------

    sorted_accounts = sort_accounts(accounts)

    # --------------------------------------------------------
    # 4. Sauvegarde JSON
    # --------------------------------------------------------

    json_output = save_json(
        sorted_accounts,
        file_name
    )

    # --------------------------------------------------------
    # 5. Génération TXT
    # --------------------------------------------------------

    txt_output = generate_txt_log(
        sorted_accounts,
        file_name
    )

    # --------------------------------------------------------
    # 6. Statistiques
    # --------------------------------------------------------

    show_statistics(sorted_accounts)

    # --------------------------------------------------------
    # FIN
    # --------------------------------------------------------

    print("\n" + "=" * 70)
    print("✅ TERMINÉ")
    print("=" * 70)

    if json_output:
        print(f"📄 JSON : {json_output}")

    if txt_output:
        print(f"📝 TXT  : {txt_output}")

    print("=" * 70)


# ============================================================
# LANCEMENT
# ============================================================

if __name__ == "__main__":
    main()
