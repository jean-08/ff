import os
import json


def ask_int(message, allow_empty=False):
    while True:
        value = input(message).strip()

        if allow_empty and value == "":
            return None

        try:
            return int(value)
        except ValueError:
            print("Valeur invalide.")


def ask_choice(message, choices):
    while True:
        value = input(message).strip().lower()
        if value in choices:
            return value
        print(f"Choix invalide ({', '.join(choices)})")


def get_level(acc):
    """Retourne le niveau du compte, 0 si absent, null ou invalide."""
    level = acc.get("level")

    if level is None:
        return 0

    try:
        return int(level)
    except (ValueError, TypeError):
        return 0


# ==========================
# Sélection du fichier
# ==========================

script_dir = os.path.dirname(os.path.abspath(__file__))

json_files = sorted(
    f for f in os.listdir(script_dir)
    if f.lower().endswith(".json")
)

if not json_files:
    print("Aucun fichier JSON trouvé.")
    input()
    exit()

print("\n=== Fichiers disponibles ===\n")

for i, file in enumerate(json_files, 1):
    print(f"[{i}] {file}")

while True:
    try:
        index = int(input("\nChoix : "))
        if 1 <= index <= len(json_files):
            break
    except ValueError:
        pass

selected = json_files[index - 1]
path = os.path.join(script_dir, selected)

with open(path, "r", encoding="utf-8") as f:
    accounts = json.load(f)

no_level_count = sum(1 for acc in accounts if acc.get("level") is None)

print(f"\n{len(accounts)} comptes chargés.")
if no_level_count:
    print(f"{no_level_count} compte(s) sans niveau (considérés comme niveau 0).")
print()

# ==========================
# Configuration des filtres
# ==========================

print("========== FILTRES ==========\n")

print("Mode niveau :")
print("1 - Niveau exact")
print("2 - Niveau minimum")
print("3 - Niveau maximum")
print("4 - Entre deux niveaux")
print("5 - Tous")

mode = ask_choice("Choix : ", ["1", "2", "3", "4", "5"])

level_exact = None
level_min = None
level_max = None

if mode == "1":
    level_exact = ask_int("Niveau : ")

elif mode == "2":
    level_min = ask_int("Niveau minimum : ")

elif mode == "3":
    level_max = ask_int("Niveau maximum : ")

elif mode == "4":
    level_min = ask_int("Niveau minimum : ")
    level_max = ask_int("Niveau maximum : ")

print("\nBannissement :")
print("1 - Non bannés")
print("2 - Bannés")
print("3 - Tous")

ban_mode = ask_choice("Choix : ", ["1", "2", "3"])

print("\nTri :")
print("1 - Niveau décroissant")
print("2 - Niveau croissant")
print("3 - Aucun")

sort_mode = ask_choice("Choix : ", ["1", "2", "3"])

# ==========================
# Filtrage
# ==========================

filtered = []

for acc in accounts:

    level = get_level(acc)

    if level_exact is not None and level != level_exact:
        continue

    if level_min is not None and level < level_min:
        continue

    if level_max is not None and level > level_max:
        continue

    banned = acc.get("banned_temp", False)

    if ban_mode == "1" and banned:
        continue

    if ban_mode == "2" and not banned:
        continue

    filtered.append(acc)

# ==========================
# Tri
# ==========================

if sort_mode == "1":
    filtered.sort(key=get_level, reverse=True)

elif sort_mode == "2":
    filtered.sort(key=get_level)

# ==========================
# Sauvegarde
# ==========================

base = os.path.splitext(selected)[0]

suffix = []

if level_exact is not None:
    suffix.append(f"lvl{level_exact}")

if level_min is not None:
    suffix.append(f"min{level_min}")

if level_max is not None:
    suffix.append(f"max{level_max}")

if ban_mode == "1":
    suffix.append("notbanned")
elif ban_mode == "2":
    suffix.append("banned")

if not suffix:
    suffix.append("filtered")

output = f"{base}_{'_'.join(suffix)}.json"

with open(
    os.path.join(script_dir, output),
    "w",
    encoding="utf-8"
) as f:
    json.dump(filtered, f, indent=4, ensure_ascii=False)

print("\n==============================")
print(f"Comptes trouvés : {len(filtered)}")
print(f"Fichier créé : {output}")
print("==============================")

input("\nEntrée pour quitter...")