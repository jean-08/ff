import asyncio
import aiohttp
import json
from itertools import cycle
import os

# =========================
# CONFIG
# =========================


APIS = [
    "https://5-jwt-activate.vercel.app/token",
    "https://5-jwt-activate-v2.vercel.app/token",
    #     "http://127.0.0.1:5002/token",
    # "http://127.0.0.1:5002/token",
]

TIMEOUT = 60
CONCURRENT_TASKS = 3
RETRY_ATTEMPTS = 3
RETRY_DELAY = 1  # secondes entre chaque tentative

SORT_BY = "level"  # sera défini interactivement

working_accounts = []
failed_accounts = []
api_cycle = cycle(APIS)
seen_uids = set()
permanent_banned_count = 0
temporary_banned_count = 0   # <-- nouveau compteur

# =========================
# SAFE LEVEL
# =========================
def safe_level(value):
    try:
        lvl = int(value)
        if 0 < lvl <= 100:
            return lvl
    except:
        pass
    return None

# =========================
# FETCH DATA
# =========================
async def fetch_data(session, url):
    try:
        async with session.get(url, timeout=TIMEOUT) as resp:
            try:
                return await resp.json()
            except:
                text = await resp.text()
                print(f"[⚠️] JSON ERROR -> {text[:100]}")
                return None
    except asyncio.TimeoutError:
        return None
    except Exception:
        return None

# =========================
# TENTATIVE UNIQUE DE CHECK
# =========================
async def attempt_check(account, session):
    uid = str(account.get("uid", "")).strip()
    password = str(account.get("password", "")).strip()

    if not uid or not password:
        return {"status": "fail", "reason": "UID ou mot de passe vide"}

    api = next(api_cycle)
    url = f"{api}?uid={uid}&password={password}&wallet=True"

    data = await fetch_data(session, url)

    if not data:
        return {"status": "fail", "reason": "Pas de réponse (timeout/erreur)"}

    # BAN PERMANENT
    if data.get("ban_type") == "ban_permanent":
        return {"status": "permanent_ban", "reason": data.get("reason", "Inconnu")}

    is_temp_banned = False
    ban_info = None
    token = None
    level1 = None

    # BAN TEMPORAIRE
    if data.get("ban_type") == "ban_temporary":
        is_temp_banned = True
        ban_info = {
            "reason": data.get("reason", "Unknown"),
            "ban_date": data.get("ban_date", "N/A"),
            "ban_type": "ban_temporary"
        }

    # ERREUR DE LOGIN (sauf si temp ban)
    if data.get("status_code") != 200 and not is_temp_banned:
        return {"status": "fail", "reason": data.get("reason", "Status code != 200")}

    if data.get("error") and not is_temp_banned:
        return {"status": "fail", "reason": data.get("error", "Champ error présent")}

    # TOKEN
    token = data.get("token_access")
    if not token or token == "N/A":
        if not is_temp_banned:
            return {"status": "fail", "reason": "Pas de token valide"}
        else:
            token = None

    # LEVEL
    level1 = safe_level(data.get("level"))

    # CONSTRUCTION DU COMPTE SAUVEGARDÉ
    account_data = {
        "diamonds": data.get("diamonds", 0),
        "coins": data.get("coins", 0),
        "uid": uid,
        "server": data.get("server", "Unknown"),
        "password": password,
        "level": level1,
        "account_id": data.get("account_id", ""),
        "access_token": token,
        "nickname": data.get("nickname", ""),
        "banned_temp": is_temp_banned,
        "ban_info": ban_info,
        "open_id": data.get("open_id")
    }

    # Retourner un statut approprié
    if is_temp_banned:
        return {
            "status": "temporary_ban",
            "data": account_data,
            "reason": data.get("reason", "Temporaire")
        }
    else:
        return {"status": "success", "data": account_data}

# =========================
# WORKER AVEC RÉESSAIS
# =========================
async def worker(queue, session):
    global permanent_banned_count, temporary_banned_count, working_accounts, failed_accounts

    while True:
        acc = await queue.get()
        uid = str(acc.get("uid", "")).strip()

        if not uid or uid in seen_uids:
            queue.task_done()
            continue

        seen_uids.add(uid)

        success = False
        for attempt in range(RETRY_ATTEMPTS):
            result = await attempt_check(acc, session)

            if result["status"] == "success":
                working_accounts.append(result["data"])
                print(f"[✅] WORK -> {uid} | Server :{result['data'].get('server')} | lvl {result['data'].get('level')} | nick : {result['data'].get('nickname')}")  
                success = True
                break

            elif result["status"] == "temporary_ban":
                temporary_banned_count += 1
                working_accounts.append(result["data"])   # on les garde quand même
                print(f"[🟡] TEMP -> {uid} | lvl {result['data'].get('level')} | nick : {result['data'].get('nickname')}")
                success = True
                break

            elif result["status"] == "permanent_ban":
                permanent_banned_count += 1
                print(f"[⛔] PERM -> {uid} | Reason: {result['reason']}")
                success = True   # on ne réessaie pas
                break

            else:  # fail
                if attempt < RETRY_ATTEMPTS - 1:
                    print(f"[🔄] RETRY {attempt+1}/{RETRY_ATTEMPTS} -> {uid} | {result['reason']}")
                    await asyncio.sleep(RETRY_DELAY)
                else:
                    # Échec définitif
                    failed_accounts.append({
                        "uid": uid,
                        "password": acc.get("password", ""),
                        "reason": result.get("reason", "Inconnu")
                    })
                    print(f"[❌] FAIL (after {RETRY_ATTEMPTS} attempts) -> {uid} | {result['reason']}")

        queue.task_done()

# =========================
# SAUVEGARDE DES RÉSULTATS (working + txt)
# =========================
def save_results(output_file, base_name):
    global working_accounts

    try:
        with open(output_file, "r", encoding="utf-8") as f:
            existing_data = json.load(f)
            if not isinstance(existing_data, list):
                existing_data = []
    except:
        existing_data = []

    existing_dict = {}
    for acc in existing_data:
        if isinstance(acc, dict) and acc.get("uid"):
            existing_dict[str(acc["uid"])] = acc

    added = 0
    for acc in working_accounts:
        uid = str(acc["uid"])
        if uid not in existing_dict:
            added += 1
        existing_dict[uid] = acc

    # Tri
    if SORT_BY == "diamonds":
        final_data = sorted(
            existing_dict.values(),
            key=lambda x: (
                x.get("banned_temp", False),
                -(x.get("diamonds", 0))
            )
        )
    else:
        final_data = sorted(
            existing_dict.values(),
            key=lambda x: -(safe_level(x.get("level")) or 0)
        )

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(final_data, f, indent=4, ensure_ascii=False)

    print(f"\n💾 Saved -> {output_file}")
    print(f"➕ Added -> {added}")
    print(f"📦 Total -> {len(final_data)}")

    # Fichier .txt
    txt_file = base_name + ".txt"
    try:
        with open(txt_file, "w", encoding="utf-8") as f:
            for acc in final_data:
                uid = str(acc.get("uid", ""))
                password = str(acc.get("password", ""))
                accesstoken = str(acc.get("access_token", "") or "")
                openid = str(acc.get("open_id", "") or "")
                f.write(f"{uid}:{password}:{accesstoken}:{openid}\n")
        print(f"📄 .txt généré -> {txt_file}")
    except Exception as e:
        print(f"⚠️ Erreur .txt : {e}")

    return final_data

# =========================
# SAUVEGARDE DES ÉCHECS
# =========================
def save_failed(base_name, failed_list):
    if not failed_list:
        print("✅ Aucun échec à enregistrer.")
        return

    fail_file = f"failed_{base_name}.json"
    try:
        with open(fail_file, "w", encoding="utf-8") as f:
            json.dump(failed_list, f, indent=4, ensure_ascii=False)
        print(f"💾 Échecs sauvegardés dans {fail_file} ({len(failed_list)} comptes)")
    except Exception as e:
        print(f"⚠️ Erreur lors de la sauvegarde des échecs : {e}")

# =========================
# STATS
# =========================
def print_stats(final_data):
    global permanent_banned_count, temporary_banned_count

    level_stats = {}
    temp_banned_in_final = 0

    for acc in final_data:
        lvl = safe_level(acc.get("level")) or 0
        level_stats[lvl] = level_stats.get(lvl, 0) + 1
        if acc.get("banned_temp"):
            temp_banned_in_final += 1

    print(f"\n⛔ Bannis permanents (ignorés) : {permanent_banned_count}")
    print(f"⏳ Bannis temporaires (sauvegardés) : {temporary_banned_count}")
    print(f"✅ Comptes normaux : {len(final_data) - temp_banned_in_final}")
    print("\n📊 Stats par niveau :")
    for lvl in sorted(level_stats.keys(), reverse=True):
        print(f"  Level {lvl} → {level_stats[lvl]} comptes")

# =========================
# SÉLECTION DU FICHIER JSON
# =========================
def select_json_file():
    files = [f for f in os.listdir('.') if f.endswith('.json') and os.path.isfile(f)]
    if not files:
        print("❌ Aucun fichier .json trouvé dans le dossier courant.")
        file_name = input("Entrez le chemin complet du fichier : ").strip()
        if not file_name:
            print("Aucun fichier fourni. Fin.")
            return None
        return file_name

    print("\n📂 Fichiers JSON disponibles :")
    for i, f in enumerate(files, 1):
        print(f"  {i}. {f}")
    while True:
        try:
            choix = input("Choisissez le numéro du fichier : ").strip()
            idx = int(choix) - 1
            if 0 <= idx < len(files):
                return files[idx]
            else:
                print("Numéro invalide.")
        except ValueError:
            print("Veuillez entrer un nombre.")

# =========================
# MAIN
# =========================
async def main():
    global SORT_BY, working_accounts, failed_accounts

    # 1. Sélection du fichier JSON
    file_name = select_json_file()
    if not file_name:
        return

    base_name = file_name.rsplit(".", 1)[0] if "." in file_name else file_name

    # 2. Choix du tri
    print("\n🔍 Choisissez le critère de tri pour le fichier de sortie :")
    print("  1. Niveau (défaut)")
    print("  2. Diamants (plus grand → plus petit)")
    choix = input("Votre choix (1/2) : ").strip()
    SORT_BY = "diamonds" if choix == "2" else "level"
    print(f"✅ Tri par {SORT_BY} sélectionné.\n")

    # 3. Chargement des comptes
    if not os.path.exists(file_name):
        print(f"❌ Fichier {file_name} introuvable.")
        return

    try:
        with open(file_name, "r", encoding="utf-8", errors="ignore") as f:
            accounts = json.load(f)
            if not isinstance(accounts, list):
                print("❌ Le JSON doit contenir une liste.")
                return
    except Exception as e:
        print(f"❌ Erreur de lecture JSON : {e}")
        return

    queue = asyncio.Queue()
    for acc in accounts:
        await queue.put(acc)

    print(f"📦 {queue.qsize()} comptes chargés.")

    # 4. Lancement des workers
    timeout = aiohttp.ClientTimeout(total=TIMEOUT)
    connector = aiohttp.TCPConnector(limit=CONCURRENT_TASKS, ssl=False)

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        tasks = [
            asyncio.create_task(worker(queue, session))
            for _ in range(CONCURRENT_TASKS)
        ]

        await queue.join()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    # 5. Sauvegarde des résultats
    output_file = file_name.replace(".json", "_UX.json")
    final_data = save_results(output_file, base_name)

    # 6. Sauvegarde des échecs
    save_failed(base_name, failed_accounts)

    # 7. Statistiques
    print(f"\n✅ Comptes traités avec succès : {len(working_accounts)}")
    print_stats(final_data)

# =========================
# RUN
# =========================
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Arrêté par l'utilisateur.")