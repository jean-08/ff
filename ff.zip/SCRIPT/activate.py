import hmac
import hashlib
import json
import time
import os
import sys
import threading
import concurrent.futures
import random
import string
import codecs
import base64
import struct
import gzip
from datetime import datetime

# ─── HTTP & SSL ─────────────────────────────────────────────────────────────
import urllib.request
import urllib.error
import ssl
import requests   # <-- installé via pip install requests

_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode = ssl.CERT_NONE

# ─── Colors ─────────────────────────────────────────────────────────────────
R = "\033[91m"
G = "\033[92m"
Y = "\033[93m"
C = "\033[96m"
M = "\033[95m"
W = "\033[97m"
B = "\033[1m"
RST = "\033[0m"

io_lock = threading.Lock()
file_lock = threading.Lock()

# ─── Config ────────────────────────────────────────────────────────────────
DATADOME_COOKIE = "datadome=vVlQ0xwKxBVqDcHIqhz4gmVF~YVN6SrL_GzQO44sq562NyqesHBz3rOSjfNrmXOexkXUuOm85PZ222uU1FhOlA4Tr7fFUn4q5faimfY6_7gVmqhestXmQxZVkVA1Tnoj"
USER_AGENT = "GarenaMSDK/4.0.42(SM-S908E ;Android 9;fr;FR;app 1.128.2 2019120828;)"

hex_key = "32656534343831396539623435393838343531343130363762323831363231383734643064356437616639643866376530306331653534373135623764316533"
HMAC_KEY = bytes.fromhex(hex_key)
AES_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
AES_IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

REGION_LANG = {
    "PK": "ur", "BD": "bn", "IND": "hi", "BR": "pt", "US": "en",
    "SAC": "es", "NA": "en", "SG": "en", "ID": "id", "TW": "zh",
    "TH": "th", "VN": "vi", "RU": "ru", "ME": "ar", "CIS": "ru",
    "EU": "en"
}

REGION_LOGIN_SERVER = {
    "ME": "https://loginbp.common.ggbluefox.com/MajorLogin",
}

REGION_LOGIN_URLS = {r: "https://loginbp.ggpolarbear.com/" for r in REGION_LANG}

LIBRARY_PATH  = "/data/app/com.dts.freefireth-nJXwOmOfD2wUXNTgtBx3oA==/lib/arm64"
LIBRARY_TOKEN = "	4c322aeb56444feaa151d1ea91a8f7f2|/data/app/com.dts.freefireth-nJXwOmOfD2wUXNTgtBx3oA==/base.apk"
DEVICE_DATA_MAJORLOGIN = "	KqsHT9gkyp1x0tETvaqsM9HrHXmlESNqpe6jTCqnqgjkSpz+byQz5KsNx9e8jrRbJvUQZsOhLjkrCwoFUptgqVSSUOo="
DEVICE_DATA_GETLOGIN   = DEVICE_DATA_MAJORLOGIN

class RateLimitException(Exception):
    pass

# ─── Fonction log flexible ────────────────────────────────────────────────
def log(*args):
    """
    Accepte 1, 2 ou 3 arguments :
      - log("message")               -> affiche en blanc
      - log("message", C)            -> affiche en couleur
      - log("TAG", "message", C)     -> affiche "[TAG] message" en couleur
    """
    with io_lock:
        if len(args) == 1:
            msg = args[0]
            print(f"{msg}{RST}")
        elif len(args) == 2:
            msg, color = args
            print(f"{color}{msg}{RST}")
        elif len(args) == 3:
            tag, msg, color = args
            print(f"{color}[{tag}] {msg}{RST}")
        else:
            print(" ".join(str(a) for a in args))

# ─── Récupération du cookie Datadome ──────────────────────────────────────
def fetch_datadome_cookie():
    """Hit the Datadome SDK endpoint with the exact payload you provided."""
    global DATADOME_COOKIE
    payload = {
        "cid": "r8MklXjdM4iDrouWrzdvCr0RxpuiQxl37cfUiRoLiwaJqQPjmalf7wgnzkYLbHA~nLtUJB4PwauRizIztlyqNJJfQ6BGdKlvqKDslrgFxPF3_MVkx659U5vdRR~TPgJK",
        "ddv": "1.13.9",
        "ddvc": "4.0.41",
        "ddk": "AE3F04AD3F0D3A462481A337485081",
        "request": "https://100067.connect.garena.com/api/v2/oauth/guest:register",
        "os": "Android",
        "osr": "9",
        "osn": "P",
        "osv": "28",
        "ua": "GarenaMSDK/4.0.41(SM-S908E ;Android 9;fr;FR;app 1.123.1 2019120270;)",
        "screen_x": "1600",
        "screen_y": "900",
        "screen_d": "240",
        "events": '[{"id":1,"message":"response validation","source":"sdk","date":1781377315862}]',
        "camera": '{"auth":"false","info":"{}"}',
        "mdl": "SM-S908E",
        "prd": "b0qxxx",
        "mnf": "samsung",
        "dev": "b0q",
        "hrd": "qcom",
        "fgp": "samsung/b0qxxx/b0q:9/TP1A.220624.014/S908EXXS2BWA2:user/release-keys",
        "tgs": "release-keys",
    }
    body = urllib.parse.urlencode(payload).encode("utf-8")
    req = urllib.request.Request(
        "https://api-sdk.datadome.co/sdk/",
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Encoding": "gzip",
            "User-Agent": "okhttp/4.12.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            j = json.loads(raw)
            cookie = j.get("cookie") or j.get("datadome") or j.get("dd_cookie")
            if cookie:
                if not cookie.startswith("datadome="):
                    cookie = "datadome=" + cookie
                DATADOME_COOKIE = cookie
                log("DD", f"Cookie refreshed: {cookie[:32]}…", G)
                return True
            log("DD", f"Unexpected response: {j}", Y)
    except Exception as e:
        log("DD", f"Cookie fetch failed: {e}", Y)
    return False

# ─── Pure Python AES-128-CBC ─────────────────────────────────────────────
_SBOX = (
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
)
_RCON = (0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36)

def _xtime(a):
    return ((a << 1) ^ 0x1b) & 0xFF if a & 0x80 else (a << 1) & 0xFF

def _mix_single(a):
    t = a[0] ^ a[1] ^ a[2] ^ a[3]
    u = a[0]
    r = [0]*4
    r[0] = a[0] ^ _xtime(a[0] ^ a[1]) ^ t
    r[1] = a[1] ^ _xtime(a[1] ^ a[2]) ^ t
    r[2] = a[2] ^ _xtime(a[2] ^ a[3]) ^ t
    r[3] = a[3] ^ _xtime(a[3] ^ u) ^ t
    return r

def _aes_key_expansion(key):
    Nk = 4; Nr = 10
    w = [0] * (4 * (Nr + 1))
    for i in range(Nk):
        w[i] = (key[4*i] << 24) | (key[4*i+1] << 16) | (key[4*i+2] << 8) | key[4*i+3]
    for i in range(Nk, 4 * (Nr + 1)):
        t = w[i-1]
        if i % Nk == 0:
            t = ((_SBOX[(t >> 16) & 0xFF] << 24) | (_SBOX[(t >> 8) & 0xFF] << 16) |
                 (_SBOX[t & 0xFF] << 8) | _SBOX[(t >> 24) & 0xFF])
            t ^= _RCON[i // Nk - 1] << 24
        w[i] = w[i - Nk] ^ t
    rk = []
    for r in range(Nr + 1):
        k = bytearray(16)
        for j in range(4):
            val = w[r*4 + j]
            k[j*4] = (val >> 24) & 0xFF
            k[j*4+1] = (val >> 16) & 0xFF
            k[j*4+2] = (val >> 8) & 0xFF
            k[j*4+3] = val & 0xFF
        rk.append(bytes(k))
    return rk

def _aes_encrypt_block(block, round_keys):
    Nr = 10
    s = bytearray(b ^ k for b, k in zip(block, round_keys[0]))
    for rnd in range(1, Nr):
        s = bytearray(_SBOX[b] for b in s)
        s[1], s[5], s[9], s[13] = s[5], s[9], s[13], s[1]
        s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
        s[3], s[7], s[11], s[15] = s[15], s[3], s[7], s[11]
        for c in range(4):
            col = [s[c*4+r] for r in range(4)]
            mixed = _mix_single(col)
            for r in range(4):
                s[c*4+r] = mixed[r]
        s = bytearray(b ^ k for b, k in zip(s, round_keys[rnd]))
    s = bytearray(_SBOX[b] for b in s)
    s[1], s[5], s[9], s[13] = s[5], s[9], s[13], s[1]
    s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
    s[3], s[7], s[11], s[15] = s[15], s[3], s[7], s[11]
    s = bytearray(b ^ k for b, k in zip(s, round_keys[Nr]))
    return bytes(s)

def _pkcs7_pad(data, block_size=16):
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)

def _aes_cbc_encrypt(data, key, iv):
    data = _pkcs7_pad(data)
    rk = _aes_key_expansion(key)
    out = bytearray()
    prev = iv
    for i in range(0, len(data), 16):
        block = bytes(d ^ p for d, p in zip(data[i:i+16], prev))
        enc = _aes_encrypt_block(block, rk)
        out.extend(enc)
        prev = enc
    return bytes(out)

def aes_encrypt_hex(hex_str: str) -> bytes:
    data = bytes.fromhex(hex_str)
    return _aes_cbc_encrypt(data, AES_KEY, AES_IV)

# ─── Protobuf Encoding ─────────────────────────────────────────────────────
def _enc_varint(n):
    buf = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        buf.append(b)
        if not n:
            break
    return bytes(buf)

def _make_bytes_field(field_num, value):
    if isinstance(value, str):
        value = value.encode('utf-8')
    header = _enc_varint((field_num << 3) | 2)
    return header + _enc_varint(len(value)) + value

def _make_int64_field(field_num, value):
    if value < 0:
        value = value + (1 << 64)
    return _enc_varint((field_num << 3) | 0) + _enc_varint(value)

def _make_int32_field(field_num, value):
    if value < 0:
        value = value + (1 << 64)
    return _enc_varint((field_num << 3) | 0) + _enc_varint(value)

# ─── Protobuf Decoding ─────────────────────────────────────────────────────
def _dec_varint(data, pos):
    result = 0
    shift = 0
    while pos < len(data):
        b = data[pos]
        result |= (b & 0x7F) << shift
        pos += 1
        if not (b & 0x80):
            break
        shift += 7
    return result, pos

def _decode_proto(data):
    result = {}
    pos = 0
    length = len(data)
    while pos < length:
        tag, pos = _dec_varint(data, pos)
        field_num = tag >> 3
        wire_type = tag & 0x07
        if wire_type == 0:
            val, pos = _dec_varint(data, pos)
            result[str(field_num)] = {"wire_type": "varint", "data": val}
        elif wire_type == 2:
            vlen, pos = _dec_varint(data, pos)
            chunk = data[pos:pos + vlen]
            pos += vlen
            try:
                s = chunk.decode('utf-8')
                result[str(field_num)] = {"wire_type": "string", "data": s}
            except:
                result[str(field_num)] = {"wire_type": "bytes", "data": chunk.hex()}
    return result

def decode_response(content_hex: str):
    try:
        data = bytes.fromhex(content_hex)
        return _decode_proto(data)
    except:
        return None

# ─── HTTP Helper ───────────────────────────────────────────────────────────
def _http_post(url, data, headers, timeout=12):
    if isinstance(data, str): data = data.encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        raw = resp.read()
        if resp.headers.get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        return resp.status, raw
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.headers.get("Content-Encoding") == "gzip":
            try: raw = gzip.decompress(raw)
            except: pass
        return e.code, raw
    except Exception as e:
        raise e

def _http_post_json(url, data, headers, timeout=12):
    status, raw = _http_post(url, data, headers, timeout)
    try:
        j = json.loads(raw)
    except:
        j = None
    return status, j

# ─── MajorLogin Proto ─────────────────────────────────────────────────────
def get_ff_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def _build_major_login_proto(access_token, open_id, lang):
    buf = bytearray()

    buf += _make_bytes_field(3, get_ff_timestamp())
    buf += _make_bytes_field(4, "free fire")
    buf += _make_int32_field(5, 1)

    buf += _make_bytes_field(7, "1.128.15")
    buf += _make_bytes_field(8, "Android OS 9 / API-28 (TP1A.220624.014/S908EXXS2BWA2)")
    buf += _make_bytes_field(9, "Handheld")

    buf += _make_bytes_field(10, "Bouygues Telecom")
    buf += _make_bytes_field(11, "WIFI")
    buf += _make_int32_field(12, 1600)
    buf += _make_int32_field(13, 900)
    buf += _make_bytes_field(14, "240")
    buf += _make_bytes_field(15, "ARMv7 VFPv3 NEON | 2000 | 4")
    buf += _make_int32_field(16, 3940)
    buf += _make_bytes_field(17, "Adreno (TM) 540")
    buf += _make_bytes_field(18, "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)")

    buf += _make_bytes_field(19, "Google|c5e5916a-9e46-43ac-80eb-ac5c8d7c79f4")
    buf += _make_bytes_field(20, "165.169.250.93")
    buf += _make_bytes_field(21, lang)
    buf += _make_bytes_field(22, open_id)
    buf += _make_bytes_field(23, "4")
    buf += _make_bytes_field(24, "Handheld")
    buf += _make_bytes_field(25, "samsung SM-S908E")
    buf += _make_bytes_field(26, "SAC")

    buf += _make_bytes_field(29, access_token)
    buf += _make_int32_field(30, 1)

    buf += _make_bytes_field(41, "Bouygues Telecom")
    buf += _make_bytes_field(42, "WIFI")

    buf += _make_bytes_field(57, "7428b253defc164018c604a1ebbfebdf")

    buf += _make_int32_field(60, 128886)
    buf += _make_int32_field(61, 110040)
    buf += _make_int32_field(62, 7998)
    buf += _make_int32_field(63, 5785)
    buf += _make_int32_field(64, 116610)
    buf += _make_int32_field(65, 128886)
    buf += _make_int32_field(66, 116610)
    buf += _make_int32_field(67, 128886)

    buf += _make_int32_field(73, 3)

    buf += _make_bytes_field(
        74,
        "/data/app/com.dts.freefireth-N2j2LDFXiAwrMyg4vPAhRA==/lib/arm64"
    )

    buf += _make_int32_field(76, 1)

    buf += _make_bytes_field(
        77,
        "4c322aeb56444feaa151d1ea91a8f7f2|/data/app/com.dts.freefireth-N2j2LDFXiAwrMyg4vPAhRA==/base.apk"
    )

    buf += _make_int32_field(78, 3)
    buf += _make_int32_field(79, 2)

    buf += _make_bytes_field(81, "64")
    buf += _make_bytes_field(83, "2019120828")

    buf += _make_int32_field(85, 3)
    buf += _make_bytes_field(86, "OpenGLES2")
    buf += _make_int32_field(87, 4095)
    buf += _make_int32_field(88, 4)

    buf += _make_int32_field(92, 24994)
    buf += _make_bytes_field(93, "android")

    buf += _make_bytes_field(
        94,
        "KqsHTyHS2cHCDbUIIwVJhWnmtfKktJ8sLzf/1t/g61BV4NOMX/ksSJEl/+VrxS1NVdXUGpnBV2k/wRn9vw0qBZi5icA="
    )

    buf += _make_int32_field(95, 111207)
    buf += _make_bytes_field(
        96,
        '{"cur_rate":null,"support_etc2":false}'
    )

    buf += _make_int32_field(97, 1)
    buf += _make_int32_field(98, 1)

    buf += _make_bytes_field(99, "4")
    buf += _make_bytes_field(100, "4")

    return bytes(buf)

def _build_login_data_proto(access_token, open_id, lang, region):
    buf = bytearray()

    buf += _make_bytes_field(3, get_ff_timestamp())
    buf += _make_bytes_field(4, "free fire")
    buf += _make_int32_field(5, 1)

    buf += _make_bytes_field(7, "1.128.15")
    buf += _make_bytes_field(8, "Android OS 9 / API-28 (TP1A.220624.014/S908EXXS2BWA2)")
    buf += _make_bytes_field(9, "Handheld")
    buf += _make_bytes_field(10, "Bouygues Telecom")
    buf += _make_bytes_field(11, "WIFI")

    buf += _make_int32_field(12, 1600)
    buf += _make_int32_field(13, 900)

    buf += _make_bytes_field(14, "240")
    buf += _make_bytes_field(15, "ARMv7 VFPv3 NEON | 2000 | 4")
    buf += _make_int32_field(16, 3940)
    buf += _make_bytes_field(17, "Adreno (TM) 540")
    buf += _make_bytes_field(18, "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)")

    buf += _make_bytes_field(19, "Google|c5e5916a-9e46-43ac-80eb-ac5c8d7c79f4")
    buf += _make_bytes_field(20, "165.169.250.93")
    buf += _make_bytes_field(21, lang)
    buf += _make_bytes_field(22, open_id)
    buf += _make_bytes_field(23, "4")
    buf += _make_bytes_field(24, "Handheld")
    buf += _make_bytes_field(25, "samsung SM-S908E")
    buf += _make_bytes_field(26, region)

    buf += _make_bytes_field(29, access_token)
    buf += _make_int32_field(30, 1)

    buf += _make_bytes_field(41, "Bouygues Telecom")
    buf += _make_bytes_field(42, "WIFI")

    buf += _make_bytes_field(57, "7428b253defc164018c604a1ebbfebdf")

    buf += _make_int32_field(60, 128886)
    buf += _make_int32_field(61, 110040)
    buf += _make_int32_field(62, 7998)
    buf += _make_int32_field(63, 5785)
    buf += _make_int32_field(64, 116610)
    buf += _make_int32_field(65, 128886)
    buf += _make_int32_field(66, 116610)
    buf += _make_int32_field(67, 128886)

    buf += _make_int32_field(73, 3)
    buf += _make_bytes_field(
        74,
        "/data/app/com.dts.freefireth-N2j2LDFXiAwrMyg4vPAhRA==/lib/arm64"
    )

    buf += _make_int32_field(76, 1)

    buf += _make_bytes_field(
        77,
        "4c322aeb56444feaa151d1ea91a8f7f2|/data/app/com.dts.freefireth-N2j2LDFXiAwrMyg4vPAhRA==/base.apk"
    )

    buf += _make_int32_field(78, 3)
    buf += _make_int32_field(79, 2)

    buf += _make_bytes_field(81, "64")
    buf += _make_bytes_field(83, "2019120828")

    buf += _make_int32_field(85, 3)
    buf += _make_bytes_field(86, "OpenGLES2")
    buf += _make_int32_field(87, 4095)
    buf += _make_int32_field(88, 4)

    buf += _make_bytes_field(90, "Saint-Denis")

    buf += _make_int32_field(92, 24994)
    buf += _make_bytes_field(93, "android")

    buf += _make_bytes_field(
        94,
        "KqsHTyHS2cHCDbUIIwVJhWnmtfKktJ8sLzf/1t/g61BV4NOMX/ksSJEl/+VrxS1NVdXUGpnBV2k/wRn9vw0qBZi5icA="
    )

    buf += _make_int32_field(95, 111207)

    buf += _make_bytes_field(
        96,
        '{"cur_rate":null,"support_etc2":false}'
    )

    buf += _make_int32_field(97, 1)
    buf += _make_int32_field(98, 1)

    buf += _make_bytes_field(99, "0")
    buf += _make_bytes_field(100, "4")

    # Champ 102 (length_delimited vide)
    buf += _make_bytes_field(102, b"")

    # Champ 103
    buf += _make_int32_field(103, 1)

    return bytes(buf)

shutdown_requested = threading.Event()  # Set by Ctrl-C handler

def _build_newbie_choice_proto(game_uid, choice=1, slot=3):
    buf = bytearray()
    buf += _make_int64_field(1, game_uid)
    buf += _make_int32_field(2, choice)
    buf += _make_int32_field(3, slot)
    return bytes(buf)

def _build_generic_proto(fields):
    buf = bytearray()
    for f, v in fields.items():
        if isinstance(v, int):
            buf += _enc_varint((f << 3) | 0) + _enc_varint(v)
        elif isinstance(v, (str, bytes)):
            buf += _make_bytes_field(f, v)
    return bytes(buf)

# ─── Fonctions API ────────────────────────────────────────────────────────

def garena_token(uid, password):
    # On s'assure que le cookie est frais avant chaque tentative
    fetch_datadome_cookie()
    retries = 3
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "Host": "100067.connect.garena.com",
        "Connection": "close",
        "Accept-Encoding": "gzip",
        "Cookie": DATADOME_COOKIE          # ← CORRECT
    }
    body = {
        "uid": int(uid),
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067",
    }
    url = "https://100067.connect.garena.com/api/v2/oauth/guest/token:grant"

    for attempt in range(retries):
        if shutdown_requested.is_set():
            raise KeyboardInterrupt
        try:
            resp = requests.post(url, json=body, headers=headers, timeout=12)
            j = resp.json() if resp.text else None
            log("TOKEN", f"Status {resp.status_code}, response: {j}", C)

            if resp.status_code != 200:
                continue

            if j and "url" in j and "captcha-delivery.com" in j.get("url", ""):
                raise RateLimitException("Datadome Captcha in Token Grant")

            db = j.get("data", j)
            if "open_id" in db and "access_token" in db:
                return db["open_id"], db["access_token"]

        except requests.exceptions.RequestException as e:
            log("RETRY", f"garena_token attempt {attempt+1}/{retries}: {e}", Y)

        time.sleep(1)

    raise Exception("garena_token failed after retries")

def major_login(access_token, open_id, lang, region=""):
    region_up = region.upper()
    url = REGION_LOGIN_SERVER.get(region_up, "https://loginbp.ggpolarbear.com/MajorLogin")
    host = url.split("/")[2]
    headers = {
        "Accept-Encoding": "gzip", "Authorization": "Bearer", "Connection": "close",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": host, "ReleaseVersion": "OB54",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)",
        "X-GA": "v1 1", "X-Unity-Version": "2018.4.11f1"
    }
    proto_bytes = _build_major_login_proto(access_token, open_id, lang)
    enc = aes_encrypt_hex(proto_bytes.hex())
    status, content = _http_post(url, enc, headers, timeout=12)
    if status == 200:
        return status, content.hex() if content else None
    return status, None

def choose_region(jwt_token, region_code):
    base = REGION_LOGIN_URLS.get(region_code.upper(), "https://loginbp.ggpolarbear.com/")
    url = base + "ChooseRegion"
    payload = _build_generic_proto({1: region_code, 2: 1})
    enc_payload = aes_encrypt_hex(payload.hex())
    headers = {
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; M2101K7AG Build/SKQ1.210908.001)",
        "Connection": "close", "Accept-Encoding": "gzip",
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Bearer {jwt_token}", "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1", "ReleaseVersion": "OB54"
    }
    status, content = _http_post(url, enc_payload, headers, timeout=12)
    return status, content.hex() if content else None

def choose_newbie_choice(jwt_token, game_uid: int):
    url = "https://loginbp.ggpolarbear.com/ChooseNewbieChoice"
    proto_bytes = _build_newbie_choice_proto(game_uid)
    enc_payload = aes_encrypt_hex(proto_bytes.hex())
    headers = {
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; M2101K7AG Build/SKQ1.210908.001)",
        "Connection": "close", "Accept-Encoding": "gzip",
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Bearer {jwt_token}", "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1", "ReleaseVersion": "OB54"
    }
    status, content = _http_post(url, enc_payload, headers, timeout=12)
    return status, content.hex() if content else None

def get_login_data(jwt_token, access_token, external_id, sig_md5, region, open_id):
    proto_bytes = _build_login_data_proto(access_token, open_id, "en", region)
    enc = aes_encrypt_hex(proto_bytes.hex())
    url = "https://clientbp.ggpolarbear.com/GetLoginData"
    print(jwt_token)
    headers = {
        "Authorization": f"Bearer {jwt_token}",
        "X-Unity-Version": "2022.3.47f1", "X-GA": "v1 1", "ReleaseVersion": "OB54",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Connection": "close", "Accept-Encoding": "gzip",
    }
    status, content = _http_post(url, enc, headers, timeout=12)
    print(content)
    print("STATTTTTTTTTTTUSSS :",status)
    if status == 200:
        return decode_response(content.hex())
    else:
        log("ERR", f"GetLoginData Failed (Status: {status})", R)
        return None

def ping():
    url = "https://loginbp.ggpolarbear.com/Ping"
    payload = bytes.fromhex("1a725b2c56ec52ba7d09623454c0a003")
    enc_payload = payload
    headers = {
        "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Connection": "close",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": "Bearer ",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB54",
        "X-Unity-Version": "2022.3.47f1"
    }

    try:
        status, content = _http_post(url, enc_payload, headers, timeout=12)
        return status
    except Exception as e:
        log("PING", f"exception: {e}", R)
        return 0

# ─── JWT Helpers ─────────────────────────────────────────────────────────────
_JWT_PREFIX_SVC1 = "eyJhbGciOiJIUzI1NiIsInZ2ciI6IjEiLCJ0eXAiOiJKV1QifQ"

def extract_jwt(response_obj, lang, raw_text=""):
    try:
        jwt = response_obj.get("8", {}).get("data", "")
        if isinstance(jwt, str) and jwt:
            second_dot = jwt.find(".", jwt.find(".") + 1)
            return jwt[:second_dot + 44] if second_dot != -1 else jwt
    except:
        pass
    if raw_text and _JWT_PREFIX_SVC1 in raw_text:
        idx = raw_text.find(_JWT_PREFIX_SVC1)
        candidate = raw_text[idx:]
        second_dot = candidate.find(".", candidate.find(".") + 1)
        if second_dot != -1:
            return candidate[:second_dot + 44]
    return None

def decode_jwt_payload(jwt: str):
    try:
        part = jwt.split(".")[1]
        part += "=" * ((4 - len(part) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(part).decode())
        eid = payload.get("external_id")
        sig = payload.get("signature_md5")
        sub = payload.get("sub")
        return eid, sig, sub
    except:
        return None, None, None

# ─── Main Activation Function ─────────────────────────────────────────────
def activate_account(uid, password, region="SAC"):
    lang = REGION_LANG.get(region.upper(), "en")

    log("INFO", f"[1] Getting Token for {uid}...", C)
    open_id, access_token = garena_token(uid, password)
    if not open_id:
        log("ERR", f"[X] Token Failed for {uid}", R)
        return None

    log("OK", f"[✓] Token OK | OpenID: {open_id[:20]}...", G)

    log("INFO", f"[2] MajorLogin (Get JWT)...", C)
    login_status, login_hex = major_login(access_token, open_id, lang, region)
    if login_status != 200 or not login_hex:
        log("ERR", f"[X] MajorLogin Failed (Status: {login_status})", R)
        return None

    parsed = decode_response(login_hex)
    jwt = extract_jwt(parsed, lang, login_hex)
    if not jwt:
        log("ERR", "[X] JWT Extract Failed", R)
        return None

    log("OK", "[✓] JWT Obtained", G)

    ext_id, sig_md5, sub = decode_jwt_payload(jwt)
    game_uid = sub if sub else 0

    log("INFO", "[3] ChooseNewbieChoice...", C)
    nc_status, nc_hex = choose_newbie_choice(jwt, game_uid)
    if nc_status == 200:
        log("OK", "[✓] Character Selected", G)
    else:
        log("WARN", f"[!] Character Selection Status: {nc_status}", Y)

    log("INFO", f"[4] ChooseRegion ({region})...", C)
    r_region = "RU" if region.upper() == "CIS" else region.upper()
    cr_status, cr_hex = choose_region(jwt, r_region)
    if cr_status in (200, 400):
        log("OK", f"[✓] Region Selected ({r_region})", G)
    else:
        log("WARN", f"[!] Region Status: {cr_status}", Y)

    log("INFO", "[5] MajorLogin Again...", C)
    login_status2, login_hex2 = major_login(access_token, open_id, lang, region)
    if login_status2 != 200:
        log("ERR", "[X] Final Login Failed", R)
        return None

    parsed2 = decode_response(login_hex2)
    jwt_final = extract_jwt(parsed2, lang, login_hex2)
    if jwt_final:
        jwt = jwt_final

    log("OK", "[✓] Final Sync OK", G)

    ping_status = ping()
    if ping_status != 200:
        log("WARN", f"Ping status {ping_status}", R)
    else:
        log("OK", f"Ping status {ping_status}", G)

    log("INFO", "[6] GetLoginData...", C)
    if ext_id and sig_md5:
        login_data = get_login_data(jwt, access_token, ext_id, sig_md5, region, open_id)
        if login_data:
            try:
                raw_uid = login_data.get("1", {}).get("data", 0)
                game_uid = int(raw_uid)
            except:
                pass

    ping_status = ping()
    if ping_status != 200:
        log("WARN", f"Ping status {ping_status}", R)
    else:
        log("OK", f"Ping status {ping_status}", G)

    log("SUCCESS", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", G)
    log("SUCCESS", "│ ACCOUNT ACTIVATED SUCCESSFULLY!", G)
    log("SUCCESS", f"│ UID:       {uid}", G)
    log("SUCCESS", f"│ PASSWORD:  {password}", G)
    log("SUCCESS", f"│ GAME UID:  {game_uid}", G)
    log("SUCCESS", f"│ REGION:    {region.upper()}", G)
    log("SUCCESS", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", G)

    with file_lock:
        with open(f"{region.upper()}_activated_accounts.txt", "a") as f:
            f.write(f"{uid}:{password}:{game_uid}:{region.upper()}\n")

    return {
        "uid": uid,
        "password": password,
        "game_uid": game_uid,
        "region": region.upper()
    }

# ─── Lecture des comptes depuis fichiers ──────────────────────────────────
def read_accounts_from_file(filename="accounts.txt"):
    """Lit un fichier texte au format uid:password"""
    accounts = []
    try:
        with open(filename, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    parts = line.split(":")
                    if len(parts) >= 2:
                        accounts.append({
                            "uid": parts[0],
                            "password": parts[1]
                        })
    except FileNotFoundError:
        log("ERR", f"[X] File {filename} not found!", R)
    return accounts

def read_accounts_from_json(filename="accounts.json"):
    """Lit un fichier JSON contenant un tableau d'objets avec uid et password"""
    accounts = []
    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                for item in data:
                    uid = item.get("uid")
                    password = item.get("password")
                    region = item.get("region")  # optionnel
                    if uid and password:
                        acc = {"uid": str(uid), "password": str(password)}
                        if region:
                            acc["region"] = region
                        accounts.append(acc)
            else:
                log("ERR", "JSON root must be an array", R)
    except FileNotFoundError:
        log("ERR", f"[X] File {filename} not found!", R)
    except json.JSONDecodeError as e:
        log("ERR", f"Invalid JSON: {e}", R)
    return accounts

# ─── Entry Point ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    os.system("cls" if os.name == "nt" else "clear")
    print(f"""
{B}{C}
 ██████╗ ██████╗ ███████╗ █████╗ ████████╗
██╔════╝ ██╔══██╗██╔════╝██╔══██╗╚══██╔══╝
██║  ███╗██████╔╝█████╗  ███████║   ██║   
██║   ██║██╔══██╗██╔══╝  ██╔══██║   ██║   
╚██████╔╝██║  ██║███████╗██║  ██║   ██║   
 ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   
{RST}{G}Account Activation Suite (Multi-Threaded){RST}
""")

    print(f"{C}[?] Input mode:{RST}")
    print(f"  {Y}1{RST} - Read from accounts.txt (Batch Mode)")
    print(f"  {Y}2{RST} - Manual input")
    print(f"  {Y}3{RST} - Read from accounts.json (Batch Mode, JSON format)")

    mode = input(f"{C}[>] Select: {RST}").strip()

    if mode == "1":
        # Récupérer un cookie frais avant le batch
        fetch_datadome_cookie()

        accounts = read_accounts_from_file()
        if not accounts:
            log("ERR", "[X] No accounts found in accounts.txt", R)
            sys.exit(1)

        region = input(f"{C}[>] Region (default BD): {RST}") or "BD"

        log("INFO", f"\n[*] Found {len(accounts)} accounts to activate", Y)
        log("INFO", f"[*] Starting threads (20 concurrent)...\n", Y)

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            future_to_acc = {executor.submit(activate_account, acc["uid"], acc["password"], region): acc for acc in accounts}

            for future in concurrent.futures.as_completed(future_to_acc):
                acc = future_to_acc[future]
                try:
                    result = future.result()
                    if result:
                        pass
                    else:
                        log("ERR", f"[X] Activation failed for {acc['uid']}", R)
                except Exception as exc:
                    log("ERR", f"[X] Exception for {acc['uid']}: {exc}", R)

        log("OK", f"\n[✓] Done! Check {region.upper()}_activated_accounts.txt", G)

    elif mode == "3":
        # Mode JSON
        fetch_datadome_cookie()

        # On peut demander le nom du fichier ou utiliser un nom par défaut
        json_file = input(f"{C}[>] JSON filename (default accounts.json): {RST}") or "accounts.json"
        accounts = read_accounts_from_json(json_file)
        if not accounts:
            log("ERR", "[X] No accounts found in JSON file", R)
            sys.exit(1)

        # On peut demander une région par défaut, mais on utilise celle de chaque compte si présente
        default_region = input(f"{C}[>] Default region (BD) - overridden by per-account 'region' if set: {RST}") or "BD"

        log("INFO", f"\n[*] Found {len(accounts)} accounts in JSON", Y)
        log("INFO", f"[*] Starting threads (20 concurrent)...\n", Y)

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            future_to_acc = {}
            for acc in accounts:
                region = acc.get("region", default_region)
                future = executor.submit(activate_account, acc["uid"], acc["password"], region)
                future_to_acc[future] = acc

            for future in concurrent.futures.as_completed(future_to_acc):
                acc = future_to_acc[future]
                try:
                    result = future.result()
                    if result:
                        pass
                    else:
                        log("ERR", f"[X] Activation failed for {acc['uid']}", R)
                except Exception as exc:
                    log("ERR", f"[X] Exception for {acc['uid']}: {exc}", R)

        log("OK", f"\n[✓] Done! Check activated files for each region.", G)

    else:
        # Mode manuel
        uid = input(f"{C}[>] UID: {RST}").strip()
        password = input(f"{C}[>] Password: {RST}").strip()
        region = input(f"{C}[>] Region (default BD): {RST}") or "BD"

        # Cookie frais pour le mode manuel aussi
        fetch_datadome_cookie()

        result = activate_account(uid, password, region)
        if result:
            log("OK", "\n[✓] Account activated successfully!", G)
        else:
            log("ERR", "\n[X] Activation failed", R)