# -*- coding: utf-8 -*-
# ─── app.py — VERSION FINALE CORRIGÉE : Anti-429 + ChooseRegion fix + Save early + HTTP text dump ───
import hmac, hashlib, string, random, json, codecs, time, base64
import os, sys, gc, struct, gzip, re, itertools
import urllib.request, urllib.error, urllib.parse, ssl
import asyncio, concurrent.futures, threading, signal
from datetime import datetime
from pathlib import Path

try:
    from google_play_scraper import app as play_scraper
    _HAS_PLAY_SCRAPER = True
except ImportError:
    _HAS_PLAY_SCRAPER = False

_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode = ssl.CERT_NONE

try:
    import aiohttp
except ImportError:
    print("❌ aiohttp not installed. Run: pip install aiohttp")
    sys.exit(1)

# ════════════════════════════════════════════════════════════════════════════
# GARENA ENDPOINT POOL
# ════════════════════════════════════════════════════════════════════════════
GARENA_REGISTER_ENDPOINTS = [
    "https://ffmconnect.ppmainecoonghj.com/api/v2/oauth/guest:register",
    "https://100067.connect.garena.com/api/v2/oauth/guest:register",
]

GARENA_TOKEN_ENDPOINTS = [
    "https://100067.connect.garena.com/api/v2/oauth/guest/token:grant",
    "https://ffmconnect.ppmainecoonghj.com/api/v2/oauth/guest/token:grant",
]

UA_POOL = [
    "GarenaMSDK/4.0.44(SM-G998B ;Android 9;fr;FR;app 1.132.1 2019121229;)",
    "GarenaMSDK/4.0.44(SM-S908E ;Android 9;fr;FR;app 1.132.1 2019121229;)",
    "GarenaMSDK/4.0.44(SM-S908E ;Android 9;en;US;app 1.132.1 2019121229;)",
    "GarenaMSDK/4.0.41(SM-G998B ;Android 9;fr;FR;app 1.132.1 2019121229;)",
]

_reg_cycle = itertools.cycle(GARENA_REGISTER_ENDPOINTS)
_tok_cycle = itertools.cycle(GARENA_TOKEN_ENDPOINTS)
_ua_cycle  = itertools.cycle(UA_POOL)

def _next_reg_url(): return next(_reg_cycle)
def _next_tok_url(): return next(_tok_cycle)
def _next_ua():      return next(_ua_cycle)

def _backoff_delay(attempt, base=1.5, cap=20):
    d = min(cap, base * (2 ** attempt))
    jitter = random.uniform(0.7, 1.3)
    return d * jitter

def _interruptible_sleep(seconds):
    end = time.time() + seconds
    while time.time() < end:
        if shutdown_requested.is_set():
            return False
        time.sleep(min(0.2, end - time.time()))
    return not shutdown_requested.is_set()

# ════════════════════════════════════════════════════════════════════════════
# Lokesh protobuf (app.proto)
# ════════════════════════════════════════════════════════════════════════════
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

_SERIALIZED_FILE_DESCRIPTOR = (
    b'\n\x0coutput.proto\x12\tapp.proto"\xfc\x03\n\x06Lokesh'
    b'\x12\x12\n\naccount_id\x18\x01 \x01(\x03'
    b'\x12\x0e\n\x06region\x18\x02 \x01(\t'
    b'\x12\r\n\x05place\x18\x03 \x01(\t'
    b'\x12\x10\n\x08location\x18\x04 \x01(\t'
    b'\x12\x0e\n\x06status\x18\x05 \x01(\t'
    b'\x12\r\n\x05token\x18\x08 \x01(\t'
    b'\x12\n\n\x02id\x18\t \x01(\x05'
    b'\x12\x0b\n\x03\x61pi\x18\n \x03(\x0c'
    b'\x12\x0e\n\x06number\x18\x0c \x01(\x05'
    b'\x12#\n\x08\x61imguard\x18\x0f \x01(\x0b\x32\x11.app.proto.Lokesh'
    b'\x12\x0c\n\x04\x61rea\x18\x10 \x01(\t'
    b'\x12\x11\n\tmain_area\x18\x12 \x01(\t'
    b'\x12\x0c\n\x04\x63ity\x18\x13 \x01(\t'
    b'\x12\x0c\n\x04name\x18\x14 \x01(\t'
    b'\x12\x11\n\ttimestamp\x18\x15 \x01(\x03'
    b'\x12\x0e\n\x06\x62inary\x18\x16 \x01(\x0c'
    b'\x12\x13\n\x0b\x62inary_data\x18\x17 \x01(\x0c'
    b'\x12\x0f\n\x07\x66ield24\x18\x18 \x01(\t'
    b'\x12*\n\x07\x66ield25\x18\x19 \x01(\x0b\x32\x19.app.proto.Lokesh.Field25'
    b'\x12\x0f\n\x07\x66ield27\x18\x1b \x01(\x0c'
    b'\x1a"\n\x12\x44\x65\x63rypted_Payloads\x12\x0c\n\x04type\x18\x01 \x01(\x05'
    b'\x1aY\n\x07\x46ield25'
    b'\x12\x0e\n\x06\x66ield1\x18\x01 \x01(\x0c'
    b'\x12\x0e\n\x06\x66ield2\x18\x02 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield5\x18\x05 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield6\x18\x06 \x01(\x05'
    b'\x12\x0e\n\x06\x66ield7\x18\x07 \x01(\x05'
    b'\x62\x06proto3'
)

_pool = descriptor_pool.DescriptorPool()
_file_proto = descriptor_pb2.FileDescriptorProto()
_file_proto.ParseFromString(_SERIALIZED_FILE_DESCRIPTOR)
_pool.Add(_file_proto)
Lokesh = message_factory.GetMessageClass(_pool.FindMessageTypeByName("app.proto.Lokesh"))

# ═══ AES-128-CBC pur Python ═══
_SBOX = (
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
)
_RCON = (0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36)

def _xtime(a): return ((a<<1)^0x1b)&0xFF if a&0x80 else (a<<1)&0xFF
def _mix_single(a):
    t=a[0]^a[1]^a[2]^a[3]; u=a[0]
    return [a[0]^_xtime(a[0]^a[1])^t, a[1]^_xtime(a[1]^a[2])^t,
            a[2]^_xtime(a[2]^a[3])^t, a[3]^_xtime(a[3]^u)^t]

def _aes_key_expansion(key):
    Nk,Nr=4,10; w=[0]*(4*(Nr+1))
    for i in range(Nk):
        w[i]=(key[4*i]<<24)|(key[4*i+1]<<16)|(key[4*i+2]<<8)|key[4*i+3]
    for i in range(Nk,4*(Nr+1)):
        t=w[i-1]
        if i%Nk==0:
            t=((_SBOX[(t>>16)&0xFF]<<24)|(_SBOX[(t>>8)&0xFF]<<16)|
               (_SBOX[t&0xFF]<<8)|_SBOX[(t>>24)&0xFF])
            t^=_RCON[i//Nk-1]<<24
        w[i]=w[i-Nk]^t
    rk=[]
    for r in range(Nr+1):
        k=bytearray(16)
        for j in range(4):
            v=w[r*4+j]; k[j*4]=(v>>24)&0xFF; k[j*4+1]=(v>>16)&0xFF
            k[j*4+2]=(v>>8)&0xFF; k[j*4+3]=v&0xFF
        rk.append(bytes(k))
    return rk

def _aes_encrypt_block(block, round_keys):
    Nr=10; s=bytearray(b^k for b,k in zip(block,round_keys[0]))
    for rnd in range(1,Nr):
        s=bytearray(_SBOX[b] for b in s)
        s[1],s[5],s[9],s[13]=s[5],s[9],s[13],s[1]
        s[2],s[6],s[10],s[14]=s[10],s[14],s[2],s[6]
        s[3],s[7],s[11],s[15]=s[15],s[3],s[7],s[11]
        for c in range(4):
            col=[s[c*4+r] for r in range(4)]; mixed=_mix_single(col)
            for r in range(4): s[c*4+r]=mixed[r]
        s=bytearray(b^k for b,k in zip(s,round_keys[rnd]))
    s=bytearray(_SBOX[b] for b in s)
    s[1],s[5],s[9],s[13]=s[5],s[9],s[13],s[1]
    s[2],s[6],s[10],s[14]=s[10],s[14],s[2],s[6]
    s[3],s[7],s[11],s[15]=s[15],s[3],s[7],s[11]
    return bytes(bytearray(b^k for b,k in zip(s,round_keys[Nr])))

_INV_SBOX=[0]*256
for _i,_v in enumerate(_SBOX): _INV_SBOX[_v]=_i

def _aes_decrypt_block(block, round_keys):
    Nr=10; s=bytearray(block)
    s=bytearray(b^k for b,k in zip(s,round_keys[Nr]))
    for rnd in range(Nr-1,0,-1):
        s[3],s[7],s[11],s[15]=s[15],s[3],s[7],s[11]
        s[2],s[6],s[10],s[14]=s[10],s[14],s[2],s[6]
        s[1],s[5],s[9],s[13]=s[5],s[9],s[13],s[1]
        s=bytearray(_INV_SBOX[b] for b in s)
        s=bytearray(b^k for b,k in zip(s,round_keys[rnd]))
        for c in range(4):
            col=[s[c*4+r] for r in range(4)]
            u=_xtime(_xtime(col[0]^col[2])); v=_xtime(_xtime(col[1]^col[3]))
            col[0]^=u; col[1]^=v; col[2]^=u; col[3]^=v
            mixed=_mix_single(col)
            for r in range(4): s[c*4+r]=mixed[r]
    s[3],s[7],s[11],s[15]=s[15],s[3],s[7],s[11]
    s[2],s[6],s[10],s[14]=s[10],s[14],s[2],s[6]
    s[1],s[5],s[9],s[13]=s[5],s[9],s[13],s[1]
    s=bytearray(_INV_SBOX[b] for b in s)
    return bytes(bytearray(b^k for b,k in zip(s,round_keys[0])))

def _pkcs7_pad(data, bs=16):
    pl=bs-(len(data)%bs); return data+bytes([pl]*pl)

def _aes_cbc_encrypt(data,key,iv):
    data=_pkcs7_pad(data); rk=_aes_key_expansion(key)
    out=bytearray(); prev=iv
    for i in range(0,len(data),16):
        block=bytes(d^p for d,p in zip(data[i:i+16],prev))
        out.extend(_aes_encrypt_block(block,rk)); prev=out[-16:]
    del rk; return bytes(out)

def _aes_cbc_decrypt(data,key,iv):
    rk=_aes_key_expansion(key); out=bytearray(); prev=iv
    for i in range(0,len(data),16):
        block=data[i:i+16]
        out.extend(_aes_decrypt_block(block,rk)); prev=block
    del rk
    if out and 1<=out[-1]<=16: out=out[:-out[-1]]
    return bytes(out)

# ═══ Globals ═══
class RateLimitException(Exception): pass
io_lock = threading.RLock()
shutdown_requested = threading.Event()
R="\033[91m"; G="\033[92m"; Y="\033[93m"; C="\033[96m"; M="\033[95m"
W="\033[97m"; B="\033[1m"; RST="\033[0m"

# ═══ KEYS ═══
hex_key = "32656534343831396539623435393838343531343130363762323831363231383734643064356437616639643866376530306331653534373135623764316533"
HMAC_KEY = bytes.fromhex(hex_key)
AES_KEY = bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56])
AES_IV  = bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])

DATADOME_COOKIE = "datadome=0TgYVopr1q2I7rZ~GdyOVhuiXeqIUgHZP_d4AJMgJReKDbPgb~sqqu8DJ21FLoV6dGaH5DzXfEwE9nlqa_q4SmJEVwVNPx0sp~yeNRlTyJYTbYow87bBfqxn3e~Qf1mF"
USER_AGENT = "GarenaMSDK/4.0.44(SM-G998B ;Android 9;fr;FR;app 1.132.1 2019121229;)"

CITY_GETLOGIN = "Saint-Denis"
DEVICE_DATA_GETLOGIN = "KqsHTwABrooayc1z2Lhk82icHO/ansALmo+nrX2nGTfCzhz3pAtNLVFBZXjBozd4tjlBeYYet/6WM74KeQ7fHq39bmhpWHV4xps7W5mkO+Aw6X7g"
CLIENT_IP = "165.169.250.93"

USER_ID = "Google|99c77376-1724-49f9-aed0-e5dffcb0b827"
UNIQUE_ID = "7428b253defc164018c604a1ebbfebdf"
LIBRARY_PATH = "/data/app/com.dts.freefireth-qmC1i_uQxu1Pnx-fvYwtWQ==/lib/arm"
LIBRARY_TOKEN = "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/com.dts.freefireth-qmC1i_uQxu1Pnx-fvYwtWQ==/base.apk"
DEVICE_DATA_MAJORLOGIN = "KqsHT1a6HW+b8YfXkio0C8RFUQf5l6xmjzIKUI63pEEkJIN7gAJNRQiKqQSIFnWs7Hc8jYrL9GY27JkQcaKTUeHt1+IP/zlnDQqkHtQJPTbp6J6a"

# ⚠️ Aligné sur les captures les plus récentes : domaine "aw" + hash "1.18c..."
HOT_UPDATE_URL = (
    "https://dl.aw.freefiremobile.com/live/ABHotUpdates/|"
    "https://core-aw.freefiremobile.com/live/ABHotUpdates/|"
    "a4332cb1c1a84e51dd77441e4856ed5a"
)
HOT_UPDATE_HASH = "1.18c76400d84e7629"

FIELD_102 = b'G]B\x14PZXS\x1aP_D\\WG\x0eG:YQ\x0fV\nqT\x11Vc\x16YW\nFk]\x043'

RESERVED = [
    (60, 128886),
    (61, 115131),   # fix: 115130 → 115131
    (62, 7998),
    (63, 5777),
    (64, 121701),   # fix: 121699 → 121701
    (65, 128886),
    (66, 121701),   # fix: 121699 → 121701
    (67, 128886),
]

REGION_LANG = {
    "PK":"ur","BD":"bn","IND":"hi","BR":"pt","US":"en","SAC":"es","NA":"en","SG":"en",
    "ID":"id","TW":"zh","TH":"th","VN":"vi","RU":"ru","ME":"ar","CIS":"ru","EU":"en",
}
REGION_URLS = {r:"https://clientbp.ppmainecoonghj.com/" for r in REGION_LANG}
REGION_URLS.update({
    "IND":"https://client.ind.freefiremobile.com/",

    "BR":"https://client.us.freefiremobile.com/",
    "SAC":"https://client.us.freefiremobile.com/",
    "NA": "https://client.us.freefiremobile.com/",
    "US": "https://client.us.freefiremobile.com/",
    "USA":"https://client.us.freefiremobile.com/",

    "EU":"https://clientbp.ppmainecoonghj.com/",
    "EUROPE":"https://clientbp.ppmainecoonghj.com/",
    "TH":"https://clientbp.ppmainecoonghj.com/",
    "BD": "https://clientbp.ppmainecoonghj.com/",
    "CIS":"https://clientbp.ppmainecoonghj.com/",
    "ID": "https://clientbp.ppmainecoonghj.com/",
    "ME": "https://clientbp.ppmainecoonghj.com/",
    "PK": "https://clientbp.ppmainecoonghj.com/",
    "SG": "https://clientbp.ppmainecoonghj.com/",
    "TW": "https://clientbp.ppmainecoonghj.com/",
    "VN": "https://clientbp.ppmainecoonghj.com/",
})
REGION_LOGIN_SERVER = {
    "ME":"https://loginbp.ppmainecoonghj.com/MajorLogin",
    "EU":"https://loginbp.ppmainecoonghj.com/MajorLogin",
}
REGION_LOGIN_URLS = {r:"https://loginbp.ppmainecoonghj.com/" for r in REGION_LANG}
LOGIN_URL_DEFAULT = "https://loginbp.ppmainecoonghj.com/"
OB = "OB55"

DEFAULT_VERSION_CODE = "1.132.9"
_VERSION_CODE = DEFAULT_VERSION_CODE

# ═══ PROTO HELPERS ═══
def _enc_varint(n):
    buf=bytearray()
    while True:
        b=n&0x7F; n>>=7
        if n: b|=0x80
        buf.append(b)
        if not n: break
    return bytes(buf)

def _dec_varint(data,pos):
    r=0; sh=0
    while pos<len(data):
        b=data[pos]; r|=(b&0x7F)<<sh; pos+=1
        if not (b&0x80): break
        sh+=7
    return r,pos

def _make_varint_field(n,v): return _enc_varint((n<<3)|0)+_enc_varint(v)
def _make_bytes_field(n,v):
    if isinstance(v,str): v=v.encode('utf-8')
    return _enc_varint((n<<3)|2)+_enc_varint(len(v))+v
def _make_int32_field(n,v):
    if v<0: v+=1<<64
    return _enc_varint((n<<3)|0)+_enc_varint(v)
def _make_int64_field(n,v):
    if v<0: v+=1<<64
    return _enc_varint((n<<3)|0)+_enc_varint(v)

def _decode_proto(data):
    result={}; pos=0; length=len(data)
    while pos<length:
        tag,pos=_dec_varint(data,pos)
        fn,wt=tag>>3,tag&7
        if wt==0:
            val,pos=_dec_varint(data,pos)
            result[str(fn)]={"wire_type":"varint","data":val}
        elif wt==2:
            vlen,pos=_dec_varint(data,pos)
            chunk=data[pos:pos+vlen]; pos+=vlen
            try:
                s=chunk.decode('utf-8')
                result[str(fn)]={"wire_type":"string","data":s}
            except:
                result[str(fn)]={"wire_type":"bytes","data":chunk.hex()}
        elif wt==1:
            val=struct.unpack_from('<Q',data,pos)[0]; pos+=8
            result[str(fn)]={"wire_type":"64bit","data":val}
        elif wt==5:
            val=struct.unpack_from('<I',data,pos)[0]; pos+=4
            result[str(fn)]={"wire_type":"32bit","data":val}
        else: break
    return result

def _safe_int(value, default=0):
    if value is None or value=="": return default
    if isinstance(value,bool): return int(value)
    if isinstance(value,int): return value
    if isinstance(value,(bytes,bytearray)):
        try: return int.from_bytes(value,"big")
        except: return default
    if isinstance(value,str):
        try: return int(value)
        except: return default
    return default

def _get_field(parsed,*field_nums,default=None):
    if not isinstance(parsed,dict): return default
    for fn in field_nums:
        key=str(fn) if not isinstance(fn,str) else fn
        if key in parsed:
            val=parsed[key].get("data") if isinstance(parsed[key],dict) else None
            if val is not None and val!="": return val
    return default

def aes_encrypt(data): return _aes_cbc_encrypt(data,AES_KEY,AES_IV)
def aes_decrypt(data): return _aes_cbc_decrypt(data,AES_KEY,AES_IV)
def aes_encrypt_hex(hex_str): return aes_encrypt(bytes.fromhex(hex_str))
def decode_response(content_hex):
    try: return _decode_proto(bytes.fromhex(content_hex))
    except Exception as e:
        log("ERR",f"decode_response: {e}",R); return None

def log(tag,msg,color=G):
    with io_lock:
        print(f"  {R}{B}[{color}{B}{tag}{R}{B}]{RST} {W}{msg}")

def step(n,total,msg):
    with io_lock:
        print(f"  {G}{B}[{n}/{total}]{RST} {C}{msg}{RST}")

def get_ff_timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# ════════════════════════════════════════════════════════════════════════════
# MAJOR_REGISTER — Field 22 blob (687 bytes, "GGRE" header) issu de la capture
# ════════════════════════════════════════════════════════════════════════════
MAJOR_REG_FIELD22 = bytes.fromhex(
    "47475245010101007b020000bde2af5a1527299c33c962f15d82cbbe64189d3b378daa880d422a59aed4d9b8a73beaf53ced710eea5a4bcf15ab6a2ceceabcab1bac5b6c769e550089a26a75c6f4b07f6123f0b119cbcd96c5d931a858229502d103a13ea4b694d0948091163a878e57c39194b19e7d84f808c42a9070dc00fcbee0cd9ffc058e7bc580ad44ab3febe571380c4a3147734216747d32af56127a462ed43d2e9c51b34599897618ac02495f90e0bd427e29c46c7995cdfb0813e43818ceda80b9739adccddc7ab10ad05b943b1bd0d7f9e4d73bc21275fda23bed086663336e9ecc90f9187b1569a7d046cfc3d8c063529dfde42645f5349e773ffbda18d944608bf95de71bca0247f86b7859c72aa7c4a6d13f87c1d8c6bb5ce12e2afff591c484a3e7fe9721ec691d656c7abe81dbd62642eeab7582c559a2b5627a59f21bbb1c354435478daff8c325b6a72c9b2daa551de964593503422d114059a90b8468242774d2dc09642b5bb78b861330c06fdda79c8fb2aeda7e3bbd5fccff1c1a15ee17fba519d31ccd4f27f3d9745ca8e7039da2351d626e5b9811501a4ff453cd463582313b75cb209e72c311a9b036bfe8d3983e7e11141de7d754b70752dfc4e592c38091908dcdb2947ab6e7161c44b2215dea1c8c176837ce762d9eb802d6b05393115679fdb92cba11d7999818691c1378a121541275531ef7f195eea9b819293386e187739be9c99bd95e2728cbcaf6d0c37cf2d16c2edd0b49e19dab27b4522d2b7c02eb72b4f89a28663b9e5a690121ccba0f2efc60621919990a5eae516b17ebfffeecdc8c7bbb409e49915adc59394a8803eac0ad580633218033670aef0e60db95a6fcf1205d996b3542ca4775bc2311751462ae9442472383241ed4342a9fbc733736129d59706620db67fa13c6363710c54e1c9568f0d348284dc10a8f36d5c1314746"
)

# ════════════════════════════════════════════════════════════════════════════
# BUILDERS
# ════════════════════════════════════════════════════════════════════════════
def _build_major_register_proto(name, access_token, open_id, field14, lang="en"):
    buf = bytearray()
    buf += _make_bytes_field(1, name)
    buf += _make_bytes_field(2, access_token)
    buf += _make_bytes_field(3, open_id)
    buf += _make_int64_field(5, 102000007)
    buf += _make_int32_field(6, 4)
    buf += _make_int32_field(7, 1)
    buf += _make_int32_field(13, 1)
    buf += _make_bytes_field(14, field14)
    buf += _make_bytes_field(15, lang)
    buf += _make_int32_field(16, 1)
    buf += _make_bytes_field(20, _VERSION_CODE)
    buf += _make_int32_field(21, 1)      # ← varint (et non bytes)
    buf += _make_bytes_field(22, MAJOR_REG_FIELD22)
    return bytes(buf)




def _build_major_login_proto(access_token, open_id, lang, region):
    buf = bytearray()

    buf += _make_bytes_field(3, get_ff_timestamp())
    buf += _make_bytes_field(4, "free fire")
    buf += _make_int32_field(5, 1)

    buf += _make_bytes_field(7, _VERSION_CODE)
    buf += _make_bytes_field(8, "Android OS 9 / API-28 (TP1A.220624.014/S908EXXS2BWA2)")
    buf += _make_bytes_field(9, "Handheld")
    buf += _make_bytes_field(10, "Bouygues Telecom")
    buf += _make_bytes_field(11, "WIFI")

    buf += _make_int32_field(12, 1334)
    buf += _make_int32_field(13, 750)

    buf += _make_bytes_field(14, "240")
    buf += _make_bytes_field(15, "ARMv7 VFPv3 NEON | 2000 | 4")
    buf += _make_int32_field(16, 7966)

    buf += _make_bytes_field(17, "Adreno (TM) 540")
    buf += _make_bytes_field(18, "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)")

    buf += _make_bytes_field(19, USER_ID)
    buf += _make_bytes_field(20, "165.169.250.93")
    buf += _make_bytes_field(21, lang)
    buf += _make_bytes_field(22, open_id)
    buf += _make_bytes_field(23, "4")
    buf += _make_bytes_field(24, "Handheld")
    buf += _make_bytes_field(25, "samsung SM-S908E")
    buf += _make_bytes_field(26, region)   # capture: "ME"

    buf += _make_bytes_field(29, access_token)
    buf += _make_int32_field(30, 1)

    buf += _make_bytes_field(41, "Bouygues Telecom")
    buf += _make_bytes_field(42, "WIFI")

    buf += _make_bytes_field(57, UNIQUE_ID)

    for n, v in RESERVED:
        buf += _make_int32_field(n, v)

    buf += _make_int32_field(73, 1)
    buf += _make_bytes_field(74, LIBRARY_PATH)
    buf += _make_int32_field(76, 1)
    buf += _make_bytes_field(77, LIBRARY_TOKEN)
    buf += _make_int32_field(78, 3)
    buf += _make_int32_field(79, 1)

    buf += _make_bytes_field(81, "32")
    buf += _make_bytes_field(83, "2019121229")

    buf += _make_int32_field(85, 3)
    buf += _make_bytes_field(86, "OpenGLES2")
    buf += _make_int32_field(87, 4095)
    buf += _make_int32_field(88, 4)

    # Pas de champ 90 dans la capture interceptée.
    buf += _make_int32_field(92, 7260)
    buf += _make_bytes_field(93, "android")
    buf += _make_bytes_field(94, DEVICE_DATA_MAJORLOGIN)
    buf += _make_int32_field(95, 111207)

    buf += _make_bytes_field(96, '{"cur_rate":null,"support_etc2":false}')
    buf += _make_int32_field(97, 1)
    buf += _make_int32_field(98, 1)

    buf += _make_bytes_field(99, "4")
    buf += _make_bytes_field(100, "4")

    buf += _make_bytes_field(102, FIELD_102)

    buf += _make_int32_field(104, 74728)
    buf += _make_int32_field(105, 1)

    buf += _make_bytes_field(106, HOT_UPDATE_URL)
    buf += _make_bytes_field(107, HOT_UPDATE_HASH)

    return bytes(buf)



def _build_get_login_data_proto(access_token, open_id, lang, region):
    version_code = _VERSION_CODE
    buf = bytearray()

    buf += _make_bytes_field(3, get_ff_timestamp())
    buf += _make_bytes_field(4, "free fire")
    buf += _make_int32_field(5, 1)

    buf += _make_bytes_field(7, version_code)
    buf += _make_bytes_field(8, "Android OS 9 / API-28 (TP1A.220624.014/S908EXXS2BWA2)")
    buf += _make_bytes_field(9, "Handheld")
    buf += _make_bytes_field(10, "Bouygues Telecom")
    buf += _make_bytes_field(11, "WIFI")

    buf += _make_int32_field(12, 1334)
    buf += _make_int32_field(13, 750)

    buf += _make_bytes_field(14, "240")
    buf += _make_bytes_field(15, "ARMv7 VFPv3 NEON | 2000 | 4")
    buf += _make_int32_field(16, 7966)     # fix: 3940 → 7966

    buf += _make_bytes_field(17, "Adreno (TM) 540")
    buf += _make_bytes_field(18, "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)")

    buf += _make_bytes_field(19, USER_ID)
    buf += _make_bytes_field(20, CLIENT_IP)
    buf += _make_bytes_field(21, lang)
    buf += _make_bytes_field(22, open_id)
    buf += _make_bytes_field(23, "4")      # fix: "8" → "4"
    buf += _make_bytes_field(24, "Handheld")
    buf += _make_bytes_field(25, "samsung SM-S908E")
    buf += _make_bytes_field(26, region)

    buf += _make_bytes_field(29, access_token)
    buf += _make_int32_field(30, 1)

    buf += _make_bytes_field(41, "Bouygues Telecom")
    buf += _make_bytes_field(42, "WIFI")

    buf += _make_bytes_field(57, UNIQUE_ID)

    for n, v in RESERVED:
        buf += _make_int32_field(n, v)

    buf += _make_int32_field(73, 1)
    buf += _make_bytes_field(74, LIBRARY_PATH)

    buf += _make_int32_field(76, 1)
    buf += _make_bytes_field(77, LIBRARY_TOKEN)
    buf += _make_int32_field(78, 3)
    buf += _make_int32_field(79, 1)        # fix: 2 → 1

    buf += _make_bytes_field(81, "32")     # fix: "64" → "32"
    buf += _make_bytes_field(83, "2019121229")

    buf += _make_int32_field(85, 3)
    buf += _make_bytes_field(86, "OpenGLES2")
    buf += _make_int32_field(87, 4095)
    buf += _make_int32_field(88, 4)        # fix: 8 → 4

    buf += _make_bytes_field(90, CITY_GETLOGIN)

    buf += _make_int32_field(92, 6399)     # fix: 7586 → 6399

    buf += _make_bytes_field(93, "android")
    buf += _make_bytes_field(94, DEVICE_DATA_GETLOGIN)
    buf += _make_int32_field(95, 111207)

    buf += _make_bytes_field(96, '{"cur_rate":null,"support_etc2":false}')
    buf += _make_int32_field(97, 1)
    buf += _make_int32_field(98, 1)

    buf += _make_bytes_field(99, "0")
    buf += _make_bytes_field(100, "4")     # fix: "8" → "4"

    buf += _make_bytes_field(102, b"")     # champ length_delimited vide

    buf += _make_int32_field(103, 1)

    buf += _make_int32_field(104, 74976)   # fix: 95455 → 74976
    buf += _make_int32_field(105, 1)

    buf += _make_bytes_field(106, HOT_UPDATE_URL)
    buf += _make_bytes_field(107, HOT_UPDATE_HASH)

    return bytes(buf)


def _build_login_get_desc_proto(lang, region):
    """LoginGetDesc : {1:lang, 2:1, 3:region, 4:1}."""
    buf = bytearray()
    buf += _make_bytes_field(1, lang)
    buf += _make_int32_field(2, 1)
    buf += _make_bytes_field(3, region.upper())
    buf += _make_int32_field(4, 1)
    return bytes(buf)


def _build_newbie_choice_proto(game_uid, choice=1, slot=3):
    buf = bytearray()
    buf += _make_int64_field(1, game_uid)
    buf += _make_int32_field(2, choice)
    buf += _make_int32_field(3, slot)
    return bytes(buf)

def _build_generic_proto(fields):
    buf = bytearray()
    for f, v in fields.items():
        if isinstance(v, int): buf += _make_varint_field(f, v)
        elif isinstance(v, (str, bytes)): buf += _make_bytes_field(f, v)
    return bytes(buf)

# ═══ NAMES / PASSWORD / OPEN-ID ═══
def generate_name(prefix="NEXX"):
    rr = "¹²³⁴⁵⁶⁷⁸⁹⁰"
    return prefix[:7] + ''.join(random.choices(rr, k=5))

# def generate_password(prefix="NEXX_"):
#     r = ''.join(random.choices(string.ascii_letters + string.digits, k=4)).upper()
#     return f"{prefix}{r}_THUG"


import secrets

def generate_password(prefix="NEXX_"):
    return "D1D3F1" + secrets.token_hex(29).upper()

KEYSTREAM = [
    0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x37,
    0x30,0x30,0x30,0x30,0x30,0x32,0x30,0x31,0x37,0x30,0x30,0x30,0x30,0x30,0x32,0x30
]
def encode_open_id(open_id):
    encoded = "".join(chr(ord(c) ^ KEYSTREAM[i % len(KEYSTREAM)]) for i, c in enumerate(open_id))
    esc = "".join(c if 32 <= ord(c) <= 126 else f"\\u{ord(c):04x}" for c in encoded)
    return codecs.decode(esc, "unicode_escape").encode("latin1")

# ════════════════════════════════════════════════════════════════════════════
# DATADOME — lock global + cooldown 15s
# ════════════════════════════════════════════════════════════════════════════
_dd_refresh_lock = threading.Lock()
_dd_last_refresh = 0.0
_DD_MIN_INTERVAL = 15.0

def fetch_datadome_cookie(force=False):
    global DATADOME_COOKIE, _dd_last_refresh

    with _dd_refresh_lock:
        now = time.time()
        if not force and (now - _dd_last_refresh) < _DD_MIN_INTERVAL:
            return False
        _dd_last_refresh = now

        payload = {
            "cid": "r8MklXjdM4iDrouWrzdvCr0RxpuiQxl37cfUiRoLiwaJqQPjmalf7wgnzkYLbHA~nLtUJB4PwauRizIztlyqNJJfQ6BGdKlvqKDslrgFxPF3_MVkx659U5vdRR~TPgJK",
            "ddv":"1.13.9","ddvc":"4.0.41","ddk":"AE3F04AD3F0D3A462481A337485081",
            "request":"https://100067.connect.garena.com/api/v2/oauth/guest:register",
            "os":"Android","osr":"9","osn":"P","osv":"28",
            "ua":USER_AGENT,
            "screen_x":"1600","screen_y":"900","screen_d":"240",
            "events":'[{"id":1,"message":"response validation","source":"sdk","date":1781377315862}]',
            "camera":'{"auth":"false","info":"{}"}',
            "mdl":"SM-S908E","prd":"b0qxxx","mnf":"samsung","dev":"b0q","hrd":"qcom",
            "fgp":"samsung/b0qxxx/b0q:9/TP1A.220624.014/S908EXXS2BWA2:user/release-keys",
            "tgs":"release-keys",
        }
        body = urllib.parse.urlencode(payload).encode("utf-8")
        req = urllib.request.Request(
            "https://api-sdk.datadome.co/sdk/", data=body, method="POST",
            headers={"Content-Type":"application/x-www-form-urlencoded",
                     "Accept-Encoding":"gzip","User-Agent":"okhttp/4.12.0"})
        try:
            with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding")=="gzip": raw=gzip.decompress(raw)
                j = json.loads(raw)
                cookie = j.get("cookie") or j.get("datadome") or j.get("dd_cookie")
                if cookie:
                    if not cookie.startswith("datadome="): cookie = "datadome=" + cookie
                    DATADOME_COOKIE = cookie
                    log("DD", f"Cookie refreshed: {cookie[:24]}…", G)
                    return True
        except Exception as e:
            log("DD", f"Cookie fetch failed: {e}", Y)
        return False

# ═══ HTTP HELPERS ═══
def _http_post(url, data, headers, timeout=12):
    if isinstance(data, str): data = data.encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    status = None
    raw = b""
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        raw = resp.read()
        if resp.headers.get("Content-Encoding")=="gzip": raw=gzip.decompress(raw)
        status = resp.status
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.headers.get("Content-Encoding")=="gzip":
            try: raw = gzip.decompress(raw)
            except: pass
        status = e.code
    except Exception as e:
        raise e

    try:
        text = raw.decode("utf-8", errors="replace")
    except Exception:
        try:
            text = raw.decode("latin1", errors="replace")
        except Exception:
            text = repr(raw)

    if status is not None and status != 200:
        try:
            with io_lock:
                print(f"  {R}{B}[HTTP {status}]{RST} {W}{url}{RST}")
                if text.strip():
                    snippet = text if len(text) <= 2000 else text[:2000] + "…[truncated]"
                    print(f"  {Y}{snippet}{RST}")
                else:
                    hexs = raw.hex()
                    snippet = hexs if len(hexs) <= 2000 else hexs[:2000] + "…[truncated]"
        except Exception:
            pass

    return status, raw, text

def _http_post_json(url, data, headers, timeout=12):
    s, raw, _ = _http_post(url, data, headers, timeout)
    try: j = json.loads(raw)
    except: j = None
    return s, j

# ════════════════════════════════════════════════════════════════════════════
# GARENA REGISTER
# ════════════════════════════════════════════════════════════════════════════
def garena_register(custom_pass="", pass_prefix="NEXX_", max_attempts=4):
    password = custom_pass if custom_pass else generate_password(pass_prefix)
    body = {"password": password, "client_type": 2, "source": 2, "app_id": 100067}
    json_data = json.dumps(body, separators=(",", ":"))
    sig = hmac.new(HMAC_KEY, json_data.encode("utf-8"), hashlib.sha256).hexdigest()

    last_status = None
    for attempt in range(max_attempts):
        if shutdown_requested.is_set():
            raise KeyboardInterrupt

        url  = _next_reg_url()
        host = url.split("/")[2]

        if attempt > 0:
            fetch_datadome_cookie()
            if not _interruptible_sleep(_backoff_delay(attempt - 1, base=2.0, cap=15)):
                raise KeyboardInterrupt

        headers = {
            "User-Agent": _next_ua(),
            "Authorization": "Signature " + sig,
            "Accept": "application/json",
            "Content-Type": "application/json; charset=utf-8",
            "Host": host,
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Cookie": DATADOME_COOKIE,
        }

        try:
            status, j = _http_post_json(url, json_data, headers, timeout=12)
            last_status = status

            if status == 200 and j and j.get("data", {}).get("uid"):
                uid = j["data"]["uid"]
                log("REGISTER", f"✅ uid={uid} (attempt {attempt+1})", G)
                return uid, password

            if status == 429 or (isinstance(j, dict) and
                                 "captcha-delivery.com" in str(j.get("url", ""))):
                if attempt == 0:
                    log("RATE", f"429 detected — entering backoff mode", Y)
                time.sleep(_backoff_delay(attempt, base=3.0, cap=20))
                continue

            if status in (403, 500, 502, 503, 504):
                time.sleep(_backoff_delay(attempt, base=2.0, cap=15))
                continue

        except Exception as e:
            if "getaddrinfo" not in str(e):
                log("RETRY", f"{host}: {e}", Y)
            time.sleep(_backoff_delay(attempt, base=1.5, cap=10))

    if last_status == 429:
        raise RateLimitException(f"Rate limit persistant après {max_attempts} essais")
    log("ERR", f"garena_register échoué (status={last_status})", R)
    return None, None

# ════════════════════════════════════════════════════════════════════════════
# GARENA TOKEN GRANT
# ════════════════════════════════════════════════════════════════════════════
def garena_token(uid, password, retries=4):
    body = {
        "client_id": 100067,
        "client_secret": HMAC_KEY.decode("utf-8"),
        "client_type": 2,
        "device_id": "02-202b5b02-b568-418d-8d7b-c1dbc9449e7b",
        "password": password,
        "response_type": "token",
        "uid": uid,
    }
    json_data = json.dumps(body, separators=(",", ":"))

    for attempt in range(retries):
        if shutdown_requested.is_set():
            raise KeyboardInterrupt

        url  = _next_tok_url()
        host = url.split("/")[2]

        if attempt > 0:
            fetch_datadome_cookie()
            time.sleep(_backoff_delay(attempt - 1, base=2.0, cap=15))

        headers = {
            "User-Agent": _next_ua(),
            "Accept": "application/json",
            "Content-Type": "application/json; charset=utf-8",
            "Host": host,
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Cookie": DATADOME_COOKIE,
        }

        try:
            status, j = _http_post_json(url, json_data, headers, timeout=12)

            if status == 200 and isinstance(j, dict):
                db = j.get("data", j)
                if "open_id" in db and "access_token" in db:
                    return db["open_id"], db["access_token"]

            if status == 429:
                time.sleep(_backoff_delay(attempt, base=3.0, cap=20))
                continue
            if status in (403, 500, 502, 503, 504):
                time.sleep(_backoff_delay(attempt, base=2.0, cap=15))
                continue

        except Exception as e:
            if "getaddrinfo" not in str(e):
                log("RETRY", f"token {host}: {e}", Y)
            time.sleep(_backoff_delay(attempt, base=1.5, cap=10))

    raise Exception("garena_token échoué")

# ═══ MAJOR APIs ═══
def major_register(access_token, open_id, field14, name):
    headers = {
        "Host": "loginbp.ppmainecoonghj.com",
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept": "*/*",
        "Accept-Encoding": "deflate, gzip",
        "X-GA-SV": str(int(time.time())),   # dynamique
        "Authorization": "Bearer ",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB55",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Unity-Version": "2018.4.12f1",
    }
    proto_bytes = _build_major_register_proto(name, access_token, open_id, field14)
    raw = aes_encrypt_hex(proto_bytes.hex())
    print(f"  [MAJOR REGISTER] plaintext={len(proto_bytes)}B ciphertext={len(raw)}B")
    status, content, _ = _http_post(
        "https://loginbp.ppmainecoonghj.com/MajorRegister", raw, headers, 12)
    return content.hex(), status

def ping(token="", region="", retries=3):
    url = "https://clientbp.ppmainecoonghj.com/Ping"
    host = url.split("/")[2]
    headers = {
        "Accept-Encoding":"gzip",
        "Authorization": f"Bearer {token}" if token else "Bearer",
        "Connection":"close",
        "Content-Type":"application/x-www-form-urlencoded",
        "Host":host,"ReleaseVersion":OB,
        "User-Agent":"Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)",
        "X-GA":"v1 1","X-Unity-Version":"2018.4.12f1",
    }
    enc = bytes.fromhex("1a725b2c56ec52ba7d09623454c0a003")
    for attempt in range(retries):
        if shutdown_requested.is_set(): raise KeyboardInterrupt
        try:
            status, content, _ = _http_post(url, enc, headers, 12)
            if status == 200: return status, content.hex()
        except Exception as e:
            pass
        time.sleep(0.5)
    return None, None

def major_login(access_token, open_id, lang, region="", retries=3):
    region_up = region.upper()
    url = REGION_LOGIN_SERVER.get(region_up,
        "https://loginbp.ppmainecoonghj.com/MajorLogin")
    headers = {
        "User-Agent":"UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept":"*/*","Accept-Encoding":"deflate, gzip",
        "X-Ga-Sv": str(int(time.time())),   # dynamique
        "Authorization":"Bearer ",
        "X-Ga":"v1 1",
        "Releaseversion":OB,
        "Content-Type":"application/x-www-form-urlencoded",
        "X-Unity-Version":"2018.4.12f1",
    }
    proto_bytes = _build_major_login_proto(access_token, open_id, lang, region_up)
    enc = aes_encrypt_hex(proto_bytes.hex())
    for attempt in range(retries):
        if shutdown_requested.is_set(): raise KeyboardInterrupt
        try:
            status, content, _ = _http_post(url, enc, headers, 12)

            if status == 200: return status, content.hex()
        except Exception as e:
            pass
        time.sleep(0.5)
    return None, None

# ════════════════════════════════════════════════════════════════════════════
# ✅ CHOOSE REGION
# ════════════════════════════════════════════════════════════════════════════
def choose_region(jwt_token, region_code):
    base = REGION_LOGIN_URLS.get(region_code.upper(), LOGIN_URL_DEFAULT)
    url = base + "ChooseRegion"
    host = url.split("/")[2]

    payload = _build_generic_proto({1: region_code})
    enc_payload = aes_encrypt_hex(payload.hex())

    headers = {
        "Host": host,
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept": "*/*",
        "Accept-Encoding": "deflate, gzip",
        "X-GA-SV": str(int(time.time())),
        "Authorization": f"Bearer {jwt_token}",
        "X-GA": "v1 1",
        "ReleaseVersion": OB,
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Unity-Version": "2018.4.12f1",
    }

    for attempt in range(3):
        if shutdown_requested.is_set():
            return 0, ""
        try:
            status, content, _ = _http_post(url, enc_payload, headers, 12)
            if status == 200:
                return status, content.hex()
            if status == 401:
                log("ERR", f"ChooseRegion 401 — JWT rejeté", R)
                return status, content.hex()
            if status in (500, 502, 503):
                time.sleep(0.5)
                continue
            return status, content.hex()
        except Exception as e:
            log("RETRY", f"ChooseRegion attempt {attempt+1}: {e}", Y)
        time.sleep(0.5)
    return 0, ""

def choose_newbie_choice(jwt_token, game_uid):
    url = "https://loginbp.ppmainecoonghj.com/ChooseNewbieChoice"
    proto_bytes = _build_newbie_choice_proto(game_uid)
    enc_payload = aes_encrypt_hex(proto_bytes.hex())
    headers = {
        "User-Agent":"UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Connection":"close","Accept-Encoding":"gzip",
        "X-GA-SV": str(int(time.time())),
        "Content-Type":"application/x-www-form-urlencoded",
        "Authorization": f"Bearer {jwt_token}", "X-Unity-Version":"2018.4.12f1",
        "X-GA":"v1 1","ReleaseVersion":OB,
    }
    status, content, _ = _http_post(url, enc_payload, headers, 12)
    return status, content.hex()

def get_login_data(jwt_token, access_token, open_id, region):
    base = REGION_URLS.get(region.upper(), "https://clientbp.ppmainecoonghj.com/")
    url = base + "GetLoginData"
    lang = REGION_LANG.get(region.upper(), "en")
    proto_bytes = _build_get_login_data_proto(access_token, open_id, lang, region)
    enc = aes_encrypt_hex(proto_bytes.hex())
    headers = {
        "Authorization": f"Bearer {jwt_token}",
        "User-Agent":"UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept":"*/*","Accept-Encoding":"deflate, gzip",
        "X-Ga-Sv": str(int(time.time())),
        "X-Ga":"v1 1",
        "Releaseversion":OB,
        "Content-Type":"application/x-www-form-urlencoded",
        "X-Unity-Version":"2018.4.12f1",
    }
    for attempt in range(3):
        if shutdown_requested.is_set(): raise KeyboardInterrupt
        try:
            status, content, _ = _http_post(url, enc, headers, 12)
            if status == 200:
                log("GETLOGINDATA",f"status: {status}")
                return content
            else :
                log("GETLOGINDATA",f"status: {status} , content {content} ", R)
                return None
        except Exception as e:
            pass
        time.sleep(0.5)
    return None


def LoginGetDesc(jwt_token, region):
    """LoginGetDesc : reconstruit {1:lang, 2:1, 3:region, 4:1} à chaque appel."""
    base = REGION_URLS.get(region.upper(), "https://clientbp.ppmainecoonghj.com/")
    url  = base + "LoginGetDesc"
    lang = REGION_LANG.get(region.upper(), "en")

    headers = {
        "Authorization": f"Bearer {jwt_token}",
        "User-Agent":"UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept":"*/*","Accept-Encoding":"deflate, gzip",
        "X-Ga-Sv": str(int(time.time())),
        "X-Ga":"v1 1",
        "Releaseversion":OB,
        "Content-Type":"application/x-www-form-urlencoded",
        "X-Unity-Version":"2018.4.12f1",
    }

    proto_bytes = _build_login_get_desc_proto(lang, region.upper())
    enc_payload = aes_encrypt_hex(proto_bytes.hex())

    status, content, _ = _http_post(url, enc_payload, headers, 12)
    return status, content.hex()

# ═══ JWT ═══
_JWT_PREFIX_SVC1 = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjEiLCJ0eXAiOiJKV1QifQ"
_JWT_PREFIX_SVC0 = "eyJhbGciOiJIUzI1NiIsInN2ciI6IiIsInR5cCI6IkpXVCJ9"
JWT_RE = re.compile(rb'eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*')

def extract_jwt(response_obj, lang, raw_text=""):
    try:
        jwt = response_obj.get("8",{}).get("data","")
        if isinstance(jwt,str) and jwt:
            second_dot = jwt.find(".", jwt.find(".")+1)
            return jwt[:second_dot+44] if second_dot != -1 else jwt
    except: pass
    if raw_text and _JWT_PREFIX_SVC0 in raw_text:
        idx = raw_text.find(_JWT_PREFIX_SVC0)
        candidate = raw_text[idx:]
        second_dot = candidate.find(".", candidate.find(".")+1)
        if second_dot != -1: return candidate[:second_dot+44]
    if raw_text and _JWT_PREFIX_SVC1 in raw_text:
        idx = raw_text.find(_JWT_PREFIX_SVC1)
        candidate = raw_text[idx:]
        second_dot = candidate.find(".", candidate.find(".")+1)
        if second_dot != -1: return candidate[:second_dot+44]
    return None

def extraire_jwt_depuis_hex(hex_content):
    hex_clean = "".join(hex_content.split())
    raw = bytes.fromhex(hex_clean)
    idx = raw.find(b"eyJhbGciOiJIUzI1NiIsInN2ciI6IiIsInR5cCI6IkpXVCJ9")
    if idx != -1:
        m = JWT_RE.search(raw, idx)
        if m: return m.group(0).decode("ascii")
    m = JWT_RE.search(raw)
    if not m: raise ValueError("Aucun JWT trouvé dans le contenu.")
    return m.group(0).decode("ascii")

def decode_jwt_payload(jwt):
    try:
        part = jwt.split(".")[1]
        part += "=" * ((4 - len(part) % 4) % 4)
        return json.loads(base64.urlsafe_b64decode(part).decode())
    except Exception as e:
        return {}

# ═══ PORTS EXTRACTOR ═══
def _bytes_to_str(v):
    if v is None or v == "": return ""
    if isinstance(v, (bytes, bytearray)):
        try: return v.decode("utf-8")
        except: return v.hex()
    return str(v)

def extract_ports_from_response(raw_response, key_bytes, iv_bytes):
    if not raw_response: return {"online":"","account":""}
    if not isinstance(raw_response, (bytes, bytearray)):
        try: raw_response = bytes(raw_response)
        except: return {"online":"","account":""}

    try:
        parsed = _decode_proto(bytes(raw_response))
        online  = _get_field(parsed, 14, default=b"")
        account = _get_field(parsed, 32, default=b"")
        if online or account:
            return {"online": _bytes_to_str(online),
                    "account": _bytes_to_str(account)}
    except Exception: pass

    for k, v in ((key_bytes, iv_bytes), (AES_KEY, AES_IV)):
        if not k or not v or len(k)!=16 or len(v)!=16: continue
        try:
            dec = _aes_cbc_decrypt(bytes(raw_response), k, v)
            if not dec: continue
            parsed = _decode_proto(dec)
            online  = _get_field(parsed, 14, default=b"")
            account = _get_field(parsed, 32, default=b"")
            if online or account:
                return {"online": _bytes_to_str(online),
                        "account": _bytes_to_str(account)}
        except Exception: continue
    return {"online":"","account":""}

# ═══ LOKESH PARSER ═══
def _parse_lok(raw):
    if not raw: return None
    for offset in range(0, min(len(raw), 200)):
        try:
            msg = Lokesh(); msg.ParseFromString(raw[offset:])
            if msg.status == "live" and msg.token.startswith("eyJ"):
                return msg
        except Exception: continue
    for offset in range(0, min(len(raw), 200)):
        try:
            msg = Lokesh(); msg.ParseFromString(raw[offset:])
            if msg.token or msg.status or len(msg.api) > 0:
                return msg
        except Exception: continue
    return None

# ═══ VERSION CONFIG ═══
def get_playstore_version():
    if not _HAS_PLAY_SCRAPER: return None
    try:
        result = play_scraper('com.dts.freefireth', lang='hi', country='id')
        return result.get("version")
    except Exception:
        return None

def version_config():
    app_version = get_playstore_version()
    if not app_version: return None
    api_url = (
        "https://version.ggwhitehawk.com/live/ver.php"
        f"?version={app_version}"
        "&lang=hi&device=android&channel=android"
        "&appstore=googleplay&region=BD"
        "&whitelist_version=1.3.0&whitelist_sp_version=1.0.0"
    )
    try:
        req = urllib.request.Request(api_url,
            headers={"User-Agent":"okhttp/4.12.0"})
        with urllib.request.urlopen(req, timeout=10, context=_ssl_ctx) as r:
            data = json.loads(r.read().decode("utf-8"))
        server_url = data.get("server_url")
        remote_version = data.get("remote_version")
        latest_release_version = data.get("latest_release_version")
        if not (server_url and remote_version and latest_release_version):
            return None
        return latest_release_version, remote_version, server_url
    except Exception:
        return None

def _extract_version_code(version):
    if version is None: return DEFAULT_VERSION_CODE
    if isinstance(version, str): return version
    if isinstance(version, (tuple, list)) and len(version) >= 1:
        v = version[0]
        if isinstance(v, str) and v: return v
    return DEFAULT_VERSION_CODE

def refresh_version_code():
    global _VERSION_CODE
    try:
        v,code,s = version_config()
        _VERSION_CODE = code
    except Exception: pass
    return _VERSION_CODE

# ═══ AUTH TOKEN ═══
def build_auth_token(bot_uid, jwt_token, timestamp):
    uid_hex = format(int(bot_uid), "x")
    padmap = {7:"000000000",8:"00000000",9:"0000000",10:"000000"}
    headers = padmap.get(len(uid_hex), "0000000")
    ts_hex = format(int(timestamp), "x")
    if len(ts_hex) % 2: ts_hex = "0" + ts_hex
    tok_bytes = jwt_token.encode("utf-8")
    tok_enc = aes_encrypt(tok_bytes)
    tok_len = format(len(tok_enc), "x")
    return f"0115{headers}{uid_hex}{ts_hex}00000{tok_len}{tok_enc.hex()}"

# ═══ DECODE JWT ═══
def decode(token):
    payload = decode_jwt_payload(token)
    account_id = payload.get("account_id", "N/A")
    lock_region = payload.get("lock_region", "N/A")
    return lock_region, account_id

# ════════════════════════════════════════════════════════════════════════════
# SAVE — Idempotent
# ════════════════════════════════════════════════════════════════════════════
def save_result(result, username):
    region = (result.get("region") or "BD").upper()
    userr = (username or "NEXX").upper()
    filename = f"{userr}_{region}.json"
    txtname  = f"{userr}_{region}_results.txt"
    uid_str  = str(result.get("uid", ""))

    entry = {
        "access_token": result.get("access_token", ""),
        "uid":          result.get("uid"),
        "password":     result.get("password", ""),
        "region":       result.get("region", region),
        "account_id":   result.get("game_uid"),
        "online":       result.get("online_ipport") or "",
        "account":      result.get("account_ipport") or "",
        "open_id":      result.get("open_id", ""),
        "created_at":   result.get("created_at",
                         datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    }

    with io_lock:
        data = []
        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, list):
                    data = []
            except (json.JSONDecodeError, ValueError):
                data = []

        replaced = False
        for i, e in enumerate(data):
            if str(e.get("uid")) == uid_str:
                if e.get("created_at"):
                    entry["created_at"] = e["created_at"]
                data[i] = entry
                replaced = True
                break
        if not replaced:
            data.append(entry)

        try:
            tmp = filename + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
                f.flush()
                try: os.fsync(f.fileno())
                except: pass
            os.replace(tmp, filename)
        except Exception as e:
            log("WARN", f"JSON write failed: {e}", Y)

        if not replaced:
            try:
                with open(txtname, "a", encoding="utf-8") as f:
                    f.write(
                        f"{result.get('uid','')}:{result.get('password','')}:"
                        f"{result.get('open_id','')}:{result.get('access_token','')}\n"
                    )
                    f.flush()
                    try: os.fsync(f.fileno())
                    except: pass
            except Exception as e:
                log("WARN", f"TXT write failed: {e}", Y)

    log("SAVE",
        f"{'Updated' if replaced else 'Saved'} uid={uid_str} → {filename}",
        G)


# ════════════════════════════════════════════════════════════════════════════
# CREATE ACCOUNT — FLUX COMPLET + SAVE EARLY
# ════════════════════════════════════════════════════════════════════════════
def create_account(region, custom_name_prefix="", custom_pass="",
                   pass_prefix="NEXX_", username="NEXX"):
    if shutdown_requested.is_set(): return None
    lang = REGION_LANG.get(region.upper(), "en")
    reg_up = region.upper()

    step(1, 5, "Garena guest register …")
    uid, password = garena_register(custom_pass, pass_prefix)
    if not uid: return None

    step(2, 5, "Garena token grant …")
    try:
        open_id, access_token = garena_token(uid, password)
    except Exception as e:
        log("FAIL", f"Token grab failed: {e}", R); return None

    step(3, 5, "MajorRegister → Handshake …")
    prefix = custom_name_prefix if custom_name_prefix else "NEXX"
    name = generate_name(prefix)
    field14 = encode_open_id(open_id)
    reg_hex, reg_status = major_register(access_token, open_id, field14, name)
    del field14
    if reg_status != 200:
        log("MAJOR REGISTER", f"status {reg_status}", R); return None
    log("MAJOR REGISTER", f"status {reg_status}")

    account_uid = 0
    parsed_reg = decode_response(reg_hex)
    if parsed_reg:
        account_uid = _safe_int(_get_field(parsed_reg, 3, default=0))
        if not account_uid:
            nested = parsed_reg.get('9', {})
            if isinstance(nested, dict):
                inner = nested.get('data', {})
                if isinstance(inner, dict):
                    account_uid = _safe_int(_get_field(inner, 8, default=0))
        if account_uid:
            log("UID", f"Account UID: {account_uid}", G)

    # 🔑 JWT avec svc="" via MajorLogin
    log("SYNC", "Fetching fresh JWT (svc=\"\") via MajorLogin…", C)
    jwt = ""
    for _retry in range(3):
        if shutdown_requested.is_set(): return None
        ls, lh = major_login(access_token, open_id, lang, region)
        if ls == 200 and lh:
            _msg = _parse_lok(bytes.fromhex(lh))
            if _msg and _msg.token:
                jwt = _msg.token
                log("JWT", f"Obtained (svc-check) len={len(jwt)}", G)
                break
            try:
                jwt = extraire_jwt_depuis_hex(lh)
                log("JWT", f"Obtained (regex) len={len(jwt)}", G)
                break
            except Exception:
                pass
        time.sleep(1)

    if not jwt:
        log("ERR", "Impossible d'obtenir le JWT pour ChooseNewbie/ChooseRegion", R)
        return None

    if account_uid:
        step("NB", 5, f"ChooseNewbieChoice (uid={account_uid}) …")
        try:
            st, ct = choose_newbie_choice(jwt, account_uid)
            if st == 200:
                log("CHOOSE NEWBIE", f"✅ status={st} body={ct}", G)
            else:
                log("CHOOSE NEWBIE", f"❌ status={st}", R)
        except Exception as e: log("WARN", f"ChooseNewbieChoice: {e}", Y)

    r_region = "EUROPE" if reg_up == "EU" else ("RU" if reg_up == "CIS" else reg_up)
    step("R", 5, f"ChooseRegion → {r_region} …")
    try:
        st, ct = choose_region(jwt, r_region)
        if st == 200:
            log("CHOOSE REGION", f"✅ status={st} body={ct}", G)
        else:
            log("CHOOSE REGION", f"❌ status={st} body={ct}", R)
    except Exception as e:
        log("WARN", f"ChooseRegion: {e}", Y)

    step(4, 5, "Ping server…")
    ping()

    step(4, 5, "MajorLogin Sync (final JWT)…")
    ls2, lh2 = major_login(access_token, open_id, lang, region)
    if ls2 != 200 or not lh2:
        log("ERR", "MajorLogin sync failed", R); return None

    example_msg = _parse_lok(bytes.fromhex(lh2))
    if example_msg is None:
        log("ERR", "Failed to parse lok message", R); return None

    jwt_final = example_msg.token or None

    region_resp = example_msg.region or None
    log("REGION FOUND ", region_resp)
    timestamp = example_msg.timestamp

    api = None
    for item in example_msg.api:
        if isinstance(item, bytes):
            try: s = item.decode("utf-8")
            except UnicodeDecodeError: continue
            if s.startswith("http"): api = s; break

    region_out, account_id_out = decode(jwt_final) if jwt_final else (None, "N/A")
    api_out = api or "N/A"
    if jwt_final: jwt = jwt_final

    auth_token_raw = jwt_final or jwt
    if not auth_token_raw:
        log("ERR", "No auth token in MajorLogin", R); return None

    key_field = example_msg.binary
    iv_field  = example_msg.binary_data
    server_url = api_out if api_out != "N/A" else None

    def _to_bytes(v):
        if not v: return b""
        try:
            if isinstance(v, bytes): return v
            if isinstance(v, str) and all(c in "0123456789abcdefABCDEF" for c in v) and len(v)%2==0:
                return bytes.fromhex(v)
            if isinstance(v, str):
                return base64.b64decode(v + "=" * ((4-len(v)%4)%4))
        except: pass
        return b""

    key_bytes = _to_bytes(key_field) if key_field else AES_KEY
    iv_bytes  = _to_bytes(iv_field)  if iv_field  else AES_IV
    if server_url and not server_url.endswith("/"): server_url += "/"
    if not server_url: server_url = "https://clientbp.ppmainecoonghj.com/"

    # LoginGetDesc (optionnel, mais présent dans la capture)
    step("D", 5, f"LoginGetDesc → {region_out or reg_up} …")
    try:
        st, ct = LoginGetDesc(jwt, (region_out or region).upper())
        if st == 200:
            log("LOGIN GET DESC", f"✅ status={st} ", G)
        else:
            log("LOGIN GET DESC", f"❌ status={st} body={ct}", R)
    except Exception as e:
        log("WARN", f"LoginGetDesc: {e}", Y)

    step(4, 5, "Ping server…")
    ping()

    partial = {
        "access_token":   access_token,
        "open_id":        open_id,
        "uid":            uid,
        "password":       password,
        "name":           name,
        "region":         (region_resp or region_out).upper(),
        "game_uid":       account_id_out,
        "jwt":            auth_token_raw,
        "timestamp":      timestamp,
        "server_url":     server_url or "https://clientbp.ppmainecoonghj.com/",
        "online_ipport":  None,
        "account_ipport": None,
    }
    try:
        save_result(partial, username)
    except Exception as e:
        log("WARN", f"Early save failed: {e}", Y)

    step(5, 5, "Fetching Account Final Details …")
    online_ipport = ""
    account_ipport = ""
    try:
        raw_getlogin = get_login_data(jwt, access_token, open_id, region_out or region)
        if raw_getlogin:
            ports = extract_ports_from_response(raw_getlogin, key_bytes, iv_bytes)
            online_ipport = ports.get("online", "")
            account_ipport = ports.get("account", "")
            log("PORTS", f"Online={online_ipport} | Account={account_ipport}", C)
    except Exception as e:
        log("WARN", f"GetLoginData: {e}", Y)

    final = {
        "access_token": access_token, "open_id": open_id, "uid": uid,
        "password": password, "name": name,
        "region": (region_out or region).upper(),
        "game_uid": account_id_out, "jwt": auth_token_raw,
        "timestamp": timestamp, "key": key_bytes, "iv": iv_bytes,
        "server_url": server_url,
        "online_ipport": online_ipport or None,
        "account_ipport": account_ipport or None,
    }

    try:
        save_result(final, username)
    except Exception as e:
        log("WARN", f"Final save failed: {e}", Y)

    return final

# ═══ SAVE ACTIVATED ═══
def write_activated_file(result):
    region = result.get("region","BD")
    fname = f"activated_{region}.txt"
    line = f"{result['uid']}:{result['password']}\n"
    with io_lock:
        with open(fname,"a",encoding="utf-8") as f:
            f.write(line); f.flush()
            try: os.fsync(f.fileno())
            except: pass

# ═══ ACTIVATOR ═══
class FastGuestActivator:
    def __init__(self, account, session):
        self.account = account
        self.session = session
        self.hr = {
            "User-Agent": USER_AGENT, "Connection":"Keep-Alive",
            "Accept-Encoding":"gzip","Content-Type":"application/x-www-form-urlencoded",
            "X-Unity-Version":"2018.4.12f1","X-GA":"v1 1","ReleaseVersion":OB,
        }

    async def connect_and_activate(self):
        acc = self.account
        online = acc.get("online_ipport","")
        chat   = acc.get("account_ipport","")
        if not online or not chat:
            log("ACT", f"[{acc['uid']}] No ports to connect to", R); return False
        try:
            oip,oport = online.split(":"); cip,cport = chat.split(":")
        except Exception as e:
            log("ACT", f"[{acc['uid']}] bad port format: {e}", R); return False

        auth_tok = build_auth_token(
            _safe_int(acc.get("game_uid")), acc["jwt"], _safe_int(acc.get("timestamp")))

        for attempt in range(2):
            if shutdown_requested.is_set(): return False
            print(f"  {C}[{acc['uid']}]{RST} ⚡ Connect attempt {attempt+1} → {oip}:{oport} / {cip}:{cport}")
            try:
                ol_r, ol_w = await asyncio.wait_for(
                    asyncio.open_connection(oip, int(oport)), timeout=5)
                ol_w.write(bytes.fromhex(auth_tok)); await ol_w.drain()

                ch_r, ch_w = await asyncio.wait_for(
                    asyncio.open_connection(cip, int(cport)), timeout=5)
                ch_w.write(bytes.fromhex(auth_tok)); await ch_w.drain()

                print(f"  {G}[{acc['uid']}]{RST} ✅ Connected — holding 1s …")
                await asyncio.sleep(1)
                try: ol_w.close(); await ol_w.wait_closed()
                except: pass
                try: ch_w.close(); await ch_w.wait_closed()
                except: pass

                write_activated_file(acc)
                print(f"  {G}[{acc['uid']}]{RST} 💾 Saved → activated_{acc['region']}.txt")
                return True
            except asyncio.TimeoutError:
                print(f"  {Y}[{acc['uid']}]{RST} ⚠️ TCP timeout")
            except Exception as e:
                print(f"  {Y}[{acc['uid']}]{RST} ⚠️ TCP error: {e}")
        return False

# ═══ BANNER / SIGNAL ═══
def banner():
    os.system("cls" if os.name=="nt" else "clear")
    try: w = os.get_terminal_size().columns
    except: w = 80
    text = f"""
{M}{B}

░███    ░██ ░██████████ ░██    ░██ ░██    ░██ 
░████   ░██ ░██          ░██  ░██   ░██  ░██  
░██░██  ░██ ░██           ░██░██     ░██░██   
░██ ░██ ░██ ░█████████     ░███       ░███    
░██  ░██░██ ░██           ░██░██     ░██░██   
░██   ░████ ░██          ░██  ░██   ░██  ░██  
░██    ░███ ░██████████ ░██    ░██ ░██    ░██ 

{RST}{C}{B}Free Fire Guest Creator + Anti-429
{C}{Y}VERSION : {G}{B}OB55
{C}{B}Last update : 10/10/2026 @thug4ff
"""
    for line in text.splitlines(): print(line.center(w))

def _install_signal_handlers():
    def _handler(signum, frame):
        if not shutdown_requested.is_set():
            shutdown_requested.set()
            print(f"\n  {Y}{B}⚠️  Ctrl-C received — stopping workers, flushing files…{RST}")
            print(f"  {W}(press Ctrl-C again to force-quit){RST}")
        else:
            print(f"\n  {R}{B}Force quit.{RST}"); os._exit(1)
    try:
        signal.signal(signal.SIGINT, _handler)
        signal.signal(signal.SIGTERM, _handler)
    except (ValueError, OSError): pass

# ═══ MAIN ═══
def main():
    _install_signal_handlers()
    banner()
    print(f"  {Y}{B}Supported Regions:{RST} {', '.join(REGION_LANG)}\n")

    region = input(f"  {R}{B}[{G}{B}+{R}{B}]{RST} Select Region: ").strip().upper()
    if region not in REGION_LANG:
        log("WARN", f"Unknown Region '{region}'. Defaulting to BD.", Y); region = "BD"

    try: total = int(input(f"  {R}{B}[{G}{B}+{R}{B}]{RST} Accounts to Create: ").strip() or "1")
    except ValueError: total = 1

    print(f"\n  {C}{B}─── Preferences ───{RST}")
    user_name = input(f"  {R}{B}[{G}{B}?{R}{B}]{RST} Name Prefix [Enter=NEXX]: ").strip()
    user_pp   = input(f"  {R}{B}[{G}{B}?{R}{B}]{RST} Pass Prefix  [Enter=NEXX_]: ").strip()
    if user_pp and not user_pp.endswith("_"): user_pp += "_"

    log("DD", "Refreshing Datadome cookie…", C)
    fetch_datadome_cookie(force=True)

    log("VER", "Fetching dynamic version…", C)
    v = refresh_version_code()
    log("VER", f"Using version_code = {v}", G)

    max_workers = min(10, total)
    print(f"\n  {Y}{B}Spawning {max_workers} worker(s) for {total} account(s)…{RST}\n")
    print(f"  {R}{'─'*65}{RST}\n")
    print(f"  {W}{B}💡 Press Ctrl+C at any time to stop gracefully{RST}\n")

    accounts: list = []
    success = 0
    lock = threading.Lock()

    def creator(i, target_total):
        nonlocal success
        attempts_left = 3
        while attempts_left > 0 and not shutdown_requested.is_set():
            attempts_left -= 1
            try:
                res = create_account(region, user_name, "", user_pp or "THUG_",
                                     username=(user_name or "NEXX"))
                if res:
                    save_result(res, user_name or "NEXX")
                    accounts.append(res)
                    with lock:
                        success += 1
                        progress = f"[{success}/{target_total}]"
                        print(f"\n  {G}{B}╭{'─'*50}╮")
                        print(f"  │ {W}{B}{progress} {G}OK")
                        print(f"  │ {W}{B}UID       : {C}{res['uid']}")
                        print(f"  │ {W}{B}PASSWORD  : {C}{res['password']}")
                        print(f"  │ {W}{B}GAME ID   : {M}{res['game_uid']}")
                        print(f"  │ {W}{B}REGION    : {C}{res['region']}")
                        print(f"  │ {W}{B}ONLINE    : {Y}{res.get('online_ipport','')}")
                        print(f"  │ {W}{B}ACCOUNT   : {Y}{res.get('account_ipport','')}")
                        print(f"  {G}{B}╰{'─'*50}╯{RST}")
                    return True
            except RateLimitException as rle:
                log("RATE", f"{rle} — waiting 30s", R)
                time.sleep(30)
            except KeyboardInterrupt: return False
            except Exception as e:
                log("ERR", f"create (retry {3-attempts_left}/3): {e}", R)
                time.sleep(1)
        return False

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = []
        task_id = 1
        while success < total and not shutdown_requested.is_set():
            future = ex.submit(creator, task_id, total)
            futures.append(future); task_id += 1
            futures = [f for f in futures if not f.done()]
            for f in list(futures):
                if f.done():
                    try: f.result()
                    except Exception as e: log("ERR", f"Task error: {e}", R)
                    futures.remove(f)
            if success >= total: break
            if len(futures) >= max_workers * 2: time.sleep(0.5)
            time.sleep(0.1)
        for f in futures:
            if not f.done():
                try: f.result(timeout=30)
                except concurrent.futures.TimeoutError:
                    log("WARN", "Task timeout, continuing...", Y)
                except Exception as e: log("ERR", f"Task error: {e}", R)

    print(f"\n  {G}{B}╔═══════════════════════════════════════════════════════════╗")
    print(f"  │  🎯  OBJECTIF ATTEINT : {success}/{total} comptes créés !")
    print(f"  ╚═══════════════════════════════════════════════════════════╝{RST}\n")

    if not accounts:
        print(f"  {R}No accounts to activate.{RST}"); return
    if shutdown_requested.is_set():
        print(f"  {Y}Skipping activation (Ctrl-C pressed).{RST}"); return

    print(f"  {M}{B}─── Phase 2: TCP 1-sec Online+Account Activation ───{RST}\n")
    print(f"  {W}{B}Activated accounts will be saved to:{RST} {G}activated_{region}.txt{RST}\n")
    try: asyncio.run(_run_activators(accounts))
    except KeyboardInterrupt: shutdown_requested.set()

    fname = f"activated_{region}.txt"
    try:
        with open(fname,"r",encoding="utf-8") as f: n = sum(1 for _ in f)
    except FileNotFoundError: n = 0
    print(f"\n  {G}{B}Activation phase complete.{RST}")
    print(f"  {C}{B}{n} activated account(s) written to {fname}{RST}\n")

async def _run_activators(accounts):
    connector = aiohttp.TCPConnector(limit=1000, ssl=False)
    timeout = aiohttp.ClientTimeout(total=15)
    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
        sem = asyncio.Semaphore(100)
        async def run(acc):
            if shutdown_requested.is_set(): return
            async with sem:
                bot = FastGuestActivator(acc, session)
                await bot.connect_and_activate()
        await asyncio.gather(*(run(a) for a in accounts))

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt:
        shutdown_requested.set()
        print(f"\n  {Y}Terminated by user.{RST}"); sys.exit(0)