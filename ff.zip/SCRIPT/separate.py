import asyncio
import aiohttp
import json
import os
from itertools import cycle

# =========================
# CONFIG
# =========================
TIMEOUT = 80
CONCURRENT_TASKS = 35
RETRY_ATTEMPTS = 5
RETRY_DELAY = 1  # secondes entre chaque tentative

# =========================
# SÉLECTION DU FICHIER JSON
# =========================
def select_json_file():
    files = [f for f in os.listdir('.') if f.endswith('.json') and os.path.isfile(f)]
    if not files:
        print("❌ Aucun fichier .json trouvé dans le dossier courant.")
        file_name = input("Entrez le chemin complet du fichier : ").strip()
        if not file_name:
            print("Aucun fichier fourni. Fin.")
            return None
        return file_name

    print("\n📂 Fichiers JSON disponibles :")
    for i, f in enumerate(files, 1):
        print(f"  {i}. {f}")
    while True:
        try:
            choix = input("Choisissez le numéro du fichier : ").strip()
            idx = int(choix) - 1
            if 0 <= idx < len(files):
                return files[idx]
            else:
                print("Numéro invalide.")
        except ValueError:
            print("Veuillez entrer un nombre.")

# =========================
# SÉPARATION PAR SERVEUR
# =========================
def separer_comptes_par_serveur(comptes):
    """
    Sépare les comptes par serveur et retourne un dictionnaire
    avec les serveurs comme clés et les listes de comptes comme valeurs.
    """
    comptes_par_serveur = {}
    
    for compte in comptes:
        if isinstance(compte, dict) and "server" in compte:
            serveur = compte["server"]
            if serveur not in comptes_par_serveur:
                comptes_par_serveur[serveur] = []
            comptes_par_serveur[serveur].append(compte)
        else:
            # Comptes sans serveur ou format invalide
            serveur = "UNKNOWN"
            if serveur not in comptes_par_serveur:
                comptes_par_serveur[serveur] = []
            comptes_par_serveur[serveur].append(compte)
    
    return comptes_par_serveur

# =========================
# SAUVEGARDE DES FICHIERS
# =========================
def sauvegarder_fichiers(comptes_par_serveur, fichier_source):
    """
    Sauvegarde les comptes dans des fichiers séparés par serveur
    avec le suffixe _SERVER.
    """
    base_name = fichier_source.rsplit(".", 1)[0] if "." in fichier_source else fichier_source
    
    print("\n📁 Début de la séparation par serveur...")
    print(f"📦 {len(comptes_par_serveur)} serveur(s) trouvé(s)\n")
    
    fichiers_crees = []
    
    for serveur, comptes in comptes_par_serveur.items():
        # Nettoyer le nom du serveur pour le nom de fichier
        nom_serveur_propre = "".join(c for c in serveur if c.isalnum() or c in ['_', '-'])
        if not nom_serveur_propre:
            nom_serveur_propre = "UNKNOWN"
        
        # Nom du fichier de sortie avec _SERVER
        nom_fichier = f"{base_name}_{nom_serveur_propre}_SERVER.json"
        
        # Vérifier si le fichier existe déjà et ajouter un suffixe si nécessaire
        if os.path.exists(nom_fichier):
            suffixe = 1
            while True:
                nom_fichier = f"{base_name}_{nom_serveur_propre}_SERVER_{suffixe}.json"
                if not os.path.exists(nom_fichier):
                    break
                suffixe += 1
        
        # Sauvegarde du fichier JSON
        try:
            with open(nom_fichier, "w", encoding="utf-8") as f:
                json.dump(comptes, f, indent=4, ensure_ascii=False)
            
            print(f"✅ Créé : {nom_fichier} ({len(comptes)} comptes)")
            fichiers_crees.append(nom_fichier)
            
        except Exception as e:
            print(f"❌ Erreur lors de la création de {nom_fichier} : {e}")
    
    # Créer un fichier récapitulatif
    recap_file = f"{base_name}_separated_{len(comptes_par_serveur)}servers.json"
    try:
        with open(recap_file, "w", encoding="utf-8") as f:
            json.dump({
                "fichier_source": fichier_source,
                "total_comptes": sum(len(comptes) for comptes in comptes_par_serveur.values()),
                "serveurs": {serveur: len(comptes) for serveur, comptes in comptes_par_serveur.items()},
                "fichiers_crees": fichiers_crees
            }, f, indent=4, ensure_ascii=False)
        print(f"\n📊 Récapitulatif créé : {recap_file}")
    except Exception as e:
        print(f"⚠️ Erreur lors de la création du récapitulatif : {e}")
    
    return fichiers_crees

# =========================
# STATISTIQUES PAR SERVEUR
# =========================
def afficher_stats_serveur(comptes_par_serveur):
    """
    Affiche des statistiques détaillées pour chaque serveur.
    """
    print("\n📊 STATISTIQUES PAR SERVEUR :")
    print("=" * 50)
    
    for serveur, comptes in sorted(comptes_par_serveur.items()):
        print(f"\n🌐 Serveur : {serveur}")
        print(f"   Total comptes : {len(comptes)}")
        
        # Statistiques supplémentaires
        temp_bans = sum(1 for c in comptes if c.get("banned_temp", False))
        normaux = len(comptes) - temp_bans
        
        # Niveaux
        niveaux = [safe_level(c.get("level")) for c in comptes]
        niveaux_valides = [n for n in niveaux if n is not None]
        
        print(f"   ✅ Comptes normaux : {normaux}")
        print(f"   ⏳ Bannis temporaires : {temp_bans}")
        
        if niveaux_valides:
            print(f"   📈 Niveaux min/max : {min(niveaux_valides)}/{max(niveaux_valides)}")
            print(f"   📊 Moyenne niveau : {sum(niveaux_valides)/len(niveaux_valides):.1f}")
        
        # Diamants
        diamants = [c.get("diamonds", 0) for c in comptes]
        if diamants:
            print(f"   💎 Diamants totaux : {sum(diamants)}")
            print(f"   💎 Diamants max : {max(diamants)}")

# =========================
# SAFE LEVEL (copié de votre script)
# =========================
def safe_level(value):
    try:
        lvl = int(value)
        if 0 < lvl <= 100:
            return lvl
    except:
        pass
    return None

# =========================
# MAIN
# =========================
def main():
    print("=" * 60)
    print("🔄 SÉPARATION DES COMPTES PAR SERVEUR")
    print("=" * 60)
    
    # 1. Sélection du fichier JSON
    print("\n📂 SÉLECTION DU FICHIER SOURCE")
    print("-" * 40)
    file_name = select_json_file()
    if not file_name:
        return
    
    # 2. Chargement du fichier
    print(f"\n📖 Chargement de {file_name}...")
    try:
        with open(file_name, "r", encoding="utf-8", errors="ignore") as f:
            comptes = json.load(f)
            if not isinstance(comptes, list):
                print("❌ Le fichier JSON doit contenir une liste de comptes.")
                return
    except Exception as e:
        print(f"❌ Erreur de lecture JSON : {e}")
        return
    
    print(f"✅ {len(comptes)} comptes chargés avec succès.")
    
    # 3. Séparation par serveur
    print("\n🔄 Séparation des comptes par serveur...")
    comptes_par_serveur = separer_comptes_par_serveur(comptes)
    
    # 4. Statistiques détaillées
    afficher_stats_serveur(comptes_par_serveur)
    
    # 5. Sauvegarde des fichiers séparés
    print("\n💾 SAUVEGARDE DES FICHIERS SÉPARÉS")
    print("-" * 40)
    fichiers_crees = sauvegarder_fichiers(comptes_par_serveur, file_name)
    
    # 6. Résumé final
    print("\n" + "=" * 60)
    print("✅ TERMINÉ !")
    print("=" * 60)
    print(f"📊 Résumé :")
    print(f"   - Fichier source : {file_name}")
    print(f"   - Total comptes : {len(comptes)}")
    print(f"   - Serveurs trouvés : {len(comptes_par_serveur)}")
    print(f"   - Fichiers créés : {len(fichiers_crees)}")
    
    print("\n📁 Fichiers de sortie :")
    for fichier in fichiers_crees:
        print(f"   📄 {fichier}")

# =========================
# RUN
# =========================
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n🛑 Arrêté par l'utilisateur.")
    except Exception as e:
        print(f"\n❌ Erreur : {e}")