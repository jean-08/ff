import json
import os

# Dossier où se trouve le script
folder = os.path.dirname(os.path.abspath(__file__))

# Scanner tous les fichiers JSON
json_files = [
    f for f in os.listdir(folder)
    if f.lower().endswith(".json")
]

json_files.sort()

if not json_files:
    print("❌ Aucun fichier JSON trouvé dans ce dossier.")
    exit()

# Afficher les fichiers
print("\n=== FICHIERS JSON DISPONIBLES ===")

for i, filename in enumerate(json_files, start=1):
    print(f"[{i}] {filename}")

# Choisir le fichier
while True:
    try:
        choice = int(input("\nChoisis le fichier par son numéro : "))

        if 1 <= choice <= len(json_files):
            break

        print("❌ Numéro invalide.")

    except ValueError:
        print("❌ Entre uniquement un numéro.")

# Fichier sélectionné
filename = json_files[choice - 1]
filepath = os.path.join(folder, filename)

print(f"\n📂 Fichier sélectionné : {filename}")

try:
    # Charger le JSON
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Vérifier que le JSON est une liste
    if not isinstance(data, list):
        print("❌ Le fichier JSON doit contenir une liste de comptes.")
        exit()

    # Récupérer tous les account_id
    account_ids = [
        str(item["account_id"])
        for item in data
        if isinstance(item, dict) and "account_id" in item
    ]

    # Séparer par des virgules
    result = ",".join(account_ids)

    print("\n=== Account IDs ===")
    print(result)

    # Sauvegarder dans un fichier
    output = os.path.join(folder, "account_ids.txt")

    with open(output, "w", encoding="utf-8") as f:
        f.write(result)

    print(f"\n✅ {len(account_ids)} account_id(s) récupéré(s).")
    print(f"💾 Sauvegardé dans '{output}'.")

except json.JSONDecodeError:
    print("❌ Le fichier sélectionné contient un JSON invalide.")

except Exception as e:
    print(f"❌ Erreur : {e}")