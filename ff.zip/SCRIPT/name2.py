import json
import os
import random


def get_prefix(password):
    """Récupère le nom avant le premier _."""

    if not isinstance(password, str):
        return None

    password = password.strip()

    if not password:
        return None

    return password.split("_", 1)[0].strip().upper()


def scan_json_files():
    """Scanne tous les fichiers JSON du dossier actuel."""

    files = []

    for filename in os.listdir("."):
        if filename.lower().endswith(".json") and os.path.isfile(filename):
            files.append(filename)

    return sorted(files)


def main():

    print("=" * 60)
    print("       JSON ACCOUNT SELECTOR")
    print("=" * 60)

    # ==============================
    # Scanner les fichiers JSON
    # ==============================

    json_files = scan_json_files()

    if not json_files:
        print("\n❌ Aucun fichier JSON trouvé dans ce dossier.")
        return

    print("\n📂 FICHIERS JSON TROUVÉS")
    print("=" * 60)

    for i, filename in enumerate(json_files, 1):
        print(f"{i:>3}. {filename}")

    print("=" * 60)

    # ==============================
    # Choisir le fichier
    # ==============================

    while True:

        choice = input("\n👉 Choisis le fichier JSON [numéro] : ").strip()

        if not choice.isdigit():
            print("❌ Entre un numéro.")
            continue

        index = int(choice)

        if 1 <= index <= len(json_files):
            filename = json_files[index - 1]
            break

        print("❌ Numéro invalide.")

    print(f"\n📁 Fichier sélectionné : {filename}")

    # ==============================
    # Charger le JSON
    # ==============================

    try:

        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)

    except Exception as e:

        print(f"❌ Erreur lors de la lecture : {e}")
        return

    if not isinstance(data, list):

        print("❌ Le JSON doit être une liste de comptes.")
        return

    print(f"📊 {len(data)} comptes trouvés dans le fichier.")

    # ==============================
    # Scanner TOUT le JSON
    # ==============================

    groups = {}

    for account in data:

        if not isinstance(account, dict):
            continue

        password = account.get("password")

        prefix = get_prefix(password)

        if not prefix:
            continue

        if prefix not in groups:
            groups[prefix] = []

        groups[prefix].append(account)

    # ==============================
    # Afficher tous les noms trouvés
    # ==============================

    if not groups:

        print("❌ Aucun nom trouvé dans les passwords.")
        return

    names = sorted(groups.keys())

    print("\n" + "=" * 60)
    print("🔎 NOMS TROUVÉS DANS TOUT LE JSON")
    print("=" * 60)

    for i, name in enumerate(names, 1):

        count = len(groups[name])

        print(f"{i:>3}. {name:<20} → {count} comptes")

    print("=" * 60)

    # ==============================
    # Choix utilisateur
    # ==============================

    print("\nExemples de sélection :")
    print("  1,3,5")
    print("  AKIRA,GOOL,YVO")
    print("  ALL = tous les noms")

    choice = input("\n👉 Quels noms veux-tu garder ? : ").strip()

    # ==============================
    # Sélection
    # ==============================

    if choice.upper() == "ALL":

        selected_names = names

    else:

        selected_names = []

        parts = [x.strip() for x in choice.split(",")]

        for part in parts:

            # Sélection par numéro
            if part.isdigit():

                index = int(part)

                if 1 <= index <= len(names):

                    name = names[index - 1]

                    if name not in selected_names:
                        selected_names.append(name)

                else:

                    print(f"⚠️ Numéro ignoré : {part}")

            # Sélection par nom
            else:

                name = part.upper()

                if name in groups:

                    if name not in selected_names:
                        selected_names.append(name)

                else:

                    print(f"⚠️ Nom ignoré : {name}")

    # ==============================
    # Vérification
    # ==============================

    if not selected_names:

        print("❌ Aucun nom sélectionné.")
        return

    # ==============================
    # Récupérer les comptes
    # ==============================

    selected_accounts = []

    for name in selected_names:

        selected_accounts.extend(groups[name])

    # ==============================
    # Supprimer les doublons
    # ==============================

    unique_accounts = {}
    duplicates = 0

    for account in selected_accounts:

        account_id = account.get("uid")

        if account_id is None:

            key = f"NO_ID_{len(unique_accounts)}"

        else:

            key = str(account_id)

        if key in unique_accounts:

            duplicates += 1
            continue

        unique_accounts[key] = account

    selected_accounts = list(unique_accounts.values())

    # ==============================
    # Mélanger
    # ==============================

    random.shuffle(selected_accounts)

    # ==============================
    # Nom du fichier
    # ==============================

    total = len(selected_accounts)

    output_name = "_".join(selected_names)

    output_filename = f"{output_name}_{total}.json"

    # ==============================
    # Éviter d'écraser
    # ==============================

    if os.path.exists(output_filename):

        counter = 1

        while True:

            new_filename = f"{output_name}_{total}_{counter}.json"

            if not os.path.exists(new_filename):

                output_filename = new_filename
                break

            counter += 1

    # ==============================
    # Sauvegarde
    # ==============================

    try:

        with open(output_filename, "w", encoding="utf-8") as f:

            json.dump(
                selected_accounts,
                f,
                indent=4,
                ensure_ascii=False
            )

    except Exception as e:

        print(f"❌ Erreur lors de la sauvegarde : {e}")
        return

    # ==============================
    # Résultat
    # ==============================

    print("\n" + "=" * 60)
    print("✅ TERMINÉ")
    print("=" * 60)

    print(f"📁 Fichier source : {filename}")
    print(f"👤 Sélection      : {' + '.join(selected_names)}")
    print(f"📊 Comptes        : {total}")
    print(f"♻️ Doublons       : {duplicates}")
    print(f"📄 Fichier créé   : {output_filename}")

    print("=" * 60)


if __name__ == "__main__":
    main()