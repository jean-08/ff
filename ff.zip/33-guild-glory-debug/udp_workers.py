# -*- coding: utf-8 -*-
"""
Parties UDP dans des processus séparés : plusieurs cœurs au lieu d'un seul.

Tout le serveur tourne sur une seule boucle asyncio, donc sur un seul cœur. Une partie BR reçoit des milliers de
paquets par seconde (ACK / PING auxquels il faut répondre) : au-delà de quelques dizaines de parties, ce cœur sature
et TOUT ralentit (parties non créditées, passerelles, relevés d'EXP, site) — d'autant plus qu'on ajoute de panels.

Ici, chaque partie trouvée est jouée dans un processus « worker » (UDP_WORKERS dans .env) qui a sa propre boucle et
son propre cœur. Le code de la partie est exactement protocol.play_match_core (rien ne change dans le dialogue avec
le serveur du jeu). Le processus principal garde tout le reste — logins, passerelles, panels, base, site — et la
comptabilité de chaque partie (place du panel, fin de partie, journal), comme avant (protocol.play_game).

Échanges : messages pickle préfixés par leur longueur (4 octets) sur l'entrée / la sortie standard du worker.
  principal -> worker : start {id, args} · cancel {id} · stop
  worker -> principal : ready · end {id, ok, info} · log {id, level, msg} · diag {id, rec} (étapes du journal de
                        diagnostic, voir ffbot.diag) · stats (chaque seconde : trafic, retard, CPU)
`info` : cause de fin de la partie (MATCH_END, HANDSHAKE_TIMEOUT…), délai de connexion, paquets reçus.
Un worker ignore Ctrl+C (c'est le principal qui décide de la fin des parties) et s'arrête de lui-même si le
principal disparaît (fin de son entrée standard). Un worker qui plante est relancé ; ses parties comptent « échouées »
(cause WORKER_LOST).
"""
import asyncio
import contextvars
import itertools
import os
import pickle
import queue
import signal
import subprocess
import sys
import threading
import time
from collections import deque
from typing import Any, Callable, Dict, List, Optional

from ffbot import diag

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_HDR = 4
_READY_TIMEOUT_S = 40.0
_STOP_TIMEOUT_S = 5.0
_RESPAWN_DELAY_S = 3.0
_AUTO_MAX_WORKERS = 12


def default_worker_count() -> int:
    """UDP_WORKERS (.env) : nombre, ou « auto » (défaut) = un worker par cœur logique en en laissant 4 au processus
    principal (passerelles, logins, site) et au système, 12 au plus (20 cœurs logiques -> 12 workers -> 300 parties
    à 25 par worker ; un worker à 25 parties BR ≈ 80 % d'un cœur). 0 = désactivé."""
    raw = os.environ.get("UDP_WORKERS", "").strip().lower()
    if raw and raw != "auto":
        try:
            return max(0, int(raw))
        except ValueError:
            pass
    return max(1, min(_AUTO_MAX_WORKERS, (os.cpu_count() or 2) - 4))


def max_matches_per_worker() -> int:
    """UDP_WORKER_MAX_MATCHES (.env, 25 par défaut). Mesuré : ~20 parties = 50 % d'un cœur, 30 = 100 %. Au-delà de
    ~500 sockets, la boucle selector de Windows (select, 512 au plus) fait planter le worker : plafond strict."""
    try:
        return max(1, min(400, int(os.environ.get("UDP_WORKER_MAX_MATCHES", "25"))))
    except ValueError:
        return 25


def _frame(msg: Dict[str, Any]) -> bytes:
    data = pickle.dumps(msg, protocol=pickle.HIGHEST_PROTOCOL)
    return len(data).to_bytes(_HDR, "little") + data


# ============================================================================================
# Processus principal
# ============================================================================================
class _Worker:
    def __init__(self, idx: int):
        self.idx = idx
        self.proc: Optional[asyncio.subprocess.Process] = None
        self.alive = False
        self.ready: Optional[asyncio.Event] = None
        self.pending: Dict[int, asyncio.Future] = {}
        self.reader: Optional[asyncio.Task] = None
        self.pid: Optional[int] = None
        self.loop_name = ""
        self.native: Optional[bool] = None
        self.lag_ms = 0.0
        self.cpu = 0.0
        self.total = 0           # parties confiées depuis le démarrage
        self.restarts = 0


class MatchPool:
    def __init__(self, size: int, on_stats: Callable[[Dict[str, int], Dict[int, int]], None],
                 loop_kind: str = "auto"):
        self.size = size
        self.on_stats = on_stats
        self.loop_kind = loop_kind if loop_kind in ("auto", "selector", "proactor") else "auto"
        self.workers: List[_Worker] = []
        self.per_worker = max_matches_per_worker()
        self._ids = itertools.count(1)
        self._logs: Dict[int, Callable[[str, str], None]] = {}
        self._diags: Dict[int, Callable[..., None]] = {}
        self._lives: Dict[int, Callable[[Dict[str, Any]], None]] = {}
        self._stopping = False
        self._respawns: set = set()
        self.overflows = 0          # parties confiées à un worker déjà plein (plus aucune place nulle part)

    # ---------- cycle de vie ----------
    async def start(self) -> int:
        """Lance les workers ; retourne le nombre de workers prêts (0 : parties jouées dans le processus principal)."""
        self.workers = [_Worker(i) for i in range(self.size)]
        await asyncio.gather(*(self._spawn(w) for w in self.workers), return_exceptions=True)
        return sum(1 for w in self.workers if w.alive)

    async def _spawn(self, w: _Worker):
        w.ready = asyncio.Event()
        w.alive = False
        w.pending = {}
        kwargs: Dict[str, Any] = {}
        if sys.platform == "win32":
            # Ctrl+C n'atteint pas le worker : le principal laisse finir les parties puis l'arrête lui-même
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        # sortie d'erreur du worker (pile d'appels d'un plantage…) dans logs/worker-N.stderr.log
        err_path = diag.worker_stderr_path(w.idx)
        if err_path:
            try:
                err_file = open(err_path, "ab")
                err_file.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} worker #{w.idx} "
                               f"(redémarrage {w.restarts}) =====\n".encode("utf-8"))
                err_file.flush()
                kwargs["stderr"] = err_file
            except OSError:
                err_file = None
        else:
            err_file = None
        t0 = time.perf_counter()
        try:
            w.proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "ffbot.udp_workers", "--worker", str(w.idx), self.loop_kind,
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, cwd=ROOT_DIR, **kwargs)
        except Exception as e:
            print(f"[udp-workers] worker #{w.idx} : lancement impossible ({e!r})", file=sys.stderr)
            diag.event("WORKER", "spawn_failed", level="error", code="WORKER_START", exc=e, w=w.idx)
            return
        finally:
            if err_file is not None:
                err_file.close()      # le processus fils garde sa propre copie du descripteur
        w.reader = asyncio.create_task(self._read(w), name=f"udp-worker-read:{w.idx}")
        proc = w.proc
        try:
            await asyncio.wait_for(w.ready.wait(), _READY_TIMEOUT_S)
            diag.event("WORKER", "ready", level="info", w=w.idx, pid=w.pid, loop=w.loop_name, native=w.native,
                       restarts=w.restarts, dur_ms=round((time.perf_counter() - t0) * 1000))
        except asyncio.TimeoutError:
            print(f"[udp-workers] worker #{w.idx} : pas prêt après {int(_READY_TIMEOUT_S)} s", file=sys.stderr)
            diag.event("WORKER", "not_ready", level="error", code="WORKER_START", w=w.idx,
                       msg=f"worker ไม่พร้อมภายใน {int(_READY_TIMEOUT_S)} วินาที")
            # seulement le processus lancé ici : s'il a planté avant d'être prêt, un remplaçant tourne peut-être déjà
            # dans w.proc (avec ses parties) et ne doit pas être tué
            if w.proc is proc:
                self._kill(w)

    async def stop(self):
        """Arrêt du serveur (après la fin ou la coupure des parties) : les workers se ferment."""
        self._stopping = True
        for task in list(self._respawns):
            task.cancel()
        for w in self.workers:
            if w.proc and w.proc.returncode is None:
                self._send(w, {"t": "stop"})
                try:
                    w.proc.stdin.close()
                except Exception:
                    pass
        for w in self.workers:
            if w.proc and w.proc.returncode is None:
                try:
                    await asyncio.wait_for(w.proc.wait(), _STOP_TIMEOUT_S)
                except asyncio.TimeoutError:
                    self._kill(w)
                    try:
                        await asyncio.wait_for(w.proc.wait(), _STOP_TIMEOUT_S)
                    except Exception:
                        pass
            if w.reader:
                w.reader.cancel()
                await asyncio.gather(w.reader, return_exceptions=True)
            self._fail_pending(w, "CANCELLED")

    @staticmethod
    def _kill(w: _Worker):
        try:
            if w.proc and w.proc.returncode is None:
                w.proc.kill()
        except Exception:
            pass

    # ---------- parties ----------
    def available(self) -> bool:
        return not self._stopping and any(w.alive for w in self.workers)

    def capacity(self) -> int:
        """Parties que les workers vivants peuvent jouer en même temps (plafond de tout le serveur)."""
        return sum(self.per_worker for w in self.workers if w.alive)

    def _pick(self, force: bool = False) -> Optional[_Worker]:
        """Worker le moins chargé sous son plafond. `force` : une partie déjà trouvée doit être jouée quelque part
        (le joueur est inscrit) : le moins chargé même plein, plutôt que la boucle principale."""
        alive = [w for w in self.workers if w.alive]
        room = [w for w in alive if len(w.pending) < self.per_worker]
        pool = room or (alive if force else [])
        if not room and pool:
            self.overflows += 1
            diag.event("WORKER", "overflow", level="warning", code="WORKER_OVERFLOW", n=self.overflows,
                       busy=sum(len(w.pending) for w in alive), capacity=self.capacity(),
                       msg="worker ทุกตัวเต็ม: แมตช์ที่เจอแล้วถูกส่งเข้า worker ที่ว่างที่สุด (เกินขีดจำกัด)")
        return min(pool, key=lambda w: (len(w.pending), w.lag_ms)) if pool else None

    async def run(self, args: tuple, on_log: Optional[Callable[[str, str], None]] = None,
                  on_diag: Optional[Callable[..., None]] = None, info: Optional[Dict[str, Any]] = None,
                  on_live: Optional[Callable[[Dict[str, Any]], None]] = None,
                  opts: Optional[Dict[str, Any]] = None) -> bool:
        """Joue une partie dans le worker le moins chargé ; True si elle s'est terminée normalement.
        `info` reçoit la cause de fin et les mesures de la partie (reason, handshake_ms, rx_packets…, worker).
        `on_diag(rec, w=…)` : étapes du journal de diagnostic émises par la partie dans le worker.
        `on_live({"hp": …})` : état en direct de la partie (PV du joueur), envoyé quand il change.
        `opts` : réglages du site pour cette partie (protocol.play_match_core) ; le worker n'a que les valeurs par
        défaut du module.
        Annulation (compte banni, arrêt du serveur…) : la partie est coupée dans le worker."""
        info = info if info is not None else {}
        w = self._pick(force=True)
        if w is None:
            info["reason"] = "WORKER_SEND"
            raise RuntimeError("aucun worker UDP disponible")
        mid = next(self._ids)
        fut = asyncio.get_running_loop().create_future()
        w.pending[mid] = fut
        if on_log:
            self._logs[mid] = on_log
        if on_diag:
            self._diags[mid] = on_diag
        if on_live:
            self._lives[mid] = on_live
        w.total += 1
        info["worker"] = w.idx
        try:
            if not self._send(w, {"t": "start", "id": mid, "args": args, "opts": opts or {}}):
                info["reason"] = "WORKER_SEND"
                return False
            result = await fut
            info.update(result.get("info") or {})
            return bool(result.get("ok"))
        except asyncio.CancelledError:
            info["reason"] = info.get("reason") or "CANCELLED"
            if w.alive:
                self._send(w, {"t": "cancel", "id": mid})
            raise
        finally:
            w.pending.pop(mid, None)
            self._logs.pop(mid, None)
            self._diags.pop(mid, None)
            self._lives.pop(mid, None)

    def _send(self, w: _Worker, msg: Dict[str, Any]) -> bool:
        try:
            w.proc.stdin.write(_frame(msg))
            return True
        except Exception:
            return False      # worker mort : sa lecture le constate (fin de flux) et ses parties sont réglées

    # ---------- messages des workers ----------
    async def _read(self, w: _Worker):
        stream = w.proc.stdout
        try:
            while True:
                header = await stream.readexactly(_HDR)
                body = await stream.readexactly(int.from_bytes(header, "little"))
                self._on_message(w, pickle.loads(body))
        except (asyncio.IncompleteReadError, ConnectionError, OSError, EOFError):
            pass
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[udp-workers] worker #{w.idx} : message illisible ({e!r})", file=sys.stderr)
            diag.event("WORKER", "bad_message", level="error", code="WORKER_EXIT", exc=e, w=w.idx)
        finally:
            self._on_exit(w)

    def _on_message(self, w: _Worker, msg: Dict[str, Any]):
        kind = msg.get("t")
        if kind == "end":
            fut = w.pending.pop(msg.get("id"), None)
            if fut and not fut.done():
                fut.set_result({"ok": bool(msg.get("ok")), "info": msg.get("info") or {}})
        elif kind == "diag":
            rec = msg.get("rec")
            if isinstance(rec, dict):
                callback = self._diags.get(msg.get("id"))
                try:
                    if callback:
                        callback(rec, w=w.idx)     # rattachée au compte de la partie
                    else:
                        diag.ingest(rec, w=w.idx)
                except Exception:
                    pass
        elif kind == "stats":
            w.lag_ms = float(msg.get("lag") or 0.0)
            w.cpu = float(msg.get("cpu") or 0.0)
            try:
                self.on_stats(msg.get("d") or {}, msg.get("by_cmd") or {})
            except Exception:
                pass
        elif kind == "live":
            callback = self._lives.get(msg.get("id"))
            if callback:
                try:
                    callback(msg)
                except Exception:
                    pass
        elif kind == "log":
            callback = self._logs.get(msg.get("id"))
            if callback:
                try:
                    callback(msg.get("level", "info"), msg.get("msg", ""))
                except Exception:
                    pass
        elif kind == "ready":
            w.pid = msg.get("pid")
            w.native = msg.get("native")
            w.loop_name = msg.get("loop", "")
            w.alive = True
            w.ready.set()

    def _fail_pending(self, w: _Worker, reason: str = "WORKER_LOST"):
        for fut in w.pending.values():
            if not fut.done():
                fut.set_result({"ok": False, "info": {"reason": reason}})
        w.pending.clear()

    def _on_exit(self, w: _Worker):
        was_alive, w.alive = w.alive, False
        lost = sum(1 for f in w.pending.values() if not f.done())
        self._fail_pending(w)
        if self._stopping:
            return
        print(f"[udp-workers] worker #{w.idx} arrêté{' — ses parties comptent échouées' if was_alive else ''} : "
              f"relancé dans {int(_RESPAWN_DELAY_S)} s", file=sys.stderr)
        task = asyncio.create_task(self._respawn(w, lost))
        self._respawns.add(task)
        task.add_done_callback(self._respawns.discard)

    async def _respawn(self, w: _Worker, lost: int = 0):
        t0 = time.monotonic()
        code = None
        if w.proc:
            try:
                code = await asyncio.wait_for(w.proc.wait(), 2.0)   # code de sortie (cause du plantage)
            except Exception:
                code = w.proc.returncode
        diag.event("WORKER", "exit", level="error", code="WORKER_EXIT", w=w.idx, pid=w.pid, returncode=code,
                   lost_matches=lost, lag_ms=round(w.lag_ms), cpu=round(w.cpu),
                   stderr=diag.worker_stderr_path(w.idx),
                   msg=f"worker #{w.idx} หยุดทำงาน (exit {code}) แมตช์ที่เล่นอยู่ {lost} แมตช์นับเป็นล้มเหลว: "
                       f"เริ่มใหม่ใน {int(_RESPAWN_DELAY_S)} วินาที")
        await asyncio.sleep(max(0.0, _RESPAWN_DELAY_S - (time.monotonic() - t0)))
        if self._stopping:
            return
        self._kill(w)
        w.restarts += 1
        await self._spawn(w)

    def summary(self) -> Dict[str, Any]:
        """Une ligne par minute dans le journal : parties par worker, retard et CPU des workers."""
        alive = [w for w in self.workers if w.alive]
        return {"alive": f"{len(alive)}/{len(self.workers)}",
                "matches": "/".join(str(len(w.pending)) for w in self.workers),
                "lag_max_ms": round(max((w.lag_ms for w in alive), default=0)),
                "cpu_max": round(max((w.cpu for w in alive), default=0)),
                "overflows": self.overflows, "restarts": sum(w.restarts for w in self.workers)}

    # ---------- supervision ----------
    def lag_ms(self) -> Optional[float]:
        """Retard de boucle du worker le moins chargé (protection anti-saturation) ; None sans worker."""
        lags = [w.lag_ms for w in self.workers if w.alive]
        return min(lags) if lags else None

    def status(self) -> List[Dict[str, Any]]:
        return [{"idx": w.idx, "pid": w.pid, "alive": w.alive, "matches": len(w.pending), "max": self.per_worker,
                 "total": w.total,
                 "lag_ms": round(w.lag_ms, 1), "cpu": round(w.cpu, 1), "native": w.native, "loop": w.loop_name,
                 "restarts": w.restarts} for w in self.workers]


# ============================================================================================
# Processus worker : python -m ffbot.udp_workers --worker <n> <boucle>
# ============================================================================================
async def _stats_loop(protocol, send, tasks: Dict[int, asyncio.Task]):
    loop = asyncio.get_running_loop()
    stats = protocol._udp_stats
    names = protocol._UdpStats.COUNTERS
    last = {n: getattr(stats, n) for n in names}
    last_cmd = dict(stats.by_cmd)
    lags: deque = deque(maxlen=10)
    cpu_prev, t_prev = time.process_time(), time.monotonic()
    while True:
        t0 = loop.time()
        await asyncio.sleep(1.0)
        lags.append(max(0.0, loop.time() - t0 - 1.0) * 1000)
        cur = {n: getattr(stats, n) for n in names}
        cmd = dict(stats.by_cmd)
        delta = {n: cur[n] - last[n] for n in names if cur[n] != last[n]}
        dcmd = {c: n - last_cmd.get(c, 0) for c, n in cmd.items() if n != last_cmd.get(c, 0)}
        last, last_cmd = cur, cmd
        cpu_now, t_now = time.process_time(), time.monotonic()
        cpu = (cpu_now - cpu_prev) / max(1e-6, t_now - t_prev) * 100
        cpu_prev, t_prev = cpu_now, t_now
        send({"t": "stats", "d": delta, "by_cmd": dcmd, "lag": round(sum(lags) / len(lags), 1),
              "cpu": round(cpu, 1), "matches": len(tasks)})


async def _live_loop(states: Dict[int, Dict[str, Any]], send):
    """PV en direct de chaque partie (state["hp"], écrit par play_match_core) envoyés au principal quand ils changent."""
    sent: Dict[int, Any] = {}
    while True:
        await asyncio.sleep(1.0)
        for mid, state in list(states.items()):
            hp = state.get("hp")
            if hp is not None and sent.get(mid) != hp:
                sent[mid] = hp
                send({"t": "live", "id": mid, "hp": hp})
        for mid in [m for m in sent if m not in states]:
            del sent[mid]


async def _serve(inp, out) -> threading.Thread:
    from ffbot import protocol, udp_codec
    from ffbot.hooks import bot_state

    protocol.CONSOLE_VERBOSE = False
    loop = asyncio.get_running_loop()
    outbox: "queue.Queue[Optional[bytes]]" = queue.Queue()

    def write_out():
        while True:
            item = outbox.get()
            if item is None:
                return
            try:
                out.write(item)
                out.flush()
            except Exception:
                return

    writer = threading.Thread(target=write_out, name="udp-worker-out", daemon=True)
    writer.start()

    def send(msg: Dict[str, Any]):
        outbox.put(_frame(msg))

    current = contextvars.ContextVar("udp_match_id", default=None)

    def sink(level: str, message: str, runner: Any):
        # journal d'une partie (avertissements, erreurs) renvoyé au principal, qui l'inscrit sous son compte
        mid = current.get()
        if mid is not None and level in ("warning", "error"):
            send({"t": "log", "id": mid, "level": level, "msg": str(message)[:500]})

    bot_state.log_sink = sink
    # étapes du journal de diagnostic : écrites par le principal, rattachées au compte de la partie
    diag.set_remote(lambda rec: send({"t": "diag", "id": current.get(), "rec": rec}))
    tasks: Dict[int, asyncio.Task] = {}
    states: Dict[int, Dict[str, Any]] = {}     # état en direct des parties (PV), relu par _live_loop
    stop = asyncio.Event()

    async def run_match(mid: int, args: tuple, opts: Optional[Dict[str, Any]] = None):
        current.set(mid)
        state: Dict[str, Any] = {"completed": False}
        states[mid] = state
        try:
            await protocol.play_match_core(*args, state=state, opts=opts)
        except asyncio.CancelledError:
            state["reason"] = state.get("reason") or "CANCELLED"
        except Exception as e:
            sink("error", f"[MATCH] worker : {e!r}", None)
            state["reason"] = "MATCH_EXCEPTION"
            state["error"] = repr(e)[:300]
            diag.event("MATCH", "worker_exception", level="error", code="MATCH_EXCEPTION", exc=e)
        finally:
            tasks.pop(mid, None)
            states.pop(mid, None)
            info = {k: v for k, v in state.items() if k != "completed"
                    and (v is None or isinstance(v, (bool, int, float, str)))}
            send({"t": "end", "id": mid, "ok": bool(state["completed"]), "info": info})

    def handle(msg: Dict[str, Any]):
        kind = msg.get("t")
        if kind == "start":
            tasks[msg["id"]] = loop.create_task(run_match(msg["id"], tuple(msg["args"]), msg.get("opts")))
        elif kind == "cancel":
            task = tasks.get(msg.get("id"))
            if task:
                task.cancel()
        elif kind == "stop":
            stop.set()

    def read_in():
        try:
            while True:
                header = inp.read(_HDR)
                if not header or len(header) < _HDR:
                    break
                size = int.from_bytes(header, "little")
                body = inp.read(size)
                if len(body) < size:
                    break
                loop.call_soon_threadsafe(handle, pickle.loads(body))
        except Exception:
            pass
        finally:
            try:
                loop.call_soon_threadsafe(stop.set)     # principal disparu : on s'arrête aussi
            except RuntimeError:
                pass

    threading.Thread(target=read_in, name="udp-worker-in", daemon=True).start()
    stats_task = loop.create_task(_stats_loop(protocol, send, tasks))
    live_task = loop.create_task(_live_loop(states, send))
    send({"t": "ready", "pid": os.getpid(), "native": bool(udp_codec.NATIVE), "loop": type(loop).__name__})
    await stop.wait()
    stats_task.cancel()
    live_task.cancel()
    running = list(tasks.values())
    for task in running:
        task.cancel()
    await asyncio.gather(stats_task, live_task, *running, return_exceptions=True)
    outbox.put(None)
    return writer


def _worker_main(loop_kind: str):
    try:
        signal.signal(signal.SIGINT, signal.SIG_IGN)
    except Exception:
        pass
    out = sys.stdout.buffer
    inp = sys.stdin.buffer
    sys.stdout = sys.stderr          # la sortie standard est réservée aux messages : tout print part sur stderr
    # Windows : boucle « selector » (socket UDP inscrite une fois, lecture par rappel) au lieu d'une tâche de lecture
    # par partie (boucle Proactor), bien moins coûteux par paquet. UDP_WORKER_LOOP=proactor pour revenir en arrière.
    use_selector = loop_kind == "selector" or (loop_kind == "auto" and sys.platform == "win32")
    loop = asyncio.SelectorEventLoop() if use_selector else asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    writer = None
    try:
        writer = loop.run_until_complete(_serve(inp, out))
    finally:
        if writer:
            writer.join(timeout=2.0)
        loop.close()


if __name__ == "__main__" and len(sys.argv) >= 3 and sys.argv[1] == "--worker":
    _worker_main(sys.argv[3] if len(sys.argv) > 3 else "auto")
