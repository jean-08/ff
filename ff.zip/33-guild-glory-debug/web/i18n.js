"use strict";
// Page language: French by default, English on demand (FR / EN button in the top bar, kept in localStorage "tb.lang").
// Texts are written in English in index.html / app.js; t("English {0}", x) gives the French text when LANG is "fr".
// trDom(el) translates the whole text nodes and the title / placeholder / aria-label attributes of an element
// (static page at load, then every block drawn by setHTML in app.js).

const LANG = (() => { try { const v = JSON.parse(localStorage.getItem("tb.lang")); return v === "en" ? "en" : "fr"; } catch { return "fr"; } })();
document.documentElement.lang = LANG;

const FR = {
    // ---------- top bar / static page ----------
    "Bot-only Clash Squad teams · clan glory · honor score": "Équipes de bots Clash Squad · gloire de guilde · score d'honneur",
    "Connecting…": "Connexion…",
    "Settings": "Réglages",
    "Every recorded match as JSON": "Tous les matchs enregistrés, en JSON",
    "Export matches": "Exporter les matchs",
    "Bots create their own team, the leader searches for a Clash Squad match, every bot plays it to the end, and each match is recorded. Use only accounts that do not play anywhere else (a second login of the same account disconnects the first one).":
        "Les bots créent leur propre équipe, le chef lance la recherche d'un match Clash Squad, chaque bot le joue jusqu'au bout et chaque match est enregistré. N'utilise que des comptes qui ne jouent nulle part ailleurs (une 2e connexion du même compte déconnecte la première).",
    "Clan · group map": "Guilde · carte des groupes",
    "Clan ID": "ID de guilde",
    "Clan ID to follow": "ID de la guilde à suivre",
    "Refresh clan": "Actualiser la guilde",
    "Start teams": "Lancer des équipes",
    "Mode": "Mode",
    "Ranked CS": "CS Classé",
    "Ranked: a bot under 95 honor switches its team to Clash Squad · Iron Cage: 2 bots (Duo: 1 or 2)":
        "Classé : un bot sous 95 d'honneur fait passer son équipe en Clash Squad · Iron Cage : 2 bots (Duo : 1 ou 2)",
    "Teams": "Équipes",
    "Fewer teams": "Moins d'équipes",
    "More teams": "Plus d'équipes",
    "Bots per team": "Bots par équipe",
    "Matches per team": "Matchs par équipe",
    "0 = keep playing until stopped": "0 = jouer jusqu'à l'arrêt",
    "Level goal": "Niveau objectif",
    "0 = no goal · at this level an account leaves its team once its match is over, and the next free account takes its place":
        "0 = aucun objectif · à ce niveau, un compte quitte son équipe à la fin de son match et le prochain compte libre prend sa place",
    "Search one team at a time": "Recherche une équipe à la fois",
    "On": "Activé",
    "Off": "Désactivé",
    "On: teams of the same mode search one at a time, the others wait in a queue (our bot teams never meet) · Off: every team searches at once; when two of our teams meet, their drones are cast one side at a time · applies at once":
        "Activé : les équipes du même mode cherchent une par une, les autres attendent leur tour (nos équipes ne se rencontrent jamais) · Désactivé : toutes cherchent en même temps ; si deux de nos équipes se rencontrent, leurs drones sont lancés un camp à la fois · s'applique tout de suite",
    "Start": "Lancer",
    "Each team finishes its current match, then leaves": "Chaque équipe finit son match en cours, puis s'arrête",
    "Stop all after match": "Tout arrêter après le match",
    "Cuts the matches in progress": "Coupe les matchs en cours",
    "Stop all now": "Tout arrêter maintenant",
    "Join clan": "Rejoindre une guilde",
    "Send a join request from pool accounts": "Envoyer une demande d'adhésion depuis les comptes de la réserve",
    "e.g. 3068420572": "ex. 3068420572",
    "Accounts": "Comptes",
    "All pool accounts": "Tous les comptes de la réserve",
    "Selected accounts": "Comptes sélectionnés",
    "Send join requests": "Envoyer les demandes",
    "The clan leader accepts the requests in game (an open clan lets them in directly).":
        "Le chef de guilde accepte les demandes en jeu (une guilde ouverte les fait entrer directement).",
    "· used to be in .env": "· avant dans .env",
    "Discard changes": "Annuler les modifications",
    "Save changes": "Enregistrer",
    "Live": "En direct",
    "followed at once, by matches already in progress too ·": "suivi tout de suite, même par les matchs déjà en cours ·",
    "Next match": "Prochain match",
    "set when a match starts ·": "pris au début d'un match ·",
    "Restart": "Redémarrage",
    "saved to .env, used after run.py restarts": "écrit dans .env, utilisé après le redémarrage de run.py",
    "Loading settings…": "Chargement des réglages…",
    "Match results": "Résultats des matchs",
    "All": "Tout",
    "Match history": "Historique des matchs",
    "· as the game shows it": "· comme dans le jeu",
    "Account whose match history to load": "Compte dont charger l'historique",
    "Load history": "Charger l'historique",
    "Download all": "Tout télécharger",
    "Pick an account and press “Load history”: its last matches (score, K/D/A, damage of every player) are drawn as images you can download.":
        "Choisis un compte et clique sur « Charger l'historique » : ses derniers matchs (score, K/D/A, dégâts de chaque joueur) sont dessinés en images téléchargeables.",
    "Account pool": "Réserve de comptes",
    "Paste guest accounts, one per line\n• UID:password\n• guest_account_info (Garena guest file)":
        "Colle des comptes invités, un par ligne\n• UID:motdepasse\n• guest_account_info (fichier invité Garena)",
    "Add to pool": "Ajouter à la réserve",
    "Select all free": "Sélectionner les libres",
    "Reads each account's honor score from the game (selected accounts, or all if none is selected)":
        "Lit le score d'honneur de chaque compte dans le jeu (comptes sélectionnés, ou tous si aucun n'est sélectionné)",
    "Check honor score": "Vérifier l'honneur",
    "Claims every finished Elite Pass mission (all 4 weeks) and the daily reward (selected accounts, or all if none is selected)":
        "Réclame toutes les missions Elite Pass terminées (les 4 semaines) et la récompense du jour (comptes sélectionnés, ou tous si aucun n'est sélectionné)",
    "Claim pass rewards": "Réclamer le Pass",
    "Claims the guild and personal weekly activity rewards, then buys the weekly guild store item with the tokens (selected accounts, or all if none is selected)":
        "Réclame les récompenses d'activité hebdo de guilde et personnelles, puis achète l'article de la boutique de guilde avec les jetons (comptes sélectionnés, ou tous si aucun n'est sélectionné)",
    "Claim guild rewards": "Réclamer la guilde",
    "Accounts whose login failed can be used again": "Les comptes dont la connexion a échoué peuvent resservir",
    "Retry selected": "Réessayer la sélection",
    "Delete selected": "Supprimer la sélection",

    // ---------- live state ----------
    "Connected": "Connecté",
    "Server offline": "Serveur hors ligne",
    // KPIs
    "Teams running": "Équipes en cours",
    "Matches recorded": "Matchs enregistrés",
    "Finished normally": "Terminés normalement",
    "Deaths per round": "Morts par manche",
    "Pull-backs per bot-match": "Retours en arrière par bot-match",
    "EXP per bot-match": "EXP par bot-match",
    "Damage per bot-match": "Dégâts par bot-match",
    "Average match time": "Durée moyenne d'un match",
    "{0} in a match · {1} waiting for search turn": "{0} en match · {1} en attente de leur tour",
    "{0} bot-matches": "{0} bot-matchs",
    "{0} deaths · {1} in zone": "{0} morts · {1} dans la zone",
    "144s {0} · stuck {1}": "144 : {0} · bloqué : {1}",
    "total {0}": "total {0}",
    "ran {0} m per bot": "{0} m courus par bot",
    "<b>{0}</b> free of {1} accounts": "<b>{0}</b> libres sur {1} comptes",
    "{0} running / {1} groups · {2}": "{0} en cours / {1} groupes · {2}",
    // pool counters / need
    "total": "total",
    "free": "libres",
    "in a team": "en équipe",
    "level reached": "niveau atteint",
    "login failed": "connexion échouée",
    "banned": "bannis",
    "Accounts that reached the level goal": "Comptes qui ont atteint le niveau objectif",
    "needs": "il faut",
    "accounts ·": "comptes ·",
    // states
    "Starting": "Démarrage", "Logging in": "Connexion", "Connecting": "Connexion au serveur", "Forming team": "Formation de l'équipe",
    "In team": "En équipe", "Searching": "Recherche", "In match": "En match", "Re-forming": "Reformation", "Finished": "Terminée",
    "Failed": "Échec", "Stopped": "Arrêtée", "Cooling down (code 57)": "Pause (code 57)", "Waiting for search turn": "Attend son tour de recherche",
    "Waiting": "En attente", "Online": "En ligne",
    "New": "Nouveau", "Ready": "Prêt", "Banned": "Banni", "Login failed": "Connexion échouée", "Level reached": "Niveau atteint",
    "Server went quiet": "Serveur muet", "Cancelled": "Annulé", "Error": "Erreur", "Could not join": "Impossible de rejoindre",
    "Network error": "Erreur réseau", "Too long": "Trop long", "Lost after outage": "Perdu après coupure", "Dead": "Mort",
    "Worker unavailable": "Worker indisponible", "Unknown": "Inconnu",
    "Leader": "Chef", "Officer": "Officier", "Member": "Membre",
    // clan
    "Enter your clan ID above and press “Refresh clan” — while teams run, the clan page is re-read every minute.":
        "Entre l'ID de ta guilde ci-dessus et clique sur « Actualiser la guilde » — tant que des équipes tournent, la page de la guilde est relue chaque minute.",
    "★ FULL SQUAD": "★ ESCOUADE COMPLÈTE",
    "Clan logo {0}": "Logo de guilde {0}",
    "{0} GROUP": "{0} GROUPE", "{0} GROUPS": "{0} GROUPES",
    "Clan total glory": "Gloire totale de la guilde",
    "Week ends in {0}": "Fin de semaine dans {0}",
    "updated {0}": "mis à jour {0}",
    "Members": "Membres", "Captain": "Capitaine", "♛ Group glory": "♛ Gloire des groupes",
    "This week's glory of the bots of the running groups": "Gloire de la semaine des bots des groupes en cours",
    "{0} group": "Groupe {0}",
    "{0} glory": "{0} gloire",
    "View group ↓": "Voir le groupe ↓",
    "No running group — start teams below.": "Aucun groupe en cours — lance des équipes plus bas.",
    "Clan": "Guilde", "Weekly glory": "Gloire de la semaine",
    "Clan members ({0}) · {1} bots of this pool": "Membres de la guilde ({0}) · {1} bots de cette réserve",
    "Player": "Joueur", "Role": "Rôle", "This week": "Cette semaine", "Total glory": "Gloire totale", "Honor": "Honneur", "Last login": "Dernière connexion",
    "Honor score not checked yet": "Score d'honneur pas encore vérifié", "Honor score": "Score d'honneur",
    "Honor score · checked {0}": "Score d'honneur · vérifié {0}", " · last change {0} on {1}": " · dernier changement {0} le {1}",
    "honor —": "honneur —",
    // jobs
    "Checking honor scores…": "Vérification de l'honneur…", "Honor scores checked": "Honneur vérifié",
    "read": "lus", "failed": "échecs",
    "Claiming pass rewards…": "Réclamation du Pass…", "Pass rewards claimed": "Pass réclamé",
    "{0}/{1} accounts": "{0}/{1} comptes",
    "missions +": "missions +", "daily · {0} rewards": "quotidiennes · {0} récompenses",
    "Claiming guild rewards…": "Réclamation de la guilde…", "Guild rewards claimed": "Guilde réclamée",
    "tokens ·": "jetons ·", "store items bought": "articles achetés",
    "Sending…": "Envoi…", "Done": "Terminé", "clan": "guilde", "sent": "envoyées",
    // teams
    "No team yet — add accounts to the pool, then press “Start”.": "Aucune équipe — ajoute des comptes à la réserve, puis clique sur « Lancer ».",
    "Group {0}": "Groupe {0}", "code {0}": "code {0}",
    "An account that reaches this level is swapped after its match": "Un compte qui atteint ce niveau est remplacé après son match",
    "level goal": "niveau objectif",
    "ended {0}": "terminée {0}",
    "★ GLORY": "★ GLOIRE",
    "This week's glory of these bots in the clan": "Gloire de la semaine de ces bots dans la guilde",
    "Region": "Région", "Uptime": "Durée", "Last match": "Dernier match",
    "{0} games": "{0} parties", " · since {0}": " · depuis {0}",
    "in match {0}": "en match {0}", "re-formed {0}×": "reformée {0}×", "stops after this match": "s'arrête après ce match",
    "search queue #": "file de recherche n°", " · group {0} is searching": " · le groupe {0} cherche",
    "searching for {0}": "recherche depuis {0}", " · {0} team(s) waiting": " · {0} équipe(s) en attente",
    "Goal · {0}/{1} matches": "Objectif · {0}/{1} matchs", "No match limit": "Pas de limite de matchs",
    "Stop after match": "Arrêter après le match", "Stop now": "Arrêter maintenant",
    "Details · team log ({0})": "Détails · journal de l'équipe ({0})",
    "Finished teams ({0})": "Équipes terminées ({0})",
    "Lv {0}": "Niv. {0}", "goal Lv {0} reached": "objectif Niv. {0} atteint", "{0} EXP to Lv {1}": "{0} EXP avant Niv. {1}",
    "EXP earned since this team started": "EXP gagnée depuis le lancement de l'équipe",
    // results
    "No match in this period yet.": "Aucun match sur cette période.",
    "How matches ended:": "Fin des matchs :",
    "rounds avg": "manches moy.", "knocked (crawling) avg": "à terre (rampant) moy.", "server lag": "latence serveur",
    "Our team": "Notre équipe", "Opponents": "Adversaires", " (team {0})": " (équipe {0})",
    "Damage dealt by this bot in this match, updated live": "Dégâts infligés par ce bot dans ce match, en direct",
    "Damage dealt by this bot in its last match": "Dégâts infligés par ce bot dans son dernier match",
    "damage": "dégâts", "last match damage": "dégâts du dernier match", " · {0} hit": " · {0} touche", " · {0} hits": " · {0} touches",
    "finished": "terminé",
    "rounds died / rounds": "manches mort / manches", "deaths {0}/{1}": "morts {0}/{1}", " (zone {0})": " (zone {0})",
    "damage dealt by the bot (number of hits)": "dégâts infligés par le bot (nombre de touches)",
    "damage {0}": "dégâts {0}", " ({0} hits)": " ({0} touches)",
    "positions corrected by the server": "positions corrigées par le serveur", "pull-backs {0}": "retours {0}",
    "stuck in a corner, followed a teammate's path": "bloqué dans un coin, a suivi le chemin d'un coéquipier",
    "stuck {0}": "bloqué {0}", "ran {0} m": "{0} m courus", "level after the match": "niveau après le match",
    "Time": "Heure", "Team": "Équipe", "Length": "Durée", "Each bot": "Chaque bot",
    "The pool is empty — paste guest accounts above and press “Add to pool”.": "La réserve est vide — colle des comptes invités ci-dessus et clique sur « Ajouter à la réserve ».",
    "Account": "Compte", "Status": "Statut", "Pass claimed": "Pass réclamé",
    "Elite Pass missions and daily rewards claimed after the matches": "Missions Elite Pass et récompenses quotidiennes réclamées après les matchs",
    "Last used": "Dernière utilisation", "Select {0}": "Sélectionner {0}", "checked {0}": "vérifié {0}", "last {0}": "dernière {0}",
    // actions / toasts / dialogs
    "Please confirm": "Confirmation", "Cancel": "Annuler", "Confirm": "Confirmer",
    "Search turns on: teams of the same mode search one at a time": "Tours activés : les équipes du même mode cherchent une par une",
    "Search turns off: every team searches at once": "Tours désactivés : toutes les équipes cherchent en même temps",
    "Level goal {0}": "Niveau objectif {0}", " · {0} account(s) already there": " · {0} compte(s) déjà à ce niveau",
    " · {0} account(s) free again": " · {0} compte(s) de nouveau libres", "No level goal": "Aucun niveau objectif",
    "{0} {1} team(s) started": "{0} équipe(s) {1} lancée(s)", " · level goal {0}": " · niveau objectif {0}",
    "Stop every team now? Matches in progress are cut.": "Arrêter toutes les équipes maintenant ? Les matchs en cours sont coupés.",
    "Stop every team? Each one finishes its current match first.": "Arrêter toutes les équipes ? Chacune finit d'abord son match en cours.",
    "Stop": "Arrêter", "Stop sent to {0} team(s)": "Arrêt envoyé à {0} équipe(s)",
    "Stop this team now? Its match in progress is cut.": "Arrêter cette équipe maintenant ? Son match en cours est coupé.",
    "Team stopped": "Équipe arrêtée", "The team stops after this match": "L'équipe s'arrête après ce match",
    "Paste some accounts first": "Colle d'abord des comptes",
    "{0} added": "{0} ajouté(s)", " · {0} already in the pool": " · {0} déjà dans la réserve", " · {0} invalid": " · {0} invalide(s)",
    "{0} account(s) selected": "{0} compte(s) sélectionné(s)", "Select accounts in the pool first": "Sélectionne d'abord des comptes dans la réserve",
    "Delete {0} account(s) from the pool? Accounts in a running team are kept.": "Supprimer {0} compte(s) de la réserve ? Les comptes dans une équipe en cours sont gardés.",
    "Delete": "Supprimer", "{0} deleted": "{0} supprimé(s)", "{0} account(s) can be used again": "{0} compte(s) peuvent resservir",
    "Enter the clan ID as a number, e.g. 3106179650": "Entre l'ID de guilde en chiffres, ex. 3106179650",
    "Enter the clan ID as a number, e.g. 3068420572": "Entre l'ID de guilde en chiffres, ex. 3068420572",
    "Loading…": "Chargement…",
    "No account selected: check the honor score of all {0} pool account(s)? Accounts not in a team log in one by one.":
        "Aucun compte sélectionné : vérifier l'honneur des {0} compte(s) de la réserve ? Les comptes hors équipe se connectent un par un.",
    "Check all": "Tout vérifier", "Checking {0} account(s)…": "Vérification de {0} compte(s)…",
    "Claim every finished pass mission and the daily reward for {0} selected account(s)? Accounts not in a team log in one by one.":
        "Réclamer toutes les missions du Pass terminées et la récompense du jour pour {0} compte(s) sélectionné(s) ? Les comptes hors équipe se connectent un par un.",
    "Claim every finished pass mission and the daily reward for {0} pool account(s)? Accounts not in a team log in one by one.":
        "Réclamer toutes les missions du Pass terminées et la récompense du jour pour {0} compte(s) de la réserve ? Les comptes hors équipe se connectent un par un.",
    "Claim": "Réclamer", "Claiming for {0} account(s)…": "Réclamation pour {0} compte(s)…",
    "Claim the guild and personal activity rewards, then buy the weekly guild store item, for {0} selected account(s)? Accounts not in a team log in one by one.":
        "Réclamer les récompenses d'activité de guilde et personnelles, puis acheter l'article hebdo de la boutique de guilde, pour {0} compte(s) sélectionné(s) ? Les comptes hors équipe se connectent un par un.",
    "Claim the guild and personal activity rewards, then buy the weekly guild store item, for {0} pool account(s)? Accounts not in a team log in one by one.":
        "Réclamer les récompenses d'activité de guilde et personnelles, puis acheter l'article hebdo de la boutique de guilde, pour {0} compte(s) de la réserve ? Les comptes hors équipe se connectent un par un.",
    "Claiming guild rewards for {0} account(s)…": "Réclamation de la guilde pour {0} compte(s)…",
    "Send a join request to clan {0} from {1} account(s)?": "Envoyer une demande d'adhésion à la guilde {0} depuis {1} compte(s) ?",
    "Send": "Envoyer", "Sending join requests…": "Envoi des demandes…",
    // history
    " · in team": " · en équipe", "No account in the pool": "Aucun compte dans la réserve",
    "Add an account to the pool first": "Ajoute d'abord un compte à la réserve",
    "{0} match(es) for {1}": "{0} match(s) pour {1}",
    "Victory": "Victoire", "Defeat": "Défaite",
    "No match in {0}'s history yet.": "Aucun match dans l'historique de {0}.",
    "{0} last matches · read {1}": "{0} derniers matchs · lu {1}",
    "Download PNG": "Télécharger le PNG",
    "Match {0}": "Match {0}", "Lv {0} · +{1} EXP · +{2} gold": "Niv. {0} · +{1} EXP · +{2} or",
    "YOUR TEAM": "TON ÉQUIPE", "OPPONENTS": "ADVERSAIRES", "RATING": "NOTE", "NAME": "NOM", "DMG": "DÉG.",
    // settings
    "Reset to .env ({0})": "Revenir à .env ({0})", " · running now: {0}": " · en service : {0}",
    "{0} unsaved": "{0} non enregistré(s)", "Save {0} change(s)": "Enregistrer {0} modification(s)",
    "{0} UDP worker(s) get changes at once": "{0} worker(s) UDP reçoivent les changements tout de suite",
    "matches run in the main process": "les matchs tournent dans le processus principal",
    "Back to the .env value": "Valeur de .env remise",
    "Saved · sent to {0} worker(s), matches in progress follow now": "Enregistré · envoyé à {0} worker(s), les matchs en cours suivent maintenant",
    " · restart run.py for server settings": " · redémarre run.py pour les réglages serveur",
    "Language": "Langue",
    "Medkits sent (the server's answer cannot be read without the session key)": "Trousses envoyées (réponse du serveur illisible sans clé de session)",
    "HP": "PV", "dead": "mort", "healing…": "soin en cours…", "Medkits used in this match": "Trousses de soin utilisées dans ce match",
    "HP of this bot in the match, updated live": "PV de ce bot dans le match, en direct",
};

// settings page: [label, help] by setting key, group names / help by group id (see ffbot/site_settings.py)
const SET_FR = {
    HOST: ["Adresse de la page (HOST)", "127.0.0.1 = cet ordinateur seulement. 0.0.0.0 = accessible depuis le réseau : la page n'a pas de mot de passe, garde le port derrière un pare-feu / VPN."],
    PORT: ["Port de la page (PORT)", "Port de cette page."],
    SAVE_LOGS: ["Enregistrer les journaux (SAVE_LOGS)", "Désactivé = aucun fichier de journal (debug, passerelle, journal de guilde, captures UDP). La base de données est toujours gardée."],
    UDP_WORKERS: ["Processus UDP (UDP_WORKERS)", "Les matchs sont joués dans ce nombre de processus séparés (0 = dans le processus principal)."],
    UDP_WORKER_MAX_MATCHES: ["Matchs par worker (UDP_WORKER_MAX_MATCHES)", "Environ ce nombre de matchs par processus."],
    login_parallel: ["Connexions en même temps", "Connexions complètes en parallèle (LOGIN_PARALLEL)."],
    login_interval_s: ["Secondes entre deux connexions", "LOGIN_INTERVAL_S."],
    login_cooldown_s: ["Pause après HTTP 429 (s)", "Plus aucune connexion pendant ce temps quand le serveur répond « trop de requêtes » (LOGIN_COOLDOWN_S)."],
    br_leave_after_s: ["Quitter après (s)", "Quitte un match BR en vie après ce nombre de secondes (BR_LEAVE_AFTER_S). 0 = rester."],
    br_leave_on_death: ["Quitter à la mort", "Quitte dès que le bot est mort (BR_LEAVE_ON_DEATH)."],
    br_insta_leave: ["Quitter instantanément à la mort", "Quitte dès l'annonce de la mort, pas à PV bas (BR_INSTA_LEAVE)."],
    br_leave_hp: ["Quitter à PV", "Quitte en vie quand les PV descendent à cette valeur (BR_LEAVE_HP). 0 = désactivé."],
    br_death_max_s: ["Départ de secours avec surveillance de la mort (s)", "Avec « quitter à la mort » : quitte en vie après ce nombre de secondes quoi qu'il arrive (BR_DEATH_MAX_S)."],
    br_no_data_s: ["Pas de données de jeu après (s)", "Match rejoint mais le serveur n'envoie pas de données de jeu après ce délai : match abandonné (BR_NO_DATA_S). 0 = désactivé."],
    br_no_data_kb: ["… sous (Ko)", "Seuil de données pour la règle ci-dessus (BR_NO_DATA_KB)."],
    cs_zone_first: ["La zone avant l'ennemi", "Hors de la zone sûre, le bot y rentre et ne fait rien d'autre avant d'être 6 m à l'intérieur ; un ennemi au bord est contourné 4 m à l'intérieur de la zone, jamais dehors (CS_ZONE_FIRST)."],
    cs_heal: ["Se soigner avec les trousses", "Utilise une trousse de soin (objet 244, 2 par manche) dès que les PV descendent à la valeur ci-dessous (CS_HEAL)."],
    cs_heal_hp: ["Se soigner à PV", "PV auxquels le bot se soigne (sur 200, CS_HEAL_HP)."],
    cs_buy: ["Acheter le pistolet en début de manche", "Pendant la préparation : ouvre la boutique, achète le pistolet et le prend en main, à chaque manche (CS_BUY)."],
    cs_item_channel: ["Canal du soin / de l'achat", "auto = fiable avec la clé de session si le bot l'a, sinon comme le drone (non fiable, clé du match) ; session ; unrel (CS_ITEM_CHANNEL)."],
    cs_lane: ["Couloirs séparés, puis course sur l'ennemi", "Au cercle rouge, chaque bot prend un couloir différent de sa ville (chemins de vrais joueurs, data/cs_lanes.json) et le court jusqu'au bout ; un ennemi à moins de 30 m est poursuivi tout de suite (CS_LANE)."],
    cs_pack: ["Garder l'équipe groupée", "Les bots suivent un chef (plus petit numéro de joueur) et restent à 2,5 m de lui ; en combat, ils tournent tous autour du même ennemi (CS_PACK)."],
    cs_straight: ["Aller tout droit vers l'ennemi", "En début de manche, sans ennemi en vue : course tout droit vers la base d'en face, dans la zone, jusqu'à voir un ennemi (CS_STRAIGHT)."],
    cs_wall_turn: ["Changer de direction au mur", "Activé : après un mur, le bot tourne, le contourne ou le longe. Désactivé : il garde sa direction (CS_WALL_TURN)."],
    cs_foe_trace: ["Suivre la route de l'ennemi", "Le bot court sur le chemin pris par l'ennemi (ses positions enregistrées) jusqu'à le rejoindre (CS_FOE_TRACE)."],
    cs_chase: ["Poursuivre l'ennemi", "Le bot court vers l'ennemi (CS_CHASE). Les équipes du Team Bot poursuivent toujours."],
    cs_skill_test: ["Compétence drone", "Lance la compétence active (drone) en Clash Squad (CS_SKILL_TEST)."],
    cs_skill_per_round: ["Drones max par manche", "0 = pas de limite : relancé dès que la recharge est finie et qu'un ennemi est à portée. 1 = ancien comportement, un drone par manche (CS_SKILL_PER_ROUND)."],
    cs_skill_every_s: ["Recharge du drone (s)", "Attente après un drone accepté par le serveur (recharge du serveur : 60 s) (CS_SKILL_EVERY_S)."],
    cs_drone_range_m: ["Portée du drone (m)", "Lancé seulement si l'ennemi le plus proche est à moins de cette distance (CS_DRONE_RANGE_M)."],
    cs_skill_unreliable: ["Drone sur canal non fiable", "Messages de compétence envoyés en non fiable avec la clé du match (CS_SKILL_UNRELIABLE)."],
    cs_skill_relmatch: ["Drone en fiable + clé du match", "Mode de test des messages de compétence (CS_SKILL_RELMATCH). Prime sur le réglage ci-dessus."],
    cs_route: ["Utiliser les routes connues", "Patrouille par les cases sûres (CS_ROUTE)."],
    cs_walkmap: ["Mémoire de la carte", "Retient les cases praticables d'un match à l'autre (CS_WALKMAP)."],
    cs_loop_walk: ["Marche en boucles", "Marche lente en boucles (CS_LOOP_WALK)."],
    cs_tp_ack: ["Répondre aux téléportations", "Accuse les remises en position du serveur (CS_TP_ACK)."],
    udp_state_sync: ["Envoyer l'état du joueur", "UDP_STATE_SYNC."],
    udp_time_sync: ["Répondre à la synchro de l'heure", "UDP_TIME_SYNC."],
    udp_quit_on_leave: ["Envoyer « quitter » en partant", "Quitte comme le vrai client (191) au lieu de fermer la connexion (UDP_QUIT_ON_LEAVE)."],
    udp_quit_grace_s: ["Attente après « quitter » (s)", "UDP_QUIT_GRACE_S."],
    udp_ack_delay_s: ["Délai des accusés groupés (s)", "UDP_ACK_DELAY_S (0 à 1)."],
    udp_loading_end: ["Envoyer la fin de chargement", "UDP_LOADING_END."],
    udp_join_seq: ["Séquence d'entrée", "UDP_JOIN_SEQ."],
    udp_join_unrel: ["Entrée non fiable", "UDP_JOIN_UNREL."],
    udp_join_replay: ["Rejouer l'entrée du vrai client", "Rejoue captures/entry_replay.json dans chaque match (UDP_JOIN_REPLAY)."],
    join_token_split: ["Découpe du jeton d'entrée", "JOIN_TOKEN_SPLIT."],
    native_search: ["Chercher dans la région du compte", "Cherche dans la région du compte au lieu de BD (NATIVE_SEARCH). Prochaine recherche."],
    lobby_prematch_calls: ["Appels du lobby avant un match", "LOBBY_PREMATCH_CALLS."],
    activity_lobby_calls: ["Appels d'activité du lobby", "ACTIVITY_LOBBY_CALLS."],
    activity_rewards_enabled: ["Réclamer les récompenses d'activité", "ACTIVITY_REWARDS_ENABLED."],
    equip_character: ["Équiper le personnage", "EQUIP_CHARACTER."],
    gw_anticheat_report: ["Rapport anti-triche de la passerelle", "GW_ANTICHEAT_REPORT."],
    gw_anticheat_oracle: ["Oracle anti-triche", "GW_ANTICHEAT_ORACLE."],
    strip_device_session_key: ["Retirer la clé de session de l'appareil", "STRIP_DEVICE_SESSION_KEY."],
    server_max_matches: ["Matchs max sur ce serveur", "Les nouveaux matchs attendent au-delà de ce nombre (SERVER_MAX_MATCHES). 0 = pas de limite."],
    load_guard_lag_ms: ["Retenir les nouveaux matchs au-delà de (ms)", "LOAD_GUARD_LAG_MS. 0 = désactivé."],
    load_guard_resume_ms: ["Reprendre sous (ms)", "LOAD_GUARD_RESUME_MS."],
    udp_capture: ["Captures UDP par processus", "Capture brute des N premiers matchs BR de chaque processus (UDP_CAPTURE). 0 = aucune."],
    honor_min: ["Classé : honneur minimum", "Un bot de CS Classé sous ce score d'honneur est remplacé / son équipe passe en Clash Squad (TEAMLAB_HONOR_MIN)."],
    guild_auto: ["Réclamer la guilde automatiquement", "GUILD_AUTO."],
    guild_claim_min_glory: ["… à partir de la gloire hebdo", "GUILD_CLAIM_MIN_GLORY."],
    guild_claim_every_s: ["… au plus toutes les (s)", "GUILD_CLAIM_EVERY_S."],
    guild_store_buy: ["Articles de la boutique de guilde (article:prix, …)", "Achetés chaque semaine avec les jetons de guilde, ex. 10500016:200 (GUILD_STORE_BUY)."],
};
const SET_GROUPS_FR = {
    server: ["Serveur", "Lu au démarrage de run.py : écrit dans .env, utilisé après un redémarrage."],
    logins: ["Connexions", "Vitesse de connexion des comptes. S'applique tout de suite, comptes déjà en attente compris."],
    br: ["Battle Royale · quitter le match", "S'applique tout de suite, matchs en cours compris."],
    cs: ["Clash Squad · déplacement & drone", "S'applique tout de suite ; ceux marqués « Prochain match » sont pris au début d'un match."],
    udp: ["Protocole des matchs (UDP)", "Trafic bas niveau des matchs. À ne changer que si tu sais pourquoi."],
    lobby: ["Appels du lobby & du compte", "Appels faits autour d'un match."],
    load: ["Charge du serveur", "Limites qui protègent la machine quand beaucoup de matchs tournent."],
    teams: ["Équipes & guilde", "S'applique tout de suite."],
};

// messages written by the server in English (team logs, job logs, account notes, errors): phrase by phrase
const MSG_FR = [
    [/^(\S+) is banned$/, "$1 est banni"],
    [/login timed out/g, "connexion expirée"],
    [/login failed/g, "connexion échouée"],
    [/: equipped character (\S+) \+ skills/, " : personnage $1 équipé + compétences"],
    [/: could not equip the character \(/, " : impossible d'équiper le personnage ("],
    [/: lobby calls refused: /, " : appels du lobby refusés : "],
    [/: level up (\S+) → (\S+)/, " : niveau supérieur $1 → $2"],
    [/^Not in the last match: (.+) · all bots restart and re-form the team \((\d+) players\) in (\d+) s$/, "Absents du dernier match : $1 · tous les bots redémarrent et reforment l'équipe ($2 joueurs) dans $3 s"],
    [/Re-forming the team in (\d+) s \(retry (\d+)\/(\d+)\)/, "Reformation de l'équipe dans $1 s (essai $2/$3)"],
    [/^Error: /, "Erreur : "],
    [/stopped during login/, "arrêtée pendant la connexion"],
    [/: cannot connect to the gateway \(/, " : connexion à la passerelle impossible ("],
    [/: the gateway closed the connection/, " : la passerelle a fermé la connexion"],
    [/Team creation failed/, "Échec de la création de l'équipe"],
    [/^(.+) created team (\S+)$/, "$1 a créé l'équipe $2"],
    [/: no answer when joining team (\S+)/, " : pas de réponse en rejoignant l'équipe $1"],
    [/: could not join team (\S+) \(code (\S+)\)/, " : impossible de rejoindre l'équipe $1 (code $2)"],
    [/Team (\S+) has only (\d+)\/(\d+) players/, "L'équipe $1 n'a que $2/$3 joueurs"],
    [/Team (\S+) complete: (\d+)\/(\d+) players/, "Équipe $1 complète : $2/$3 joueurs"],
    [/Honor score below (\d+): /, "Honneur sous $1 : "],
    [/ · replaced by (.+) · team stays in Ranked CS/, " · remplacés par $1 · l'équipe reste en CS Classé"],
    [/ · not enough free accounts with honor ≥ (\d+) · switching to normal Clash Squad (\S+)/, " · pas assez de comptes libres avec honneur ≥ $1 · passage en Clash Squad normal $2"],
    [/Level (\d+) reached \(goal (\d+)\)/, "Niveau $1 atteint (objectif $2)"],
    [/^(.+) reached level (\d+) \(goal (\d+)\) · EXP /, "$1 a atteint le niveau $2 (objectif $3) · EXP "],
    [/No free account left in the pool to replace (.+): team finished/, "Plus de compte libre dans la réserve pour remplacer $1 : équipe terminée"],
    [/^Replaced (.+) by (.+) for the next match$/, "$1 remplacé(s) par $2 pour le prochain match"],
    [/Only (\d+) free account\(s\) left in the pool: the team goes on with (\d+) players/, "Plus que $1 compte(s) libre(s) dans la réserve : l'équipe continue avec $2 joueurs"],
    [/Search turn received \(waited (\d+) s\)/, "Tour de recherche obtenu (attente $1 s)"],
    [/Code 57: the server blocks this team's search for a while \(our bot teams were matched against each other several times\) · retrying in (\d+) min/,
        "Code 57 : le serveur bloque la recherche de cette équipe un moment (nos équipes de bots se sont rencontrées plusieurs fois) · nouvel essai dans $1 min"],
    [/Leader match search failed (\d+) times /, "La recherche du chef a échoué $1 fois "],
    [/\(no answer from the server\)/, "(pas de réponse du serveur)"],
    [/Matchmaking refused by the server \(code (\S+)\) · leader received: /, "Recherche refusée par le serveur (code $1) · reçu par le chef : "],
    [/No match found within (\d+) min/, "Aucun match trouvé en $1 min"],
    [/This match is against one of our own bot teams \((.+)\)/, "Ce match oppose une de nos propres équipes de bots ($1)"],
    [/Drone one side at a time: (\d+) of our bot teams in this match \+ search turns off \(one side casts until its drone hits, then the other side\)/,
        "Drone un camp à la fois : $1 de nos équipes dans ce match + tours de recherche désactivés (un camp lance jusqu'à ce que son drone touche, puis l'autre)"],
    [/^Match found -> /, "Match trouvé -> "],
    [/ \(not received by: /, " (pas reçu par : "],
    [/^Match (\d+) over: (\d+)\/(\d+) finished normally · (\d+) deaths · damage (\d+) · /, "Match $1 terminé : $2/$3 terminés normalement · $4 morts · dégâts $5 · "],
    [/Level goal from 1 to (\d+) \(0 = no goal\)/, "Niveau objectif de 1 à $1 (0 = aucun)"],
    [/^Unknown mode /, "Mode inconnu "],
    [/: teams of (.+) players$/, " : équipes de $1 joueurs"],
    [/At most (\d+) teams at once \((\d+) running\)/, "Au plus $1 équipes en même temps ($2 en cours)"],
    [/Not enough free accounts: (\d+) needed \((\d+) teams × (\d+)\), (\d+) free/, "Pas assez de comptes libres : $1 nécessaires ($2 équipes × $3), $4 libres"],
    [/^Team started · /, "Équipe lancée · "],
    [/ · (\d+) players · /, " · $1 joueurs · "],
    [/unlimited matches/, "matchs illimités"],
    [/ · (\d+) matches( · |$)/, " · $1 matchs$2"],
    [/ · accounts swapped at level (\d+)/, " · comptes remplacés au niveau $1"],
    [/^Stop requested$/, "Arrêt demandé"],
    [/: could not read the pass missions \(/, " : impossible de lire les missions du Pass ("],
    [/: claimed (\d+) pass mission\(s\)/, " : $1 mission(s) du Pass réclamée(s)"],
    [/: nothing to claim · (\d+) mission\(s\) still in progress/, " : rien à réclamer · $1 mission(s) encore en cours"],
    [/: guild \((\d+) glory\)/, " : guilde ($1 gloire)"],
    [/: guild · /, " : guilde · "],
    [/ · (\d+) token\(s\) claimed/, " · $1 jeton(s) réclamé(s)"],
    [/ · bought /, " · acheté : "],
    [/ · not bought: /, " · non acheté : "],
    [/A guild claim is already running, wait for it to finish/, "Une réclamation de guilde est déjà en cours, attends qu'elle finisse"],
    [/Enter the clan ID first/, "Entre d'abord l'ID de guilde"],
    [/No accounts to claim for/, "Aucun compte pour lequel réclamer"],
    [/^Claiming guild rewards for (\d+) account\(s\)$/, "Réclamation de la guilde pour $1 compte(s)"],
    [/: skipped \(/, " : ignoré ("],
    [/^Done · (\d+) token\(s\) claimed · (\d+) item\(s\) bought/, "Terminé · $1 jeton(s) réclamé(s) · $2 article(s) acheté(s)"],
    [/A claim is already running, wait for it to finish/, "Une réclamation est déjà en cours, attends qu'elle finisse"],
    [/^Claiming pass rewards for (\d+) account\(s\)$/, "Réclamation du Pass pour $1 compte(s)"],
    [/^Done · (\d+) mission\(s\) \+ (\d+) daily reward\(s\) claimed · (\d+) reward\(s\)/, "Terminé · $1 mission(s) + $2 récompense(s) quotidienne(s) réclamée(s) · $3 récompense(s)"],
    [/ · (\d+) account\(s\) failed/, " · $1 compte(s) en échec"],
    [/An honor score check is already running, wait for it to finish/, "Une vérification d'honneur est déjà en cours, attends qu'elle finisse"],
    [/No accounts to check/, "Aucun compte à vérifier"],
    [/Account not in the pool/, "Compte absent de la réserve"],
    [/Could not log in to read the match history: /, "Connexion impossible pour lire l'historique : "],
    [/Add an account to the pool first \(it reads the clan page\)/, "Ajoute d'abord un compte à la réserve (il lit la page de la guilde)"],
    [/Could not log in to read the clan page: /, "Connexion impossible pour lire la page de la guilde : "],
    [/A clan request batch is already running, wait for it to finish/, "Un envoi de demandes de guilde est déjà en cours, attends qu'il finisse"],
    [/No accounts to send/, "Aucun compte à envoyer"],
    [/^Request sent/, "Demande envoyée"],
    [/ · reply /, " · réponse "],
    [/^timed out$/, "délai dépassé"],
    [/the clan ID must be a number \(e\.g\. (\d+)\)/, "l'ID de guilde doit être un nombre (ex. $1)"],
    [/^pick an account$/, "choisis un compte"],
    [/team not found \(already over\?\)/, "équipe introuvable (déjà terminée ?)"],
    [/^clan page: /, "page de la guilde : "],
    [/^match history: /, "historique des matchs : "],
    [/^server error: /, "erreur serveur : "],
    // settings (ffbot/site_settings.py)
    [/: a number is expected$/, " : un nombre est attendu"],
    [/: a whole number is expected$/, " : un nombre entier est attendu"],
    [/: at least /, " : au moins "],
    [/: at most /, " : au plus "],
    [/: too long$/, " : trop long"],
    [/ is not item:price \(e\.g\. 10500016:200\)/, " n'est pas article:prix (ex. 10500016:200)"],
    [/: invalid address$/, " : adresse invalide"],
    [/^unknown setting /, "réglage inconnu "],
    [/^nothing to save$/, "rien à enregistrer"],
];
function trMsg(text) {
    if (LANG !== "fr" || !text) return text;
    let s = String(text);
    for (const [re, rep] of MSG_FR) s = s.replace(re, rep);
    return s;
}

function t(en, ...args) {
    let s = (LANG === "fr" && FR[en] !== undefined) ? FR[en] : en;
    return args.length ? s.replace(/\{(\d+)\}/g, (m, i) => (args[i] ?? "")) : s;
}
const setFr = it => LANG === "fr" && SET_FR[it.key] ? SET_FR[it.key] : [it.label, it.help];
const groupFr = g => LANG === "fr" && SET_GROUPS_FR[g.id] ? SET_GROUPS_FR[g.id] : [g.name, g.help];

// whole text nodes and title / placeholder / aria-label attributes of `root`, English -> French
const TR_ATTRS = ["title", "placeholder", "aria-label"];
function trDom(root) {
    if (LANG !== "fr" || !root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: n => n.parentElement && n.parentElement.closest("script,style,textarea,.mono,[data-no-tr]") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        const raw = n.nodeValue, key = raw.replace(/\s+/g, " ").trim();
        if (!key || !/[A-Za-z]/.test(key)) continue;
        const lead = /^\s/.test(raw) ? " " : "", trail = /\s$/.test(raw) ? " " : "";
        if (FR[key] !== undefined) n.nodeValue = lead + FR[key] + trail;
        else {
            const msg = trMsg(key);          // server messages (team log, notes, errors)
            if (msg !== key) n.nodeValue = lead + msg + trail;
        }
    }
    const els = root.querySelectorAll ? [root, ...root.querySelectorAll("[title],[placeholder],[aria-label]")] : [];
    for (const el of els) for (const a of TR_ATTRS) {
        const v = el.getAttribute && el.getAttribute(a);
        if (v && FR[v] !== undefined) el.setAttribute(a, FR[v]);
    }
}

// FR / EN switch in the top bar: saved, then the page reloads in the chosen language
function setLang(lang) {
    try { localStorage.setItem("tb.lang", JSON.stringify(lang)); } catch { /* storage unavailable */ }
    location.reload();
}
document.addEventListener("DOMContentLoaded", () => {
    trDom(document.body);
    if (LANG === "fr") document.title = "FF Team Bot";
    const seg = document.getElementById("lang");
    if (seg) {
        seg.querySelectorAll("button").forEach(b => b.classList.toggle("active", b.dataset.lang === LANG));
        seg.addEventListener("click", e => { const b = e.target.closest("button"); if (b && b.dataset.lang !== LANG) setLang(b.dataset.lang); });
    }
});
