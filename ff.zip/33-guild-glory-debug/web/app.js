"use strict";
// FF Team Bot page: state from GET /api/status every 3 s, actions through POST /api/* (see run.py).

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const LOCALE = LANG === "fr" ? "fr-FR" : "en-US";
const nf = new Intl.NumberFormat(LOCALE);
const nf1 = new Intl.NumberFormat(LOCALE, { maximumFractionDigits: 1 });
const fmtN = v => v === null || v === undefined ? "—" : nf.format(v);
const fmt1 = v => v === null || v === undefined ? "—" : nf1.format(v);
const fmtPct = v => v === null || v === undefined ? "—" : nf1.format(v) + "%";
const fmtDur = s => {
    s = Math.max(0, Math.floor(s || 0));
    const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
    return h ? `${h}h ${String(m).padStart(2, "0")}m` : `${m}m ${String(sec).padStart(2, "0")}s`;
};
const fmtTime = ts => ts ? new Date(ts * 1000).toLocaleTimeString("en-GB") : "—";
const fmtDT = ts => ts ? new Date(ts * 1000).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "—";
const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } };
const hue = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const avatar = (key, name) => `<span class="avatar" style="--h:${hue(key)}">${esc(String(name || "?").replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase() || "?")}</span>`;
const tr = (...a) => t(...a);     // t is shadowed by the team object in teamsHTML / levelHTML / groupMapHTML
const pill = (text, color = "", cls = "") => `<span class="pill ${color} ${cls}"><i></i>${esc(text)}</span>`;
function setHTML(el, html) { if (el && el._html !== html) { el.innerHTML = html; el._html = html; trDom(el); } }

const L = {
    team: { starting: "Starting", login: "Logging in", connect: "Connecting", forming: "Forming team", team: "In team",
            searching: "Searching", in_match: "In match", retry: "Re-forming", ended: "Finished", failed: "Failed", stopped: "Stopped",
            cooldown: "Cooling down (code 57)", queued: "Waiting for search turn" },
    teamColor: { starting: "blue", login: "blue", connect: "blue", forming: "blue", team: "green", searching: "violet",
                 in_match: "green", retry: "amber", ended: "", failed: "red", stopped: "amber", cooldown: "amber", queued: "blue" },
    member: { wait: "Waiting", login: "Logging in", connect: "Connecting", online: "Online", team: "In team", search: "Searching", match: "In match" },
    acc: { new: "New", ok: "Ready", banned: "Banned", login_failed: "Login failed", maxed: "Level reached" },
    accColor: { new: "blue", ok: "green", banned: "red", login_failed: "amber", maxed: "violet" },
    reason: { MATCH_END: "Finished", IDLE_END: "Server went quiet", CANCELLED: "Cancelled", MATCH_EXCEPTION: "Error",
              HANDSHAKE_TIMEOUT: "Could not join", SOCKET_ERROR: "Network error", MAX_DURATION: "Too long",
              OUTAGE_LOST: "Lost after outage", PLAYER_DEAD: "Dead", WORKER_SEND: "Worker unavailable", UNKNOWN: "Unknown" },
    since: { all: ["All", 0], day: ["24 h", 86400], hour: ["1 h", 3600] },
};
const reason = r => L.reason[r] || r || "—";
const MODE = { clash_squad: "Clash Squad", cs_ranked: "Ranked CS 4vs4", big_head: "Big Head",
               iron_cage_dual: "Iron Cage Dual 2v2", iron_cage_duo: "Iron Cage Duo 2v2",
               br_evolution: "BR Evolution" };
const ROLE = { leader: "Leader", officer: "Officer", member: "Member" };
// honor score (GetCreditScoreChangeInfo): 100 at the start, lowered by in-match penalties
const honor = (score, title = "") => {
    if (score === null || score === undefined) return `<span class="honor" title="${t("Honor score not checked yet")}">${t("honor —")}</span>`;
    const cls = score >= 90 ? "good" : score >= 70 ? "warn" : "bad";
    return `<span class="honor ${cls}" title="${esc(title || t("Honor score"))}">♥ ${fmtN(score)}</span>`;
};
// level and EXP of a bot; with a level goal: EXP left to reach it and a bar (total EXP / EXP of the goal level)
const fmtExp = (v, sign = false) => v === null || v === undefined ? "—" : (sign && v > 0 ? "+" : "") + fmtN(v);
function levelHTML(m, t) {
    const lv = m.level ? tr("Lv {0}", fmtN(m.level)) : tr("Lv {0}", "—");
    const exp = m.exp === null || m.exp === undefined ? "" : ` · ${fmtExp(m.exp)} EXP`;
    const won = m.exp_gained ? ` <span class="pos" title="${tr("EXP earned since this team started")}">${fmtExp(m.exp_gained, true)}</span>` : "";
    if (!t.level_target || !t.goal_exp || m.exp === null || m.exp === undefined)
        return `<div class="sub">${lv}${exp}${won}</div>`;
    const reached = (m.level || 0) >= t.level_target;
    const pct = Math.min(100, Math.round(m.exp / t.goal_exp * 100));
    return `<div class="sub">${lv}${exp}${won}</div>
        <div class="bar lv" title="${fmtExp(m.exp)} / ${fmtExp(t.goal_exp)} EXP (level ${fmtN(t.level_target)})"><i style="width:${pct}%"></i></div>
        <div class="sub">${reached ? `<b class="pos">${tr("goal Lv {0} reached", fmtN(t.level_target))}</b>` : tr("{0} EXP to Lv {1}", fmtExp(t.goal_exp - m.exp), fmtN(t.level_target))}</div>`;
}
const honorTitle = a => a.honor_at ? `${t("Honor score · checked {0}", fmtDT(a.honor_at))}${a.honor_delta ? t(" · last change {0} on {1}", (a.honor_delta > 0 ? "+" : "") + a.honor_delta, fmtDT(a.honor_change_at)) : ""}` : "";
const fmtLeft = s => {
    s = Math.max(0, Math.floor(s || 0));
    return `${Math.floor(s / 3600)}h ${String(Math.floor(s % 3600 / 60)).padStart(2, "0")}m`;
};
// clan member (GetClanMainPageInfo) by game ID, and pool account by UID
const clanById = d => new Map((d.clan_info?.members || []).map(m => [m.id, m]));
const accByUid = d => new Map((d.accounts || []).map(a => [a.uid, a]));
const teamGlory = (t, clan) => {
    let sum = 0, seen = 0;
    for (const m of t.members) { const c = clan.get(String(m.id)); if (c) { sum += c.weekly_glory || 0; seen++; } }
    return seen ? sum : null;
};

const S = {
    data: null, clock: 0,
    size: lsGet("tb.size", 4), since: lsGet("tb.since", "all"),
    mode: null,                       // mode of the next teams: the server's last choice until one is clicked
    // match results of one mode at a time (no "all modes": the two modes are not compared mixed)
    resultMode: (v => v in MODE ? v : "clash_squad")(lsGet("tb.resultMode", "")),
    picked: new Set(), openLogs: new Set(),
};
const now = () => Date.now() / 1000 + S.clock;

// ---------- API ----------
async function api(method, path, body) {
    const opts = { method, headers: {} };
    if (method !== "GET") opts.headers["X-TeamBot"] = "1";
    if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    const res = await fetch(path, opts);
    let data = null;
    try { data = await res.json(); } catch { /* empty answer */ }
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || `error ${res.status}`);
    return data.data === undefined ? true : data.data;
}
async function act(fn, okMsg) {
    try {
        const r = await fn();
        if (okMsg) toast(typeof okMsg === "function" ? okMsg(r) : okMsg);
        return r;
    } catch (e) { toast(e.message, true); return undefined; }
}
function toast(msg, error = false) {
    const el = document.createElement("div");
    el.className = "toast" + (error ? " error" : "");
    el.textContent = trMsg(msg);       // server errors are in English (see i18n.js)
    $("#toasts").appendChild(el);
    while ($("#toasts").children.length > 3) $("#toasts").firstChild.remove();
    setTimeout(() => el.remove(), error ? 6000 : 3000);
}
function confirmBox(message, okText = t("Confirm"), danger = false) {
    return new Promise(resolve => {
        const box = $("#modal");
        box.innerHTML = `<div class="dialog" role="dialog" aria-modal="true"><h2>${t("Please confirm")}</h2><p>${esc(message)}</p>
            <div class="row" style="justify-content:flex-end"><button class="btn" data-x="0">${t("Cancel")}</button>
            <button class="btn ${danger ? "danger" : "primary"}" data-x="1">${esc(okText)}</button></div></div>`;
        box.hidden = false;
        const done = v => { box.hidden = true; box.innerHTML = ""; document.removeEventListener("keydown", esc_); resolve(v); };
        const esc_ = e => { if (e.key === "Escape") done(false); };
        document.addEventListener("keydown", esc_);
        box.onclick = e => { if (e.target === box) done(false); const b = e.target.closest("[data-x]"); if (b) done(b.dataset.x === "1"); };
    });
}

// ---------- state ----------
async function load() {
    const span = L.since[S.since]?.[1] || 0;
    const since = span ? Math.floor(now() - span) : 0;
    try {
        const d = await api("GET", `/api/status?since=${since}${S.resultMode ? `&mode=${encodeURIComponent(S.resultMode)}` : ""}`);
        S.clock = d.server_time - Date.now() / 1000;
        S.data = d;
        if (!S.mode) { S.mode = d.mode; markMode(); }
        setLive(true);
        render(d);
    } catch (e) {
        setLive(false, e.message);
    }
}
function setLive(on, why = "") {
    const el = $("#live");
    el.className = "live " + (on ? "on" : "off");
    $("span", el).textContent = on ? t("Connected") : t("Server offline");
    el.title = why;
}

// ---------- rendering ----------
function render(d) {
    const s = d.summary, c = d.counts;
    const kpi = (v, l, sub = "") => `<div class="kpi"><div class="v">${v}</div><div class="l">${l}</div>${sub ? `<div class="s">${sub}</div>` : ""}</div>`;
    setHTML($("#kpis"), [
        kpi(fmtN(d.teams.length), "Teams running", t("{0} in a match · {1} waiting for search turn", fmtN(d.teams.filter(x => x.state === "in_match").length), fmtN(d.teams.filter(x => x.state === "queued").length))),
        kpi(fmtN(s.matches), "Matches recorded", `${t("{0} bot-matches", fmtN(s.bots))} · ${t(L.since[S.since]?.[0] || "")}${S.resultMode ? ` · ${MODE[S.resultMode]}` : ""}`),
        kpi(s.bots ? fmtPct(s.completed / s.bots * 100) : "—", "Finished normally", `${fmtN(s.completed)} / ${fmtN(s.bots)}`),
        kpi(s.death_rate === null ? "—" : fmtPct(s.death_rate * 100), "Deaths per round", t("{0} deaths · {1} in zone", fmtN(s.deaths), fmtN(s.zone_deaths))),
        kpi(fmt1(s.snaps_avg), "Pull-backs per bot-match", t("144s {0} · stuck {1}", fmt1(s.force144_avg), fmt1(s.escapes_avg))),
        kpi(fmt1(s.exp_avg), "EXP per bot-match", t("total {0}", fmtN(s.exp_total))),
        kpi(fmt1(s.dmg_avg), "Damage per bot-match", t("total {0}", fmtN(s.dmg_total || 0))),
        kpi(s.duration_avg_s ? fmtDur(s.duration_avg_s) : "—", "Average match time", t("ran {0} m per bot", fmt1(s.ran_m_avg))),
    ].join(""));
    setHTML($("#free"), t("<b>{0}</b> free of {1} accounts", fmtN(c.free), fmtN(c.total)));
    need();
    if (!S.clanTyped && document.activeElement !== $("#clan-view-id")) $("#clan-view-id").value = d.clan_id || "";
    if (!S.levelTyped && document.activeElement !== $("#level-target")) $("#level-target").value = d.level_target || 0;
    $$("#turns button").forEach(b => b.classList.toggle("active", b.dataset.t === (d.search_turns ? "1" : "0")));
    setHTML($("#clan-running"), t("{0} running / {1} groups · {2}", fmtN(d.teams.length), fmtN(d.teams.length + d.finished.length), esc(MODE[d.mode] || d.mode || "")));
    setHTML($("#clan-hero"), clanHeroHTML(d));
    setHTML($("#clan-groups"), groupMapHTML(d));
    setHTML($("#clan-members"), clanMembersHTML(d));
    setHTML($("#teams"), teamsHTML(d));
    $$("#teams details[data-team]").forEach(x => { if (S.openLogs.has(x.dataset.team)) x.open = true; });
    setHTML($("#honor-job"), honorJobHTML(d.honor_job));
    setHTML($("#claim-job"), claimJobHTML(d.claim_job));
    setHTML($("#guild-job"), guildJobHTML(d.guild_job));
    setHTML($("#reasons"), reasonsHTML(s));
    setHTML($("#results"), matchesHTML(d.matches));   // ("#matches" is the "matches per team" input)
    setHTML($("#counts"), `<span class="chips"><span class="chip">total <b>${fmtN(c.total)}</b></span><span class="chip">free <b>${fmtN(c.free)}</b></span>
        <span class="chip">in a team <b>${fmtN(c.in_team)}</b></span>${c.maxed ? `<span class="chip" title="Accounts that reached the level goal">level reached <b>${fmtN(c.maxed)}</b></span>` : ""}${c.failed ? `<span class="chip">login failed <b>${fmtN(c.failed)}</b></span>` : ""}${c.banned ? `<span class="chip">banned <b>${fmtN(c.banned)}</b></span>` : ""}</span>`);
    setHTML($("#pool"), poolHTML(d.accounts));
    setHTML($("#clan-job"), clanHTML(d.clan));
    histAccounts(d.accounts);
}
function teamsWanted() { return Math.max(1, Math.floor(Number($("#team-count").value)) || 1); }
function need() {
    if (!S.data) return;
    const want = teamsWanted() * S.size, free = S.data.counts.free;
    setHTML($("#need"), `needs <b>${fmtN(want)}</b> accounts · <b class="${free < want ? "neg" : ""}">${fmtN(free)}</b> free`);
}
function clanHeroHTML(d) {
    const c = d.clan_info;
    if (!c) return `<div class="empty">${d.clan_error ? `<span class="neg">${esc(d.clan_error)}</span><br>` : ""}
        Enter your clan ID above and press “Refresh clan” — while teams run, the clan page is re-read every minute.</div>`;
    const clan = clanById(d), leader = clan.get(c.leader_id);
    const groupGlory = d.teams.reduce((s, t) => s + (teamGlory(t, clan) || 0), 0);
    const initials = String(c.name || "?").replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase();
    return `<div class="hero">
        ${c.max_members && c.member_count >= c.max_members ? `<span class="badge">★ FULL SQUAD</span>` : ""}
        <div class="clan-logo" title="${t("Clan logo {0}", esc(c.avatar_id))}">${esc(initials)}<small>LV.${fmtN(c.level)}</small></div>
        <div class="hero-main">
            <h3>${esc(c.name)}</h3>
            ${c.slogan ? `<div class="slogan">“${esc(c.slogan)}”</div>` : ""}
            <div class="meta"><span>ID: ${esc(c.clan_id)}</span><span>${esc(c.region || "—")}</span><span>${t(d.teams.length === 1 ? "{0} GROUP" : "{0} GROUPS", fmtN(d.teams.length))}</span></div>
            <div class="hint">Clan total glory</div>
            <div class="num big">${fmtN(c.total_glory)}</div>
            <div class="hint">${c.week_ends_at ? t("Week ends in {0}", fmtLeft(c.week_ends_at - now())) : ""} · ${t("updated {0}", fmtTime(c.fetched_at))}</div>
        </div>
        <div class="hero-stats">
            <div class="stat"><div class="l">Members</div><div class="v num">${fmtN(c.member_count)}/${fmtN(c.max_members)}</div></div>
            <div class="stat"><div class="l">Captain</div><div class="v num" style="color:var(--gold)">${esc(leader?.nickname || c.leader_id || "—")}</div></div>
            <div class="stat"><div class="l">♛ Group glory</div><div class="v xl num glory" title="This week's glory of the bots of the running groups">${fmtN(groupGlory)}</div></div>
        </div>
    </div>`;
}
function groupMapHTML(d) {
    const c = d.clan_info;
    if (!c && !d.teams.length) return "";
    const clan = clanById(d);
    const groups = d.teams.length ? d.teams.map(t => {
        const g = teamGlory(t, clan);
        return `<div class="node group${t.state === "in_match" || t.state === "searching" ? "" : " idle"}">
            <div class="l">${tr("{0} group", esc(tr(L.team[t.state] || t.state)))}</div>
            <div class="num">#${esc(t.id)}</div>
            <div class="num glory" style="font-size:18px;margin:4px 0">${tr("{0} glory", g === null ? "—" : fmtN(g))}</div>
            <a href="#team-${esc(t.id)}" data-goto="${esc(t.id)}">View group ↓</a></div>`;
    }).join("") : `<div class="node faint">No running group — start teams below.</div>`;
    return `<div class="groupmap">
        <div class="node"><div class="l">Clan</div><div class="num">${esc(c?.name || "—")}</div>
            <div class="hint" style="margin-top:8px">Weekly glory</div><div class="v num">${c ? fmtN(c.weekly_glory) : "—"}</div></div>
        <div class="link"></div>
        <div class="groups-col">${groups}</div>
    </div>`;
}
function clanMembersHTML(d) {
    const c = d.clan_info;
    if (!c?.members?.length) return "";
    const ours = new Map((d.accounts || []).filter(a => a.account_id).map(a => [String(a.account_id), a]));
    return `<details data-clan-members ${S.clanOpen ? "open" : ""}><summary>${t("Clan members ({0}) · {1} bots of this pool", fmtN(c.members.length), fmtN(c.members.filter(m => ours.has(m.id)).length))}</summary>
        <div class="table-wrap"><table><thead><tr><th>#</th><th>Player</th><th>Role</th><th>This week</th><th>Total glory</th><th>Honor</th><th>Last login</th></tr></thead><tbody>
        ${c.members.map((m, i) => { const a = ours.get(m.id); return `<tr><td class="faint">${i + 1}</td>
            <td><div class="acc">${avatar(m.id, m.nickname)}<div><b>${esc(m.nickname || "—")}</b><div class="sub">Lv ${fmtN(m.level)} · ID ${esc(m.id)}${a ? ` · <span class="pill blue" style="height:18px">bot</span>` : ""}</div></div></div></td>
            <td>${esc(ROLE[m.role] || m.role)}</td><td class="num glory">${fmtN(m.weekly_glory)}</td><td class="num">${fmtN(m.total_glory)}</td>
            <td>${a ? honor(a.honor, honorTitle(a)) : `<span class="faint">—</span>`}</td><td>${fmtDT(m.last_login)}</td></tr>`; }).join("")}
        </tbody></table></div></details>`;
}
function honorJobHTML(job) {
    if (!job) return "";
    return `<div class="row"><span>${t(job.running ? "Checking honor scores…" : "Honor scores checked")} · ${fmtN(job.done)}/${fmtN(job.total)}
        · ${t("read")} <b class="pos">${fmtN(job.ok)}</b>${job.fail ? ` · ${t("failed")} <b class="neg">${fmtN(job.fail)}</b>` : ""}</span>
        ${job.fail && job.last_error ? `<span class="sub">${esc(job.last_error)}</span>` : ""}</div>`;
}
function claimJobHTML(job) {
    if (!job) return "";
    return `<div class="row"><span>${t(job.running ? "Claiming pass rewards…" : "Pass rewards claimed")} · ${t("{0}/{1} accounts", fmtN(job.done), fmtN(job.total))}
        · <b class="pos">${fmtN(job.missions)}</b> ${t("missions +")} <b class="pos">${fmtN(job.daily)}</b> ${t("daily · {0} rewards", fmtN(job.awards))}
        ${job.fail ? ` · ${t("failed")} <b class="neg">${fmtN(job.fail)}</b>` : ""}</span></div>
        ${job.log?.length ? `<div class="log">${job.log.slice().reverse().map(x => `<div class="${esc(x.level)}"><span class="faint">${fmtTime(x.t)}</span> ${esc(x.text)}</div>`).join("")}</div>` : ""}`;
}
function guildJobHTML(job) {
    if (!job) return "";
    return `<div class="row"><span>${t(job.running ? "Claiming guild rewards…" : "Guild rewards claimed")} · ${t("{0}/{1} accounts", fmtN(job.done), fmtN(job.total))}
        · <b class="pos">${fmtN(job.tokens)}</b> ${t("tokens ·")} <b class="pos">${fmtN(job.bought)}</b> ${t("store items bought")}
        ${job.fail ? ` · ${t("failed")} <b class="neg">${fmtN(job.fail)}</b>` : ""}</span></div>
        ${job.log?.length ? `<div class="log">${job.log.slice().reverse().map(x => `<div class="${esc(x.level)}"><span class="faint">${fmtTime(x.t)}</span> ${esc(x.text)}</div>`).join("")}</div>` : ""}`;
}
function teamsHTML(d) {
    if (!d.teams.length && !d.finished.length)
        return `<div class="card empty">No team yet — add accounts to the pool, then press “Start”.</div>`;
    const clan = clanById(d), accs = accByUid(d);
    const card = (t, live) => {
        const inMatch = t.state === "in_match" && t.match_at;
        const g = teamGlory(t, clan);
        const pct = t.target ? Math.min(100, Math.round(t.done / t.target * 100)) : null;
        const fact = (l, v) => `<div><div class="l">${l}</div><div class="v">${v}</div></div>`;
        const turn = (d.turns || {})[t.mode];     // team searching in this mode (one team at a time) and its queue
        const searchingNow = live && turn && turn.searching === t.id;
        return `<div class="card team" id="team-${esc(t.id)}">
            <div class="gtop"><div>
                <h2>${tr("Group {0}", esc(t.id))}${t.code ? `<span class="code">${tr("code {0}", esc(t.code))}</span>` : ""}</h2>
                <div style="margin-top:8px">${pill(L.team[t.state] || t.state, L.teamColor[t.state] || "", live && inMatch ? "live" : "")}
                    ${t.mode ? `<span class="chip${t.mode === "cs_ranked" ? " ranked" : ""}">${esc(MODE[t.mode] || t.mode)}</span>` : ""}
                    ${t.level_target ? `<span class="chip" title="${tr("An account that reaches this level is swapped after its match")}">${tr("level goal")} <b>${fmtN(t.level_target)}</b></span>` : ""}</div>
                <div class="updated">${live ? tr("updated {0}", fmtTime(now())) : tr("ended {0}", fmtDT(t.ended_at))}</div></div>
                <div class="gl"><div class="hint">★ GLORY</div><div class="num glory v" title="This week's glory of these bots in the clan">${g === null ? "—" : fmtN(g)}</div></div>
            </div>
            <div class="facts">
                ${fact("Region", esc(t.region || "—"))}
                ${fact("Accounts", fmtN(t.size))}
                ${fact("Uptime", fmtDur((live ? now() : t.ended_at || now()) - t.created_at))}
                ${fact("Last match", `${tr("{0} games", fmtN(t.done))}${t.last_match_at ? tr(" · since {0}", fmtTime(t.last_match_at)) : ""}`)}
            </div>
            ${inMatch ? `<div class="chips" style="margin-top:12px"><span class="chip">${tr("in match {0}", fmtDur(now() - t.match_at))}${t.server ? ` · ${esc(t.server)}` : ""}</span>
                ${t.resets ? `<span class="chip">${tr("re-formed {0}×", fmtN(t.resets))}</span>` : ""}${live && t.stop_after_match ? `<span class="chip">stops after this match</span>` : ""}</div>` : ""}
            ${live && (t.queue || searchingNow) ? `<div class="chips" style="margin-top:12px">
                ${t.queue ? `<span class="chip">${tr("search queue #")}<b>${fmtN(t.queue)}</b>${turn && turn.searching !== t.id ? tr(" · group {0} is searching", esc(turn.searching)) : ""}</span>` : ""}
                ${searchingNow ? `<span class="chip">${tr("searching for {0}", fmtDur(now() - turn.since))}${turn.waiting.length ? tr(" · {0} team(s) waiting", fmtN(turn.waiting.length)) : ""}</span>` : ""}</div>` : ""}
            ${inMatch && t.vs ? vsHTML(t.vs) : ""}
            <div class="goal"><div class="head"><span>${t.target ? tr("Goal · {0}/{1} matches", fmtN(t.done), fmtN(t.target)) : tr("No match limit")}</span>${pct === null ? "" : `<b>${pct}%</b>`}</div>
                <div class="bar"><i style="width:${pct === null ? 0 : pct}%"></i></div></div>
            ${live ? `<div class="gbtns">
                <button class="btn" data-stop="${esc(t.id)}" ${t.stop_after_match ? "disabled" : ""}>Stop after match</button>
                <button class="btn danger" data-stop="${esc(t.id)}" data-now="1">Stop now</button></div>` : ""}
            <div class="members">${t.members.map(m => { const a = accs.get(m.uid) || {}; return `<div class="member">${avatar(m.uid, m.name)}<div style="min-width:0;flex:1"><b>${esc(m.name)}</b>
                <div class="sub">${esc(live ? (L.member[m.state] || m.state) : m.uid)}</div>
                ${levelHTML(m, t)}
                <div style="margin-top:3px">${honor(a.honor, honorTitle(a))}${clan.get(String(m.id)) ? ` <span class="sub glory">${tr("{0} glory", fmtN(clan.get(String(m.id)).weekly_glory))}</span>` : ""}</div>
                ${hpHTML(m, live && m.state === "match")}
                ${dmgHTML(m, live && m.state === "match")}</div></div>`; }).join("")}</div>
            ${t.error ? `<div class="err">${esc(t.error)}</div>` : ""}
            ${t.log?.length ? `<details data-team="${esc(t.id)}"><summary>${tr("Details · team log ({0})", fmtN(t.log.length))}</summary><div class="log">
                ${t.log.slice().reverse().map(x => `<div class="${esc(x.level)}"><span class="faint">${fmtTime(x.t)}</span> ${esc(x.text)}</div>`).join("")}</div></details>` : ""}
        </div>`;
    };
    return (d.teams.length ? `<div class="teams">${d.teams.map(t => card(t, true)).join("")}</div>` : "")
        + (d.finished.length ? `<details class="card"><summary>${t("Finished teams ({0})", fmtN(d.finished.length))}</summary>
            <div class="teams" style="margin-top:12px">${d.finished.map(t => card(t, false)).join("")}</div></details>` : "");
}
function reasonsHTML(s) {
    const entries = Object.entries(s.reasons || {}).sort((a, b) => b[1] - a[1]);
    if (!entries.length) return `<p class="faint" style="margin:0">No match in this period yet.</p>`;
    return `<div class="chips"><span class="faint">How matches ended:</span>${entries.map(([r, n]) => `<span class="chip" title="${esc(r)}">${esc(reason(r))} <b>${fmtN(n)}</b></span>`).join("")}
        <span class="chip">rounds avg <b>${fmt1(s.rounds_avg)}</b></span>
        <span class="chip">knocked (crawling) avg <b>${fmt1(s.frozen_avg)}</b></span>
        <span class="chip">${t("server lag")} <b>${s.lag_ms_avg === null ? "—" : fmtN(Math.round(s.lag_ms_avg))}</b> ms</span></div>`;
}
function vsHTML(vs, team) {
    // player names of both sides (the game has no team names); ours = this group's accounts, team 1/2 as in the game
    if (!vs) return "";
    const names = a => a.length ? a.map(n => `<b>${esc(n || "?")}</b>`).join(", ") : `<span class="faint">—</span>`;
    return `<div class="vs"><div><span class="faint">${t("Our team")}${team ? t(" (team {0})", team) : ""}:</span> ${names(vs.ours || [])}</div>
        <div><span class="faint">${t("Opponents")}${team ? t(" (team {0})", 3 - team) : ""}:</span> ${names(vs.theirs || [])}</div></div>`;
}
// live damage of a bot on its team card (sent by the match every second); "+N" = the last increase, for a few seconds
// live HP of a bot in a match (Clash Squad: 200 - damage taken in the round, set again by the server after a heal);
// "+N" in green for a few seconds when it goes up (medkit), "healing" while the bot stands still to heal
const hpSeen = new Map();
function hpHTML(m, playing) {
    if (!playing || m.hp === null || m.hp === undefined) { hpSeen.delete(m.uid); return ""; }
    let s = hpSeen.get(m.uid);
    if (!s) s = { v: m.hp, up: 0, at: 0 };
    else if (m.hp > s.v) s = { v: m.hp, up: m.hp - s.v, at: now() };
    else s = { ...s, v: m.hp };
    hpSeen.set(m.uid, s);
    const pct = Math.max(0, Math.min(100, m.hp / 200 * 100));
    const cls = m.hp <= 0 ? "dead" : m.hp <= 60 ? "low" : m.hp <= 120 ? "mid" : "";
    const up = s.up && now() - s.at < 8 ? ` <span class="up">+${fmtN(s.up)}</span>` : "";
    const healing = m.healing ? ` <span class="healing">${t("healing…")}</span>` : "";
    const heals = m.heals ? ` <span class="faint" title="${t("Medkits used in this match")}">· ✚ ${fmtN(m.heals)}</span>`
        : m.confirmed === false && m.heals_sent ? ` <span class="faint" title="${t("Medkits sent (the server's answer cannot be read without the session key)")}">· ✚ ${fmtN(m.heals_sent)}?</span>` : "";
    return `<div class="hp ${cls}" title="${t("HP of this bot in the match, updated live")}">
        <div class="hp-row"><span>${t("HP")} <b>${m.hp <= 0 ? t("dead") : fmtN(m.hp)}</b>${m.hp > 0 ? "/200" : ""}</span>${up}${healing}${heals}</div>
        <div class="bar hpbar"><i style="width:${pct}%"></i></div></div>`;
}
const dmgSeen = new Map();
function dmgHTML(m, playing) {
    if (m.dmg === null || m.dmg === undefined) {
        if (!playing) return "";
        dmgSeen.set(m.uid, { v: 0, up: 0, at: 0 });
        return `<div class="dmg on" title="${t("Damage dealt by this bot in this match, updated live")}">${t("damage")} <b>0</b></div>`;
    }
    let s = dmgSeen.get(m.uid);
    if (!s || m.dmg < s.v) s = { v: m.dmg, up: 0, at: 0 };
    else if (m.dmg > s.v) s = { v: m.dmg, up: m.dmg - s.v, at: now() };
    dmgSeen.set(m.uid, s);
    const hits = m.hits ? t(m.hits === 1 ? " · {0} hit" : " · {0} hits", fmtN(m.hits)) : "";
    const up = playing && s.up && now() - s.at < 6 ? ` <span class="up">+${fmtN(s.up)}</span>` : "";
    return `<div class="dmg${playing ? " on" : ""}" title="${t(playing ? "Damage dealt by this bot in this match, updated live" : "Damage dealt by this bot in its last match")}">
        ${t(playing ? "damage" : "last match damage")} <b>${fmtN(m.dmg)}</b>${hits}${up}</div>`;
}
function matchesHTML(rows) {
    if (!rows.length) return "";
    const v = fmtN;
    const bot = b => `<div class="bot${b.completed ? "" : " bad"}"><b>${esc(b.name || b.uid)}</b>
        <span>${b.completed ? t("finished") : esc(t(reason(b.reason)))}</span>
        <span title="${t("rounds died / rounds")}">${t("deaths {0}/{1}", v(b.deaths), v(b.rounds))}${b.zone_deaths ? t(" (zone {0})", v(b.zone_deaths)) : ""}</span>
        <span class="${b.dmg ? "pos" : ""}" title="${t("damage dealt by the bot (number of hits)")}">${t("damage {0}", b.dmg === null || b.dmg === undefined ? "—" : v(b.dmg))}${b.hits ? t(" ({0} hits)", v(b.hits)) : ""}</span>
        <span title="${t("positions corrected by the server")}">${t("pull-backs {0}", v(b.snaps))}</span><span title="RUDP_FORCE_SYNC (144)">144 ${v(b.force144)}</span>
        <span title="${t("stuck in a corner, followed a teammate's path")}">${t("stuck {0}", v(b.escapes))}</span><span>${t("ran {0} m", v(b.ran_m))}</span>
        <span class="${b.exp ? "pos" : ""}">EXP ${b.exp === null || b.exp === undefined ? "?" : (b.exp > 0 ? "+" : "") + v(b.exp)}</span>
        ${b.level ? `<span title="${t("level after the match")}">${t("Lv {0}", v(b.level))}</span>` : ""}</div>`;
    return `<div class="table-wrap"><table><thead><tr><th>Time</th><th>Team</th><th>Length</th><th>Each bot</th></tr></thead><tbody>
        ${rows.map(r => `<tr><td>${fmtDT(r.started_at)}</td><td>${esc(r.team_id)}<div class="sub">${esc(MODE[r.mode] || r.mode || "")}</div><div class="sub">${esc(r.server || "")}</div></td>
            <td>${r.ended_at && r.started_at ? fmtDur(r.ended_at - r.started_at) : "—"}</td>
            <td><div class="botcell">${vsHTML(r.players, (r.bots || []).map(b => b.team).find(t => t === 1 || t === 2))}${(r.bots || []).map(bot).join("")}</div></td></tr>`).join("")}</tbody></table></div>`;
}
function poolHTML(rows) {
    if (!rows.length) return `<div class="empty">The pool is empty — paste guest accounts above and press “Add to pool”.</div>`;
    const keep = new Set(rows.map(a => a.uid));
    [...S.picked].forEach(u => { if (!keep.has(u)) S.picked.delete(u); });
    return `<div class="table-wrap"><table><thead><tr><th></th><th>Account</th><th>UID</th><th>Status</th><th>Honor</th><th title="Elite Pass missions and daily rewards claimed after the matches">Pass claimed</th><th>Team</th><th>Clan</th><th>Last used</th></tr></thead><tbody>
        ${rows.map(a => `<tr><td><input type="checkbox" data-uid="${esc(a.uid)}" ${S.picked.has(a.uid) ? "checked" : ""} aria-label="${t("Select {0}", esc(a.uid))}"></td>
            <td><div class="acc">${avatar(a.uid, a.nickname || a.uid)}<div><b>${esc(a.nickname || "—")}</b>
                <div class="sub">${a.level ? t("Lv {0}", fmtN(a.level)) : ""}${a.exp !== null && a.exp !== undefined ? ` · ${fmtExp(a.exp)} EXP` : ""}${a.account_id ? ` · ID ${esc(a.account_id)}` : ""}</div></div></div></td>
            <td class="mono">${esc(a.uid)}</td>
            <td>${pill(L.acc[a.status] || a.status, L.accColor[a.status] || "")}${a.note ? `<div class="sub">${esc(a.note)}</div>` : ""}</td>
            <td>${honor(a.honor, honorTitle(a))}${a.honor_delta ? `<div class="sub ${a.honor_delta < 0 ? "neg" : "pos"}">${a.honor_delta > 0 ? "+" : ""}${fmtN(a.honor_delta)} · ${fmtDT(a.honor_change_at)}</div>`
                : a.honor_at ? `<div class="sub">${t("checked {0}", fmtDT(a.honor_at))}</div>` : ""}</td>
            <td>${a.ep_claimed ? `<b>${fmtN(a.ep_claimed)}</b><div class="sub">${t("last {0}", fmtDT(a.ep_claimed_at))}</div>` : `<span class="faint">—</span>`}</td>
            <td>${a.team ? esc(a.team) : "—"}</td>
            <td>${a.clan ? esc(a.clan) : "—"}</td>
            <td>${fmtDT(a.used_at)}</td></tr>`).join("")}</tbody></table></div>`;
}
function clanHTML(job) {
    if (!job) return "";
    const items = job.items || [];
    return `<div class="row"><span>${t(job.running ? "Sending…" : "Done")} · ${t("clan")} <b>${esc(job.clan_id)}</b> · ${fmtN(job.done)}/${fmtN(job.total)}
        · ${t("sent")} <b class="pos">${fmtN(job.ok)}</b>${job.fail ? ` · ${t("failed")} <b class="neg">${fmtN(job.fail)}</b>` : ""}</span></div>
        ${items.length ? `<div class="log">${items.slice().reverse().map(x => `<div class="${x.ok ? "" : "error"}"><b>${esc(x.name)}</b> ${esc(x.text)}</div>`).join("")}</div>` : ""}`;
}

// ---------- controls ----------
function wireSeg(seg, attr, value, onPick) {
    const mark = v => $$("button", seg).forEach(b => b.classList.toggle("active", b.dataset[attr] === String(v)));
    mark(value);
    seg.addEventListener("click", e => {
        const b = e.target.closest("button");
        if (!b) return;
        mark(b.dataset[attr]);
        onPick(b.dataset[attr]);
    });
}
wireSeg($("#size"), "n", S.size, v => { S.size = Number(v); lsSet("tb.size", S.size); need(); });
function markMode() { $$("#mode button").forEach(b => b.classList.toggle("active", b.dataset.m === S.mode)); fitSize(); }
// team sizes allowed by the chosen mode (Iron Cage: 2, or 1–2 for Duo); an unavailable size moves to the largest allowed
function fitSize() {
    const sizes = S.data?.mode_sizes?.[S.mode] || S.data?.sizes || [2, 3, 4];
    if (!sizes.includes(S.size)) { S.size = sizes[sizes.length - 1]; lsSet("tb.size", S.size); }
    $$("#size button").forEach(b => {
        b.disabled = !sizes.includes(Number(b.dataset.n));
        b.classList.toggle("active", Number(b.dataset.n) === S.size);
    });
    need();
}
$("#mode").addEventListener("click", e => {
    const b = e.target.closest("button");
    if (!b) return;
    S.mode = b.dataset.m;
    markMode();
});
wireSeg($("#result-mode"), "r", S.resultMode, v => { S.resultMode = v; lsSet("tb.resultMode", v); load(); });
wireSeg($("#since"), "s", S.since, v => { S.since = v; lsSet("tb.since", v); load(); });
$("#matches").value = lsGet("tb.matches", 10);
$("#clan-id").value = lsGet("tb.clan", "");
$("#team-count").addEventListener("input", need);
$$("[data-step]").forEach(b => b.onclick = () => { $("#team-count").value = Math.max(1, teamsWanted() + Number(b.dataset.step)); need(); });

// level goal: saved as soon as it changes (running teams apply it at the end of their match), and sent with "Start"
const levelWanted = () => Math.min(S.data?.max_level || 100, Math.max(0, Math.floor(Number($("#level-target").value)) || 0));
$("#level-target").addEventListener("input", () => { S.levelTyped = true; });
// search one team at a time: applies at once to the running teams (shown state = the server's, see render)
$("#turns").addEventListener("click", async e => {
    const b = e.target.closest("button");
    if (!b) return;
    const on = b.dataset.t === "1";
    if (S.data && S.data.search_turns === on) return;
    const r = await act(() => api("POST", "/api/search-turns", { on }),
        r => t(r.on ? "Search turns on: teams of the same mode search one at a time" : "Search turns off: every team searches at once"));
    if (r) load();
});
$("#level-target").addEventListener("change", async () => {
    const level = levelWanted();
    $("#level-target").value = level;
    const r = await act(() => api("POST", "/api/level-target", { level }),
        r => r.level_target ? `${t("Level goal {0}", r.level_target)}${r.maxed ? t(" · {0} account(s) already there", r.maxed) : ""}${r.freed ? t(" · {0} account(s) free again", r.freed) : ""}`
            : `${t("No level goal")}${r.freed ? t(" · {0} account(s) free again", r.freed) : ""}`);
    S.levelTyped = false;
    if (r) load();
});
$("#start").onclick = async e => {
    const btn = e.currentTarget, matches = Math.max(0, Math.floor(Number($("#matches").value)) || 0);
    lsSet("tb.matches", matches);
    btn.disabled = true;
    const mode = S.mode || S.data?.mode || "clash_squad", level_target = levelWanted();
    const r = await act(() => api("POST", "/api/start", { teams: teamsWanted(), size: S.size, matches, mode, level_target }),
        r => `${t("{0} {1} team(s) started", r.teams.length, MODE[mode] || mode)}${level_target ? t(" · level goal {0}", level_target) : ""}`);
    S.levelTyped = false;
    btn.disabled = false;
    if (r) load();
};
$$("[data-stop-all]").forEach(b => b.onclick = async () => {
    const nowFlag = b.dataset.stopAll === "1";
    if (!await confirmBox(t(nowFlag ? "Stop every team now? Matches in progress are cut." : "Stop every team? Each one finishes its current match first."), t("Stop"), nowFlag)) return;
    if (await act(() => api("POST", "/api/stop-all", { now: nowFlag }), r => t("Stop sent to {0} team(s)", r.count))) load();
});
$("#teams").addEventListener("click", async e => {
    const b = e.target.closest("[data-stop]");
    if (!b || b.disabled) return;
    const nowFlag = !!b.dataset.now;
    if (nowFlag && !await confirmBox(t("Stop this team now? Its match in progress is cut."), t("Stop now"), true)) return;
    if (await act(() => api("POST", `/api/teams/${encodeURIComponent(b.dataset.stop)}/stop`, { now: nowFlag }),
        t(nowFlag ? "Team stopped" : "The team stops after this match"))) load();
});
$("#teams").addEventListener("toggle", e => {
    const d = e.target.closest("details[data-team]");
    if (d) { if (d.open) S.openLogs.add(d.dataset.team); else S.openLogs.delete(d.dataset.team); }
}, true);

$("#add").onclick = async () => {
    const box = $("#add-text"), text = box.value.trim();
    if (!text) return toast(t("Paste some accounts first"), true);
    const r = await act(() => api("POST", "/api/accounts", { text }));
    if (!r) return;
    toast(`${t("{0} added", r.added)}${r.duplicates ? t(" · {0} already in the pool", r.duplicates) : ""}${r.invalid ? t(" · {0} invalid", r.invalid) : ""}`, !r.added && r.invalid > 0);
    if (r.errors?.length) toast(r.errors[0], true);
    if (r.added) box.value = "";
    load();
};
$("#pool").addEventListener("change", e => {
    const box = e.target.closest("input[data-uid]");
    if (!box) return;
    if (box.checked) S.picked.add(box.dataset.uid); else S.picked.delete(box.dataset.uid);
});
$("#pick-free").onclick = () => {
    (S.data?.accounts || []).filter(a => !a.team && a.status !== "banned").forEach(a => S.picked.add(a.uid));
    $$("#pool input[data-uid]").forEach(x => { x.checked = S.picked.has(x.dataset.uid); });
    toast(t("{0} account(s) selected", S.picked.size));
};
$$("[data-acc]").forEach(b => b.onclick = async () => {
    const ids = [...S.picked], action = b.dataset.acc;
    if (!ids.length) return toast(t("Select accounts in the pool first"), true);
    if (action === "delete" && !await confirmBox(t("Delete {0} account(s) from the pool? Accounts in a running team are kept.", ids.length), t("Delete"), true)) return;
    const r = await act(() => api("POST", `/api/accounts/${action}`, { uids: ids }),
        r => t(action === "delete" ? "{0} deleted" : "{0} account(s) can be used again", r.count));
    if (r) { if (action === "delete") S.picked.clear(); load(); }
});

$("#clan-view-id").addEventListener("input", () => { S.clanTyped = true; });
$("#clan-load").onclick = async e => {
    const btn = e.currentTarget, id = $("#clan-view-id").value.trim();
    if (id && !/^\d{3,20}$/.test(id)) return toast(t("Enter the clan ID as a number, e.g. 3106179650"), true);
    btn.disabled = true;
    btn.textContent = t("Loading…");
    const r = await act(() => api("POST", "/api/clan/info", { clan_id: id || undefined }), c => `${c.name} · ${t("{0} glory", fmtN(c.total_glory))}`);
    btn.disabled = false;
    btn.textContent = t("Refresh clan");
    if (r) { S.clanTyped = false; load(); }
};
$("#clan-members").addEventListener("toggle", e => { if (e.target.matches("[data-clan-members]")) S.clanOpen = e.target.open; }, true);
$("#clan-groups").addEventListener("click", e => {
    const a = e.target.closest("[data-goto]");
    if (!a) return;
    e.preventDefault();
    const card = $(`#team-${CSS.escape(a.dataset.goto)}`);
    if (!card) return;
    card.scrollIntoView({ behavior: "smooth", block: "center" });
    card.classList.add("flash");
    setTimeout(() => card.classList.remove("flash"), 1600);
});
$("#honor-check").onclick = async e => {
    const btn = e.currentTarget, ids = [...S.picked];
    const n = ids.length || (S.data?.counts.total || 0) - (S.data?.counts.banned || 0);
    if (!ids.length && !await confirmBox(t("No account selected: check the honor score of all {0} pool account(s)? Accounts not in a team log in one by one.", n), t("Check all"))) return;
    btn.disabled = true;
    const r = await act(() => api("POST", "/api/honor", { uids: ids.length ? ids : undefined }), j => t("Checking {0} account(s)…", j.total));
    btn.disabled = false;
    if (r) load();
};

$("#claim-all").onclick = async e => {
    const btn = e.currentTarget, ids = [...S.picked];
    const n = ids.length || (S.data?.counts.total || 0) - (S.data?.counts.banned || 0);
    if (!await confirmBox(t(ids.length ? "Claim every finished pass mission and the daily reward for {0} selected account(s)? Accounts not in a team log in one by one." : "Claim every finished pass mission and the daily reward for {0} pool account(s)? Accounts not in a team log in one by one.", n), t("Claim"))) return;
    btn.disabled = true;
    const r = await act(() => api("POST", "/api/claim", { uids: ids.length ? ids : undefined }), j => t("Claiming for {0} account(s)…", j.total));
    btn.disabled = false;
    if (r) load();
};

$("#guild-claim").onclick = async e => {
    const btn = e.currentTarget, ids = [...S.picked];
    const n = ids.length || (S.data?.counts.total || 0) - (S.data?.counts.banned || 0);
    if (!await confirmBox(t(ids.length ? "Claim the guild and personal activity rewards, then buy the weekly guild store item, for {0} selected account(s)? Accounts not in a team log in one by one." : "Claim the guild and personal activity rewards, then buy the weekly guild store item, for {0} pool account(s)? Accounts not in a team log in one by one.", n), t("Claim"))) return;
    btn.disabled = true;
    const r = await act(() => api("POST", "/api/guild-claim", { uids: ids.length ? ids : undefined }), j => t("Claiming guild rewards for {0} account(s)…", j.total));
    btn.disabled = false;
    if (r) load();
};

$("#clan-send").onclick = async e => {
    const btn = e.currentTarget, id = $("#clan-id").value.trim();
    if (!/^\d{3,20}$/.test(id)) return toast(t("Enter the clan ID as a number, e.g. 3068420572"), true);
    lsSet("tb.clan", id);
    const picked = $("#clan-who").value === "picked" ? [...S.picked] : null;
    if (picked && !picked.length) return toast(t("Select accounts in the pool first"), true);
    const n = picked ? picked.length : (S.data?.counts.total || 0) - (S.data?.counts.banned || 0);
    if (!await confirmBox(t("Send a join request to clan {0} from {1} account(s)?", id, n), t("Send"))) return;
    btn.disabled = true;
    const r = await act(() => api("POST", "/api/clan", { clan_id: id, uids: picked || undefined }), t("Sending join requests…"));
    btn.disabled = false;
    if (r) load();
};

// ---------- match history (GetMatchStatsHistory) drawn like the game's end-of-match screen ----------
const H = { uid: lsGet("tb.histUid", ""), data: null };
function histAccounts(rows) {
    const sel = $("#hist-acc");
    if (document.activeElement === sel) return;
    const list = (rows || []).filter(a => a.status !== "banned");
    if (!H.uid && list.length) H.uid = list[0].uid;
    setHTML(sel, list.length
        ? list.map(a => `<option value="${esc(a.uid)}" ${a.uid === H.uid ? "selected" : ""}>${esc(a.nickname || a.uid)}${a.level ? " · " + t("Lv {0}", fmtN(a.level)) : ""}${a.team ? t(" · in team") : ""}</option>`).join("")
        : `<option value="">${t("No account in the pool")}</option>`);
}
$("#hist-acc").addEventListener("change", e => { H.uid = e.target.value; lsSet("tb.histUid", H.uid); });
$("#hist-load").onclick = async e => {
    const btn = e.currentTarget;
    if (!H.uid) return toast(t("Add an account to the pool first"), true);
    btn.disabled = true;
    btn.textContent = t("Loading…");
    const r = await act(() => api("POST", "/api/match-history", { uid: H.uid }), r => t("{0} match(es) for {1}", r.matches.length, r.nickname));
    btn.disabled = false;
    btn.textContent = t("Load history");
    if (r) { H.data = r; renderHistory(); }
};
$("#hist-all").onclick = async () => {
    for (const c of $$("#history canvas")) { downloadCanvas(c); await new Promise(res => setTimeout(res, 300)); }
};
$("#history").addEventListener("click", e => {
    const b = e.target.closest("[data-dl]");
    if (b) downloadCanvas($(`#history canvas[data-i="${b.dataset.dl}"]`));
});
function downloadCanvas(c) {
    if (!c) return;
    const a = document.createElement("a");
    a.download = c.dataset.file;
    a.href = c.toDataURL("image/png");
    a.click();
}
const matchTitle = m => m.mode === "CS"
    ? `${t(m.won ? "Victory" : "Defeat")} ${m.score[0]}-${m.score[1]} · Clash Squad · ${m.map}`
    : `#${m.placement}/${m.total_players} · Battle Royale · ${m.map}`;
function renderHistory() {
    const r = H.data, box = $("#history");
    $("#hist-all").hidden = !r?.matches.length;
    if (!r.matches.length) { box.innerHTML = `<div class="empty">${t("No match in {0}'s history yet.", esc(r.nickname))}</div>`; return; }
    box.innerHTML = `<div class="hist-head"><b>${esc(r.nickname)}</b><span class="hint">${t("{0} last matches · read {1}", fmtN(r.matches.length), fmtTime(r.fetched_at))}</span></div>
        <div class="hist-grid">${r.matches.map((m, i) => `<figure class="hist-item"><canvas data-i="${i}" role="img" aria-label="${esc(matchTitle(m))}"></canvas>
            <figcaption><span>${esc(matchTitle(m))} · ${fmtDT(m.start_time)}</span><button class="btn sm" data-dl="${i}">${t("Download PNG")}</button></figcaption></figure>`).join("")}</div>`;
    // the account's own avatar / banner (a BR match has no player list): taken from its CS matches
    H.me = r.matches.flatMap(m => m.team).find(p => p.is_me) || null;
    const draw = () => r.matches.forEach((m, i) => {
        const c = $(`#history canvas[data-i="${i}"]`);
        if (!c) return;
        c.dataset.file = `match-${(r.nickname || r.uid).replace(/[^\p{L}\p{N}_-]/gu, "")}-${m.match_id}.png`;
        drawMatch(c, m);
    });
    draw();                                     // right away with what is loaded, again once every image is in
    const players = r.matches.flatMap(m => [...m.team, ...m.opponents]).concat(H.me ? [H.me] : []);
    Promise.all(players.flatMap(p => [cardImage("avatar", p.head_pic), cardImage("banner", p.banner_id)])).then(() => {
        if (H.data === r) draw();
    });
}
// avatars and banners through the bot (/api/card-image, same origin: the canvas stays exportable)
const IMG = new Map();
function cardImage(kind, id) {
    const key = `${kind}/${/^\d{1,12}$/.test(String(id || "")) ? id : 0}`;
    if (!IMG.has(key)) IMG.set(key, new Promise(res => {
        const img = new Image();
        img.onload = () => { img.ready = true; res(img); };
        img.onerror = () => res(null);
        img.src = `/api/card-image/${key}`;
        IMG.set(key + ":img", img);
    }));
    return IMG.get(key);
}
const loaded = (kind, id) => {
    const img = IMG.get(`${kind}/${/^\d{1,12}$/.test(String(id || "")) ? id : 0}:img`);
    return img && img.ready ? img : null;
};
function cover(ctx, img, x, y, w, h) {
    const s = Math.max(w / img.width, h / img.height), sw = w / s, sh = h / s;
    ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, w, h);
}
// a player's strip as in the game: avatar, then the banner behind the name (faded into the row)
function playerStrip(ctx, p, x, y, w, h, me) {
    ctx.fillStyle = me ? GAME.me : GAME.row;
    ctx.fillRect(x, y, w, h);
    const banner = loaded("banner", p?.banner_id), avatar = loaded("avatar", p?.head_pic);
    const bx = x + h, bw = w - h;
    if (banner) {
        ctx.save();
        ctx.globalAlpha = me ? .55 : .8;
        cover(ctx, banner, bx, y, bw, h);
        ctx.restore();
        const fade = ctx.createLinearGradient(bx, 0, bx + bw, 0);
        const base = me ? "30,87,184" : "27,27,46";
        fade.addColorStop(0, `rgba(${base},.15)`);
        fade.addColorStop(.55, `rgba(${base},.55)`);
        fade.addColorStop(1, `rgba(${base},1)`);
        ctx.fillStyle = fade;
        ctx.fillRect(bx, y, bw, h);
    }
    if (avatar) cover(ctx, avatar, x, y, h, h);
    else { ctx.fillStyle = "#2a2b45"; ctx.fillRect(x, y, h, h); }
}

// The canvas is drawn at 2x for a sharp PNG; all coordinates below are in the 900-wide layout.
const GAME = { bg1: "#1d1636", bg2: "#0c0a18", gold: "#f6c445", white: "#f2f3f7", grey: "#a3a7ba", dim: "#6f7389",
               row: "#1b1b2e", rowLine: "#2b2b44", me: "#1e57b8", blue: "#1f6fe0", orange: "#ec6a2c" };
const FONT = (w, s) => `${w} ${s}px "Segoe UI", Inter, system-ui, sans-serif`;
function fit(ctx, text, max) {
    text = String(text ?? "");
    if (ctx.measureText(text).width <= max) return text;
    while (text.length > 1 && ctx.measureText(text + "…").width > max) text = text.slice(0, -1);
    return text + "…";
}
function drawMatch(canvas, m) {
    const W = 900, Hh = m.mode === "CS" ? 520 : 330, k = 2;
    canvas.width = W * k;
    canvas.height = Hh * k;
    const ctx = canvas.getContext("2d");
    ctx.scale(k, k);
    const g = ctx.createLinearGradient(0, 0, 0, Hh);
    g.addColorStop(0, GAME.bg1);
    g.addColorStop(1, GAME.bg2);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, Hh);
    const text = (t, x, y, font, color, align = "left") => { ctx.font = font; ctx.fillStyle = color; ctx.textAlign = align; ctx.fillText(t, x, y); };

    text(m.mode === "CS" ? "CLASH SQUAD" : "BATTLE ROYALE", 24, 36, FONT(700, 20), GAME.white);
    text(String(m.map || "").toUpperCase(), 24, 58, FONT(600, 14), GAME.grey);
    text(new Date(m.start_time * 1000).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }),
         W - 24, 36, FONT(500, 13), GAME.grey, "right");
    text(`${Math.floor(m.duration_sec / 60)}'${String(m.duration_sec % 60).padStart(2, "0")}"`, W - 24, 56, FONT(500, 13), GAME.dim, "right");
    text(t("Match {0}", m.match_id), 24, Hh - 14, FONT(400, 11), GAME.dim);
    text(t("Lv {0} · +{1} EXP · +{2} gold", m.level, m.exp_gained, m.coins_gained), W - 24, Hh - 14, FONT(400, 11), GAME.dim, "right");

    if (m.mode === "CS") drawCS(ctx, m, W, text);
    else drawBR(ctx, m, W, text);
}
function drawCS(ctx, m, W, text) {
    text(m.won ? "VICTORY" : "DEFEAT", W / 2, 100, FONT(800, 44), m.won ? GAME.gold : GAME.white, "center");
    // score bar: our team (blue) VS opponents (orange)
    const y = 124, h = 40;
    ctx.fillStyle = GAME.blue;
    ctx.beginPath(); ctx.moveTo(24, y); ctx.lineTo(W / 2 - 30, y); ctx.lineTo(W / 2 - 46, y + h); ctx.lineTo(24, y + h); ctx.fill();
    ctx.fillStyle = GAME.orange;
    ctx.beginPath(); ctx.moveTo(W / 2 + 46, y); ctx.lineTo(W - 24, y); ctx.lineTo(W - 24, y + h); ctx.lineTo(W / 2 + 30, y + h); ctx.fill();
    text(t("YOUR TEAM"), W / 4, y + 27, FONT(700, 15), GAME.white, "center");
    text(String(m.score[0]), W / 2 - 66, y + 30, FONT(800, 26), GAME.white, "center");
    text("VS", W / 2, y + 31, FONT(800, 28), GAME.white, "center");
    text(String(m.score[1]), W / 2 + 66, y + 30, FONT(800, 26), GAME.white, "center");
    text(t("OPPONENTS"), W * 3 / 4, y + 27, FONT(700, 15), GAME.white, "center");

    const team = [...m.team].sort((a, b) => b.is_me - a.is_me);
    const colW = (W - 48 - 16) / 2;
    [[team, 24], [m.opponents, 24 + colW + 16]].forEach(([players, x]) => {
        const hy = 190;
        // rating box left of each row, then the player's strip (avatar + banner) as in the game
        const sx = x + 50, sw = colW - 50;
        text(t("RATING"), x + 2, hy, FONT(600, 11), GAME.grey);
        text(t("NAME"), sx + 66, hy, FONT(600, 11), GAME.grey);
        text("K / D / A", x + colW - 120, hy, FONT(600, 11), GAME.grey, "center");
        text(t("DMG"), x + colW - 40, hy, FONT(600, 11), GAME.grey, "center");
        for (let i = 0; i < 4; i++) {
            const p = players[i], ry = 200 + i * 66;
            playerStrip(ctx, p, sx, ry, sw, 58, p?.is_me);
            ctx.strokeStyle = p?.is_me ? "#6aa2ff" : GAME.rowLine;
            ctx.strokeRect(sx + .5, ry + .5, sw - 1, 57);
            if (!p) continue;
            const best = p.rating !== null && p.rating === Math.max(...players.map(q => q.rating ?? -1));
            ctx.fillStyle = best ? GAME.gold : "#2a2b45";
            ctx.fillRect(x + 2, ry + 13, 42, 32);
            text(p.rating === null ? "—" : p.rating.toFixed(1), x + 23, ry + 35, FONT(800, 15), best ? "#1a1205" : GAME.white, "center");
            ctx.save();
            ctx.shadowColor = "rgba(0,0,0,.85)";
            ctx.shadowBlur = 3;
            ctx.font = FONT(700, 15);
            text(fit(ctx, p.nickname, sw - 66 - 160), sx + 66, ry + 27, FONT(700, 15), GAME.white);
            ctx.font = FONT(500, 12);
            text(fit(ctx, p.guild || "", sw - 66 - 160), sx + 66, ry + 45, FONT(500, 12), "#d4d7e3");
            text(`${p.kills} / ${p.deaths} / ${p.assists}`, x + colW - 120, ry + 35, FONT(700, 15), GAME.white, "center");
            text(fmtN(p.damage), x + colW - 40, ry + 35, FONT(700, 15), GAME.white, "center");
            ctx.restore();
        }
    });
}
function drawBR(ctx, m, W, text) {
    ctx.textAlign = "center";
    ctx.font = FONT(800, 64);
    const place = `#${m.placement}`, total = `/${m.total_players}`;
    const w1 = ctx.measureText(place).width;
    ctx.font = FONT(700, 44);
    const w2 = ctx.measureText(total).width, x0 = W / 2 - (w1 + w2) / 2;
    text(place, x0, 120, FONT(800, 64), GAME.gold);
    text(total, x0 + w1, 120, FONT(700, 44), GAME.grey);
    text(m.placement === 1 ? "BOOYAH!" : "TRY AGAIN NEXT TIME!", W / 2, 152, FONT(700, 16), GAME.white, "center");
    const me = { kills: m.kills, damage: m.damage };
    const cols = [["NAME", 120, "left"], ["K", 470, "center"], ["DMG", 590, "center"], ["SURVIVAL TIME", 740, "center"]];
    cols.forEach(([l, x, a]) => text(l, x, 196, FONT(600, 12), GAME.grey, a));
    playerStrip(ctx, H.me, 24, 208, W - 48, 58, true);
    ctx.strokeStyle = "#6aa2ff";
    ctx.strokeRect(24.5, 208.5, W - 49, 57);
    ctx.shadowColor = "rgba(0,0,0,.85)";
    ctx.shadowBlur = 3;
    text(`${me.kills}`, 470, 244, FONT(700, 17), GAME.white, "center");
    text(fmtN(me.damage), 590, 244, FONT(700, 17), GAME.white, "center");
    text(`${String(Math.floor(m.duration_sec / 60)).padStart(2, "0")}'${String(m.duration_sec % 60).padStart(2, "0")}"`, 740, 244, FONT(700, 17), GAME.white, "center");
    const name = H.data?.nickname || m.account_id;
    ctx.font = FONT(700, 16);
    text(fit(ctx, name, 320), 120, 236, FONT(700, 16), GAME.white);
    text(`ID ${m.account_id}`, 120, 255, FONT(500, 12), GAME.grey);
}

// ---------- Settings (GET/POST /api/settings, see ffbot/site_settings.py) ----------
const SET = { data: null, draft: {}, open: new Set(lsGet("tb.setOpen", ["br", "cs"])) };
const APPLIES = { live: ["live", "Live"], next: ["next", "Next match"], restart: ["restart", "Restart"] };
const setVal = it => it.key in SET.draft ? SET.draft[it.key] : it.value;
function setFieldHTML(it) {
    const v = setVal(it), id = `set-${it.key}`, [cls, txt] = APPLIES[it.applies] || ["", it.applies], [lab, hlp] = setFr(it);
    let ctl;
    if (it.kind === "bool")
        ctl = `<span class="switch"><input type="checkbox" role="switch" id="${id}" data-set="${esc(it.key)}" ${v ? "checked" : ""}><i></i></span><span class="hint">${t(v ? "On" : "Off")}</span>`;
    else if (it.kind === "str")
        ctl = `<input type="text" id="${id}" data-set="${esc(it.key)}" value="${esc(v ?? "")}" spellcheck="false">`;
    else
        ctl = `<input type="number" id="${id}" data-set="${esc(it.key)}" value="${esc(v ?? "")}"${it.min !== null ? ` min="${it.min}"` : ""}${it.max !== null ? ` max="${it.max}"` : ""} step="${it.step ?? (it.kind === "int" ? 1 : "any")}" inputmode="decimal">`;
    const def = it.default === null || it.default === undefined ? "" : (it.kind === "bool" ? t(it.default ? "On" : "Off") : it.default);
    const extra = it.applies === "restart" && it.running !== null && it.running !== undefined && String(it.running) !== String(it.value ?? "")
        ? t(" · running now: {0}", esc(it.running)) : "";
    const reset = it.changed ? ` · <button type="button" class="linkish" data-set-reset="${esc(it.key)}">${t("Reset to .env ({0})", esc(def))}</button>` : "";
    return `<div class="set-item${it.key in SET.draft ? " dirty" : ""}">
        <div class="top"><label for="${id}">${esc(lab)}</label><span class="tag ${cls}">${t(txt)}</span></div>
        <div class="ctl">${ctl}</div>
        <small>${esc(hlp)}${extra}${reset}</small></div>`;
}
function renderSettings() {
    const d = SET.data;
    if (!d) return;
    const html = d.groups.map(g => {
        const items = d.items.filter(i => i.group === g.id);
        if (!items.length) return "";
        const n = items.filter(i => i.key in SET.draft).length;
        return `<details class="set-group" data-g="${esc(g.id)}" ${SET.open.has(g.id) ? "open" : ""}>
            <summary><h3>${esc(groupFr(g)[0])}</h3><span class="hint">${esc(groupFr(g)[1])}</span>${n ? `<span class="tag next">${t("{0} unsaved", n)}</span>` : ""}</summary>
            <div class="set-grid">${items.map(setFieldHTML).join("")}</div></details>`;
    }).join("");
    const body = $("#set-body"), focus = document.activeElement?.id, caret = document.activeElement?.selectionStart;
    setHTML(body, html);
    if (focus && focus.startsWith("set-")) { const el = $("#" + CSS.escape(focus)); if (el) { el.focus(); try { if (caret != null) el.setSelectionRange(caret, caret); } catch { /* number input */ } } }
    const dirty = Object.keys(SET.draft).length;
    $("#set-save").disabled = $("#set-undo").disabled = !dirty;
    $("#set-save").textContent = dirty ? t("Save {0} change(s)", dirty) : t("Save changes");
    $("#set-state").textContent = d.workers ? t("{0} UDP worker(s) get changes at once", d.workers) : t("matches run in the main process");
}
async function loadSettings() {
    const d = await act(() => api("GET", "/api/settings"));
    if (d) { SET.data = d; renderSettings(); }
}
function setInput(e) {
    const el = e.target.closest("[data-set]");
    if (!el) return;
    const it = SET.data.items.find(i => i.key === el.dataset.set);
    let v = it.kind === "bool" ? el.checked : el.value;
    if ((it.kind === "int" || it.kind === "float") && v !== "") v = Number(v);
    const same = it.kind === "bool" ? v === !!it.value : String(v) === String(it.value ?? "");
    if (same) delete SET.draft[it.key]; else SET.draft[it.key] = v;
    if (e.type === "change" || it.kind === "bool") renderSettings();
    else { el.closest(".set-item").classList.toggle("dirty", !same); const n = Object.keys(SET.draft).length; $("#set-save").disabled = $("#set-undo").disabled = !n; $("#set-save").textContent = n ? t("Save {0} change(s)", n) : t("Save changes"); }
}
$("#set-body").addEventListener("input", setInput);
$("#set-body").addEventListener("change", setInput);
$("#set-body").addEventListener("toggle", e => {
    const g = e.target.closest?.("details.set-group");
    if (!g) return;
    g.open ? SET.open.add(g.dataset.g) : SET.open.delete(g.dataset.g);
    lsSet("tb.setOpen", [...SET.open]);
}, true);
$("#set-body").addEventListener("click", async e => {
    const b = e.target.closest("[data-set-reset]");
    if (!b) return;
    const d = await act(() => api("POST", "/api/settings/reset", { keys: [b.dataset.setReset] }), t("Back to the .env value"));
    if (d) { delete SET.draft[b.dataset.setReset]; SET.data = d; renderSettings(); }
});
$("#set-undo").addEventListener("click", () => { SET.draft = {}; SET.data && (setHTML($("#set-body"), ""), renderSettings()); });
$("#set-save").addEventListener("click", async () => {
    const values = { ...SET.draft };
    if (!Object.keys(values).length) return;
    const restart = Object.keys(values).some(k => SET.data.items.find(i => i.key === k)?.applies === "restart");
    $("#set-save").disabled = true;
    const d = await act(() => api("POST", "/api/settings", { values }),
        r => `${t("Saved · sent to {0} worker(s), matches in progress follow now", r.applied.workers)}${restart ? t(" · restart run.py for server settings") : ""}`);
    if (d) { SET.draft = {}; SET.data = d; }
    renderSettings();
});
$("#settings-open").addEventListener("click", e => { e.preventDefault(); $("#settings").scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); });
loadSettings();

load();
setInterval(() => { if (!document.hidden) load(); }, 3000);
