# -*- coding: utf-8 -*-
"""
FF Team Bot — standalone web app, two features only:
  - bot-only Clash Squad teams: 2–4 bots make their own team, the leader searches, all play the match; several
    teams at once; per-match data (deaths, zone deaths, server pull-backs, 144s, EXP…) kept in data/teamlab.db;
  - clan join requests for the accounts of the pool.

    python run.py                       # then open http://127.0.0.1:8090

No login: whoever can open the page controls the bots. HOST stays 127.0.0.1 (this computer only) unless .env says
otherwise; with HOST=0.0.0.0, keep the port closed to the internet (firewall / VPN).
Settings: .env next to this file (see .env.example).
"""
import asyncio
import os
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
if sys.platform == "win32":
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

from ffbot.config import _load_dotenv  # noqa: E402

# .env before importing ffbot.protocol (several settings are read when the module loads)
_load_dotenv(os.path.join(ROOT, ".env"))
# SAVE_LOGS=0 (VPS) : aucun fichier de log, quels que soient les autres réglages du .env — journal de diagnostic
# (logs/teambot-debug|errors-*.log, logs/worker-N.stderr.log), messages de la passerelle (logs/teambot-gateway.jsonl),
# journal de la guilde (logs/guild-rewards.json), captures UDP (logs/capture/, captures/bot/). Les workers UDP
# héritent de ces variables. La base data/teamlab.db (comptes, parties) est toujours gardée.
if os.environ.get("SAVE_LOGS", "1").strip().lower() in ("0", "false", "no", "off", "non"):
    os.environ.update(DEBUG_LOG="0", UDP_CAPTURE="0", TEAMBOT_GATEWAY_DUMP="", GUILD_JOURNAL="")
os.environ.setdefault("DEBUG_LOG_PREFIX", "teambot-")
os.environ.setdefault("UDP_WORKERS", "2")

from aiohttp import web  # noqa: E402

from ffbot import api_client, card_images, diag  # noqa: E402
from ffbot import protocol  # noqa: E402
from ffbot import teamlab as teamlab_module  # noqa: E402
from ffbot.login_gate import LoginGate  # noqa: E402
from ffbot.site_settings import SiteSettings  # noqa: E402
from ffbot.teamlab import TeamLab  # noqa: E402

HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8090") or 8090)
WEB_DIR = os.path.join(ROOT, "web")
WEB_FILES = {"index.html": "text/html", "app.js": "application/javascript", "i18n.js": "application/javascript",
             "style.css": "text/css"}
CSRF_HEADER = "X-TeamBot"            # every POST from the page carries it (a plain cross-site form cannot)
LAB = web.AppKey("lab", TeamLab)
IMAGES = web.AppKey("images", card_images.CardImages)
SETTINGS = web.AppKey("settings", SiteSettings)


def _log(text: str, color: str = "96"):
    print(f"\033[{color}m{text}\033[0m", flush=True)


def ok(data=None) -> web.Response:
    return web.json_response({"ok": True, "data": data})


@web.middleware
async def errors(request: web.Request, handler):
    if request.method == "POST" and request.headers.get(CSRF_HEADER) != "1":
        return web.json_response({"ok": False, "error": f"missing {CSRF_HEADER} header"}, status=403)
    try:
        return await handler(request)
    except web.HTTPException:
        raise
    except (ValueError, TypeError) as e:
        return web.json_response({"ok": False, "error": str(e) or "invalid value"}, status=400)
    except Exception as e:
        diag.event("TEAMBOT", "api_error", level="error", exc=e, tb=True, path=request.path)
        return web.json_response({"ok": False, "error": f"server error: {e!r}"[:300]}, status=500)


async def body(request: web.Request) -> dict:
    try:
        data = await request.json()
    except Exception:
        raise ValueError("invalid JSON body")
    if not isinstance(data, dict):
        raise ValueError("JSON body must be an object")
    return data


def uids(data: dict) -> list:
    raw = data.get("uids")
    return [str(u) for u in raw[:5000]] if isinstance(raw, list) else []


# ---------- pages ----------
async def static(request: web.Request) -> web.Response:
    name = request.match_info.get("name") or "index.html"
    if name not in WEB_FILES:
        raise web.HTTPNotFound()
    with open(os.path.join(WEB_DIR, name), "rb") as f:
        return web.Response(body=f.read(), content_type=WEB_FILES[name], charset="utf-8",
                            headers={"Cache-Control": "no-cache"})


# ---------- API ----------
async def status(request: web.Request) -> web.Response:
    try:
        since = max(0.0, float(request.query.get("since") or 0))
    except ValueError:
        since = 0.0
    return ok(request.app[LAB].status(since, request.query.get("mode") or None))


async def accounts_add(request: web.Request) -> web.Response:
    return ok(request.app[LAB].add_accounts(str((await body(request)).get("text") or "")))


async def accounts_action(request: web.Request) -> web.Response:
    lab, ids = request.app[LAB], uids(await body(request))
    n = lab.remove_accounts(ids) if request.match_info["action"] == "delete" else lab.reset_accounts(ids)
    return ok({"count": n})


async def start(request: web.Request) -> web.Response:
    data = await body(request)
    goal = data.get("level_target")
    r = await request.app[LAB].start(int(data.get("teams") or 1), int(data.get("size") or 4),
                                     int(data.get("matches") or 0), data.get("mode") or None,
                                     None if goal in (None, "") else int(goal))
    _log(f"[+] {len(r['teams'])} team(s) started ({data.get('mode') or 'last mode'}): {', '.join(r['teams'])}", "92")
    return ok(r)


async def level_target(request: web.Request) -> web.Response:
    """Niveau objectif (0 = aucun) : un compte qui l'atteint quitte son équipe à la fin de sa partie, remplacé."""
    r = request.app[LAB].set_level_target(int((await body(request)).get("level") or 0))
    _log(f"[+] level goal: {r['level_target'] or 'none'} ({r['maxed']} account(s) maxed, {r['freed']} freed)", "92")
    return ok(r)


async def search_turns(request: web.Request) -> web.Response:
    """Une équipe en recherche à la fois par mode (teamlab.SEARCH_TURNS) : activé / désactivé tout de suite."""
    on = request.app[LAB].set_search_turns(bool((await body(request)).get("on")))
    _log(f"[+] search turns {'on: one team searches at a time' if on else 'off: every team searches at once'}", "92")
    return ok({"on": on})


async def stop_team(request: web.Request) -> web.Response:
    data = await body(request)
    if not await request.app[LAB].stop(request.match_info["id"], bool(data.get("now"))):
        raise web.HTTPNotFound(text='{"ok": false, "error": "team not found (already over?)"}',
                               content_type="application/json")
    return ok()


async def stop_all(request: web.Request) -> web.Response:
    return ok({"count": await request.app[LAB].stop_all(bool((await body(request)).get("now")))})


async def clan(request: web.Request) -> web.Response:
    data = await body(request)
    clan_id = str(data.get("clan_id") or "").strip()
    if not clan_id.isdigit() or not 3 <= len(clan_id) <= 20:
        raise ValueError("the clan ID must be a number (e.g. 3068420572)")
    job = request.app[LAB].join_clan(int(clan_id), uids(data) or None)
    _log(f"[+] clan {clan_id}: sending join requests for {job['total']} account(s)", "92")
    return ok(job)


async def clan_info(request: web.Request) -> web.Response:
    clan_id = str((await body(request)).get("clan_id") or "").strip()
    if clan_id and (not clan_id.isdigit() or not 3 <= len(clan_id) <= 20):
        raise ValueError("the clan ID must be a number (e.g. 3106179650)")
    try:
        return ok(await request.app[LAB].refresh_clan(clan_id or None))
    except api_client.GameApiError as e:
        return web.json_response({"ok": False, "error": f"clan page: {e}"[:300]}, status=502)


async def honor(request: web.Request) -> web.Response:
    job = request.app[LAB].refresh_honor(uids(await body(request)) or None)
    _log(f"[+] honor score check for {job['total']} account(s)", "92")
    return ok(job)


async def claim(request: web.Request) -> web.Response:
    job = request.app[LAB].claim_all(uids(await body(request)) or None)
    _log(f"[+] pass rewards claim for {job['total']} account(s)", "92")
    return ok(job)


async def guild_claim(request: web.Request) -> web.Response:
    job = request.app[LAB].claim_guild_all(uids(await body(request)) or None)
    _log(f"[+] guild rewards claim for {job['total']} account(s)", "92")
    return ok(job)


async def match_history(request: web.Request) -> web.Response:
    uid = str((await body(request)).get("uid") or "").strip()
    if not uid:
        raise ValueError("pick an account")
    try:
        return ok(await request.app[LAB].match_history(uid))
    except api_client.GameApiError as e:
        return web.json_response({"ok": False, "error": f"match history: {e}"[:300]}, status=502)


async def card_image(request: web.Request) -> web.Response:
    """Avatar / bannière d'un joueur (ffbot.card_images), pour les images de l'historique des matchs."""
    images = request.app[IMAGES]
    kind, image_id = request.match_info["kind"], request.match_info["id"]
    data, real = await (images.avatar(image_id) if kind == "avatar" else images.banner(image_id))
    if not data:
        raise web.HTTPNotFound()
    return web.Response(body=data, content_type=card_images.image_type(data),
                        headers={"Cache-Control": "max-age=86400" if real else "no-store"})


async def export(request: web.Request) -> web.Response:
    import json
    text = json.dumps(request.app[LAB].export(), ensure_ascii=False, indent=1)
    return web.Response(text=text, content_type="application/json", headers={
        "Content-Disposition": f'attachment; filename="teambot-matches-{time.strftime("%Y%m%d-%H%M")}.json"',
        "Cache-Control": "no-store"})


async def settings_get(request: web.Request) -> web.Response:
    return ok(request.app[SETTINGS].view())


async def settings_save(request: web.Request) -> web.Response:
    """Réglages de la page : appliqués tout de suite, parties en cours comprises (voir ffbot.site_settings)."""
    values = (await body(request)).get("values")
    r = request.app[SETTINGS].update(values if isinstance(values, dict) else {})
    _log(f"[+] settings saved: {', '.join(values)} (sent to {r['applied']['workers']} worker(s))", "92")
    return ok(r)


async def settings_reset(request: web.Request) -> web.Response:
    keys = (await body(request)).get("keys")
    r = request.app[SETTINGS].reset([str(k) for k in keys] if isinstance(keys, list) else [])
    _log(f"[+] settings reset to .env / default: {', '.join(map(str, keys or []))}", "92")
    return ok(r)


def build_app(lab: TeamLab, settings: SiteSettings) -> web.Application:
    app = web.Application(middlewares=[errors], client_max_size=4 * 1024 * 1024)
    app[LAB] = lab
    app[SETTINGS] = settings
    r = app.router
    r.add_get("/", static)
    r.add_get("/{name:index\\.html|app\\.js|i18n\\.js|style\\.css}", static)
    r.add_get("/api/status", status)
    r.add_get("/api/export", export)
    r.add_get("/api/settings", settings_get)
    r.add_post("/api/settings", settings_save)
    r.add_post("/api/settings/reset", settings_reset)
    r.add_post("/api/accounts", accounts_add)
    r.add_post("/api/accounts/{action:delete|reset}", accounts_action)
    r.add_post("/api/start", start)
    r.add_post("/api/level-target", level_target)
    r.add_post("/api/search-turns", search_turns)
    r.add_post("/api/stop-all", stop_all)
    r.add_post("/api/teams/{id}/stop", stop_team)
    r.add_post("/api/clan", clan)
    r.add_post("/api/clan/info", clan_info)
    r.add_post("/api/honor", honor)
    r.add_post("/api/claim", claim)
    r.add_post("/api/guild-claim", guild_claim)
    r.add_post("/api/match-history", match_history)
    r.add_get("/api/card-image/{kind:avatar|banner}/{id:\\d{1,12}}", card_image)
    app[IMAGES] = card_images.CardImages()

    async def close_images(app_: web.Application):
        await app_[IMAGES].close()
    app.on_cleanup.append(close_images)
    return app


async def start_match_pool():
    """UDP matches in worker processes (UDP_WORKERS in .env, 0 = in this process)."""
    from ffbot.udp_workers import MatchPool, default_worker_count
    count = default_worker_count()
    if count <= 0:
        _log("[i] Matches played in this process (UDP_WORKERS=0)")
        return None
    pool = MatchPool(count, on_stats=protocol.apply_worker_stats, loop_kind=os.environ.get("UDP_WORKER_LOOP", "auto"))
    ready = await pool.start()
    if not ready:
        _log("[-] UDP workers unavailable: matches played in this process", "91")
        await pool.stop()
        return None
    protocol.set_match_pool(pool)
    _log(f"[+] {ready} UDP worker(s) ready — up to {pool.capacity()} matches at once", "92")
    return pool


async def main():
    diag.configure()
    diag.install_loop_handler(asyncio.get_running_loop())
    pool = await start_match_pool()
    gate = LoginGate()
    lab = TeamLab(protocol, gate)
    settings = SiteSettings(lab.db, protocol, teamlab_module, gate)
    settings.init_server()          # choix de la page (data/teamlab.db) par-dessus .env
    runner = web.AppRunner(build_app(lab, settings), access_log=None)
    await runner.setup()
    await web.TCPSite(runner, HOST, PORT).start()
    shown = "127.0.0.1" if HOST in ("0.0.0.0", "") else HOST
    _log("=" * 60)
    _log(f"   FF Team Bot  ->  http://{shown}:{PORT}", "92")
    _log("=" * 60)
    if HOST not in ("127.0.0.1", "localhost"):
        _log(f"[!] HOST={HOST}: the page has no login, keep port {PORT} closed to the internet", "93")
    try:
        await asyncio.Event().wait()
    except asyncio.CancelledError:
        pass
    finally:
        _log("[!] Stopping: teams leave their team (matches in progress are cut)...", "93")
        await lab.stop_all()
        await lab.shutdown(15)
        await runner.cleanup()
        if pool is not None:
            protocol.set_match_pool(None)
            await pool.stop()
        await api_client.close()
        protocol.flush_files()          # token_cache.json / devices.json
        diag.shutdown()
        _log("[+] Stopped.", "92")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
