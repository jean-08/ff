# -*- coding: utf-8 -*-
"""
Client des serveurs du jeu, repris de get_info.py.

Une seule méthode pour les requêtes POST vers le serveur du jeu :
  - en-têtes de get_info.py (format inchangé) ; sans token, pas d'Authorization ;
  - Host déduit de l'URL appelée ;
  - la réponse est TOUJOURS lue avant de vérifier le statut HTTP : une erreur
    (ex. HTTP 427) remonte avec son code et le début de son contenu.

Utilisé par GetPlayerPersonalShow (check_info / get_player_info), à la place de l'API web
raw.thug4ff.xyz pour la carte de profil (ffbot/profile_card.py), et pour le relevé d'EXP / niveau
des comptes en session (account_profile, appelé par ffbot/protocol.py) : simple lecture du profil,
alors que GetLoginData fait partie du login.
MajorLogin et GetLoginData (login) gardent la méthode d'origine de ffbot/protocol.py
(client httpx, en-têtes UnityPlayer), comme fast-old-ui : avec ces en-têtes MajorLogin répond
HTTP 400 « SignError1 », et GetLoginData expirait souvent sous charge (délai total de 10 s + 2 essais).
"""
import asyncio
import base64
import json
import time
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import aiohttp
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

from GetPlayerPersonalShowReq_pb2 import GetPlayerPersonalShowRequest
from GetPlayerPersonalShowResp_pb2 import GetPlayerPersonalShowResponse

# ============================================================
# CONFIGURATION
# ============================================================

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'
VERSION = "OB55"

TIMEOUT_S = 10
RETRY_STATUSES = frozenset({408, 427, 429, 500, 502, 503, 504})
RETRY_DELAY_S = 1.5
# Requêtes simultanées vers le serveur du jeu : au-delà, elles attendent leur tour (hors délai) au lieu de
# partir toutes ensemble quand des dizaines de comptes finissent leurs matchs en même temps.
MAX_CONCURRENT = 24

_session: Optional[aiohttp.ClientSession] = None
_slots = asyncio.Semaphore(MAX_CONCURRENT)
stats = {"requests": 0, "ok": 0, "timeouts": 0, "errors": 0}


class GameApiError(Exception):
    """Échec d'un appel au serveur du jeu (réseau, statut HTTP ou réponse illisible)."""

    def __init__(self, message: str, status: Optional[int] = None):
        super().__init__(message)
        self.status = status


def _preview(content: bytes, limit: int = 120) -> str:
    """Début lisible d'une réponse : texte si c'en est, sinon hexadécimal."""
    try:
        text = " ".join(content.decode("utf-8").split())
        if text.isprintable():
            return text[:limit]
    except UnicodeDecodeError:
        pass
    return content[:limit // 2].hex()


# ============================================================
# AES
# ============================================================

def encrypt_aes(data: bytes) -> bytes:
    """Chiffrement AES-CBC des données."""
    cipher = AES.new(
        AES_KEY,
        AES.MODE_CBC,
        AES_IV
    )

    return cipher.encrypt(
        pad(data, AES.block_size)
    )


# ============================================================
# HTTP
# ============================================================

def server_url(server: str) -> str:
    """URL du serveur du jeu d'une région (choix de get_info.py)."""
    if server == "IND":
        return "https://client.ind.freefiremobile.com/"
    if server in {"BR", "US", "SAC", "NA"}:
        return "https://client.us.freefiremobile.com/"
    return "https://clientbp.ppmainecoonghj.com/"


def game_headers(host: str, token: Optional[str] = None, release_version: str = VERSION,
                 client: bool = False) -> Dict[str, str]:
    """En-têtes de get_info.py. Sans token (MajorLogin), l'en-tête Authorization est omis.
    `client` : User-Agent et version Unity du vrai client (relevé decoded_traffic.jsonl, 100 requêtes sur 100), pour
    les requêtes du lobby et des récompenses d'activité."""
    headers = {
        "X-Unity-Version": "2018.4.12f1" if client else "2018.4.11f1",
        "ReleaseVersion": release_version or VERSION,
        "Content-Type": "application/x-www-form-urlencoded",
        "X-GA": "v1 1",
        "Authorization": f"Bearer {token}",
        "User-Agent": (
            "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)" if client else
            "Dalvik/2.1.0 (Linux; U; Android 7.1.2; "
            "SM-G998B Build/SP1A.210812.016)"
        ),
        "Host": host,
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip"
    }
    if not token:
        del headers["Authorization"]
    return headers


async def _get_session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        # connexions gardées ouvertes (keep-alive) et DNS en cache : pas de résolution ni de poignée de main TLS
        # à chaque relevé d'EXP
        connector = aiohttp.TCPConnector(limit=MAX_CONCURRENT * 2, ttl_dns_cache=600, keepalive_timeout=60)
        _session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT_S), connector=connector)
    return _session


async def close():
    """Ferme la session HTTP partagée (arrêt du serveur)."""
    global _session
    if _session is not None and not _session.closed:
        await _session.close()
    _session = None


async def game_post(url: str, payload: bytes, token: Optional[str] = None,
                    release_version: str = VERSION, retries: int = 0, client: bool = False) -> bytes:
    """POST au serveur du jeu. Retourne le contenu d'une réponse 200, lève GameApiError sinon.

    `retries` : nouveaux essais sur erreur réseau ou statut passager (RETRY_STATUSES, dont 427).
    `client` : en-têtes du vrai client (voir game_headers).
    """
    parsed = urlparse(url)
    endpoint = parsed.path.rsplit("/", 1)[-1] or url
    headers = game_headers(parsed.netloc, token, release_version, client)
    attempt = 0
    while True:
        stats["requests"] += 1
        try:
            session = await _get_session()
            async with _slots:
                async with session.post(url, headers=headers, data=payload) as response:
                    # IMPORTANT : on lit TOUJOURS la réponse avant de vérifier le status HTTP.
                    content = await response.read()
            if response.status == 200:
                stats["ok"] += 1
                return content
            error = GameApiError(f"{endpoint} : HTTP {response.status}"
                                 + (f" ({len(content)} octets) {_preview(content)}" if content else ""),
                                 status=response.status)
        except asyncio.TimeoutError:
            error = GameApiError(f"{endpoint}: หมดเวลารอ ({TIMEOUT_S}s)")
        except aiohttp.ClientError as e:
            error = GameApiError(f"{endpoint} : {e.__class__.__name__} {e}".strip())
        stats["timeouts" if error.status is None and "หมดเวลารอ" in str(error) else "errors"] += 1
        if attempt < retries and (error.status is None or error.status in RETRY_STATUSES):
            attempt += 1
            await asyncio.sleep(RETRY_DELAY_S * attempt)
            continue
        raise error


# ============================================================
# TOKEN DU COMPTE
# ============================================================

def token_claims(token: Optional[str]) -> Dict[str, Any]:
    """Contenu du token de session (JWT renvoyé par MajorLogin) : account_id, lock_region, exp…"""
    try:
        payload = str(token).split(".")[1]
        payload += "=" * (-len(payload) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload))
        return claims if isinstance(claims, dict) else {}
    except Exception:
        return {}


def token_valid(token: Optional[str], margin_s: float = 120) -> bool:
    exp = token_claims(token).get("exp")
    return isinstance(exp, (int, float)) and exp > time.time() + margin_s


def token_identity(token: str, account_id: Any = None, region: Optional[str] = None) -> Tuple[Optional[str], str]:
    """(account_id, région) du compte : lus dans le token, sinon valeurs fournies."""
    claims = token_claims(token)
    acc = claims.get("account_id") or account_id
    reg = claims.get("lock_region") or claims.get("noti_region") or region or ""
    return (str(acc) if acc else None), str(reg).upper()


# ============================================================
# CHECK PLAYER INFO (GetPlayerPersonalShow)
# ============================================================

async def fetch_personal_show(target_uid: Any, token: str, server: str = "", base_url: Optional[str] = None,
                              release_version: str = VERSION, retries: int = 0) -> GetPlayerPersonalShowResponse:
    """Profil d'un joueur. `base_url` (URL renvoyée par MajorLogin) prime sur le choix par région."""
    uri = base_url.rstrip("/") + "/" if base_url else server_url(server)

    try:
        msg = GetPlayerPersonalShowRequest()
        msg.account_id = int(target_uid)
        msg.field2 = 7
        msg.field4 = 1
        payload = encrypt_aes(msg.SerializeToString())
    except Exception as e:
        raise GameApiError(f"Erreur Protobuf : {e}")

    content = await game_post(uri + "GetPlayerPersonalShow", payload, token, release_version, retries)

    info = GetPlayerPersonalShowResponse()
    try:
        info.ParseFromString(content)
    except Exception as e:
        raise GameApiError(f"GetPlayerPersonalShow : réponse illisible ({e}) {_preview(content)}")
    if not info.HasField("basicinfo") or not info.basicinfo.accountid:
        raise GameApiError(f"ไม่พบผู้เล่น {target_uid}")
    return info


async def check_info(target_uid: int, token: str, server: str):
    """Interface d'origine de get_info.py : (nickname, level), ou (None, None) en cas d'échec."""
    try:
        info = await fetch_personal_show(target_uid, token, server)
    except GameApiError:
        return None, None
    return info.basicinfo.nickname, info.basicinfo.level


# Champs repris, sous les noms de l'ancienne API web (basicInfo.headPic, clanBasicInfo.clanName…)
_API_FIELDS = {
    "basicinfo": ("basicInfo", {
        "accountid": "accountId", "accounttype": "accountType", "nickname": "nickname", "region": "region",
        "level": "level", "exp": "exp", "bannerid": "bannerId", "headpic": "headPic", "rank": "rank",
        "rankingpoints": "rankingPoints", "role": "role", "haselitepass": "hasElitePass", "badgecnt": "badgeCnt",
        "badgeid": "badgeId", "seasonid": "seasonId", "liked": "liked", "showrank": "showRank",
        "lastloginat": "lastLoginAt", "csrank": "csRank", "csrankingpoints": "csRankingPoints", "pinid": "pinId",
        "maxrank": "maxRank", "csmaxrank": "csMaxRank", "createat": "createAt", "title": "title",
        "releaseversion": "releaseVersion", "showbrrank": "showBrRank", "showcsrank": "showCsRank",
    }),
    "clanbasicinfo": ("clanBasicInfo", {
        "clanid": "clanId", "clanname": "clanName", "captainid": "captainId", "clanlevel": "clanLevel",
        "capacity": "capacity", "membernum": "memberNum",
    }),
    "socialinfo": ("socialInfo", {
        "accountid": "accountId", "gender": "gender", "language": "language", "signature": "signature",
        "rankshow": "rankShow",
    }),
    "profileinfo": ("profileInfo", {
        "avatarid": "avatarId", "skincolor": "skinColor", "clothes": "clothes", "equipedskills": "equipedSkills",
    }),
}


def response_to_dict(info: GetPlayerPersonalShowResponse) -> Dict[str, Any]:
    """Même forme que la réponse de l'ancienne API web ; comme elle, les valeurs nulles sont omises."""
    out: Dict[str, Any] = {}
    for proto_name, (api_name, fields) in _API_FIELDS.items():
        if not info.HasField(proto_name):
            continue
        sub = getattr(info, proto_name)
        section: Dict[str, Any] = {}
        for field, key in fields.items():
            value = getattr(sub, field, None)
            if isinstance(value, (bool, int, float, str)):
                if value:
                    section[key] = value
            elif value is not None and hasattr(value, "__len__") and len(value) \
                    and all(isinstance(v, (bool, int, float, str)) for v in value):
                section[key] = list(value)
        out[api_name] = section
    return out


async def get_player_info(target_uid: Any, token: str, server: str = "", base_url: Optional[str] = None,
                          release_version: str = VERSION) -> Dict[str, Any]:
    """GetPlayerPersonalShow -> dict au format de l'API web. Lève GameApiError en cas d'échec."""
    info = await fetch_personal_show(target_uid, token, server, base_url, release_version)
    return response_to_dict(info)


# ============================================================
# PROFIL DU COMPTE EN SESSION (relevé EXP / niveau)
# ============================================================

def session_profile(info: GetPlayerPersonalShowResponse) -> Dict[str, Any]:
    """Champs suivis pendant une session : niveau, EXP, likes (relevé d'EXP) et avatar / bannière (carte de profil)."""
    b = info.basicinfo
    return {
        "account_id": str(b.accountid),
        "nickname": b.nickname,
        "region": b.region,
        "level": int(b.level),
        "exp": int(b.exp),
        "likes": int(b.liked),
        "head_pic": str(b.headpic) if b.headpic else "",
        "banner_id": str(b.bannerid) if b.bannerid else "",
        # rang classé : 301 = Bronze I … (voir web/app.js rankName) et points ; BR et Clash Squad, saison en cours
        "br_rank": int(b.rank), "br_points": int(b.rankingpoints), "br_max_rank": int(b.maxrank),
        "cs_rank": int(b.csrank), "cs_points": int(b.csrankingpoints), "season": int(b.seasonid),
        "source": "personal_show",
    }


async def account_profile(session: Dict[str, Any], retries: int = 1) -> Dict[str, Any]:
    """Profil du compte d'une session de jeu (token, server_url, release_version de MajorLogin).

    Simple lecture (GetPlayerPersonalShow sur son propre account_id) : ne touche pas à la session en cours,
    contrairement à GetLoginData. Lève GameApiError si la lecture échoue ou si l'EXP manque dans la réponse.
    """
    token = session.get("token")
    if not token:
        raise GameApiError("session sans token")
    uid, region = token_identity(token, session.get("account_id"), session.get("region"))
    if not uid:
        raise GameApiError("account_id inconnu")
    info = await fetch_personal_show(uid, token, region, session.get("server_url"),
                                     session.get("release_version") or VERSION, retries)
    profile = session_profile(info)
    if profile["level"] >= 2 and profile["exp"] <= 0:
        # un compte de niveau 2+ a forcément de l'EXP : réponse incomplète, on ne s'y fie pas
        raise GameApiError("GetPlayerPersonalShow : EXP absente de la réponse")
    return profile


# ============================================================
# RÉCOMPENSES D'ACTIVITÉ (GetActivityRewards)
# ============================================================
# Requête du client du jeu relevée le 15/10 (fichier « ss » : récompense « ล็อกอิน 1/1 วัน », activité 5962201) :
# corps chiffré comme GetPlayerPersonalShow (même clé AES), protobuf
#   1 = activités (varints groupés), 2 = langue, 3 = {1: activité, 2: n° de la récompense}
# Réponse en clair (protobuf) :
#   1 = {1: objet reçu {1: id, 2: nombre, 3: durée s, 6: durée s}…}, 2 = {1: activité, 2: récompense, 3: état,
#   4: condition (« ล็อกอิน 1/1 วัน »)}, 3 = objet ajouté à l'inventaire.

def _pb_varint(n: int) -> bytes:
    out = bytearray()
    n &= (1 << 64) - 1
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)


def _pb_key(num: int, wire: int) -> bytes:
    return _pb_varint(num << 3 | wire)


def _pb_bytes(num: int, data: bytes) -> bytes:
    return _pb_key(num, 2) + _pb_varint(len(data)) + data


def _pb_uint(num: int, value: int) -> bytes:
    return _pb_key(num, 0) + _pb_varint(value)


def pb_parse(data: bytes) -> Dict[int, list]:
    """Protobuf sans schéma : numéro de champ -> valeurs (int pour les varints, bytes pour le reste).
    Lève ValueError si les données ne sont pas du protobuf."""
    out: Dict[int, list] = {}
    i, n = 0, len(data)

    def varint() -> int:
        nonlocal i
        shift = value = 0
        while True:
            if i >= n or shift > 63:
                raise ValueError("varint")
            b = data[i]
            i += 1
            value |= (b & 0x7F) << shift
            if not b & 0x80:
                return value
            shift += 7

    while i < n:
        key = varint()
        num, wire = key >> 3, key & 7
        if num == 0:
            raise ValueError("field 0")
        if wire == 0:
            value: Any = varint()
        elif wire == 2:
            length = varint()
            if i + length > n:
                raise ValueError("length")
            value = data[i:i + length]
            i += length
        elif wire == 5:
            value = int.from_bytes(data[i:i + 4], "little")
            i += 4
        elif wire == 1:
            value = int.from_bytes(data[i:i + 8], "little")
            i += 8
        else:
            raise ValueError(f"wire {wire}")
        out.setdefault(num, []).append(value)
    return out


def pb_json(data: bytes, depth: int = 0) -> Any:
    """Protobuf sans schéma -> objet JSON lisible pour les journaux : {"n° de champ": valeur}, sous-messages décodés,
    sinon texte, sinon hex ; champ répété -> liste. Données qui ne sont pas du protobuf : leur hex."""
    try:
        fields = pb_parse(data)
    except ValueError:
        return data.hex()
    out: Dict[str, Any] = {}
    for num, vals in fields.items():
        conv = [v if isinstance(v, int) else _pb_json_bytes(v, depth) for v in vals]
        out[str(num)] = conv[0] if len(conv) == 1 else conv
    return out


def _pb_json_bytes(v: bytes, depth: int) -> Any:
    if v and depth < 8:
        try:
            pb_parse(v)
            return pb_json(v, depth + 1)
        except ValueError:
            pass
    try:
        text = v.decode("utf-8")
        if text.isprintable():
            return text
    except UnicodeDecodeError:
        pass
    return v.hex()


def activity_rewards_payload(activity_id: int, reward_id: int = 1, lang: str = "en") -> bytes:
    """Corps chiffré de GetActivityRewards (octet pour octet celui du client du jeu)."""
    plain = (_pb_bytes(1, _pb_varint(int(activity_id))) + _pb_bytes(2, lang.encode())
             + _pb_bytes(3, _pb_uint(1, int(activity_id)) + _pb_uint(2, int(reward_id))))
    return encrypt_aes(plain)


def parse_activity_rewards(content: bytes) -> Dict[str, Any]:
    """Réponse de GetActivityRewards -> {items: [{id, count, duration_s}], activity, reward, state, condition}."""
    root = pb_parse(content)
    items = []
    for block in root.get(1, []):
        if isinstance(block, bytes):
            for raw in pb_parse(block).get(1, []):
                if isinstance(raw, bytes):
                    it = pb_parse(raw)
                    items.append({"id": (it.get(1) or [0])[0], "count": (it.get(2) or [0])[0],
                                  "duration_s": (it.get(3) or it.get(6) or [0])[0]})
    status: Dict[str, Any] = {}
    for block in root.get(2, []):
        if isinstance(block, bytes):
            st = pb_parse(block)
            cond = (st.get(4) or [b""])[0]
            status = {"activity": (st.get(1) or [None])[0], "reward": (st.get(2) or [None])[0],
                      "state": (st.get(3) or [None])[0],
                      "condition": cond.decode("utf-8", "replace") if isinstance(cond, bytes) else str(cond)}
    return {"items": items, **status}


def _session_uri(session: Dict[str, Any]) -> Tuple[str, str]:
    """(URL du serveur du jeu, token) d'une session de MajorLogin. Lève GameApiError sans token."""
    token = session.get("token")
    if not token:
        raise GameApiError("session sans token")
    _, region = token_identity(token, session.get("account_id"), session.get("region"))
    base = session.get("server_url")
    return (base.rstrip("/") + "/" if base else server_url(region)), token


# ActivityTrigger : envoyé par le client une fois dans le lobby (relevé du 16/10, fichier « dcod » : compte
# neuf, ActivityTrigger event_type 34 ~12 s après MajorLogin, puis GetActivityRewards 5962201 accepté). Sans lui,
# le serveur ne compte pas la condition « ล็อกอิน 1/1 วัน » (ConditionType_ANYDAYLOGIN) et répond
# BR_ACTIVITY_NO_REWARDS_AVAILABLE. Corps : {1: event_type, 4: optional_download_id vide} -> 08 22 22 00.
def activity_trigger_payload(event_type: int) -> bytes:
    """Corps chiffré d'ActivityTrigger (octet pour octet celui du client du jeu)."""
    return encrypt_aes(_pb_uint(1, int(event_type)) + _pb_bytes(4, b""))


async def activity_trigger(session: Dict[str, Any], event_type: int, retries: int = 1) -> bytes:
    """Envoie ActivityTrigger pour le compte de la session. Lève GameApiError (statut HTTP)."""
    uri, token = _session_uri(session)
    return await game_post(uri + "ActivityTrigger", activity_trigger_payload(event_type),
                           token, session.get("release_version") or VERSION, retries, client=True)


# ============================================================
# CheckHackBehavior  (anti-cheat, obligatoire depuis 1.132.12)
# ============================================================
# Relevé du vrai client 1.132.13 (22/10 21:57:29, compte 15580682741 ; avant : ss #116 du 18/10, 1.132.12).
# CSCheckHackBehaviorReq { 1: MatchClientInfo { tpsdk_str, start_time, file_exception, … } }

# tpsdk_str envoyé tel quel, casse comprise (majuscules puis « ff…cacfa16d » en minuscules chez le vrai client) :
# la fin cacfa16d est la même chez le vrai client les 20/10 et 22/10. Avant : tout en majuscules, octets 2-5
# remplacés par l'heure et 60-63 par un MD5, ce que le client ne fait pas.
_CHB_TPSDK = (
    b"080780B0A0AEF9E4"
    b"0201000000000000"
    b"0006000100050000"
    b"2B7C43730F000000"
    b"4676251400000000"
    b"0000000000000000"
    b"00000000000000ff"
    b"00000000cacfa16d"
)

_CHB_FILE_EXC = bytes.fromhex(
    "73585d511403084a0259570001030754055e5509010c0004"
    "070c00030f0f050d040104520053015d15010949705c4140"
    "4e1a081a01111604034d04517c7a055f60446f7e7b664e44"
    "7a605e7171037709617c00717b0d1b04497b5c6656745b7b"
    "4a7761727657557374415d7e595a575b5055644505155657"
    "5b411e627c1a7548460144626766410444465d4c5c4d621e"
    "4b794c400b6179785340671e470c0a1109054c7f6c426262"
    "7e6377135b5c6901715f6b1f5f046e554a5376797e7c0914"
    "0a444207681a5e62631b6d0b7c456a52465e43785f4e1976"
    "1d5f4046740c12064b197e4e547e441a40505c785c624447"
    "4b585703010d634a084459710816084d4175647965750b57"
    "5c0161455d707c454a7e525a6866797f755b630d1b040d4d"
    "487b18660e5a760e51466b656d55746c6c1b4e0c50695e7f"
    "645c690b130b497d1a005064610972461307530559620253"
    "4d1d5f0b721e771a63070f1b024c5e4c7250467e6e730967"
    "690d476468770164465b19434202727474091400084a417f"
    "031e505846795574445b6d6147434405004a760545517a42"
    "700c17024e574043517d535f5a7545504d5b1b6c725d4152"
    "7e6645170f64624208"
)

_CHB_LIB_RESULT = b"~W[P"
_CHB_NATIVE_RESULT = bytes.fromhex("10767a0c00607b1111")


def _chb_tpsdk_str() -> bytes:
    return _CHB_TPSDK


def _chb_body(client_version: str) -> bytes:
    inner = (
        _pb_bytes(1, _chb_tpsdk_str())
        + _pb_uint(2, 4)
        + _pb_bytes(3, _CHB_FILE_EXC)
        + _pb_bytes(4, _CHB_LIB_RESULT)
        + _pb_uint(6, 12)
        + _pb_bytes(7, _CHB_NATIVE_RESULT)
        + _pb_bytes(8, client_version.encode("ascii"))
        + _pb_uint(9, 3)
        + _pb_uint(10, 1)
    )
    return _pb_bytes(1, inner)


async def check_hack_behavior(session: Dict[str, Any], retries: int = 1) -> bool:
    """CheckHackBehavior (anti-cheat obligatoire 1.132.12). True = 200, False = erreur."""
    try:
        uri, token = _session_uri(session)
        cv = session.get("client_version") or "1.132.13"
        body = encrypt_aes(_chb_body(cv))
        await game_post(uri + "CheckHackBehavior", body, token,
                        session.get("release_version") or VERSION, retries, client=True)
        return True
    except Exception:
        return False


# État des activités du compte : réponse de LoginGetSplash, champ 3 (CSGetActivityInfoRes) = {1: ActivityInfo…},
# ActivityInfo = {1: id, 2: progression, 3: état (EActivity/State)}. Une activité sans progression n'y figure pas.
# Relevé decoded_traffic.jsonl : compte neuf (18760684721, 18/10 23:32) -> 5962201 absente au login puis réclamée
# 20 s plus tard ; comptes déjà connectés un autre jour -> {5962201, data 1, état 1} (condition remplie, à réclamer).
ACTIVITY_STATE_RECEIVED, ACTIVITY_STATE_FINISHED, ACTIVITY_STATE_AWARDED = 0, 1, 2
ACTIVITY_STATE_NAMES = {0: "RECEIVED", 1: "FINISHED", 2: "AWARDED", 3: "UNRECEIVED"}
SPLASH_BODY = _pb_bytes(1, b"en") + _pb_uint(2, 2) + _pb_uint(3, 1)      # 0a02656e 1002 1801, celui du client


def parse_activity_states(content: bytes) -> Dict[int, Dict[str, int]]:
    """Réponse de LoginGetSplash -> {activité: {"data": progression, "state": état}}. Lève ValueError."""
    out: Dict[int, Dict[str, int]] = {}
    for block in pb_parse(content).get(3, []):
        if isinstance(block, bytes):
            for raw in pb_parse(block).get(1, []):
                if isinstance(raw, bytes):
                    info = pb_parse(raw)
                    out[(info.get(1) or [0])[0]] = {"data": (info.get(2) or [0])[0], "state": (info.get(3) or [0])[0]}
    return out


async def activity_states(session: Dict[str, Any], retries: int = 1) -> Dict[int, Dict[str, int]]:
    """État des activités du compte (LoginGetSplash, comme le client au login). Lève GameApiError."""
    uri, token = _session_uri(session)
    content = await game_post(uri + "LoginGetSplash", encrypt_aes(SPLASH_BODY), token,
                              session.get("release_version") or VERSION, retries, client=True)
    try:
        return parse_activity_states(content)
    except ValueError as e:
        raise GameApiError(f"LoginGetSplash : réponse illisible ({e}) {_preview(content)}")


# Requêtes du lobby que le client envoie entre GetLoginData et ActivityTrigger, dans son ordre (relevé
# decoded_traffic.jsonl du 18/10 23:32, compte neuf 18760684721 : « ล็อกอิน 0/1 วัน » au login, 5962201 réclamée
# ensuite ; même suite le 17/10 11:06). Corps en clair octet pour octet ceux du client ; LoginGetDesc porte le pays
# du compte. Seulement des requêtes ordinaires du lobby (pas CheckHackBehavior ni les SDK de sécurité).
def lobby_login_bodies(country: str = "TH") -> List[Tuple[str, bytes]]:
    country = (country or "TH").upper()[:2]
    return [
        ("LoginGetDesc", _pb_bytes(1, b"en") + _pb_uint(2, 1) + _pb_bytes(3, country.encode()) + _pb_uint(4, 1)),
        ("LoginGetSplash", SPLASH_BODY),
        ("LoginGetAccountInfo", _pb_bytes(1, b"en") + _pb_uint(2, 1) + _pb_uint(3, 1)),
        ("LoginGetProfile", b""),
        ("GetAttendance", b""),
        # GetBackpack is_login (10011a02656e2001) : pas envoyé, « SignError1 » sans le champ 94 signé du vrai client
    ]


async def lobby_login_calls(session: Dict[str, Any], retries: int = 1
                            ) -> Tuple[List[Tuple[str, Optional[str]]], Optional[Dict[int, Dict[str, int]]]]:
    """Envoie les requêtes du lobby (lobby_login_bodies) dans l'ordre du client.
    -> ([(endpoint, erreur ou None)], états des activités lus dans LoginGetSplash ou None)."""
    uri, token = _session_uri(session)
    _, region = token_identity(token, session.get("account_id"), session.get("region"))
    out: List[Tuple[str, Optional[str]]] = []
    states: Optional[Dict[int, Dict[str, int]]] = None
    for endpoint, body in lobby_login_bodies(region or "TH"):
        try:
            content = await game_post(uri + endpoint, encrypt_aes(body), token,
                                      session.get("release_version") or VERSION, retries, client=True)
            if endpoint == "LoginGetSplash":
                try:
                    states = parse_activity_states(content)
                except ValueError:
                    pass
            out.append((endpoint, None))
        except GameApiError as e:
            out.append((endpoint, str(e)[:120]))
    return out, states


# Requêtes du lobby liées aux parties et au classement, dans l'ordre du vrai client et avec SES corps, octet pour
# octet (capture du 23/10 14:33, création de compte puis premier lobby : journal « ssss », 107 requêtes vers
# clientbp en 14 s ; le bot n'en envoyait que 7). Celles-ci décrivent au serveur un joueur qui a ouvert son lobby :
# file de parties, classement BR et CS, progression de nouveau joueur, paliers de niveau. Elles sont envoyées une
# fois par session, avant la première recherche de partie (voir LOBBY_PREMATCH_CALLS).
# Un corps vide est bien ce qu'envoie le client pour ces appels-là. Les requêtes qui exigent le champ 94 signé du
# vrai client (GetBackpack is_login…) ne sont pas reprises : elles répondent « SignError1 ».
MATCH_LOBBY_BODIES: List[Tuple[str, bytes]] = [
    ("GetAccountFreshInfo", b""),
    ("GetLevelRewardsConfig", b""),
    ("GetFreshDesc", b""),
    ("GetAPIMatchPool", bytes.fromhex("0a02656e")),             # 1 language = "en"
    ("GetRankingTaskList", b""),
    ("GetGuideOfNewPlayer", b""),
    ("UpdateGuideOfNewPlayer", bytes.fromhex("0a010c")),        # 1 update_guides = [12]
    # Puis exactement la suite que le vrai client envoie en OUVRANT SON ÉCRAN DE RECHERCHE, dans son ordre
    # (relevé du 23/10 15:57:59 → 15:58:06, journal « ssss ») : c'est le dernier échange avant le StartMatch.
    ("GetMatchmakingBlacklist", b""),
    ("GetPlayerHippoRankingInfo", b""),
    ("GetModeStatsConfig", b""),
    ("InitPlayerCSRankingInfoEx", bytes.fromhex("0801")),       # 1 need_next_ranking_info = true
    ("GetBRRankingInfoEx", bytes.fromhex("0801")),
    ("GetPlayerRankingInfoEx", bytes.fromhex("1001")),          # 2 need_next_ranking_info = true
    ("GetNewPlayerGoal", b""),
    ("GetJSSysRedDotInfo", b""),
    ("GetSparkInfo", b""),
    ("GetOccupationInfo", b""),
    ("GetPlayerDailyRankingSummary", b""),
    ("GetTeamUpBonusDesc", b""),
    # GetItemLimitedInGame (1 item_id) et ClaimFreshActivityRewards (2 identifiant d'activité) ne sont pas repris :
    # les identifiants relevés appartiennent au compte du vrai client, pas au nôtre.
]


# Requêtes du vrai client PENDANT une partie BR, les mêmes dans les 2 parties relevées le 24/10 (TH 16:38 et IND 16:06,
# journal du proxy, corps déchiffrés) : GetQuickMsgSettings ~3 s après le « match trouvé »,
# GetAccountExternalIconInfoByAccountIDs {1: [son ID]} après le saut (~45 s), puis À SA MORT UpdateGuideOfNewPlayer
# {2: [187]} et GetAllAchievementDesc — 1 s AVANT que la passerelle n'envoie l'EXP —, GetMatchmakingBlacklist ~3 s après.
MATCH_START_BODIES: List[Tuple[str, bytes]] = [("GetQuickMsgSettings", b"")]
MATCH_END_BODIES: List[Tuple[str, bytes]] = [
    ("UpdateGuideOfNewPlayer", bytes.fromhex("1202bb01")),     # 2 update_ingame_guides = [187]
    ("GetAllAchievementDesc", b""),
]
MATCH_AFTER_BODIES: List[Tuple[str, bytes]] = [("GetMatchmakingBlacklist", b"")]


def match_icon_body(account_id) -> bytes:
    """GetAccountExternalIconInfoByAccountIDs du vrai client en partie : {1: [son propre ID]} (liste compacte)."""
    v, n = bytearray(), int(account_id)
    while True:
        v.append((n & 0x7F) | (0x80 if n > 0x7F else 0))
        n >>= 7
        if not n:
            break
    return b"\x0a" + bytes([len(v)]) + bytes(v)


async def client_calls(session: Dict[str, Any], bodies: List[Tuple[str, bytes]],
                       retries: int = 1) -> List[Tuple[str, Optional[str]]]:
    """Envoie `bodies` dans l'ordre, comme le client. -> [(endpoint, erreur ou None)]. Une erreur n'interrompt pas la
    suite."""
    uri, token = _session_uri(session)
    out: List[Tuple[str, Optional[str]]] = []
    for endpoint, body in bodies:
        try:
            await game_post(uri + endpoint, encrypt_aes(body), token,
                            session.get("release_version") or VERSION, retries, client=True)
            out.append((endpoint, None))
        except GameApiError as e:
            out.append((endpoint, str(e)[:120]))
    return out


async def match_lobby_calls(session: Dict[str, Any], retries: int = 1) -> List[Tuple[str, Optional[str]]]:
    """Envoie MATCH_LOBBY_BODIES dans l'ordre du client. -> [(endpoint, erreur ou None)].
    Aucune de ces réponses ne sert au bot : seul compte le fait de les avoir envoyées, comme le vrai client. Une
    erreur n'interrompt pas la suite (un endpoint refusé ne doit pas empêcher le compte de jouer)."""
    uri, token = _session_uri(session)
    out: List[Tuple[str, Optional[str]]] = []
    for endpoint, body in MATCH_LOBBY_BODIES:
        try:
            await game_post(uri + endpoint, encrypt_aes(body), token,
                            session.get("release_version") or VERSION, retries, client=True)
            out.append((endpoint, None))
        except GameApiError as e:
            out.append((endpoint, str(e)[:120]))
    return out


# ============================================================
# LogEvent  (serveur « event » de la région : analytique du client)
# ============================================================
# Le client officiel envoie des événements d'analytique au serveur « event » de sa région. Capture Fiddler (compte
# SAC) : POST https://sacevent.ggblueshark.com/LogEvent, Content-Type application/x-www-form-urlencoded, corps = JSON
#   {"event_type":"EventTypeBRDeadInfo","event_payload":"{\"match_id\":2113623872047403008,\"quality\":1,\"map_id\":4,…}"}
# event_payload est lui-même une CHAÎNE JSON (champs échappés). En-têtes = ceux du vrai client (User-Agent UnityPlayer,
# X-Unity-Version 2018.4.12f1), plus X-GA-SV et Accept: */*.
# ⚠ Capture connue PARTIELLE : les champs de event_payload après map_id ne sont pas visibles, et X-GA-SV comme l'hôte
# viennent de cette seule capture. Le mécanisme est fidèle à ce qui est visible ; compléter sur une capture complète.

# X-GA-SV relevé dans la capture LogEvent (diffère du 1789535859 des requêtes clientbp de ffbot/protocol.py).
EVENT_XGA_SV = "1792762255"

# Hôte « event » par région = <region minuscule> + "event.ggblueshark.com". Confirmés : SAC -> sacevent (capture
# Fiddler), TH -> thevent (captures TLS du 21-23/10, comptes TH). Les autres régions suivent la même règle.
EVENT_HOSTS = {"SAC": "sacevent.ggblueshark.com", "TH": "thevent.ggblueshark.com"}
EVENT_HOST_DEFAULT = "thevent.ggblueshark.com"


def event_host(region: str) -> str:
    """Hôte du serveur « event » pour une région (choix confirmé, sinon règle <region>event.ggblueshark.com)."""
    r = (region or "").strip().upper()
    if r in EVENT_HOSTS:
        return EVENT_HOSTS[r]
    return f"{r.lower()}event.ggblueshark.com" if r else EVENT_HOST_DEFAULT


def event_headers(host: str, token: str, release_version: str = VERSION) -> Dict[str, str]:
    """En-têtes de la requête LogEvent du vrai client (ordre et valeurs de la capture Fiddler)."""
    return {
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "Accept": "*/*",
        "Accept-Encoding": "deflate, gzip",
        "X-GA-SV": EVENT_XGA_SV,
        "Authorization": f"Bearer {token}",
        "X-GA": "v1 1",
        "ReleaseVersion": release_version or VERSION,
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Unity-Version": "2018.4.12f1",
        "Host": host,
    }


def log_event_body(event_type: str, payload: Any) -> bytes:
    """Corps de LogEvent : JSON compact {event_type, event_payload}, event_payload = JSON (chaîne) des détails.
    `payload` : dict (sérialisé en chaîne JSON) ou chaîne JSON déjà prête."""
    inner = payload if isinstance(payload, str) else json.dumps(payload, separators=(",", ":"))
    return json.dumps({"event_type": str(event_type), "event_payload": inner}, separators=(",", ":")).encode("utf-8")


# EventTypeBRDeadInfo : envoyé par le client à la mort du joueur en BR. Champs connus de la capture (tronquée après
# map_id, dans cet ordre) : match_id (5.1 du « match trouvé »), quality, map_id. Les champs suivants (« g… ») ne sont
# pas visibles ; `extra` permet de les ajouter une fois relevés, sans changer l'ordre des trois premiers.
def br_dead_info_payload(match_id: int, map_id: int, quality: int = 1, **extra: Any) -> Dict[str, Any]:
    """Détails (event_payload) d'un EventTypeBRDeadInfo. L'ordre des clés suit la capture."""
    payload: Dict[str, Any] = {"match_id": int(match_id), "quality": int(quality), "map_id": int(map_id)}
    payload.update(extra)
    return payload


async def log_event(session: Dict[str, Any], event_type: str, payload: Any) -> bool:
    """Envoie un LogEvent au serveur « event » de la région du compte, comme le vrai client. True = HTTP 200.
    Analytique : JAMAIS bloquant pour le reste (toute erreur est avalée et renvoie False)."""
    try:
        token = session.get("token")
        if not token:
            return False
        _, region = token_identity(token, session.get("account_id"), session.get("region"))
        host = event_host(region)
        headers = event_headers(host, token, session.get("release_version") or VERSION)
        body = log_event_body(event_type, payload)
        http = await _get_session()
        async with _slots:
            async with http.post(f"https://{host}/LogEvent", headers=headers, data=body) as response:
                await response.read()      # on lit toujours la réponse (keep-alive propre)
                return response.status == 200
    except Exception:
        return False


async def claim_activity_reward(session: Dict[str, Any], activity_id: int, reward_id: int = 1, lang: str = "en",
                                retries: int = 1) -> Dict[str, Any]:
    """Réclame une récompense d'activité pour le compte de la session (token, server_url, release_version de
    MajorLogin), comme le bouton « รับ » du jeu. Lève GameApiError (statut HTTP, réponse illisible)."""
    uri, token = _session_uri(session)
    content = await game_post(uri + "GetActivityRewards", activity_rewards_payload(activity_id, reward_id, lang),
                              token, session.get("release_version") or VERSION, retries, client=True)
    try:
        result = parse_activity_rewards(content)
    except ValueError as e:
        raise GameApiError(f"GetActivityRewards : réponse illisible ({e}) {_preview(content)}")
    result["raw"] = content[:200].hex()
    return result


# ============================================================
# PERSONNAGE ÉQUIPÉ (personnage + compétences, comme le guide du nouveau joueur)
# ============================================================
# Relevé du client officiel TH 1.132.13 (fichier « ssss », 25/10 20:11, compte neuf 15608136159), dans l'ordre :
#   GiveAccountNewbieRoles {1: newbie_preset_id = 3}         -> personnages du lot de départ n° 3
#   SelectPresetLoadout   {2: equip_skill {1: personnage, 2: emplacements [0..3], 3: compétences, 4: sources [0…]},
#                          6: update_preset_loadout {1: {1: entrée 1, 2: personnage, 3: [{1: emplacement,
#                          2: compétence}…], 6: "PRESET 1"}}, 11: build_id = 1}
#        réponse {1: is_success, 3: {1: AvatarProfile {1: personnage, 3: peau, 4: vêtements…, 5: compétences,
#                 6: is_selected}}}
#   UnlockProfile          {1: personnage, 2: unlock_level = 1}  (101000023 puis 102000037)
#   GetAccountFreshStatsInfo (corps vide) -> {1: claim_newbie_preset_id} : 3 après la réclamation, absent avant.
# Corps ci-dessous octet pour octet ceux du client (vérifié : SelectPresetLoadout = 78 octets en clair identiques).
NEWBIE_PRESET_ID = 3
NEWBIE_AVATAR_ID = 102000007
NEWBIE_SKILLS = (706, 5506, 4806, 4106)          # emplacement 0 = compétence du personnage, 1-3 = lot de départ 3
NEWBIE_UNLOCK_AVATARS = (101000023, 102000037)


def _pb_packed(num: int, values) -> bytes:
    return _pb_bytes(num, b"".join(_pb_varint(int(v)) for v in values))


def _skill_slot(slot: int, skill: int) -> bytes:
    # emplacement 0 / compétence 0 : champ absent, comme le client (proto3)
    return (_pb_uint(1, slot) if slot else b"") + (_pb_uint(2, skill) if skill else b"")


def select_preset_loadout_body(avatar_id: int, skills, equip: bool = True) -> bytes:
    """Corps en clair de SelectPresetLoadout : personnage `avatar_id` avec `skills` (emplacements 0, 1, 2…).
    `equip` False : mise à jour du préréglage seule (1re requête du client, compétences pas encore reçues)."""
    skills = [int(s) for s in skills]
    schema = (_pb_uint(1, 1) + _pb_uint(2, avatar_id)
              + b"".join(_pb_bytes(3, _skill_slot(i, s if equip or i == 0 else 0)) for i, s in enumerate(skills))
              + _pb_bytes(6, b"PRESET 1"))
    body = b""
    if equip:
        body += _pb_bytes(2, _pb_uint(1, avatar_id) + _pb_packed(2, range(len(skills))) + _pb_packed(3, skills)
                          + _pb_packed(4, [0] * len(skills)))
    return body + _pb_bytes(6, _pb_bytes(1, schema)) + _pb_uint(11, 1)


def parse_select_preset_loadout(content: bytes) -> Dict[str, Any]:
    """Réponse de SelectPresetLoadout -> {ok, avatar, clothes, skills}. Lève ValueError."""
    root = pb_parse(content)
    out: Dict[str, Any] = {"ok": bool((root.get(1) or [0])[0]), "avatar": None, "clothes": [], "skills": []}
    for block in root.get(3, []):
        for raw in pb_parse(block).get(1, []) if isinstance(block, bytes) else []:
            prof = pb_parse(raw)
            out["avatar"] = (prof.get(1) or [None])[0]
            out["clothes"] = [v for v in prof.get(4, []) if isinstance(v, int)]
            for c in prof.get(4, []):
                if isinstance(c, bytes):                      # vêtements en liste groupée
                    i = 0
                    while i < len(c):
                        v, i = _read_uvarint(c, i)
                        out["clothes"].append(v)
            for raw_slot in prof.get(5, []):
                slot = pb_parse(raw_slot)
                out["skills"].append(((slot.get(1) or [0])[0], (slot.get(2) or [0])[0]))
    return out


def _read_uvarint(data: bytes, i: int) -> Tuple[int, int]:
    v = s = 0
    while True:
        b = data[i]
        i += 1
        v |= (b & 0x7F) << s
        s += 7
        if b < 0x80:
            return v, i


async def _client_call(session: Dict[str, Any], endpoint: str, body: bytes, retries: int = 1) -> bytes:
    uri, token = _session_uri(session)
    return await game_post(uri + endpoint, encrypt_aes(body), token, session.get("release_version") or VERSION,
                           retries, client=True)


async def newbie_preset_claimed(session: Dict[str, Any]) -> int:
    """Lot de départ déjà réclamé par le compte (GetAccountFreshStatsInfo, champ 1), 0 sinon. Lève GameApiError."""
    content = await _client_call(session, "GetAccountFreshStatsInfo", b"")
    try:
        return int((pb_parse(content).get(1) or [0])[0] or 0)
    except ValueError as e:
        raise GameApiError(f"GetAccountFreshStatsInfo : réponse illisible ({e}) {_preview(content)}")


async def equip_newbie_character(session: Dict[str, Any], preset_id: int = NEWBIE_PRESET_ID,
                                 avatar_id: int = NEWBIE_AVATAR_ID, skills=NEWBIE_SKILLS,
                                 unlock=NEWBIE_UNLOCK_AVATARS, force: bool = False) -> Dict[str, Any]:
    """Personnage équipé comme le guide du nouveau joueur du client officiel (voir plus haut) : lot de départ
    `preset_id` réclamé s'il ne l'est pas, puis personnage + compétences équipés, puis profils débloqués. Compte qui a
    déjà réclamé un lot (déjà passé par le guide, personnage peut-être choisi par son joueur) : rien n'est changé, sauf
    `force`. Retourne {claimed (lot avant), skipped, given, ok, avatar, clothes, skills, unlocked, errors}. Lève
    GameApiError si GetAccountFreshStatsInfo (sans `force`) ou SelectPresetLoadout échoue."""
    result: Dict[str, Any] = {"errors": [], "skipped": False}
    try:
        result["claimed"] = await newbie_preset_claimed(session)
    except GameApiError as e:
        if not force:
            raise
        result["claimed"], result["errors"] = None, [str(e)]
    if result["claimed"] and not force:
        result["skipped"] = True
        return result
    if not result["claimed"]:
        await _client_call(session, "SelectPresetLoadout", select_preset_loadout_body(avatar_id, skills, equip=False))
        await _client_call(session, "GiveAccountNewbieRoles", _pb_uint(1, preset_id))
        result["given"] = preset_id
    content = await _client_call(session, "SelectPresetLoadout", select_preset_loadout_body(avatar_id, skills))
    try:
        result.update(parse_select_preset_loadout(content))
    except ValueError as e:
        raise GameApiError(f"SelectPresetLoadout : réponse illisible ({e}) {_preview(content)}")
    result["unlocked"] = []
    for avatar in unlock:
        try:
            await _client_call(session, "UnlockProfile", _pb_uint(1, avatar) + _pb_uint(2, 1))
            result["unlocked"].append(avatar)
        except GameApiError as e:
            result["errors"].append(str(e))
    return result


# ============================================================
# Guilde (clan)
# ============================================================
# Demande d'entrée du vrai client TH 1.132.13 (fichier « ssss », 26/10 01:03:39, guilde 3068420572) :
# RequestJoinClan {1: id de la guilde, 2: 1} (08dcc391b70b1001 en clair), puis GetClanApplicationsAndInvitations
# {1: id} 0,7 s plus tard. Le chef de la guilde accepte ensuite la demande (ou elle entre d'office si la guilde
# est ouverte).
def join_clan_body(clan_id: int) -> bytes:
    return _pb_uint(1, int(clan_id)) + _pb_uint(2, 1)


async def request_join_clan(session: Dict[str, Any], clan_id: int, retries: int = 1) -> Dict[str, Any]:
    """Demande d'entrée dans la guilde `clan_id` pour le compte de la session, comme le client. Retourne
    {fields: champs de la réponse (pb_parse), applications: erreur de GetClanApplicationsAndInvitations ou None}.
    Lève GameApiError si RequestJoinClan est refusé (statut HTTP)."""
    content = await _client_call(session, "RequestJoinClan", join_clan_body(clan_id), retries)
    try:
        fields = {k: [v if isinstance(v, int) else _preview(v, 40) for v in vals] for k, vals in pb_parse(content).items()}
    except Exception:
        fields = {"raw": _preview(content, 60)}
    out = {"fields": fields, "applications": None}
    try:
        await _client_call(session, "GetClanApplicationsAndInvitations", _pb_uint(1, int(clan_id)), 0)
    except GameApiError as e:
        out["applications"] = str(e)[:120]
    return out


# ============================================================
# Score d'honneur (GetCreditScoreChangeInfo) et page de la guilde (GetClanMainPageInfo)
# ============================================================
# Requêtes du vrai client (dossiers GetCreditScoreChangeInfo / GetClanMainPageInfo de 1-decode-trafiq-udp, 26/10) :
#   GetCreditScoreChangeInfo : corps vide (1a725b2c… = un bloc de bourrage seul), réponse pour le compte du token :
#     {1: account_id, 2: changements {1: date, 2: motif, 3: variation (int32), 4: score après, 5: exempté}} ;
#     aucun changement = score de départ (CREDIT_SCORE_DEFAULT).
#   GetClanMainPageInfo : {1: id de la guilde, 2: 1 (avec les membres)} ; réponse {1: guilde, 2: membres,
#     3: journal, 4: prochaine remise à zéro de la semaine}.
CREDIT_SCORE_DEFAULT = 100
CREDIT_REASONS = {10201: "In-match behaviour penalty"}
CLAN_ROLES = {1: "member", 2: "officer", 3: "leader"}


def _first(fields: Dict[int, list], num: int, default: Any = 0) -> Any:
    return (fields.get(num) or [default])[0]


def _text(fields: Dict[int, list], num: int) -> str:
    v = _first(fields, num, b"")
    return v.decode("utf-8", "replace") if isinstance(v, bytes) else str(v or "")


def _int32(v: int) -> int:
    """Varint d'un int32 négatif (encodé sur 64 bits) -> entier signé."""
    return v - (1 << 64) if v >= 1 << 63 else v


def parse_credit_score(content: bytes) -> Dict[str, Any]:
    root = pb_parse(content)
    changes = []
    for raw in root.get(2, []):
        if isinstance(raw, bytes):
            f = pb_parse(raw)
            changes.append({"time": _first(f, 1), "reason": _first(f, 2), "delta": _int32(_first(f, 3)),
                            "after": _first(f, 4), "exempt": bool(_first(f, 5))})
    changes.sort(key=lambda c: c["time"], reverse=True)
    return {"account_id": str(_first(root, 1) or ""),
            "score": changes[0]["after"] if changes else CREDIT_SCORE_DEFAULT, "changes": changes}


async def credit_score(session: Dict[str, Any], retries: int = 1) -> Dict[str, Any]:
    """Score d'honneur du compte de la session : {account_id, score, changes (le plus récent d'abord)}.
    Lève GameApiError si la requête échoue ou si la réponse est illisible."""
    content = await _client_call(session, "GetCreditScoreChangeInfo", b"", retries)
    try:
        return parse_credit_score(content)
    except ValueError as e:
        raise GameApiError(f"GetCreditScoreChangeInfo : réponse illisible ({e}) {_preview(content)}")


async def match_stats_history(session: Dict[str, Any], retries: int = 1) -> List[Dict[str, Any]]:
    """Derniers matchs du compte de la session (GetMatchStatsHistory, corps {1: account_id}), décodés par
    match_history.decode_history (le plus récent d'abord). Lève GameApiError si la réponse est illisible."""
    from .match_history import decode_history
    account_id, _ = token_identity(session.get("token") or "", session.get("account_id"), session.get("region"))
    if not account_id:
        raise GameApiError("GetMatchStatsHistory : account_id inconnu")
    content = await _client_call(session, "GetMatchStatsHistory", _pb_uint(1, int(account_id)), retries)
    try:
        return decode_history(content)
    except Exception as e:
        raise GameApiError(f"GetMatchStatsHistory : réponse illisible ({e}) {_preview(content)}")


def parse_clan_page(content: bytes) -> Dict[str, Any]:
    root = pb_parse(content)
    c = pb_parse(_first(root, 1, b""))
    members = []
    for raw in root.get(2, []):
        if not isinstance(raw, bytes):
            continue
        f = pb_parse(raw)
        pl = pb_parse(_first(f, 1, b""))
        members.append({"id": str(_first(pl, 1) or ""), "nickname": _text(pl, 3), "level": _first(pl, 6),
                        "last_login": _first(pl, 24), "role": CLAN_ROLES.get(_first(f, 4), "member"),
                        "joined_at": _first(f, 5), "weekly_glory": _first(f, 10), "total_glory": _first(f, 11)})
    members.sort(key=lambda m: (m["weekly_glory"], m["total_glory"]), reverse=True)
    return {"clan_id": str(_first(c, 1) or ""), "name": _text(c, 2), "created_at": _first(c, 3),
            "leader_id": str(_first(c, 4) or ""), "level": _first(c, 38) or _first(c, 5),
            "max_members": _first(c, 6), "member_count": _first(c, 7), "slogan": _text(c, 12),
            "region": _text(c, 13), "weekly_glory": _first(c, 36), "total_glory": _first(c, 37),
            "avatar_id": _first(c, 41), "week_ends_at": _first(root, 4), "members": members}


async def clan_main_page(session: Dict[str, Any], clan_id: int, retries: int = 1) -> Dict[str, Any]:
    """Page de la guilde `clan_id` vue par le compte de la session (gloire, membres). Lève GameApiError."""
    content = await _client_call(session, "GetClanMainPageInfo", _pb_uint(1, int(clan_id)) + _pb_uint(2, 1), retries)
    try:
        info = parse_clan_page(content)
    except ValueError as e:
        raise GameApiError(f"GetClanMainPageInfo : réponse illisible ({e}) {_preview(content)}")
    if not info["clan_id"]:
        raise GameApiError(f"GetClanMainPageInfo : guilde {clan_id} absente de la réponse {_preview(content)}")
    return info


# ============================================================
# Récompenses d'activité de la guilde et magasin de la guilde
# ============================================================
# Captures du client officiel du 27/10 (16:01-16:17, guilde 3106326252) :
#   ClaimClanActAward (corps vide) : paliers atteints de l'activité de la GUILDE (500 / 1500 / 2000 : 15 + 20 + 30
#     jetons) -> CSClaimClanActAwardRes {1: ExchangeChangeData {1: transaction, 2: {1: objet, 2: nombre}, 7: …}} ;
#     65 jetons (814000003) ce jour-là ;
#   ClaimPersonalActRewards {1: id de la guilde} : paliers atteints de l'activité PERSONNELLE de la semaine (150 / 450 /
#     900 / 1500 : 60 + 65 + 70 + 75 jetons) -> {1: ExchangeChangeData} ; 195 jetons ;
#   ExchangeStorePurchase (CSExchangeStorePurchaseReq) {1: store_id 100, 2: commodity_id, 4: cnt, 5: currency_id
#     (814000003, jeton de guilde), 6: currency_price, 8: entry_from 1} -> {1: ExchangeChangeData {2: objet reçu,
#     3: monnaie dépensée {1: 814000003, 2: prix}}, 2: purchase_times} ; article 10500016 à 200 jetons (limite 1 par
#     semaine) -> objet 851000004.
# Rien à réclamer / limite atteinte / jetons insuffisants : le serveur refuse (GameApiError).
GUILD_TOKEN_ITEM = 814000003
GUILD_STORE_ID = 100


def _exchange_items(data: bytes, num: int = 2) -> List[Tuple[int, int]]:
    """Objets (objet, nombre) du champ `num` d'un ExchangeChangeData (2 : reçus, 3 : dépensés)."""
    out = []
    for raw in pb_parse(data).get(num, []):
        if isinstance(raw, bytes):
            f = pb_parse(raw)
            out.append((_first(f, 1), _first(f, 2)))
    return out


def _guild_tokens(content: bytes) -> int:
    """Jetons de guilde reçus d'après une réponse de réclamation ({1: ExchangeChangeData}), 0 si illisible."""
    try:
        data = _first(pb_parse(content), 1, b"")
        return sum(n for item, n in _exchange_items(data) if item == GUILD_TOKEN_ITEM) if data else 0
    except ValueError:
        return 0


# journal(endpoint, corps en clair, réponse en clair ou None, erreur ou None) : appelé après chaque appel de la guilde
GuildJournal = Callable[[str, bytes, Optional[bytes], Optional[BaseException]], None]


async def _guild_call(session: Dict[str, Any], endpoint: str, body: bytes, retries: int,
                      journal: Optional[GuildJournal]) -> bytes:
    """_client_call, avec la requête et la réponse (ou l'erreur) passées à `journal`."""
    try:
        content = await _client_call(session, endpoint, body, retries)
    except GameApiError as e:
        if journal is not None:
            journal(endpoint, body, None, e)
        raise
    if journal is not None:
        journal(endpoint, body, content, None)
    return content


async def claim_clan_act_award(session: Dict[str, Any], retries: int = 1,
                               journal: Optional[GuildJournal] = None) -> int:
    """Paliers de l'activité de la guilde réclamés ; jetons reçus. Lève GameApiError (rien à réclamer compris)."""
    return _guild_tokens(await _guild_call(session, "ClaimClanActAward", b"", retries, journal))


async def claim_personal_act_rewards(session: Dict[str, Any], clan_id: int, retries: int = 1,
                                     journal: Optional[GuildJournal] = None) -> int:
    """Paliers de l'activité personnelle de la semaine réclamés ; jetons reçus. Lève GameApiError."""
    return _guild_tokens(await _guild_call(session, "ClaimPersonalActRewards", _pb_uint(1, int(clan_id)), retries,
                                           journal))


async def guild_store_purchase(session: Dict[str, Any], commodity_id: int, price: int, cnt: int = 1,
                               retries: int = 0, journal: Optional[GuildJournal] = None) -> Dict[str, Any]:
    """Achat de `cnt` article(s) `commodity_id` du magasin de la guilde, payé en jetons (`price` chacun) comme le
    client. Retourne {items: [(objet, nombre)], spent, times}. Lève GameApiError (limite atteinte, jetons insuffisants)."""
    body = (_pb_uint(1, GUILD_STORE_ID) + _pb_uint(2, int(commodity_id)) + _pb_uint(4, cnt)
            + _pb_uint(5, GUILD_TOKEN_ITEM) + _pb_uint(6, int(price) * cnt) + _pb_uint(8, 1))
    content = await _guild_call(session, "ExchangeStorePurchase", body, retries, journal)
    try:
        root = pb_parse(content)
        data = _first(root, 1, b"")
        return {"items": _exchange_items(data) if data else [],
                "spent": sum(n for item, n in _exchange_items(data, 3) if item == GUILD_TOKEN_ITEM) if data else 0,
                "times": _first(root, 2)}
    except ValueError as e:
        raise GameApiError(f"ExchangeStorePurchase : réponse illisible ({e}) {_preview(content)}")


# ============================================================
# Missions du Pass (Elite Pass) : défis de la semaine et récompense quotidienne
# ============================================================
# Captures du client officiel (tdecoded_traffic.txt de 1-decode-trafiq-udp, 26/10 03:20-03:31) et classes du dump :
#   GetEPInfo (corps vide) -> CSGetEPInfoRes : 3 = challenges, ChallengeStatus {1: challenge_id, 2: statut
#     (EPTarget_Status : 0 en cours, 1 atteint = à réclamer, 2 réclamé), 8: progression {1: type, 2: fait, 3: but}} ;
#     26 = daily_process {1: challenge_num, 2: DailyProcessStatus {1: node_id, 2: statut (EPProcess_Status, mêmes
#     valeurs)}}.
#   EPClaimBadge {2: challenge_ids (varints groupés)} : le client réclame tous les défis atteints d'une semaine d'un
#     coup (semaine 1 : 101025-101028) ; réponse {1: objets ajoutés, 2: récompenses {1: type, 2: objet, 3: nombre}}.
#   GetDailyChallengeProcessRewards {1: node_id} (08 35 = palier 53) : récompense du palier quotidien atteint.
EP_REACHED = 1


def _packed(data: Any) -> List[int]:
    """Varints groupés (packed) d'un champ wire 2, ou varint seul."""
    if isinstance(data, int):
        return [data]
    out, i = [], 0
    while i < len(data):
        v, i = _read_uvarint(data, i)
        out.append(v)
    return out


def parse_ep_info(content: bytes) -> Dict[str, Any]:
    root = pb_parse(content)
    challenges = []
    for raw in root.get(3, []):
        if isinstance(raw, bytes):
            f = pb_parse(raw)
            prog = pb_parse(_first(f, 8, b""))
            challenges.append({"id": _first(f, 1), "status": _first(f, 2), "done": _first(prog, 2),
                               "goal": _first(prog, 3)})
    daily = []
    dp = pb_parse(_first(root, 26, b""))
    for raw in dp.get(2, []):
        if isinstance(raw, bytes):
            f = pb_parse(raw)
            daily.append({"node": _first(f, 1), "status": _first(f, 2)})
    return {"ep_id": _first(root, 4), "challenges": challenges, "daily": daily,
            "daily_done": _first(dp, 1)}


def _award_count(content: bytes) -> int:
    """Nombre de récompenses d'une réponse de réclamation (champ 2), 0 si illisible."""
    try:
        return len(pb_parse(content).get(2, []))
    except ValueError:
        return 0


async def ep_info(session: Dict[str, Any], retries: int = 1) -> Dict[str, Any]:
    content = await _client_call(session, "GetEPInfo", b"", retries)
    try:
        return parse_ep_info(content)
    except ValueError as e:
        raise GameApiError(f"GetEPInfo : réponse illisible ({e}) {_preview(content)}")


async def claim_ep_rewards(session: Dict[str, Any], retries: int = 1) -> Dict[str, Any]:
    """Réclame tout ce qui est atteint dans le Pass, comme le bouton « Claim all » du client, toutes semaines
    confondues, puis les paliers quotidiens atteints. Un lot refusé est repris défi par défi (un défi refusé
    n'empêche pas les autres). Retourne {challenges: ids réclamés, daily: paliers réclamés, awards: récompenses
    reçues, failed: [(id, erreur)], pending: défis encore en cours}. Lève GameApiError si GetEPInfo échoue."""
    info = await ep_info(session, retries)
    reached = [c["id"] for c in info["challenges"] if c["status"] == EP_REACHED]
    out: Dict[str, Any] = {"challenges": [], "daily": [], "awards": 0, "failed": [],
                           "pending": sum(1 for c in info["challenges"] if c["status"] == 0)}
    if reached:
        body = _pb_bytes(2, b"".join(_pb_varint(i) for i in reached))
        try:
            out["awards"] += _award_count(await _client_call(session, "EPClaimBadge", body, retries))
            out["challenges"] = reached
        except GameApiError:
            for cid in reached:
                try:
                    content = await _client_call(session, "EPClaimBadge", _pb_bytes(2, _pb_varint(cid)), 0)
                    out["awards"] += _award_count(content)
                    out["challenges"].append(cid)
                except GameApiError as e:
                    out["failed"].append((cid, str(e)[:120]))
    for d in info["daily"]:
        if d["status"] != EP_REACHED:
            continue
        try:
            content = await _client_call(session, "GetDailyChallengeProcessRewards", _pb_uint(1, d["node"]), retries)
            out["awards"] += max(1, _award_count(content))
            out["daily"].append(d["node"])
        except GameApiError as e:
            out["failed"].append((f"daily {d['node']}", str(e)[:120]))
    return out
