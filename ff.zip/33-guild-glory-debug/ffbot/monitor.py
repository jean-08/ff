# -*- coding: utf-8 -*-
"""
Santé du serveur, mesurée en continu pour un coût négligeable (un relevé par seconde).

- retard de la boucle asyncio : tout le serveur (parties UDP, relevés d'EXP, site) tourne sur un seul thread ;
  si ce retard monte, les réponses aux paquets des parties partent en retard, les relevés d'EXP dépassent leur
  délai et le site rame. C'est LA mesure à surveiller (et celle qu'utilise la protection anti-saturation) ;
- CPU du processus (en % d'un cœur : 100 % = boucle saturée) ;
- compteurs (paquets, relevés…) convertis en débits par seconde, et jauges (parties en cours…).

Historique : 5 min seconde par seconde, 1 h par tranches de 15 s (page « Serveur » de l'administration).
"""
import asyncio
import os
import platform
import sys
import time
from collections import deque
from typing import Any, Callable, Deque, Dict, List, Optional

_INTERVAL_S = 1.0
_FINE_POINTS = 300        # 5 min à 1 s
_COARSE_STEP = 15         # tranches de 15 s…
_COARSE_POINTS = 240      # … sur 1 h
LAG_WARN_MS = 100         # au-delà : chargé
LAG_CRIT_MS = 250         # au-delà : saturé
LAG_SPIKE_MS = 500        # une seconde avec plus de 500 ms de retard : dans le journal de diagnostic


def level_of(lag_ms: float) -> str:
    return "critical" if lag_ms > LAG_CRIT_MS else "warning" if lag_ms > LAG_WARN_MS else "ok"


class LoopMonitor:
    def __init__(self):
        self.started_at = time.time()
        self._counters: Dict[str, Callable[[], float]] = {}
        self._gauges: Dict[str, Callable[[], float]] = {}
        self._raw: Deque[Dict[str, float]] = deque(maxlen=_FINE_POINTS + 1)   # relevés bruts (compteurs cumulés)
        self._fine: Deque[Dict[str, float]] = deque(maxlen=_FINE_POINTS)       # points dérivés (débits, CPU %)
        self._coarse: Deque[Dict[str, float]] = deque(maxlen=_COARSE_POINTS)
        self._task: Optional[asyncio.Task] = None

    # ---------- sources ----------
    def add_counter(self, name: str, fn: Callable[[], float]):
        """Compteur cumulé : affiché en débit par seconde."""
        self._counters[name] = fn

    def add_gauge(self, name: str, fn: Callable[[], float]):
        """Valeur instantanée (parties en cours, navigateurs…)."""
        self._gauges[name] = fn

    # ---------- boucle de mesure ----------
    def start(self):
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="loop-monitor")

    async def stop(self):
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None

    async def _run(self):
        from ffbot import diag      # import tardif : diag n'est pas nécessaire aux autres utilisateurs du moniteur
        loop = asyncio.get_running_loop()
        spikes, logged_at = 0, 0.0
        while True:
            t = loop.time()
            await asyncio.sleep(_INTERVAL_S)
            lag = max(0.0, loop.time() - t - _INTERVAL_S) * 1000
            try:
                self._sample(lag)
            except Exception as e:  # pragma: no cover
                print(f"[monitor] relevé en échec : {e!r}")
            if lag > LAG_SPIKE_MS:
                # boucle bloquée : tout le serveur (passerelles, logins, site) a attendu. Une ligne toutes les 10 s
                # au plus, avec le nombre de pics depuis la précédente.
                spikes += 1
                if time.time() - logged_at >= 10:
                    logged_at = time.time()
                    diag.event("SYSTEM", "loop_lag", level="warning", code="LOOP_LAG", lag_ms=round(lag),
                               spikes=spikes, cpu=self._fine[-1]["cpu"] if self._fine else None)
                    spikes = 0

    def _read(self, sources: Dict[str, Callable[[], float]]) -> Dict[str, float]:
        out = {}
        for name, fn in sources.items():
            try:
                out[name] = float(fn() or 0)
            except Exception:
                out[name] = 0.0
        return out

    def _sample(self, lag: float):
        raw = {"t": time.time(), "mono": time.monotonic(), "cpu_s": time.process_time(), "lag": lag,
               **self._read(self._counters)}
        prev = self._raw[-1] if self._raw else None
        self._raw.append(raw)
        if prev is None:
            return
        dt = max(1e-6, raw["mono"] - prev["mono"])
        point = {"t": round(raw["t"], 1), "lag": round(lag, 1),
                 "cpu": round((raw["cpu_s"] - prev["cpu_s"]) / dt * 100, 1)}
        for name in self._counters:
            point[name] = round(max(0.0, raw[name] - prev[name]) / dt, 1)
        point.update(self._read(self._gauges))
        self._fine.append(point)
        if len(self._fine) % _COARSE_STEP == 0:
            self._coarse.append(self._aggregate(list(self._fine)[-_COARSE_STEP:]))

    @staticmethod
    def _aggregate(points: List[Dict[str, float]]) -> Dict[str, float]:
        out = {"t": points[-1]["t"], "lag_max": max(p["lag"] for p in points)}
        for key in points[-1]:
            if key != "t":
                out[key] = round(sum(p.get(key, 0) for p in points) / len(points), 1)
        return out

    # ---------- lecture ----------
    def recent_lag_ms(self, seconds: int = 10) -> float:
        pts = list(self._fine)[-seconds:]
        return sum(p["lag"] for p in pts) / len(pts) if pts else 0.0

    def snapshot(self, window: int = 10) -> Dict[str, Any]:
        """État actuel, moyenné sur les `window` dernières secondes."""
        pts = list(self._fine)[-window:]
        lag_avg = sum(p["lag"] for p in pts) / len(pts) if pts else 0.0
        last = pts[-1] if pts else {}
        rates = {name: round(sum(p.get(name, 0) for p in pts) / len(pts), 1) if pts else 0.0 for name in self._counters}
        return {
            "uptime": int(time.time() - self.started_at),
            "loop_lag_ms": {"avg": round(lag_avg, 1), "max": round(max((p["lag"] for p in pts), default=0.0), 1)},
            "cpu_percent": round(sum(p["cpu"] for p in pts) / len(pts), 1) if pts else None,
            "level": level_of(lag_avg),
            "overloaded": lag_avg > LAG_CRIT_MS,
            "rates": rates,
            "gauges": {name: last.get(name, 0) for name in self._gauges},
        }

    def history(self, span: str = "5m") -> List[Dict[str, float]]:
        return list(self._coarse if span == "1h" else self._fine)


def rss_mb() -> Optional[float]:
    """Mémoire utilisée par le processus (Mo), sans dépendance : /proc sous Linux, psapi sous Windows."""
    try:
        if sys.platform.startswith("linux"):
            with open("/proc/self/status", encoding="ascii") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        return round(int(line.split()[1]) / 1024, 1)
        elif sys.platform == "win32":
            import ctypes
            from ctypes import wintypes

            class _PMC(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                            ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                            ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
            pmc = _PMC()
            pmc.cb = ctypes.sizeof(_PMC)
            kernel32 = ctypes.WinDLL("kernel32")
            kernel32.GetCurrentProcess.restype = wintypes.HANDLE
            get_info = ctypes.WinDLL("psapi").GetProcessMemoryInfo
            get_info.argtypes = (wintypes.HANDLE, ctypes.POINTER(_PMC), wintypes.DWORD)
            get_info.restype = wintypes.BOOL
            if get_info(kernel32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb):
                return round(pmc.WorkingSetSize / 1048576, 1)
    except Exception:
        pass
    return None


_udp_stats_fn = None


def udp_system_stats() -> Optional[Dict[str, int]]:
    """Compteurs UDP IPv4 de toute la machine (Windows : GetUdpStatisticsEx2, compteurs 64 bits) : datagrammes reçus
    et envoyés, rejetés faute de tampon ou en erreur (in_errors), sans port destinataire (no_ports). None ailleurs."""
    global _udp_stats_fn
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        if _udp_stats_fn is None:
            from ctypes import wintypes

            class _UdpStats2(ctypes.Structure):     # MIB_UDPSTATS2 (défini une fois : argtypes y est lié)
                _fields_ = [("in_dgrams", ctypes.c_uint64), ("no_ports", wintypes.DWORD),
                            ("in_errors", wintypes.DWORD), ("out_dgrams", ctypes.c_uint64),
                            ("num_addrs", wintypes.DWORD)]
            fn = ctypes.WinDLL("iphlpapi").GetUdpStatisticsEx2
            fn.argtypes = [ctypes.POINTER(_UdpStats2), wintypes.ULONG]
            fn.restype = wintypes.ULONG
            _udp_stats_fn = (fn, _UdpStats2)
        fn, struct_cls = _udp_stats_fn
        st = struct_cls()
        if fn(ctypes.byref(st), 2) == 0:          # AF_INET
            return {"in": int(st.in_dgrams), "out": int(st.out_dgrams), "in_errors": int(st.in_errors),
                    "no_ports": int(st.no_ports)}
    except Exception:
        pass
    return None


def system_info() -> Dict[str, Any]:
    return {"platform": platform.platform(terse=True), "python": platform.python_version(),
            "cpu_count": os.cpu_count(), "pid": os.getpid(), "event_loop": type(asyncio.get_event_loop()).__name__}


monitor = LoopMonitor()
