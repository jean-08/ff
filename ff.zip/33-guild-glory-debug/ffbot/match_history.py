# -*- coding: utf-8 -*-
"""
Décodeur de la réponse GetMatchStatsHistory (historique des matchs).
La réponse est du gzip qui contient un protobuf (voir match_history.proto).
Décodage manuel : aucune dépendance, les champs inconnus sont ignorés.

Usage CLI :  python match_history.py reponse.hex   -> écrit match_history.json
"""

import json
import struct
import sys
import zlib
from typing import Any, Dict, List, Optional

# Cartes connues (Clash Squad : champ 31 du détail, BR : champ 41)
CS_MAPS = {7: "Solara", 8: "Bermuda"}
BR_MAPS = {1: "Bermuda", 7: "Kalahari"}


def _varint(buf: bytes, i: int):
    result = shift = 0
    while True:
        b = buf[i]
        i += 1
        result |= (b & 0x7F) << shift
        shift += 7
        if b < 0x80:
            return result, i


def _parse(buf: bytes) -> Dict[int, list]:
    """Retourne {numéro_de_champ: [valeurs...]} pour un message protobuf."""
    out: Dict[int, list] = {}
    i = 0
    while i < len(buf):
        key, i = _varint(buf, i)
        field, wire = key >> 3, key & 7
        if wire == 0:
            val, i = _varint(buf, i)
        elif wire == 1:
            val = struct.unpack("<d", buf[i:i + 8])[0]
            i += 8
        elif wire == 5:
            val = struct.unpack("<f", buf[i:i + 4])[0]
            i += 4
        elif wire == 2:
            n, i = _varint(buf, i)
            val = buf[i:i + n]
            i += n
        else:
            raise ValueError(f"wire type {wire} non géré")
        out.setdefault(field, []).append(val)
    return out


def _get(msg: Dict[int, list], field: int, default: Any = None) -> Any:
    vals = msg.get(field)
    return vals[0] if vals else default


def _text(val: Any) -> Optional[str]:
    if not isinstance(val, (bytes, bytearray)):
        return None
    try:
        return val.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _player(raw: bytes, my_uid: int) -> Dict[str, Any]:
    p = _parse(raw)
    rating = _get(p, 88)
    uid = _get(p, 1, 0)
    return {
        "uid": str(uid),
        "nickname": _text(_get(p, 2)) or str(uid),
        "guild": _text(_get(p, 7)) or "",
        "level": _get(p, 9, 0),
        "head_pic": str(_get(p, 4, "") or ""),
        "banner_id": str(_get(p, 5, "") or ""),
        "kills": _get(p, 3, 0),
        "deaths": _get(p, 20, 0),
        "assists": _get(p, 22, 0),
        "damage": _get(p, 19, 0),
        "rating": round(rating, 1) if isinstance(rating, float) else None,
        "is_me": uid == my_uid,
    }


def _match(raw: bytes) -> Dict[str, Any]:
    m = _parse(raw)
    my_uid = _get(m, 2, 0)
    prog = _parse(_get(m, 7, b""))
    det = _parse(_get(m, 8, b""))

    team = [_player(x, my_uid) for x in det.get(25, [])]
    opponents = [_player(x, my_uid) for x in det.get(70, [])]
    is_cs = bool(team or opponents)
    won = _get(det, 46) == 1
    rating = _get(det, 305)

    match: Dict[str, Any] = {
        "match_id": str(_get(m, 1, "")),
        "account_id": str(my_uid),
        "start_time": _get(m, 3, 0),
        "end_time": _get(m, 4, 0),
        "duration_sec": _get(det, 3, 0),
        "mode": "CS" if is_cs else "BR",
        "kills": _get(det, 5, 0),
        "damage": _get(det, 6, 0),
        "rating": round(rating, 1) if isinstance(rating, float) else None,
        "level": _get(prog, 7, 0),
        "exp_gained": _get(prog, 1, 0),
        "coins_gained": _get(prog, 2, 0),
        "br_points": [_get(prog, 8, 0), _get(prog, 9, 0)],
        "cs_points": [_get(prog, 10, 0), _get(prog, 11, 0)],
        "team": team,
        "opponents": opponents,
    }

    if is_cs:
        # Champ 68 = nombre total de manches ; l'équipe gagnante en a 4
        rounds = _get(det, 68, 0)
        other = max(0, rounds - 4)
        match["won"] = won
        match["score"] = [4, other] if won else [other, 4]
        map_id = _get(det, 31, 0)
        match["map"] = CS_MAPS.get(map_id, f"Carte #{map_id}")
    else:
        match["placement"] = _get(det, 4, 0)
        match["total_players"] = _get(det, 31, 50)
        match["won"] = match["placement"] == 1
        map_id = _get(det, 41, 0)
        match["map"] = BR_MAPS.get(map_id, f"Carte #{map_id}")
    return match


def decode_history(data: bytes) -> List[Dict[str, Any]]:
    """Décode la réponse brute (gzip ou déjà décompressée) en liste de matchs."""
    if data[:2] == b"\x1f\x8b":
        data = zlib.decompress(data, 31)
    root = _parse(data)
    return [_match(x) for x in root.get(1, [])]


def decode_history_hex(hex_str: str) -> List[Dict[str, Any]]:
    cleaned = "".join(hex_str.split())
    return decode_history(bytes.fromhex(cleaned))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage : python match_history.py reponse.hex [sortie.json]")
        sys.exit(1)
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        matches = decode_history_hex(f.read())
    out_path = sys.argv[2] if len(sys.argv) > 2 else "match_history.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(matches, f, ensure_ascii=False, indent=2)
    print(f"{len(matches)} matchs décodés -> {out_path}")
