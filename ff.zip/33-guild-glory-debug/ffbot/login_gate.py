# -*- coding: utf-8 -*-
"""
LoginGate : cadence des logins complets (guest/token/grant + MajorLogin + GetLoginData) sur tout le serveur.

Sans elle, des centaines de comptes qui (re)démarrent en même temps envoient des centaines de demandes de token
d'un coup : le serveur de connexion répond HTTP 429 « error_too_many_requests », les logins échouent, chaque
échec relance un login… Ici :
  - LOGIN_PARALLEL logins complets au plus en même temps (.env, 2 par défaut) ;
  - un départ au plus toutes les LOGIN_INTERVAL_S secondes (.env, 1 s par défaut) ;
  - après un HTTP 429 : plus aucun login pendant LOGIN_COOLDOWN_S secondes (.env, 60 s par défaut), pour TOUS les
    comptes, au lieu d'insister (chaque nouvelle demande prolongeait le refus).
Une session gardée (token_cache.json) ne passe pas par ici : elle ne contacte pas le serveur de connexion.
"""
import asyncio
import os
import time


def _env_float(name: str, default: float, low: float) -> float:
    try:
        return max(low, float(os.environ.get(name, default)))
    except ValueError:
        return default


class LoginGate:
    def __init__(self, parallel: int = None, interval_s: float = None, cooldown_s: float = None):
        self.parallel = int(parallel if parallel is not None else _env_float("LOGIN_PARALLEL", 2, 1))
        self.interval_s = interval_s if interval_s is not None else _env_float("LOGIN_INTERVAL_S", 1.0, 0.0)
        self.cooldown_s = cooldown_s if cooldown_s is not None else _env_float("LOGIN_COOLDOWN_S", 60.0, 1.0)
        self._active = 0          # logins complets en cours (au plus self.parallel, modifiable à chaud)
        self._slots = asyncio.Condition()
        self._lock = asyncio.Lock()
        self._next_at = 0.0
        self._cooldown_until = 0.0
        self.waiting = 0          # comptes qui attendent leur tour (affichage)
        self.rate_limited = 0     # refus HTTP 429 reçus depuis le démarrage

    @property
    def cooling_s(self) -> float:
        """Secondes restantes de pause après un refus HTTP 429 (0 = aucune pause)."""
        return max(0.0, self._cooldown_until - time.monotonic())

    def set_limits(self, parallel=None, interval_s=None, cooldown_s=None) -> None:
        """Réglages de la page (Settings) : suivis tout de suite, comptes déjà en attente compris."""
        if parallel is not None:
            self.parallel = max(1, int(parallel))
        if interval_s is not None:
            self.interval_s = max(0.0, float(interval_s))
        if cooldown_s is not None:
            self.cooldown_s = max(1.0, float(cooldown_s))
        try:
            asyncio.get_running_loop().create_task(self._wake())
        except RuntimeError:
            pass

    async def _wake(self):
        async with self._slots:
            self._slots.notify_all()

    async def _release(self):
        async with self._slots:
            self._active -= 1
            self._slots.notify_all()

    def cooldown(self) -> bool:
        """Refus HTTP 429 : pause de tous les logins. True si la pause commence (pour ne la signaler qu'une fois)."""
        self.rate_limited += 1
        started = self.cooling_s <= 0
        self._cooldown_until = max(self._cooldown_until, time.monotonic() + self.cooldown_s)
        return started

    async def __aenter__(self):
        self.waiting += 1
        try:
            async with self._slots:
                await self._slots.wait_for(lambda: self._active < self.parallel)
                self._active += 1
            try:
                async with self._lock:     # un seul compte calcule son heure de départ à la fois
                    while True:
                        wait = max(self._next_at, self._cooldown_until) - time.monotonic()
                        if wait <= 0:
                            break
                        await asyncio.sleep(wait)
                    self._next_at = time.monotonic() + self.interval_s
            except BaseException:
                await asyncio.shield(self._release())
                raise
        finally:
            self.waiting -= 1
        return self

    async def __aexit__(self, *exc):
        await asyncio.shield(self._release())
        return False

    def status(self) -> dict:
        return {"parallel": self.parallel, "interval_s": self.interval_s, "cooldown_s": self.cooldown_s,
                "waiting": self.waiting, "cooling_s": round(self.cooling_s, 1), "rate_limited": self.rate_limited}
