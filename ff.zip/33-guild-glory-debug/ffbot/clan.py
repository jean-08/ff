# -*- coding: utf-8 -*-
"""
Demandes d'entrée en guilde (clan) pour des comptes du bot : une série à la fois, un compte après l'autre, état lu
par la page (FF Team Bot → Join clan, comptes de la réserve).

Requête du vrai client (api_client.request_join_clan, capture « ssss » du 26/10 01:03:39) : RequestJoinClan
{1: id de la guilde, 2: 1}. La guilde reçoit la demande ; son chef l'accepte dans le jeu (ou elle entre d'office si
la guilde est ouverte à tous).
"""
import asyncio
import time
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from . import api_client, diag

GAP_S = 0.6                            # entre deux comptes : quelques requêtes par seconde au plus
ITEMS_KEPT = 300                       # lignes de résultat gardées pour la page

# (clé, nom affiché, session du compte) ; la session est obtenue au moment de son tour (login si besoin)
Target = Tuple[str, str, Callable[[], Awaitable[Optional[Dict[str, Any]]]]]


class SkipAccount(Exception):
    """Compte passé sans demande (session indisponible pour l'instant…) : message affiché tel quel."""


class ClanJobs:
    """Série en cours / dernière série de demandes d'entrée en guilde."""

    def __init__(self):
        self.job: Optional[Dict[str, Any]] = None
        self._task: Optional[asyncio.Task] = None

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self, clan_id: int, targets: List[Target],
              on_ok: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
        if self.running:
            raise ValueError("A clan request batch is already running, wait for it to finish")
        if not targets:
            raise ValueError("No accounts to send")
        self.job = {"clan_id": str(clan_id), "total": len(targets), "done": 0, "ok": 0, "fail": 0, "running": True,
                    "started_at": time.time(), "ended_at": None, "items": []}
        self._task = asyncio.create_task(self._run(self.job, int(clan_id), targets, on_ok), name="clan-join")
        return self.job

    async def _run(self, job: Dict[str, Any], clan_id: int, targets: List[Target],
                   on_ok: Optional[Callable[[str], None]]):
        try:
            for key, name, session in targets:
                item = {"key": key, "name": name, "ok": False, "text": ""}
                try:
                    acc = await session()
                    if not acc:
                        raise SkipAccount("login failed")
                    item["name"] = acc.get("nickname") or name
                    res = await api_client.request_join_clan(acc, clan_id)
                    item["ok"] = True
                    item["text"] = "Request sent" + (f" · reply {res['fields']}" if res.get("fields") else "")
                    if on_ok:
                        on_ok(key)
                except (SkipAccount, api_client.GameApiError) as e:
                    item["text"] = str(e)[:160]
                except asyncio.TimeoutError:
                    item["text"] = "timed out"
                except Exception as e:
                    item["text"] = repr(e)[:160]
                    diag.event("CLAN", "join_failed", level="error", exc=e)
                job["items"].append(item)
                del job["items"][:-ITEMS_KEPT]
                job["done"] += 1
                job["ok" if item["ok"] else "fail"] += 1
                await asyncio.sleep(GAP_S)
        finally:
            job["running"] = False
            job["ended_at"] = time.time()

    def cancel(self):
        if self.running:
            self._task.cancel()
