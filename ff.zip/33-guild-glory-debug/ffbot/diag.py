# -*- coding: utf-8 -*-
"""
Journal de diagnostic : chaque étape du parcours d'un compte, avec un code d'erreur précis.

Fichiers (dossier DEBUG_LOG_DIR, « logs » par défaut) écrits par un thread : la boucle asyncio n'attend jamais le disque.
  logs/debug-AAAA-MM-JJ.log    toutes les étapes : login, passerelle, recherche, place de match, partie UDP, EXP, moteur
  logs/errors-AAAA-MM-JJ.log   avertissements et erreurs seulement (avec la pile d'appels) : le premier fichier à ouvrir

Une ligne = une étape d'un compte :
  2026-10-14 08:12:03.512 WARN  GATEWAY  connect_failed      NET_SEM_TIMEOUT    [Panel 1|FF-ABCD|uid=4770095517|gid=123]
      dur_ms=21034 | [WinError 121] The semaphore timeout period has expired

Chaque erreur reçoit un code stable (classify) ; la page « Serveur » compte les codes par étape (5 min / 1 h / total)
avec le dernier exemple, la cause des fins de partie et la durée de chaque étape (p50 / p95). Dans un worker UDP, les
étapes partent au processus principal (même fichier, rattachées au compte de la partie).

.env : DEBUG_LOG=1 (0 = pas de fichier), DEBUG_LOG_LEVEL=info (debug = aussi chaque renvoi de StartMatch, chaque
attente…), DEBUG_LOG_DIR=logs, DEBUG_LOG_DAYS=7 (fichiers plus vieux supprimés), DEBUG_LOG_MAX_MB=500 (par jour ;
au-delà, seuls les avertissements et erreurs continuent dans debug-*.log).
"""
import asyncio
import contextvars
import os
import queue
import re
import sys
import threading
import time
import traceback
from collections import deque
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

from ffbot.config import ROOT_DIR
from ffbot.hooks import current_runner

LEVELS = {"debug": 10, "info": 20, "warning": 30, "error": 40}
_TAGS = {10: "DEBUG", 20: "INFO", 30: "WARN", 40: "ERROR"}

# ---------------------------------------------------------------------------------------------------------------
# Étapes et codes (libellés affichés sur la page « Serveur »)
# ---------------------------------------------------------------------------------------------------------------
STAGES = ("LOGIN", "GATEWAY", "SEARCH", "SLOT", "MATCH", "EXP", "SESSION", "PANEL", "WORKER", "CACHE", "SYSTEM")
STAGE_LABELS = {
    "LOGIN": "เข้าสู่ระบบ", "GATEWAY": "เกตเวย์ (TCP)", "SEARCH": "หาแมตช์", "SLOT": "รอช่องแมตช์",
    "MATCH": "แมตช์ (UDP)", "EXP": "อ่าน EXP", "SESSION": "เซสชันบัญชี", "PANEL": "Panel", "WORKER": "worker UDP",
    "CACHE": "ไฟล์แคช", "SYSTEM": "ระบบ", "REWARD": "รับรางวัลกิจกรรม",
}
CODE_LABELS = {
    # réseau
    "NET_SEM_TIMEOUT": "เน็ตหมดเวลา (WinError 121): สัญญาณเน็ตหลุดหรือไม่เสถียร",
    "NET_TIMEOUT": "เชื่อมต่อหมดเวลา (ปลายทางไม่ตอบ)",
    "NET_RESET": "ปลายทางตัดการเชื่อมต่อ (connection reset)",
    "NET_ABORTED": "การเชื่อมต่อถูกยกเลิกที่เครื่องนี้ (เน็ตหลุด/ไดรเวอร์รีเซ็ต)",
    "NET_REFUSED": "ปลายทางปฏิเสธการเชื่อมต่อ",
    "NET_UNREACHABLE": "ไปไม่ถึงเครือข่ายปลายทาง (เน็ตหลุด)",
    "NET_NO_BUFFERS": "ทรัพยากรเครือข่ายของเครื่องหมด (WinError 10055): ซ็อกเก็ต/พอร์ตเต็ม",
    "NET_ADDR_IN_USE": "พอร์ตของเครื่องหมด (WinError 10048)",
    "NET_NAME_DELETED": "การเชื่อมต่อหายกลางทาง (WinError 64)",
    "NET_BROKEN_PIPE": "ส่งข้อมูลไม่ได้: การเชื่อมต่อถูกปิดไปแล้ว",
    "NET_OTHER": "ข้อผิดพลาดเครือข่ายอื่น ๆ",
    "NET_DROPS": "เครื่องรับแพ็กเก็ต UDP ไม่ทันจนต้องทิ้ง (เน็ต/การ์ดแลนรับโหลดไม่ไหว)",
    "DNS_FAIL": "แปลงชื่อโดเมนไม่สำเร็จ (DNS)",
    "TLS_ERROR": "ข้อผิดพลาด TLS/SSL",
    "TIMEOUT": "หมดเวลารอคำตอบ",
    # HTTP
    "HTTP_429": "เซิร์ฟเวอร์จำกัดจำนวนคำขอ (HTTP 429)",
    "HTTP_4XX": "เซิร์ฟเวอร์ปฏิเสธคำขอ (HTTP 4xx)",
    "HTTP_5XX": "เซิร์ฟเวอร์เกมขัดข้อง (HTTP 5xx)",
    "HTTP_BAD_RESPONSE": "คำตอบจากเซิร์ฟเวอร์อ่านไม่ได้/ไม่ครบ",
    # login
    "BANNED": "บัญชีถูกแบน",
    "VERSION_CONFIG": "อ่านเวอร์ชันเกมไม่ได้ (Play Store / ver.php)",
    "LOGIN_NO_GATEWAY": "เข้าสู่ระบบได้แต่ไม่ได้รับที่อยู่เกตเวย์",
    "LOGIN_NO_TOKEN": "เซิร์ฟเวอร์เกมตอบโดยไม่ส่ง token ตอนเข้าสู่ระบบ (ไม่ใช่แบนที่ระบบรู้จัก — ดู hex ใน log)",
    "LOGIN_TIMEOUT": "เข้าสู่ระบบนานเกินกำหนด",
    "LOGIN_UNSUPPORTED": "ไม่รองรับข้อมูลเข้าสู่ระบบประเภทนี้",
    "LOGIN_CLIENT_REJECTED": "เซิร์ฟเวอร์เกมไม่รับไคลเอนต์ (BR_AUTH_ABNORMAL_GAME_CLIENT) — ข้อมูลเวอร์ชัน/APK "
                             "ที่ส่งตอนเข้าสู่ระบบไม่ตรงกับเกมจริงแล้ว ไม่ใช่ความผิดของบัญชี ทุกบัญชีจะเจอเหมือนกัน",
    # passerelle / recherche
    "GW_IDLE": "เกตเวย์เงียบเกิน 40 วินาที",
    "GW_CLOSED": "เกตเวย์ปิดการเชื่อมต่อ",
    "GW_REJECTED": "เกตเวย์ไม่รับ session (ปิดทันทีหลังส่ง token)",
    "GW_BAD_PACKET": "ได้แพ็กเก็ตใหญ่ที่ไม่ใช่ข้อมูลแมตช์",
    "GW_PARSE_ERROR": "ถอดรหัสแพ็กเก็ตแมตช์ไม่ได้",
    "GW_SEND_FAILED": "ส่งคำขอหาแมตช์ไม่สำเร็จ",
    "CACHE_EXPIRED": "session หมดอายุ: ต้องเข้าสู่ระบบใหม่",
    # attente d'une place
    "PANEL_FULL": "ช่องแมตช์ของ Panel เต็ม",
    "WORKERS_FULL": "เซิร์ฟเวอร์เต็ม: แมตช์ทั้งเครื่องครบตามที่ worker รับได้",
    "PANEL_SHARE": "Panel นี้ใช้ส่วนแบ่งช่องของเซิร์ฟเวอร์ครบแล้ว: ให้ Panel อื่นที่ยังได้ไม่ครบก่อน",
    "SERVER_MAX": "ถึงแมตช์สูงสุดทั้งเซิร์ฟเวอร์ (หลังบ้าน → ตั้งค่าระบบ → เซิร์ฟเวอร์)",
    "LOAD_GUARD": "ระบบป้องกันโหลดพักแมตช์ใหม่",
    "ACCOUNT_LIMIT": "บัญชีเล่นครบจำนวนแมตช์คู่ขนานที่ตั้งไว้",
    "MATCH_END_WAIT": "รอแมตช์ที่ออกมาแล้วจบบนเซิร์ฟเวอร์ก่อน จึงเริ่มแมตช์ใหม่ (หลังบ้าน → ตั้งค่าระบบ → การเล่นแมตช์)",
    "FAIR_SHARE": "แบ่งแมตช์เท่ากัน: ให้บัญชีที่มีแมตช์น้อยกว่าหรือยังล็อกอินไม่เสร็จได้เล่นก่อน",
    # fin de partie
    "MATCH_END": "จบแมตช์ปกติ (เซิร์ฟเวอร์แจ้งจบ)",
    "PLAYER_DEAD": "จบแมตช์ (ตัวละครตาย)",
    "IDLE_END": "จบแมตช์ (เซิร์ฟเวอร์หยุดส่งข้อมูลหลังเล่น)",
    "SERVER_BYE": "จบแมตช์ (เซิร์ฟเวอร์ปิดการเชื่อมต่อ UDP_BYEBYE)",
    "MAX_DURATION": "ครบเวลาสูงสุดของแมตช์",
    "BR_LEFT": "ออกจากแมตช์ BR ตามเวลาที่ตั้ง (BR_LEAVE_AFTER_S): EXP เข้าเมื่อแมตช์จบบนเซิร์ฟเวอร์",
    "BR_DIED_LEFT": "ตัวละครตายแล้วจึงออกจากแมตช์ BR (BR_LEAVE_ON_DEATH; ตรวจเลือดและการเกิดใหม่ก่อนออก): ไม่ขึ้น ABANDONED",
    "BR_LOW_HP": "เลือดใกล้หมด (BR_LEAVE_HP) จึงออกจากแมตช์ BR ก่อนตาย: ออกตอนยังไม่ตายจึงได้ EXP",
    "BR_INSTA_LEFT": "ตายปุ๊บออกปั๊บ (BR_INSTA_LEAVE, เทส): ออกจากแมตช์ BR ทันทีที่เซิร์ฟเวอร์แจ้งว่าตัวละครตาย",
    "HANDSHAKE_TIMEOUT": "เข้าแมตช์ไม่สำเร็จ: เซิร์ฟเวอร์แมตช์ไม่ตอบภายในเวลาที่กำหนด",
    "MATCH_NO_DATA": "เข้าแมตช์แล้วแต่เซิร์ฟเวอร์ไม่ส่งข้อมูลเกม (มีแต่ปิง ตัวละครไม่ได้ลงแมพ): ออกแล้วหาแมตช์ใหม่ (BR_NO_DATA_S)",
    "SOCKET_ERROR": "ซ็อกเก็ต UDP ผิดพลาดนานเกินไป",
    "OUTAGE_LOST": "เน็ตหลุดระหว่างแมตช์ แล้วเซิร์ฟเวอร์ไม่ตอบกลับ",
    "MATCH_EXCEPTION": "ข้อผิดพลาดภายในแมตช์ (ดู traceback ใน log)",
    "CANCELLED": "แมตช์ถูกยกเลิก (แบน / ปิดเซิร์ฟเวอร์)",
    "WORKER_LOST": "worker UDP หยุดทำงานระหว่างแมตช์",
    "WORKER_SEND": "ส่งแมตช์ไปยัง worker ไม่ได้",
    "UDP_SEND_FAILED": "ส่งแพ็กเก็ตเข้าแมตช์ไม่สำเร็จ",
    # session / moteur
    "SEARCH_TIMEOUT": "หาแมตช์ไม่เจอนานเกินกำหนด",
    "STALL": "ไม่มีความคืบหน้านานเกินกำหนด",
    "FAULT_REPEAT": "เกตเวย์ผิดพลาดซ้ำหลายครั้ง",
    "SESSION_DROPPED": "เซสชันโปรโตคอลหลุดเอง",
    "LOGIN_FAILED": "เข้าสู่ระบบล้มเหลว",
    "ZERO_EXP": "เล่นจบหลายแมตช์แต่ EXP ไม่เพิ่ม",
    "CRASH": "ข้อผิดพลาดภายในโปรแกรม (ดู traceback ใน log)",
    # système
    "LOOP_LAG": "เซิร์ฟเวอร์หน่วง (event loop ช้า)",
    "WORKER_EXIT": "worker UDP หยุดทำงาน",
    "WORKER_START": "เริ่ม worker UDP ไม่สำเร็จ",
    "WORKER_OVERFLOW": "worker เต็มแต่ต้องรับแมตช์ที่เจอแล้ว",
    "CACHE_SAVE": "บันทึกไฟล์แคชไม่สำเร็จ",
    "CACHE_CORRUPT": "ไฟล์แคชเสีย จึงลบทิ้ง",
    "STORE_WRITE": "เขียนฐานข้อมูลไม่สำเร็จ",
    "TASK_ERROR": "งานเบื้องหลังผิดพลาด (ดู traceback ใน log)",
    "UNKNOWN": "ไม่ทราบสาเหตุ (ดูข้อความ)",
}
OK_CODES = frozenset({"MATCH_END", "PLAYER_DEAD", "IDLE_END", "SERVER_BYE", "BR_LEFT",
                      "BR_DIED_LEFT", "BR_LOW_HP", "BR_INSTA_LEFT"})   # fins de partie normales

# ---------------------------------------------------------------------------------------------------------------
# Classement des erreurs
# ---------------------------------------------------------------------------------------------------------------
_WINERRORS = {
    121: "NET_SEM_TIMEOUT", 64: "NET_NAME_DELETED", 1236: "NET_ABORTED", 1225: "NET_REFUSED",
    1231: "NET_UNREACHABLE", 1232: "NET_UNREACHABLE", 10035: "NET_OTHER", 10048: "NET_ADDR_IN_USE",
    10050: "NET_UNREACHABLE", 10051: "NET_UNREACHABLE", 10053: "NET_ABORTED", 10054: "NET_RESET",
    10055: "NET_NO_BUFFERS", 10060: "NET_TIMEOUT", 10061: "NET_REFUSED", 10065: "NET_UNREACHABLE",
}
_ERRNOS = {104: "NET_RESET", 110: "NET_TIMEOUT", 111: "NET_REFUSED", 101: "NET_UNREACHABLE", 113: "NET_UNREACHABLE",
           105: "NET_NO_BUFFERS", 98: "NET_ADDR_IN_USE", 32: "NET_BROKEN_PIPE", 103: "NET_ABORTED"}
_CLASS_CODES = {
    "AccountBanned": "BANNED", "CancelledError": "CANCELLED", "gaierror": "DNS_FAIL", "SSLError": "TLS_ERROR",
    "ConnectionResetError": "NET_RESET", "ConnectionRefusedError": "NET_REFUSED",
    "ConnectionAbortedError": "NET_ABORTED", "BrokenPipeError": "NET_BROKEN_PIPE",
    "ConnectTimeout": "NET_TIMEOUT", "ServerTimeoutError": "TIMEOUT", "ReadTimeout": "TIMEOUT",
    "WriteTimeout": "TIMEOUT", "PoolTimeout": "TIMEOUT", "TimeoutError": "TIMEOUT",
    "ServerDisconnectedError": "NET_RESET", "RemoteProtocolError": "HTTP_BAD_RESPONSE",
    "IncompleteReadError": "GW_CLOSED",
}
_TEXT_RULES: List[Tuple[re.Pattern, str]] = [(re.compile(p, re.I), c) for p, c in (
    (r"http 429|too_many_requests|too many requests", "HTTP_429"),
    # refus du client par le serveur de connexion : avant le « http 4xx » générique, qui n'en disait rien
    (r"abnormal_game_client", "LOGIN_CLIENT_REJECTED"),
    (r"http 5\d\d", "HTTP_5XX"),
    (r"http 4\d\d", "HTTP_4XX"),
    (r"gateway idle timeout", "GW_IDLE"),
    (r"connection closed by server", "GW_CLOSED"),
    (r"cache expired", "CACHE_EXPIRED"),
    (r"banned|แบน", "BANNED"),
    (r"ไม่ส่ง token/region|ไม่มี URL/token", "LOGIN_NO_TOKEN"),
    (r"getaddrinfo|name or service not known|nodename nor servname|no address associated", "DNS_FAIL"),
    (r"ssl|certificate", "TLS_ERROR"),
    (r"connection reset", "NET_RESET"),
    (r"refused", "NET_REFUSED"),
    (r"unreachable", "NET_UNREACHABLE"),
    (r"timed out|timeout|หมดเวลา", "TIMEOUT"),
)]
_WIN_RE = re.compile(r"\[(?:winerror|errno) (\d+)\]", re.I)


def _chain(exc: BaseException):
    seen = set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        yield exc
        exc = exc.__cause__ or exc.__context__


def _classify_exc(exc: BaseException) -> Optional[str]:
    winerror = getattr(exc, "winerror", None)
    if isinstance(winerror, int) and winerror in _WINERRORS:
        return _WINERRORS[winerror]
    err = getattr(exc, "errno", None)
    if isinstance(err, int):
        if err in _WINERRORS:
            return _WINERRORS[err]
        if err in _ERRNOS:
            return _ERRNOS[err]
    for cls in type(exc).__mro__:
        if cls.__name__ in _CLASS_CODES:
            return _CLASS_CODES[cls.__name__]
    return None


def classify(err: Any) -> str:
    """Code stable d'une erreur (exception, ou texte d'erreur déjà formaté) : NET_SEM_TIMEOUT, HTTP_429, GW_IDLE…"""
    if err is None:
        return "UNKNOWN"
    if isinstance(err, BaseException):
        text = f"{type(err).__name__} {err}"
        # message explicite (« Gateway idle timeout ») avant le type : ConnectionError n'en dit pas plus
        by_text = _classify_text(text, default=None)
        if by_text in ("GW_IDLE", "GW_CLOSED", "CACHE_EXPIRED", "HTTP_429"):
            return by_text
        for e in _chain(err):
            code = _classify_exc(e)
            if code:
                return code
        if isinstance(err, OSError):
            return by_text or "NET_OTHER"
        return by_text or "UNKNOWN"
    return _classify_text(str(err))


def _classify_text(text: str, default: Optional[str] = "UNKNOWN") -> Optional[str]:
    m = _WIN_RE.search(text)
    if m:
        n = int(m.group(1))
        code = _WINERRORS.get(n) or _ERRNOS.get(n)
        if code:
            return code
    for rx, code in _TEXT_RULES:
        if rx.search(text):
            return code
    return default


def label(code: Optional[str]) -> str:
    return CODE_LABELS.get(code or "", code or "")


# ---------------------------------------------------------------------------------------------------------------
# Contexte : compte / panel / partie de chaque ligne
# ---------------------------------------------------------------------------------------------------------------
_ctx: contextvars.ContextVar = contextvars.ContextVar("ffbot_diag_ctx", default=None)


def bind(**fields) -> contextvars.Token:
    """Ajoute des champs de contexte à toutes les lignes de la tâche courante (et de ses sous-tâches)."""
    cur = _ctx.get()
    merged = dict(cur) if cur else {}
    merged.update({k: v for k, v in fields.items() if v is not None})
    return _ctx.set(merged)


def unbind(token: contextvars.Token):
    try:
        _ctx.reset(token)
    except Exception:
        pass


def _runner_ctx() -> Dict[str, Any]:
    runner = current_runner.get()
    if runner is None:
        return {}
    try:
        auth = runner.account.get("auth") or {}
        return {"panel": runner.panel_name, "acc": runner.name, "uid": auth.get("uid"),
                "gid": runner.game_id, "s": (runner.session_id or "")[:6]}
    except Exception:
        return {}


_CTX_ORDER = ("panel", "acc", "uid", "gid", "s", "m", "w")


def _ctx_text(ctx: Dict[str, Any]) -> str:
    parts = []
    for key in _CTX_ORDER:
        v = ctx.get(key)
        if v in (None, ""):
            continue
        parts.append(str(v) if key in ("panel", "acc") else f"{key}={v}")
    for key, v in ctx.items():
        if key not in _CTX_ORDER and v not in (None, ""):
            parts.append(f"{key}={v}")
    return "|".join(parts)


def _ctx_short(ctx: Dict[str, Any]) -> str:
    return " · ".join(str(ctx[k]) for k in ("panel", "acc") if ctx.get(k)) or ""


def _fmt_value(v: Any) -> str:
    if v is None:
        return "-"
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, float):
        return f"{v:.1f}" if abs(v) < 1e6 else f"{v:.0f}"
    s = str(v)
    if not s or any(c in s for c in ' "=|\n\r\t'):
        s = '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ").replace("\r", " ") + '"'
    return s


# ---------------------------------------------------------------------------------------------------------------
# Écriture des fichiers (thread)
# ---------------------------------------------------------------------------------------------------------------
class _Writer(threading.Thread):
    def __init__(self, directory: str, keep_days: int, max_bytes: int, prefix: str = ""):
        super().__init__(name="diag-writer", daemon=True)
        self.dir = directory
        self.prefix = prefix         # DEBUG_LOG_PREFIX : « web- » pour la partie web séparée (fichiers à elle)
        self.keep_days = keep_days
        self.max_bytes = max_bytes
        self.q: "queue.SimpleQueue" = queue.SimpleQueue()
        self.day = ""
        self.debug_f = None
        self.errors_f = None
        self.debug_bytes = 0
        self.capped = False
        self.failed = False

    def paths(self, day: Optional[str] = None) -> Dict[str, str]:
        day = day or time.strftime("%Y-%m-%d")
        return {"debug": os.path.join(self.dir, f"{self.prefix}debug-{day}.log"),
                "errors": os.path.join(self.dir, f"{self.prefix}errors-{day}.log")}

    def run(self):
        while True:
            item = self.q.get()
            if item is None:
                break
            batch = [item]
            stop = False
            while len(batch) < 1000:
                try:
                    item = self.q.get_nowait()
                except queue.Empty:
                    break
                if item is None:
                    stop = True
                    break
                batch.append(item)
            self._write(batch)
            if stop:
                break
        self._close()

    def _open(self, day: str):
        self._close()
        os.makedirs(self.dir, exist_ok=True)
        p = self.paths(day)
        self.debug_f = open(p["debug"], "a", encoding="utf-8", buffering=1 << 16)
        self.errors_f = open(p["errors"], "a", encoding="utf-8", buffering=1 << 14)
        self.day = day
        try:
            self.debug_bytes = os.path.getsize(p["debug"])
        except OSError:
            self.debug_bytes = 0
        self.capped = False
        self._purge()

    def _purge(self):
        """Supprime les journaux de plus de keep_days jours."""
        limit = time.time() - self.keep_days * 86400
        try:
            for name in os.listdir(self.dir):
                if re.fullmatch(re.escape(self.prefix) + r"(debug|errors)-\d{4}-\d{2}-\d{2}\.log", name):
                    path = os.path.join(self.dir, name)
                    if os.path.getmtime(path) < limit:
                        os.remove(path)
        except OSError:
            pass

    def _write(self, batch):
        if self.failed:
            return
        try:
            for day, lv, text in batch:
                if day != self.day:
                    self._open(day)
                if not self.capped or lv >= 30:
                    self.debug_f.write(text)
                    self.debug_bytes += len(text)
                    if not self.capped and self.debug_bytes > self.max_bytes:
                        self.capped = True
                        self.debug_f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} WARN  SYSTEM   log_capped "
                                           f"- [] max_mb={self.max_bytes // 1048576} | debug log ใหญ่เกิน "
                                           f"DEBUG_LOG_MAX_MB: วันนี้บันทึกเฉพาะคำเตือนและข้อผิดพลาด\n")
                if lv >= 30:
                    self.errors_f.write(text)
            self.debug_f.flush()
            self.errors_f.flush()
        except Exception as e:
            self.failed = True
            print(f"[diag] écriture du journal impossible ({e!r}) : journal de diagnostic désactivé", file=sys.stderr)

    def _close(self):
        for f in (self.debug_f, self.errors_f):
            try:
                if f:
                    f.close()
            except Exception:
                pass
        self.debug_f = self.errors_f = None


# ---------------------------------------------------------------------------------------------------------------
# Statistiques en mémoire (page « Serveur »)
# ---------------------------------------------------------------------------------------------------------------
class _Bucket:
    __slots__ = ("total", "minutes", "level", "last_ts", "last_msg", "last_ctx")

    def __init__(self):
        self.total = 0
        self.minutes: Dict[int, int] = {}
        self.level = 0
        self.last_ts = 0.0
        self.last_msg = ""
        self.last_ctx = ""

    def add(self, ts: float, lv: int, msg: str, ctx: str):
        self.total += 1
        minute = int(ts // 60)
        self.minutes[minute] = self.minutes.get(minute, 0) + 1
        if len(self.minutes) > 75:
            for m in [m for m in self.minutes if m < minute - 61]:
                del self.minutes[m]
        self.level = max(self.level, lv)
        self.last_ts = ts
        if msg:
            self.last_msg = msg[:300]
        self.last_ctx = ctx

    def window(self, minutes: int, now_min: int) -> int:
        return sum(n for m, n in self.minutes.items() if m > now_min - minutes)


class _Stats:
    def __init__(self):
        self.lock = threading.Lock()
        self.buckets: Dict[Tuple[str, str, str], _Bucket] = {}
        self.timings: Dict[Tuple[str, str], Deque[Tuple[float, float]]] = {}
        self.recent: Deque[Dict[str, Any]] = deque(maxlen=400)
        self.counts = {"events": 0, "warnings": 0, "errors": 0}
        self.started_at = time.time()

    def add(self, rec: Dict[str, Any], ctx: Dict[str, Any]):
        lv, ts = rec["lv"], rec["ts"]
        key = (rec["stage"], rec["name"], rec["code"] or "")
        short = _ctx_short(ctx)
        with self.lock:
            self.counts["events"] += 1
            if lv >= 40:
                self.counts["errors"] += 1
            elif lv >= 30:
                self.counts["warnings"] += 1
            if lv >= 20 or rec["code"]:
                b = self.buckets.get(key)
                if b is None:
                    b = self.buckets[key] = _Bucket()
                b.add(ts, lv, rec["msg"], short)
            dur = rec["fields"].get("dur_ms")
            if isinstance(dur, (int, float)):
                d = self.timings.get(key[:2])
                if d is None:
                    d = self.timings[key[:2]] = deque(maxlen=2000)
                d.append((ts, float(dur)))
            if lv >= 30:
                self.recent.append({"ts": ts, "level": "error" if lv >= 40 else "warning", "stage": rec["stage"],
                                    "name": rec["name"], "code": rec["code"], "label": label(rec["code"]),
                                    "msg": rec["msg"][:400], "ctx": short,
                                    "uid": ctx.get("uid"), "gid": ctx.get("gid")})


def _pct(values: List[float], p: float) -> float:
    if not values:
        return 0.0
    i = min(len(values) - 1, max(0, int(round(p / 100 * (len(values) - 1)))))
    return values[i]


# ---------------------------------------------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------------------------------------------
class _Diag:
    def __init__(self):
        self.enabled = False
        self.file_level = 20
        self.writer: Optional[_Writer] = None
        self.remote: Optional[Callable[[Dict[str, Any]], None]] = None
        self.stats = _Stats()
        self.summaries: Dict[str, Callable[[], Any]] = {}
        self.summary_task: Optional[asyncio.Task] = None
        self.dir = ""

    def configure(self):
        """Lit le .env (déjà chargé) et démarre l'écriture des fichiers (processus principal)."""
        if self.writer is not None:
            return
        self.file_level = LEVELS.get(os.environ.get("DEBUG_LOG_LEVEL", "info").strip().lower(), 20)
        self.dir = os.path.abspath(os.path.join(ROOT_DIR, os.environ.get("DEBUG_LOG_DIR", "logs")))
        if os.environ.get("DEBUG_LOG", "1").strip().lower() in ("0", "false", "no", "off", "non"):
            self.enabled = False
            return
        try:
            keep = max(1, int(os.environ.get("DEBUG_LOG_DAYS", "7")))
        except ValueError:
            keep = 7
        try:
            max_mb = max(10, int(os.environ.get("DEBUG_LOG_MAX_MB", "500")))
        except ValueError:
            max_mb = 500
        prefix = re.sub(r"[^A-Za-z0-9_-]", "", os.environ.get("DEBUG_LOG_PREFIX", ""))[:20]
        self.writer = _Writer(self.dir, keep, max_mb * 1048576, prefix)
        self.writer.start()
        self.enabled = True

    def shutdown(self):
        if self.summary_task:
            self.summary_task.cancel()
            self.summary_task = None
        w, self.writer = self.writer, None
        self.enabled = False
        if w is not None:
            w.q.put(None)
            w.join(timeout=3.0)

    # ---------- événements ----------
    def event(self, stage: str, name: str, level: str = "info", code: Optional[str] = None, msg: str = "",
              exc: Optional[BaseException] = None, tb: bool = False, fields: Optional[Dict[str, Any]] = None):
        lv = LEVELS.get(level, 20)
        fields = fields or {}
        if exc is not None:
            if code is None:
                code = classify(exc)
            if not msg:
                msg = f"{type(exc).__name__}: {exc}" if str(exc) else type(exc).__name__
        if self.remote is None and lv < self.file_level and code is None and "dur_ms" not in fields:
            return        # rien à écrire ni à compter (étape de détail, DEBUG_LOG_LEVEL=info)
        rec = {"ts": time.time(), "lv": lv, "stage": stage, "name": name, "code": code, "msg": str(msg or ""),
               "fields": fields, "tb": None}
        if exc is not None and (tb or lv >= 40):
            rec["tb"] = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__, limit=12))[-4000:]
        ctx = dict(_ctx.get() or {})
        if self.remote is not None:          # worker UDP : vers le processus principal
            rec["ctx"] = ctx
            try:
                self.remote(rec)
            except Exception:
                pass
            return
        self._process(rec, ctx)

    def ingest(self, rec: Dict[str, Any], **extra):
        """Étape reçue d'un worker UDP : complétée par le contexte courant (compte de la partie) puis traitée."""
        try:
            ctx = dict(rec.get("ctx") or {})
            ctx.update({k: v for k, v in extra.items() if v is not None})
            rec.setdefault("fields", {})
            rec.setdefault("tb", None)
            self._process(rec, ctx)
        except Exception:
            pass

    def _process(self, rec: Dict[str, Any], ctx: Dict[str, Any]):
        runner_ctx = _runner_ctx()
        if runner_ctx:
            ctx = {**runner_ctx, **ctx}
        try:
            self.stats.add(rec, ctx)
        except Exception:
            pass
        if self.writer is None or rec["lv"] < self.file_level:
            return
        ts = rec["ts"]
        lt = time.localtime(ts)
        day = time.strftime("%Y-%m-%d", lt)
        fields = " ".join(f"{k}={_fmt_value(v)}" for k, v in rec["fields"].items())
        msg = rec["msg"].replace("\r", " ").replace("\n", " ⏎ ")
        line = (f"{day} {time.strftime('%H:%M:%S', lt)}.{int(ts % 1 * 1000):03d} {_TAGS.get(rec['lv'], 'INFO'):<5} "
                f"{rec['stage']:<8} {rec['name']:<20} {rec['code'] or '-':<18} [{_ctx_text(ctx)}]"
                f"{' ' + fields if fields else ''}{' | ' + msg if msg else ''}\n")
        if rec.get("tb"):
            line += "".join(f"    | {t}\n" for t in rec["tb"].rstrip().splitlines())
        self.writer.q.put((day, rec["lv"], line))

    # ---------- résumé périodique ----------
    def add_summary(self, name: str, fn: Callable[[], Any]):
        self.summaries[name] = fn

    def start_summary(self, interval_s: float = 60.0):
        if self.summary_task is None:
            self.summary_task = asyncio.create_task(self._summary_loop(interval_s), name="diag-summary")

    async def _summary_loop(self, interval_s: float):
        while True:
            await asyncio.sleep(interval_s)
            try:
                self.summary()
            except Exception as e:  # pragma: no cover
                event("SYSTEM", "summary_failed", level="error", exc=e)

    def summary(self):
        fields: Dict[str, Any] = {}
        for name, fn in self.summaries.items():
            try:
                value = fn()
            except Exception as e:
                value = f"!{e!r}"
            if isinstance(value, dict):
                fields.update({f"{name}.{k}" if k else name: v for k, v in value.items()})
            else:
                fields[name] = value
        now_min = int(time.time() // 60)
        with self.stats.lock:
            problems = sorted(((b.window(1, now_min), k) for k, b in self.stats.buckets.items()
                               if b.level >= 30 and b.window(1, now_min)), reverse=True)[:8]
        if problems:
            fields["problems_1m"] = ",".join(f"{k[0]}.{k[2] or k[1]}={n}" for n, k in problems)
        self.event("SYSTEM", "summary", level="info", fields=fields)

    # ---------- lecture (page « Serveur ») ----------
    def snapshot(self, recent: int = 100) -> Dict[str, Any]:
        now_ts = time.time()
        now_min = int(now_ts // 60)
        problems, match_end = [], {}
        with self.stats.lock:
            for (stage, name, code), b in self.stats.buckets.items():
                if stage == "MATCH" and name == "end":
                    match_end[code] = {"code": code, "label": label(code), "ok": code in OK_CODES,
                                       "m5": b.window(5, now_min), "h1": b.window(60, now_min), "total": b.total}
                    if code in OK_CODES:
                        continue
                if b.level < 30:
                    continue
                problems.append({"stage": stage, "stage_label": STAGE_LABELS.get(stage, stage), "name": name,
                                 "code": code, "label": label(code), "level": "error" if b.level >= 40 else "warning",
                                 "m5": b.window(5, now_min), "h1": b.window(60, now_min), "total": b.total,
                                 "last_ts": b.last_ts, "last_msg": b.last_msg, "last_ctx": b.last_ctx})
            timings = []
            for (stage, name), samples in self.stats.timings.items():
                vals = sorted(ms for ts, ms in samples if now_ts - ts <= 3600)
                if vals:
                    timings.append({"stage": stage, "stage_label": STAGE_LABELS.get(stage, stage), "name": name,
                                    "count": len(vals), "p50": round(_pct(vals, 50)), "p95": round(_pct(vals, 95)),
                                    "max": round(vals[-1])})
            recent_list = list(self.stats.recent)[-recent:][::-1] if recent > 0 else []
            counts = dict(self.stats.counts)
        order = {s: i for i, s in enumerate(STAGES)}
        problems.sort(key=lambda p: (-p["h1"], -p["total"]))
        timings.sort(key=lambda t: (order.get(t["stage"], 99), t["name"]))
        paths = self.writer.paths() if self.writer else {}
        return {"enabled": self.enabled, "dir": self.dir, "files": paths,
                "level": _TAGS.get(self.file_level, "INFO").lower(), "since": self.stats.started_at,
                "counts": counts, "problems": problems,
                "match_end": sorted(match_end.values(), key=lambda m: (not m["ok"], -m["h1"], -m["total"])),
                "timings": timings, "recent": recent_list}

    def tail(self, kind: str = "errors", lines: int = 300, q: str = "") -> Dict[str, Any]:
        """Dernières lignes du fichier du jour (debug ou errors), lues depuis la fin (2 Mo au plus, 16 Mo avec un
        filtre `q` : texte cherché, par ex. l'uid d'un compte pour suivre tout son parcours). La pile d'appels qui
        suit une ligne retenue est gardée avec elle."""
        if not self.writer:
            return {"path": None, "lines": []}
        path = self.writer.paths()["debug" if kind == "debug" else "errors"]
        q = (q or "").strip().lower()
        try:
            with open(path, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - (16 if q else 2) * 1048576))
                data = f.read().decode("utf-8", errors="replace")
        except OSError:
            return {"path": path, "lines": [], "q": q}
        out = data.splitlines()
        if q:
            kept, keep_tb = [], False
            for line in out:
                if line.startswith("    | "):
                    if keep_tb:
                        kept.append(line)
                    continue
                keep_tb = q in line.lower()
                if keep_tb:
                    kept.append(line)
            out = kept
        return {"path": path, "lines": out[-max(1, min(5000, lines)):], "q": q}


_d = _Diag()


def configure():
    _d.configure()


def shutdown():
    _d.shutdown()


def set_remote(send: Optional[Callable[[Dict[str, Any]], None]]):
    """Worker UDP : les étapes sont envoyées au processus principal au lieu d'être écrites ici."""
    _d.remote = send


def event(stage: str, name: str, /, level: str = "info", code: Optional[str] = None, msg: Any = "",
          exc: Optional[BaseException] = None, tb: bool = False, **fields):
    """Une étape : event("GATEWAY", "connect_failed", level="warning", exc=e, dur_ms=…). Ne lève jamais."""
    try:
        _d.event(stage, name, level, code, msg, exc, tb, fields)
    except Exception:
        pass


def ingest(rec: Dict[str, Any], **extra):
    _d.ingest(rec, **extra)


def add_summary(name: str, fn: Callable[[], Any]):
    _d.add_summary(name, fn)


def start_summary(interval_s: float = 60.0):
    _d.start_summary(interval_s)


def snapshot(recent: int = 100) -> Dict[str, Any]:
    return _d.snapshot(recent)


def files() -> Dict[str, Any]:
    """Fichiers du jour et dossier du journal (affichage)."""
    return {"enabled": _d.enabled, "dir": _d.dir, **(_d.writer.paths() if _d.writer else {})}


def worker_stderr_path(idx: int) -> Optional[str]:
    """Sortie d'erreur du worker UDP n° idx (plantage) : logs/worker-<idx>.stderr.log, None sans journal."""
    if not _d.enabled or not _d.dir:
        return None
    try:
        os.makedirs(_d.dir, exist_ok=True)
    except OSError:
        return None
    return os.path.join(_d.dir, f"worker-{idx}.stderr.log")


def tail(kind: str = "errors", lines: int = 300, q: str = "") -> Dict[str, Any]:
    return _d.tail(kind, lines, q)


def enabled_level(level: str) -> bool:
    """Le niveau `level` est-il écrit dans le fichier ? (évite de préparer une étape de détail inutile)"""
    return _d.remote is not None or LEVELS.get(level, 20) >= _d.file_level


def install_loop_handler(loop: asyncio.AbstractEventLoop):
    """Exceptions de tâches jamais récupérées, rappels en échec… : dans le journal, avec la pile d'appels."""
    previous = loop.get_exception_handler()

    def handler(lp, context):
        exc = context.get("exception")
        message = context.get("message", "")
        task = context.get("task") or context.get("future")
        name = getattr(task, "get_name", lambda: "")() if task is not None else ""
        event("SYSTEM", "task_error", level="error", code="TASK_ERROR", msg=f"{message} {name}".strip(), exc=exc,
              tb=True)
        if previous:
            previous(lp, context)
        else:
            lp.default_exception_handler(context)

    loop.set_exception_handler(handler)
