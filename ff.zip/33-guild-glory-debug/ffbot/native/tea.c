/*
 * TEA (16 tours) en mode OICQ, version native de ffbot/udp_codec.py (mêmes résultats, ~100x plus rapide).
 * Chargé par ctypes ; sans cette bibliothèque, udp_codec utilise sa version Python.
 *
 * Linux / Docker : gcc -O2 -shared -fPIC -o libtea.so tea.c
 * Windows        : python -m ziglang cc -O2 -shared -o tea.dll tea.c
 */
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#if defined(_WIN32)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __attribute__((visibility("default")))
#endif

#define DELTA 0x9E3779B9u
#define ROUNDS 16

static uint32_t rd32(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static void wr32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

/* n : multiple de 8 */
EXPORT void tea_cbc_decrypt(const uint8_t *in, uint8_t *out, size_t n, const uint8_t *key) {
    uint32_t k0 = rd32(key), k1 = rd32(key + 4), k2 = rd32(key + 8), k3 = rd32(key + 12);
    uint32_t pi0 = 0, pi1 = 0, pc0 = 0, pc1 = 0;
    for (size_t i = 0; i + 8 <= n; i += 8) {
        uint32_t c0 = rd32(in + i), c1 = rd32(in + i + 4);
        uint32_t v0 = c0 ^ pi0, v1 = c1 ^ pi1, s = DELTA * ROUNDS;
        for (int r = 0; r < ROUNDS; r++) {
            v1 -= ((v0 << 4) + k2) ^ (v0 + s) ^ ((v0 >> 5) + k3);
            v0 -= ((v1 << 4) + k0) ^ (v1 + s) ^ ((v1 >> 5) + k1);
            s -= DELTA;
        }
        wr32(out + i, v0 ^ pc0);
        wr32(out + i + 4, v1 ^ pc1);
        pi0 = v0; pi1 = v1; pc0 = c0; pc1 = c1;
    }
}

EXPORT void tea_cbc_encrypt(const uint8_t *in, uint8_t *out, size_t n, const uint8_t *key) {
    uint32_t k0 = rd32(key), k1 = rd32(key + 4), k2 = rd32(key + 8), k3 = rd32(key + 12);
    uint32_t pc0 = 0, pc1 = 0, px0 = 0, px1 = 0;
    for (size_t i = 0; i + 8 <= n; i += 8) {
        uint32_t x0 = rd32(in + i) ^ pc0, x1 = rd32(in + i + 4) ^ pc1;
        uint32_t v0 = x0, v1 = x1, s = 0;
        for (int r = 0; r < ROUNDS; r++) {
            s += DELTA;
            v0 += ((v1 << 4) + k0) ^ (v1 + s) ^ ((v1 >> 5) + k1);
            v1 += ((v0 << 4) + k2) ^ (v0 + s) ^ ((v0 >> 5) + k3);
        }
        pc0 = v0 ^ px0; pc1 = v1 ^ px1;
        wr32(out + i, pc0);
        wr32(out + i + 4, pc1);
        px0 = x0; px1 = x1;
    }
}
