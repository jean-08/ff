# -*- coding: utf-8 -*-
"""
Codec UDP des parties : TEA (mode OICQ) et lecture des en-têtes, en fonctions synchrones.

C'est le chemin le plus chaud du serveur : chaque partie reçoit des dizaines de paquets d'état par seconde,
et avec plusieurs panels des milliers par seconde au total, sur l'unique thread de la boucle asyncio.
Mesure (py-spy, ~80 parties) : la moitié du CPU partait dans le TEA de protocol.py (octet par octet, une
coroutine par bloc) et la boucle restait saturée à 100 % ; les relevés d'EXP dépassaient alors leur délai.

Ici :
  - TEA natif (ffbot/native/tea.c, chargé par ctypes) quand la bibliothèque compilée est présente, sinon TEA
    Python sur des entiers 32 bits (pas d'octet par octet ni de coroutine par bloc) ;
  - en-têtes lus sans rien déchiffrer : le corps n'est déchiffré que si son contenu sert.
Résultats identiques à l'implémentation d'origine (vérifié octet par octet).
"""
import ctypes
import os
import struct
import sys
from typing import List, Optional, Sequence, Tuple

DELTA = 0x9E3779B9
ROUNDS = 16
_M = 0xFFFFFFFF
_DEC_SUM0 = (DELTA * ROUNDS) & _M
FIELD_SIZES = {0: 1, 1: 2, 2: 2, 3: 1, 4: 2}
FIELD_NAMES = {0: "sendOption", 1: "cmd", 2: "orderId", 3: "flags", 4: "length"}

Header = dict


def key_words(key: bytes) -> Tuple[int, int, int, int]:
    return struct.unpack_from("<4I", key, 0)


def tea_cbc_decrypt(body: bytes, key: bytes) -> bytes:
    """Déchiffrement OICQ : dec = TEA⁻¹(bloc ^ intermédiaire précédent), clair = dec ^ chiffré précédent."""
    k0, k1, k2, k3 = key_words(key)
    n = len(body) // 4
    words = struct.unpack_from(f"<{n}I", body, 0)
    out = [0] * n
    pi0 = pi1 = pc0 = pc1 = 0
    for i in range(0, n, 2):
        c0, c1 = words[i], words[i + 1]
        v0, v1 = c0 ^ pi0, c1 ^ pi1
        s = _DEC_SUM0
        for _ in range(ROUNDS):
            v1 = (v1 - ((((v0 << 4) + k2) & _M) ^ ((v0 + s) & _M) ^ (((v0 >> 5) + k3) & _M))) & _M
            v0 = (v0 - ((((v1 << 4) + k0) & _M) ^ ((v1 + s) & _M) ^ (((v1 >> 5) + k1) & _M))) & _M
            s = (s - DELTA) & _M
        out[i], out[i + 1] = v0 ^ pc0, v1 ^ pc1
        pi0, pi1, pc0, pc1 = v0, v1, c0, c1
    return struct.pack(f"<{n}I", *out)


def tea_cbc_encrypt(padded: bytes, key: bytes) -> bytes:
    """Chiffrement OICQ : x = clair ^ chiffré précédent, chiffré = TEA(x) ^ x précédent."""
    k0, k1, k2, k3 = key_words(key)
    n = len(padded) // 4
    words = struct.unpack_from(f"<{n}I", padded, 0)
    out = [0] * n
    pc0 = pc1 = px0 = px1 = 0
    for i in range(0, n, 2):
        x0, x1 = words[i] ^ pc0, words[i + 1] ^ pc1
        v0, v1, s = x0, x1, 0
        for _ in range(ROUNDS):
            s = (s + DELTA) & _M
            v0 = (v0 + ((((v1 << 4) + k0) & _M) ^ ((v1 + s) & _M) ^ (((v1 >> 5) + k1) & _M))) & _M
            v1 = (v1 + ((((v0 << 4) + k2) & _M) ^ ((v0 + s) & _M) ^ (((v0 >> 5) + k3) & _M))) & _M
        c0, c1 = v0 ^ px0, v1 ^ px1
        out[i], out[i + 1] = c0, c1
        pc0, pc1, px0, px1 = c0, c1, x0, x1
    return struct.pack(f"<{n}I", *out)


def _load_native():
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), "native")
    name = "tea.dll" if sys.platform == "win32" else "libtea.so"
    path = os.environ.get("FFBOT_TEA_LIB") or os.path.join(here, name)
    if os.environ.get("FFBOT_TEA_NATIVE", "1") == "0" or not os.path.exists(path):
        return None
    try:
        lib = ctypes.CDLL(path)
        for fn in (lib.tea_cbc_decrypt, lib.tea_cbc_encrypt):
            fn.argtypes = (ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p)
            fn.restype = None
        return lib
    except OSError:
        return None


_native = _load_native()
NATIVE = _native is not None
_py_decrypt, _py_encrypt = tea_cbc_decrypt, tea_cbc_encrypt

if NATIVE:
    def tea_cbc_decrypt(body: bytes, key: bytes) -> bytes:  # noqa: F811 (remplace la version Python)
        n = len(body) & ~7
        out = ctypes.create_string_buffer(n)
        _native.tea_cbc_decrypt(bytes(body), out, n, bytes(key[:16]))
        return out.raw

    def tea_cbc_encrypt(padded: bytes, key: bytes) -> bytes:  # noqa: F811
        n = len(padded) & ~7
        out = ctypes.create_string_buffer(n)
        _native.tea_cbc_encrypt(bytes(padded), out, n, bytes(key[:16]))
        return out.raw


def oicq_unpad(padded: bytes) -> Optional[bytes]:
    if not padded or len(padded) < 8 or any(padded[-7:]):
        return None
    s = 3 + (padded[0] & 0x07)
    e = len(padded) - 7
    return padded[s:e] if s < e else b""


def layouts(mask) -> Tuple[List[int], List[int]]:
    """Ordre des champs d'en-tête (RUDP, puis non-RUDP sans orderId) d'après le code de match."""
    ru = [int(c) for c in str(mask).strip()]
    return ru, [c for c in ru if c != 2]


def read_header(data: bytes, layout: Sequence[int], k: int, v80: int) -> Optional[Header]:
    """En-tête valide pour cette disposition (mêmes contrôles que decode_packet), sinon None."""
    off = 2
    h = {}
    size = len(data)
    for code in layout:
        if FIELD_SIZES[code] == 1:
            if off + 1 > size:
                return None
            h[FIELD_NAMES[code]] = data[off] ^ k
            off += 1
        else:
            if off + 2 > size:
                return None
            h[FIELD_NAMES[code]] = ((data[off] | (data[off + 1] << 8)) ^ v80) & 0xFFFF
            off += 2
    if h.get("flags", 0) > 7 or h.get("sendOption", 0) > 7 or h.get("length") != size - off:
        return None
    if h.get("flags", 0) & 1 and (h["length"] < 8 or h["length"] % 8):
        return None
    h["headerLen"] = off
    return h


def headers(data: bytes, key: bytes, lays: Sequence[Sequence[int]]) -> List[Header]:
    """En-têtes plausibles d'un paquet (une par disposition qui passe les contrôles). Rien n'est déchiffré."""
    if len(data) < 8:
        return []
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    out = []
    for layout in lays:
        h = read_header(data, layout, k, v80)
        if h is not None:
            out.append(h)
    return out


def plans(lays: Sequence[Sequence[int]]) -> List[Tuple]:
    """Positions des champs de chaque disposition, calculées une fois par partie (pour control_cmd / scan) :
    (sendOption, cmd, flags, length, longueur d'en-tête, orderId) ; orderId None hors RUDP."""
    out = []
    for layout in lays:
        off, pos = 2, {}
        for code in layout:
            pos[code] = off
            off += FIELD_SIZES[code]
        if 1 in pos and 4 in pos:   # sans cmd ni longueur, read_header ne retient jamais la disposition
            out.append((pos.get(0), pos[1], pos.get(3), pos[4], off, pos.get(2)))
    return out


def control_cmd(data: bytes, k: int, v80: int, plan: Sequence[Tuple], wanted) -> Optional[int]:
    """Première commande de `wanted` trouvée dans un en-tête valide, sinon None. Mêmes contrôles que
    read_header / headers, sans construire de dict : appelé pour CHAQUE datagramme reçu (des dizaines de
    milliers par seconde avec beaucoup de parties)."""
    return scan(data, k, v80, plan, wanted)[1]


def scan(data: bytes, k: int, v80: int, plan: Sequence[Tuple], wanted) -> Tuple[Optional[int], Optional[int],
                                                                               Optional[int], Optional[int]]:
    """Une seule lecture d'en-tête par datagramme : (commande du premier en-tête valide, première commande de
    `wanted` — même résultat que control_cmd —, sendOption et orderId du premier en-tête valide). orderId est None
    pour un paquet sans numéro d'ordre (non RUDP) ; (None, None, None, None) si aucun en-tête n'est valide."""
    n = len(data)
    if n < 8:
        return None, None, None, None
    first = send_option = order_id = None
    for so, cm, fl, ln, hl, od in plan:
        if hl > n:
            continue
        length = ((data[ln] | (data[ln + 1] << 8)) ^ v80) & 0xFFFF
        if length != n - hl:
            continue
        flags = (data[fl] ^ k) if fl is not None else 0
        if flags > 7 or (so is not None and (data[so] ^ k) > 7):
            continue
        if flags & 1 and (length < 8 or length % 8):
            continue
        cmd = ((data[cm] | (data[cm + 1] << 8)) ^ v80) & 0xFFFF
        if first is None:
            first = cmd
            send_option = (data[so] ^ k) if so is not None else None
            order_id = ((data[od] | (data[od + 1] << 8)) ^ v80) & 0xFFFF if od is not None else None
        if cmd in wanted:
            return first, cmd, send_option, order_id
    return first, None, send_option, order_id


def crc7(buf: bytes, table: bytes) -> int:
    c = 0
    for b in buf:
        c = table[((2 * c) ^ b) & 0xFF] & 0x7F
    return c


def build_padded(content: bytes) -> bytes:
    pad_len = (8 - (len(content) + 10) % 8) % 8
    return bytes([pad_len, 0, 0]) + b"\x00" * pad_len + content + b"\x00" * 7


def build_packet(msg_key, layout, send_option, cmd, order_id, flags, content, key, crc_table, encrypted=True,
                 ext=None) -> bytes:
    """Équivalent synchrone de protocol.build_packet (même paquet, octet pour octet).
    `ext` : accusé de réception joint au paquet (prochain n° d'ordre attendu), comme le client du jeu : flags | 4 et
    3 octets (petit-boutiste, XOR de la clé comme l'en-tête) entre l'en-tête et le contenu."""
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = tea_cbc_encrypt(build_padded(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0])
    values = {0: send_option, 1: cmd, 2: order_id, 3: flags | (4 if ext is not None else 0), 4: len(body)}
    for code in layout:
        value = values[code]
        if FIELD_SIZES[code] == 1:
            hdr.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            hdr.append(v & 0xFF)
            hdr.append((v >> 8) & 0xFF)
    if ext is not None:
        hdr += bytes(((ext >> (8 * i)) & 0xFF) ^ k for i in range(3))
    packet = hdr + body
    packet[1] = crc7(packet[2:], crc_table)
    return bytes(packet)


def decode(data: bytes, key: bytes, lays: Sequence[Sequence[int]]) -> Optional[dict]:
    """Équivalent synchrone de protocol.decode_packet(paquet, clé, code de match) : même paquet retenu.
    (Là-bas le score CRC est le même pour tous les candidats, le tri stable garde donc le premier : RUDP.)"""
    if len(data) < 8:
        return None
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    for kind, layout in zip(("RUDP", "nonRUDP"), lays):
        h = read_header(data, layout, k, v80)
        if h is None:
            continue
        c = content(data, h, key)
        if c is None:
            continue
        return {"kind": kind, "cmd": h["cmd"], "flags": h.get("flags"), "sendOption": h.get("sendOption"),
                "orderId": h.get("orderId"), "length": h["length"], "headerLen": h["headerLen"],
                "msgKey": data[0], "content": c, "total": len(data)}
    return None


def content(data: bytes, header: Header, key: bytes) -> Optional[bytes]:
    """Contenu du paquet (déchiffré si chiffré). None si le bourrage est invalide (mauvaise disposition)."""
    body = data[header["headerLen"]:header["headerLen"] + header["length"]]
    if header.get("flags", 0) & 1:
        return oicq_unpad(tea_cbc_decrypt(body, key))
    return body
