# -*- coding: utf-8 -*-
"""Guest accounts pasted on the page -> [(uid, password)].

Accepted (same formats as the main site's import, ffbot/importer there):
  - one account per line: UID:password (also ; | , tab or space as separator);
  - Garena guest file content: {"guest_account_info": {"com.garena.msdk.guest_uid": …, "com.garena.msdk.guest_password": …}}
    (several pasted one after another, or one per line);
  - JSON objects / arrays with uid + password (uid / guest_uid, password / pass / pwd).
"""
import json
from typing import Any, Dict, List, Tuple

_UID_KEYS = ("uid", "guest_uid", "guestUid")
_PWD_KEYS = ("password", "pass", "pwd")
_GUEST_UID = "com.garena.msdk.guest_uid"
_GUEST_PWD = "com.garena.msdk.guest_password"


class InvalidAccount(Exception):
    pass


def _json_values(text: str) -> List[Any]:
    """JSON values one after another (NDJSON, or several guest files pasted end to end)."""
    decoder = json.JSONDecoder()
    values, pos = [], 0
    while True:
        while pos < len(text) and (text[pos].isspace() or text[pos] == ","):
            pos += 1
        if pos >= len(text):
            return values
        value, pos = decoder.raw_decode(text, pos)
        values.append(value)


def _records(text: str) -> List[Any]:
    text = (text or "").lstrip("﻿").strip()
    if not text:
        return []
    if text[0] in "[{":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            data = _json_values(text)          # raises JSONDecodeError if really broken
        if isinstance(data, dict):
            for key in ("accounts", "data", "items"):
                if isinstance(data.get(key), list):
                    return data[key]
            return [data]
        return [x for v in data for x in (v if isinstance(v, list) else [v])] if isinstance(data, list) else [data]
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "//")):
            continue
        if line[0] == "{":
            try:
                out.append(json.loads(line))
                continue
            except json.JSONDecodeError:
                pass
        for sep in (":", ";", "|", ",", "\t", " "):
            parts = [p.strip() for p in line.split(sep) if p.strip()]
            if len(parts) >= 2:
                out.append({"uid": parts[0], "password": parts[1]})
                break
        else:
            out.append(line)
    return out


def _pick(rec: Dict[str, Any], keys) -> Any:
    return next((rec[k] for k in keys if rec.get(k) not in (None, "")), None)


def _account(rec: Any) -> Tuple[str, str]:
    if not isinstance(rec, dict):
        raise InvalidAccount(f"not a guest account: {str(rec)[:40]!r}")
    info = rec.get("guest_account_info") if isinstance(rec.get("guest_account_info"), dict) else rec
    uid = info.get(_GUEST_UID) or _pick(rec, _UID_KEYS)
    pwd = info.get(_GUEST_PWD) or _pick(rec, _PWD_KEYS)
    if uid is None or pwd is None:
        raise InvalidAccount("needs a UID and a password (access tokens are not supported here)")
    uid, pwd = str(uid).strip(), str(pwd).strip()
    if not uid.isdigit() or not 5 <= len(uid) <= 20:
        raise InvalidAccount(f"UID {uid[:30]!r} is not a valid number")
    if not pwd or len(pwd) > 256 or any(c.isspace() or ord(c) < 32 for c in pwd):
        raise InvalidAccount(f"UID {uid}: invalid password")
    return uid, pwd


def parse_accounts(text: str) -> Tuple[List[Tuple[str, str]], int, List[str]]:
    """-> (accounts, invalid count, first error messages)."""
    try:
        records = _records(text)
    except json.JSONDecodeError as e:
        return [], 1, [f"invalid JSON (line {e.lineno}, column {e.colno}): {e.msg}"]
    accounts, invalid, errors = [], 0, []
    for rec in records:
        try:
            accounts.append(_account(rec))
        except InvalidAccount as e:
            invalid += 1
            if len(errors) < 5:
                errors.append(str(e))
    return accounts, invalid, errors
