# -*- coding: utf-8 -*-
"""
Avatars et bannières des joueurs (mêmes sources et même cache que la carte de profil de 32-levelupranked,
ffbot/profile_card.py) : mémoire, puis disque (data/card_images, gardé d'un lancement à l'autre), puis première
URL qui répond. Image introuvable : image par défaut livrée à la racine du projet (<id>.png).

Servies à la page par GET /api/card-image/{avatar|banner}/{id} : même origine que la page, le canvas de
l'historique des matchs reste exportable en PNG.
"""
import asyncio
import io
import os
import time
from collections import OrderedDict
from functools import lru_cache
from typing import Dict, Iterable, Optional, Tuple

import aiohttp
from PIL import Image

from .config import ROOT_DIR

IMAGE_URLS = {
    'icon_api1': "https://raw.githubusercontent.com/I-SHOW-AKIRU200/AKIRU-ICONS/refs/heads/main/ICONS/",
    'icon_api2': "http://getitems.thug4ff.xyz/item?id=",
    'banner_api': "https://raw.githubusercontent.com/paulafredo/All-Banner-free-fire/refs/heads/main/img_id/",
    'banner_api2': "https://raw.githubusercontent.com/iamdeveco/banners/refs/heads/main/",
}
DEFAULT_HEAD_PIC = '902000074'
DEFAULT_BANNER_ID = '900000014'

IMAGE_TIMEOUT_S = 8
IMAGE_FAIL_TTL_S = 90         # image introuvable : nouvel essai au bout de 90 s
IMAGE_DOWNLOADS = 4           # téléchargements simultanés (une page d'historique demande jusqu'à ~50 images)
IMAGE_DIR = os.path.join(ROOT_DIR, "data", "card_images")
_MAX_IMAGES = 400
_IMAGE_MAX_BYTES = 4 * 1024 * 1024


def banner_id(value) -> str:
    value = str(value or DEFAULT_BANNER_ID)
    return DEFAULT_BANNER_ID if value in ('0', '901042014') else value


def head_pic(value) -> str:
    value = str(value or DEFAULT_HEAD_PIC)
    return DEFAULT_HEAD_PIC if value == '0' else value


def _avatar_urls(pic: str) -> Tuple[str, ...]:
    return (f"{IMAGE_URLS['icon_api2']}{pic}", f"{IMAGE_URLS['icon_api1']}{pic}.png")


def _banner_urls(bid: str) -> Tuple[str, ...]:
    return (f"{IMAGE_URLS['banner_api2']}{bid}.png", f"{IMAGE_URLS['banner_api']}{bid}.png")


def _disk_path(key: str) -> str:
    return os.path.join(IMAGE_DIR, "".join(c for c in key if c.isalnum() or c in "_-") + ".img")


def _disk_read(key: str) -> Optional[bytes]:
    try:
        with open(_disk_path(key), "rb") as f:
            data = f.read()
        Image.open(io.BytesIO(data))   # fichier abîmé : retéléchargé
        return data
    except Exception:
        return None


def _disk_write(key: str, data: bytes):
    try:
        os.makedirs(IMAGE_DIR, exist_ok=True)
        tmp = _disk_path(key) + ".tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, _disk_path(key))
    except Exception:
        pass


@lru_cache(maxsize=4)
def _default_image(image_id: str) -> Optional[bytes]:
    try:
        with open(os.path.join(ROOT_DIR, f"{image_id}.png"), "rb") as f:
            return f.read()
    except Exception:
        return None


def image_type(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data[:3] == b"GIF":
        return "image/gif"
    return "application/octet-stream"


class CardImages:
    def __init__(self):
        self._ok: "OrderedDict[str, bytes]" = OrderedDict()
        self._failed: Dict[str, float] = {}
        self._pending: Dict[str, asyncio.Task] = {}
        self._session: Optional[aiohttp.ClientSession] = None
        self._slots = asyncio.Semaphore(IMAGE_DOWNLOADS)

    async def avatar(self, pic) -> Tuple[bytes, bool]:
        """(image, vraie) de l'avatar `pic` ; l'avatar par défaut est toujours l'image locale."""
        pic = head_pic(pic)
        local = _default_image(DEFAULT_HEAD_PIC) if pic == DEFAULT_HEAD_PIC else None
        data = local or await self._get(f"avatar_{pic}", _avatar_urls(pic))
        return (data, True) if data else (_default_image(DEFAULT_HEAD_PIC) or b"", False)

    async def banner(self, bid) -> Tuple[bytes, bool]:
        bid = banner_id(bid)
        local = _default_image(DEFAULT_BANNER_ID) if bid == DEFAULT_BANNER_ID else None
        data = local or await self._get(f"banner_{bid}", _banner_urls(bid))
        return (data, True) if data else (_default_image(DEFAULT_BANNER_ID) or b"", False)

    async def _get(self, key: str, urls: Tuple[str, ...]) -> Optional[bytes]:
        if key in self._ok:
            self._ok.move_to_end(key)
            return self._ok[key]
        if time.time() - self._failed.get(key, 0) < IMAGE_FAIL_TTL_S:
            return None
        task = self._pending.get(key)
        if task is None:
            task = asyncio.create_task(self._load(key, urls))
            self._pending[key] = task
            task.add_done_callback(lambda _t: self._pending.pop(key, None))
        return await asyncio.shield(task)

    def _keep(self, key: str, data: bytes):
        self._ok[key] = data
        while len(self._ok) > _MAX_IMAGES:
            self._ok.popitem(last=False)

    async def _load(self, key: str, urls: Iterable[str]) -> Optional[bytes]:
        loop = asyncio.get_running_loop()
        data = await loop.run_in_executor(None, _disk_read, key)
        if data:
            self._keep(key, data)
            return data
        async with self._slots:
            for url in urls:
                data = await self._download(url)
                if data:
                    self._keep(key, data)
                    self._failed.pop(key, None)
                    await loop.run_in_executor(None, _disk_write, key, data)
                    return data
        self._failed[key] = time.time()
        return None

    async def _download(self, url: str) -> Optional[bytes]:
        try:
            if self._session is None or self._session.closed:
                self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=IMAGE_TIMEOUT_S))
            async with self._session.get(url) as response:
                if response.status != 200 or (response.content_length or 0) > _IMAGE_MAX_BYTES:
                    return None
                data = await response.content.read(_IMAGE_MAX_BYTES + 1)
                while len(data) <= _IMAGE_MAX_BYTES:
                    more = await response.content.read(_IMAGE_MAX_BYTES + 1 - len(data))
                    if not more:
                        break
                    data += more
                if len(data) > _IMAGE_MAX_BYTES:
                    return None
            Image.open(io.BytesIO(data))   # une page d'erreur n'est pas une image
            return data
        except Exception:
            return None

    async def close(self):
        if self._session is not None and not self._session.closed:
            await self._session.close()
