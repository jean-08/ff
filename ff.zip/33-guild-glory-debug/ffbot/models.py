# -*- coding: utf-8 -*-
"""Constantes d'état, paramètres de panel et helpers de sérialisation."""
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from .levels import calculate_level_progress, level_for_exp


class AccountBanned(Exception):
    """Compte banni détecté à la connexion (MajorLogin). On arrête la session sans réessayer."""
    def __init__(self, label: str, permanent: bool = False, duration_s: int = 0, reason: str = ""):
        super().__init__(label)
        self.label = label                # texte affiché (ex. « banni 3j 5h »)
        self.permanent = permanent
        self.duration_s = duration_s
        self.reason = reason


def new_id() -> str:
    return uuid.uuid4().hex


def now() -> float:
    return time.time()


# « หยุดเวลาเช่า » (ffbot.engine.orchestrator.freeze_rent, 21/10) : pendant une fermeture du site, l'heure des
# forfaits, rangs de ตัวแทน, accès clients et Panels s'arrête à l'instant de l'arrêt ; rien n'expire et le temps restant
# ne baisse plus. À la reprise, les dates de fin sont repoussées de la durée de l'arrêt.
_rent_frozen_at = 0.0


def set_rent_frozen(ts: float):
    global _rent_frozen_at
    _rent_frozen_at = float(ts or 0.0)


def rent_frozen_at() -> float:
    """Début de l'arrêt du temps de location, 0 = le temps court."""
    return _rent_frozen_at


def rent_now() -> float:
    """Heure des fins de location : l'heure réelle, ou l'instant de l'arrêt tant que le temps est arrêté."""
    return _rent_frozen_at or time.time()


# ---------- État runtime d'un compte (machine à états du runner) ----------
class RunState:
    LOGGING_IN = "LOGGING_IN"
    CONNECTING = "CONNECTING"
    ONLINE = "ONLINE"
    SEARCHING = "SEARCHING"
    IN_MATCH = "IN_MATCH"
    RECONNECTING = "RECONNECTING"
    STALLED = "STALLED"
    DRAINING = "DRAINING"      # objectif atteint : plus de nouveaux matchs, on laisse finir les matchs en cours
    STOPPING = "STOPPING"
    ENDED = "ENDED"
    # Hors ligne en attente d'une place de match du panel (limite atteinte, protection anti-saturation) :
    # attente normale, jamais comptée comme un blocage par le watchdog.
    WAITING = "WAITING"

    PLAYING = (ONLINE, SEARCHING, IN_MATCH, WAITING)


# ---------- Position d'un compte dans la file de son panel (persistée) ----------
class QueueState:
    PENDING = "pending"        # en attente
    ACTIVE = "active"          # en cours
    COMPLETED = "completed"    # objectif atteint
    FAILED = "failed"          # abandonné après trop d'erreurs (login, blocage...)
    STOPPED = "stopped"        # arrêté manuellement, ignoré par la file
    DISABLED = "disabled"      # désactivé
    BANNED = "banned"          # compte banni détecté à la connexion : passé, plus de reconnexion

    ALL = (PENDING, ACTIVE, COMPLETED, FAILED, STOPPED, DISABLED, BANNED)


class PanelStatus:
    STOPPED = "stopped"
    RUNNING = "running"
    FINISHED = "finished"      # file épuisée
    EXPIRED = "expired"        # durée de vie dépassée (panel client) : ne peut plus démarrer

    ALL = (STOPPED, RUNNING, FINISHED, EXPIRED)


class EndReason:
    OBJECTIVE = "objective_reached"
    MAX_MATCHES = "max_matches"
    MAX_DURATION = "max_duration"
    LOGIN_FAILED = "login_failed"
    STALLED = "stalled"
    MANUAL_STOP = "manual_stop"
    PANEL_STOPPED = "panel_stopped"
    SKIPPED = "skipped"
    SHUTDOWN = "shutdown"
    CRASH = "crash"
    PANEL_EXPIRED = "panel_expired"
    BANNED = "banned"
    REBALANCED = "rebalanced"      # comptes actifs simultanés réduits (réglage ou places de match du panel)

    LABELS = {
        OBJECTIVE: "ถึงเป้าหมายแล้ว",
        MAX_MATCHES: "ครบจำนวนแมตช์สูงสุดแล้ว",
        MAX_DURATION: "ครบระยะเวลาสูงสุดแล้ว",
        LOGIN_FAILED: "เข้าสู่ระบบล้มเหลวซ้ำหลายครั้ง",
        STALLED: "บัญชีค้าง (ไม่มีความคืบหน้า)",
        MANUAL_STOP: "หยุดด้วยตนเอง",
        PANEL_STOPPED: "Panel หยุดแล้ว",
        SKIPPED: "ข้ามด้วยตนเอง",
        SHUTDOWN: "เซิร์ฟเวอร์หยุดทำงาน",
        CRASH: "ข้อผิดพลาดภายใน",
        PANEL_EXPIRED: "สิทธิ์การเข้าใช้หมดอายุ",
        BANNED: "บัญชีถูกแบน",
        REBALANCED: "ลดจำนวนบัญชีที่เล่นพร้อมกัน (กลับเข้าคิว)",
    }

    # raison de fin -> état de file
    QUEUE_RESULT = {
        OBJECTIVE: QueueState.COMPLETED,
        MAX_MATCHES: QueueState.COMPLETED,
        MAX_DURATION: QueueState.COMPLETED,
        SKIPPED: QueueState.COMPLETED,
        LOGIN_FAILED: QueueState.FAILED,
        STALLED: QueueState.FAILED,
        CRASH: QueueState.FAILED,
        MANUAL_STOP: QueueState.STOPPED,
        BANNED: QueueState.BANNED,            # compte banni : passé, pas de reconnexion
        PANEL_STOPPED: QueueState.PENDING,   # reprendra au prochain démarrage du panel
        SHUTDOWN: QueueState.PENDING,
        PANEL_EXPIRED: QueueState.PENDING,
        REBALANCED: QueueState.PENDING,
    }


class Role:
    ADMIN = "admin"        # tout, y compris utilisateurs, clients et espaces des clients
    OPERATOR = "operator"  # panels, comptes, import (espace administrateur)
    VIEWER = "viewer"      # lecture seule (espace administrateur)
    CLIENT = "client"      # accès vendu : uniquement ses propres panels et comptes, jusqu'à expiration

    STAFF = (ADMIN, OPERATOR, VIEWER)
    ALL = (ADMIN, OPERATOR, VIEWER, CLIENT)
    # le client a les droits d'un opérateur, mais seulement sur son espace (vérifié dans l'API)
    RANK = {VIEWER: 0, OPERATOR: 1, CLIENT: 1, ADMIN: 2}


# Paramètres imposés aux panels des clients sans forfait (ancienne offre : 1 compte à la fois par panel ; les autres
# réglages, dont les matchs simultanés du panel, se règlent Panel par Panel comme ceux de l'administrateur)
CLIENT_FORCED_SETTINGS: Dict[str, Any] = {"concurrency": 1}
# matchs simultanés d'un nouveau Panel (réglage « แมตช์พร้อมกันสูงสุดของ Panel », modifiable ensuite dans la page)
DEFAULT_PANEL_MAX_MATCHES = 10


# ---------- Mode de jeu ----------
class GameMode:
    LONE_WOLF = "lone_wolf"
    BR = "br"               # Battle Royale
    BR_RANKED = "br_ranked"            # Battle Royale classé, départ en cours de partie (EXP / niveau)
    BR_RANKED_RANK = "br_ranked_rank"  # Battle Royale classé, jusqu'à la fin de la partie (points de rang)
    CLASH_SQUAD = "clash_squad"
    CS_RANKED = "cs_ranked"            # Clash Squad classé (CS Rank 4vs4), jusqu'à la fin de la partie
                                       # (EXP et points de rang CS)
    BR_EVOLUTION = "br_evolution"      # Open Squad BR Evolution (escouade de 4, mode 85)

    ALL = (LONE_WOLF, BR, BR_RANKED, BR_RANKED_RANK, CLASH_SQUAD, CS_RANKED, BR_EVOLUTION)
    DEFAULT = BR
    # plusieurs modes à la fois (réglage mode_mix) : ordre de priorité à égalité de place (classé d'abord, sa file est
    # la plus lente à trouver une partie)
    MIX_ORDER = (BR_RANKED_RANK, BR_RANKED, CS_RANKED, BR, BR_EVOLUTION, CLASH_SQUAD, LONE_WOLF)
    LABELS = {LONE_WOLF: "Lone Wolf", BR: "Battle Royale", BR_RANKED: "Ranked BR · เพิ่มเลเวล",
              BR_RANKED_RANK: "Ranked BR · เพิ่มแรงค์", CLASH_SQUAD: "Clash Squad", CS_RANKED: "Ranked CS 4vs4",
              BR_EVOLUTION: "BR Evolution"}


# Le Lone Wolf n'est ouvert qu'à partir de ce niveau : en dessous, un compte en mode Lone Wolf joue en BR.
LONE_WOLF_MIN_LEVEL = 3


def effective_game_mode(setting: Optional[str], level: Optional[int]) -> str:
    """Mode réellement joué : Lone Wolf demandé mais niveau < 3 (ou inconnu) -> Battle Royale."""
    mode = setting if setting in GameMode.ALL else GameMode.DEFAULT
    if mode == GameMode.LONE_WOLF and (not level or int(level) < LONE_WOLF_MIN_LEVEL):
        return GameMode.BR
    return mode


def mix_plan(settings: Dict[str, Any], level: Optional[int]) -> Optional[Dict[str, int]]:
    """Plusieurs modes à la fois (réglage mode_mix) : mode joué -> parties simultanées au plus par compte (slots_<mode> ;
    Lone Wolf sous le niveau 3 compté en BR, voir effective_game_mode). None : un seul mode (réglage game_mode)."""
    if not settings.get("mode_mix"):
        return None
    plan: Dict[str, int] = {}
    for mode in GameMode.MIX_ORDER:
        n = int(settings.get(f"slots_{mode}") or 0)
        if n > 0:
            played = effective_game_mode(mode, level)
            plan[played] = plan.get(played, 0) + n
    return plan or None


# โหมดเพิ่มแรงค์ : « หยุดเมื่อแต้มแรงก์ถึง » (réglage rank_target, points de rang BR ; 0 = sans limite). Bronze I = 1 000.
RANK_POINTS_MIN = 1_000
RANK_POINTS_MAX = 50_000


def rank_mode(settings: Dict[str, Any]) -> bool:
    """Panel en Ranked BR · เพิ่มแรงค์ seul (pas mode_mix) : son objectif est en points de rang, plus en niveau (presque
    0 EXP par partie dans ce mode : un niveau visé ne serait jamais atteint, ou déjà dépassé dès le départ)."""
    return not settings.get("mode_mix") and settings.get("game_mode") == GameMode.BR_RANKED_RANK


def rank_goal(settings: Dict[str, Any]) -> int:
    """Points de rang BR où un compte s'arrête (rank_mode) ; 0 : pas d'arrêt aux points (ou autre mode)."""
    return max(0, int(settings.get("rank_target") or 0)) if rank_mode(settings) else 0


def pick_mix_mode(plan: Dict[str, int], active: Dict[str, int]) -> Optional[str]:
    """Mode de la prochaine recherche : celui qui a le plus de place (parties en cours / plafond le plus bas), à égalité
    dans l'ordre GameMode.MIX_ORDER. `active` : parties en cours du compte par mode. None : tous les modes sont pleins."""
    free = [(active.get(m, 0) / cap, GameMode.MIX_ORDER.index(m), m) for m, cap in plan.items()
            if active.get(m, 0) < cap]
    return min(free)[2] if free else None


# ---------- Paramètres de panel ----------
OBJECTIVE_TYPES = ("none", "matches", "exp", "level", "duration")

# nom -> (défaut, min, max, type)
PANEL_SETTING_SPEC: Dict[str, Tuple[Any, Any, Any, type]] = {
    "game_mode": (GameMode.DEFAULT, None, None, str),   # lone_wolf (BR sous le niveau 3) | br | br_ranked | br_ranked_rank | clash_squad | cs_ranked
    "objective_type": ("level", None, None, str),
    "objective_value": (15, 0, 10_000_000, int),
    "rank_target": (0, 0, RANK_POINTS_MAX, int),        # โหมดเพิ่มแรงค์ : points de rang d'arrêt, 0 = sans limite (rank_goal)
    "max_duration_min": (0, 0, 7 * 24 * 60, int),      # 0 = illimité
    "max_matches": (0, 0, 100_000, int),                # 0 = illimité
    "switch_delay_s": (5, 0, 3600, int),                # délai avant de lancer le compte suivant
    "concurrency": (1, 1, 1000, int),                   # comptes actifs simultanément dans le panel
    "max_parallel_matches": (0, 0, 100, int),           # matchs simultanés par compte, 0 = illimité
    # matchs simultanés du panel, 0 = illimité (= capacité des workers) ; plafond 100 000 comme server_max_matches (1000
    # avant le 20/10 : trop bas pour un serveur de 4 800 places) — la vraie limite reste la capacité des workers
    "panel_max_matches": (DEFAULT_PANEL_MAX_MATCHES, 0, 100_000, int),
    "stall_timeout_min": (15, 0, 24 * 60, int),         # sans progression -> redémarrage, 0 = off (attente de place exclue)
    "search_timeout_s": (300, 0, 3600, int),            # recherche de match sans résultat -> nouveau login immédiat, 0 = off
    "max_restarts": (3, 0, 100, int),                   # redémarrages pour blocage avant échec
    "max_login_failures": (5, 1, 100, int),             # échecs de login consécutifs avant échec
    "drain_timeout_s": (120, 0, 3600, int),             # attente des matchs en cours à la fin
    # --- cadence (réglages avancés : plus court = plus de matchs/min, mais plus de sollicitations serveur)
    "start_interval_s": (3.0, 1.0, 30.0, float),        # intervalle entre deux demandes de match
    "relaunch_delay_s": (3.0, 0.5, 30.0, float),        # pause hors ligne après un match trouvé
    "exp_refresh_s": (90, 30, 600, int),                # relevé du profil (EXP / niveau)
    "loop_queue": (False, None, None, bool),            # file terminée -> recommencer les comptes terminés
    "auto_resume": (True, None, None, bool),            # relancer le panel au redémarrage du serveur
    # --- plusieurs modes à la fois (voir mix_plan) : remplace game_mode ; parties simultanées par compte dans chaque
    # mode, 0 = mode non joué (ex. classé 1 + BR 2 : le compte joue au plus 1 partie classée et 2 BR en même temps)
    "mode_mix": (False, None, None, bool),
    "slots_br_ranked_rank": (0, 0, 100, int),
    "slots_br_ranked": (0, 0, 100, int),
    "slots_cs_ranked": (0, 0, 100, int),
    "slots_br": (0, 0, 100, int),
    "slots_br_evolution": (0, 0, 100, int),
    "slots_clash_squad": (0, 0, 100, int),
    "slots_lone_wolf": (0, 0, 100, int),
}


# choix fait à l'ajout d'un lot de comptes (account["target"]) : โนมอล (Safe : une partie à la fois, niveau au choix)
# ou พรีเมียม (niveau fixe ; une partie à la fois « safe » ou ปั้มเสี่ยง « risky » : autant que le Panel en permet)
TARGET_MODES = ("normal", "premium")
TARGET_STYLES = ("safe", "risky")
# Premium : carte jouée par le lot, à la place du mode de jeu du Panel (Ranked = แมพแรงก์, départ en cours de partie
# pour l'EXP ; Classic = BR ทั่วไป ; เพิ่มแรงค์ = แมพแรงก์ jusqu'au bout, points de rang). Sans choix (Normal, ancien
# lot) : mode du Panel.
TARGET_GAMES = (GameMode.BR_RANKED, GameMode.BR, GameMode.BR_RANKED_RANK)


def account_settings(settings: Dict[str, Any], account: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Réglages d'un compte : ceux de son Panel, puis son choix à l'ajout (niveau où il s'arrête ; Safe = une partie à
    la fois). Compte ajouté sans choix : ceux du Panel. En โหมดเพิ่มแรงค์, l'objectif devient les points de rang
    (« rank » ; « none » sans points d'arrêt)."""
    out = _target_settings(dict(settings), account)
    if rank_mode(out):
        pts = rank_goal(out)
        out["objective_type"], out["objective_value"] = ("rank", pts) if pts else ("none", 0)
    return out


def _target_settings(out: Dict[str, Any], account: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Choix du lot gardé sur le compte (account["target"], lots d'avant le 20/10) appliqué à `out`."""
    target = (account or {}).get("target") or {}
    if not target:
        return out
    level = int(target.get("level") or 0)
    # Panel de l'administrateur avec une « เลเวลเป้าหมาย » : elle vaut pour tous ses comptes (choix du 20/10), le niveau
    # choisi à l'ajout ne sert que sans niveau de Panel. Panels des clients : le niveau du lot (Normal / Premium) vaut.
    panel_level = out.get("objective_type") == "level" and not (account or {}).get("owner_id")
    if level > 0 and not panel_level:
        out["objective_type"], out["objective_value"] = "level", level
    elif level == 0 and target.get("mode") == "premium" and not panel_level:
        out["objective_type"], out["objective_value"] = "none", 0      # Premium « ไม่จำกัด » : pas de niveau d'arrêt
    if target.get("style") != "risky":
        out["max_parallel_matches"] = 1
    if target.get("game") in TARGET_GAMES:
        out["game_mode"] = target["game"]
        out["mode_mix"] = False          # une seule carte : celle choisie, même si le Panel mélange les modes
    return out


def play_settings(play: Dict[str, Any], base: Dict[str, Any], client: bool) -> Dict[str, Any]:
    """Choix « Normal / Premium » d'un Panel (panel["play"], fait sur la page หน้าเพิ่มแอคเค้า ou dans l'onglet
    การตั้งค่า, depuis le 20/10) traduit en réglages du Panel : niveau d'arrêt (0 = ไม่จำกัด), ปลอดภัย = une partie à la
    fois par compte, carte Ranked / Classic / เพิ่มแรงค์, points de rang d'arrêt (rank, โหมดเพิ่มแรงค์). ปั้มเสี่ยง : Panel
    d'un client = parties simultanées de son forfait (déjà dans `base`) ; Panel de l'administrateur réglé sur 1 : valeur
    par défaut d'un Panel."""
    level = int(play.get("level") or 0)
    out: Dict[str, Any] = ({"objective_type": "level", "objective_value": level} if level > 0
                           else {"objective_type": "none"})
    if "rank" in play:
        out["rank_target"] = int(play.get("rank") or 0)
    if play.get("style") != "risky":
        out["max_parallel_matches"] = 1
    elif not client and int(base.get("max_parallel_matches") or 0) == 1:
        out["max_parallel_matches"] = PANEL_SETTING_SPEC["max_parallel_matches"][0]
    if play.get("game") in TARGET_GAMES:
        out["game_mode"] = play["game"]
        out["mode_mix"] = False
    return out


def play_from_settings(settings: Dict[str, Any], prev: Dict[str, Any], client: bool) -> Dict[str, Any]:
    """Réglages du Panel enregistrés à la main (formulaire การตั้งค่า de l'administrateur) : le choix Normal / Premium
    du Panel suit (niveau ; ปลอดภัย / ปั้มเสี่ยง sauf Panel d'un client, où les parties simultanées viennent du forfait ;
    carte d'un Premium). Les deux restent ainsi toujours les mêmes, où qu'on les règle."""
    play = dict(prev)
    play["level"] = int(settings.get("objective_value") or 0) if settings.get("objective_type") == "level" else 0
    play["rank"] = int(settings.get("rank_target") or 0)
    if not client:
        play["style"] = "safe" if int(settings.get("max_parallel_matches") or 0) == 1 else "risky"
    if play.get("style") == "risky":
        play["mode"] = "premium"
    play.pop("game", None)
    if play.get("mode") == "premium" and not settings.get("mode_mix") and settings.get("game_mode") in TARGET_GAMES:
        play["game"] = settings["game_mode"]
    return play


def default_panel_settings() -> Dict[str, Any]:
    return {k: spec[0] for k, spec in PANEL_SETTING_SPEC.items()}


def validate_panel_settings(raw: Dict[str, Any], base: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], List[str]]:
    """Fusionne `raw` sur `base` en validant chaque champ. Retourne (settings, erreurs)."""
    settings = dict(default_panel_settings())
    settings.update(base or {})
    errors: List[str] = []
    for key, value in (raw or {}).items():
        if key not in PANEL_SETTING_SPEC:
            continue
        default, lo, hi, typ = PANEL_SETTING_SPEC[key]
        try:
            if typ is bool:
                value = value if isinstance(value, bool) else str(value).lower() in ("1", "true", "on", "yes", "oui")
            elif typ in (int, float):
                value = typ(value)
                if (lo is not None and value < lo) or (hi is not None and value > hi):
                    errors.append(f"{key} ต้องอยู่ระหว่าง {lo} ถึง {hi}")
                    continue
            else:
                value = str(value)
        except (TypeError, ValueError):
            errors.append(f"{key}: ค่าไม่ถูกต้อง")
            continue
        if key == "objective_type" and value not in OBJECTIVE_TYPES:
            errors.append(f"objective_type ต้องเป็นหนึ่งใน {', '.join(OBJECTIVE_TYPES)}")
            continue
        if key == "game_mode" and value not in GameMode.ALL:
            errors.append(f"game_mode ต้องเป็นหนึ่งใน {', '.join(GameMode.ALL)}")
            continue
        if key == "rank_target" and 0 < value < RANK_POINTS_MIN:
            errors.append(f"แต้มแรงก์ที่จะหยุดต้องอยู่ระหว่าง {RANK_POINTS_MIN:,} ถึง {RANK_POINTS_MAX:,} (0 = ไม่จำกัด)")
            continue
        settings[key] = value
    if settings.get("mode_mix") and not mix_plan(settings, None):
        errors.append("เปิด “เล่นหลายโหมดพร้อมกัน” แล้ว ต้องตั้งจำนวนแมตช์อย่างน้อย 1 โหมด")
    return settings, errors


def new_panel_doc(name: str, order: int, settings: Optional[Dict[str, Any]] = None,
                  owner_id: Optional[str] = None, expires_at: Optional[float] = None) -> Dict[str, Any]:
    ts = now()
    return {
        "_id": new_id(),
        "name": name,
        "order": order,
        "owner_id": owner_id,          # None = espace administrateur, sinon id du client
        "expires_at": expires_at,      # None = sans limite
        "status": PanelStatus.STOPPED,
        "settings": settings or default_panel_settings(),
        "stats": {"matches": 0, "exp_gained": 0, "sessions": 0, "completed": 0, "failed": 0},
        "created_at": ts,
        "updated_at": ts,
        "started_at": None,
    }


def level_progress(level: Optional[int], exp: Optional[int]) -> Optional[Dict[str, Any]]:
    """Progression vers le niveau suivant (None tant que l'EXP est inconnue)."""
    if exp is None:
        return None
    exp = int(exp)
    return calculate_level_progress(int(level) if level else level_for_exp(exp), exp)


# ---------- Forfaits d'un client inscrit (ffbot.billing) : un forfait par Panel ----------
# user["plans"] = [{panel_id, package_id, name, parallel, price, period_hours, started_at, expires_at, segments}] ;
# segments = tranches successives [{accounts, until}] : une prolongation s'ajoute APRÈS la fin en cours, avec son
# propre nombre de comptes (ex. 2 comptes encore 2 h, puis 1 compte 24 h : fin réelle dans 26 h).
def plan_active(plan: Optional[Dict[str, Any]], ts: Optional[float] = None) -> bool:
    return bool(plan) and (plan.get("expires_at") or 0) > (ts or rent_now())


def plan_segments(plan: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Tranches du forfait ; ancien forfait (un seul nombre de comptes jusqu'à la fin) : une tranche."""
    segs = plan.get("segments")
    if segs:
        return segs
    return [{"accounts": int(plan.get("accounts") or 0), "until": plan.get("expires_at") or 0}]


def plan_accounts(plan: Optional[Dict[str, Any]], ts: Optional[float] = None) -> int:
    """Comptes joués en même temps MAINTENANT (tranche en cours), 0 = forfait fini."""
    if not plan:
        return 0
    ts = ts or rent_now()
    return next((int(s["accounts"]) for s in plan_segments(plan) if (s.get("until") or 0) > ts), 0)


def plan_shifted(plan: Dict[str, Any], since: float, delta: float) -> Dict[str, Any]:
    """Forfait repoussé de `delta` s (reprise après « หยุดเวลาเช่า ») : sa fin et ses tranches pas finies à `since`."""
    out = dict(plan)
    if (out.get("expires_at") or 0) > since:
        out["expires_at"] = out["expires_at"] + delta
    if out.get("segments"):
        out["segments"] = [{**s, "until": s["until"] + delta} if (s.get("until") or 0) > since else s
                           for s in out["segments"]]
    return out


def plan_public(plan: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not plan:
        return None
    ts = rent_now()
    keys = ("panel_id", "package_id", "name", "parallel", "price", "period_hours", "started_at", "expires_at")
    out = {k: plan.get(k) for k in keys}
    out["active"] = plan_active(plan, ts)
    out["accounts"] = plan_accounts(plan, ts) if out["active"] else int(plan_segments(plan)[-1]["accounts"])
    out["remaining_s"] = max(0, int((plan.get("expires_at") or 0) - ts))
    out["segments"] = [{"accounts": int(s["accounts"]), "until": s["until"]}
                       for s in plan_segments(plan) if (s.get("until") or 0) > ts]
    return out


def plans_of(user: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Forfaits d'un client (un par Panel) ; ancien forfait unique pas encore migré : tel quel."""
    if user.get("plans"):
        return list(user["plans"])
    return [user["plan"]] if user.get("plan") else []


def plans_summary(user: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Résumé des forfaits d'un client (menu, tableau de bord, liste des membres) : actif si au moins un forfait
    court ; comptes = somme des tranches en cours ; fin = la PLUS PROCHE des forfaits en cours ; `plans` : le détail
    par Panel. Aucun forfait en cours : le dernier fini (pour « หมดอายุแล้ว »)."""
    plans = [p for p in (plan_public(p) for p in plans_of(user)) if p]
    if not plans:
        return None
    live = [p for p in plans if p["active"]]
    if not live:
        last = max(plans, key=lambda p: p.get("expires_at") or 0)
        return {**last, "count": 0, "plans": plans}
    soon = min(live, key=lambda p: p["expires_at"])
    names = list(dict.fromkeys(p["name"] for p in live))
    parallel = {p.get("parallel") for p in live}
    return {**soon, "name": " + ".join(names), "accounts": sum(p["accounts"] for p in live),
            "parallel": parallel.pop() if len(parallel) == 1 else None, "count": len(live),
            "latest_expires_at": max(p["expires_at"] for p in live), "plans": plans}


# ---------- ยศตัวแทน (ffbot.billing) : rang acheté, dont les พ้อย expirent avec lui ----------
# user["agent"] = {since, expires_at, points, paid, closed} : `points` = part du solde (user["points"]) achetée comme
# ตัวแทน, retirée à `expires_at` (avec le rang) ; `closed` = fin déjà traitée (retrait fait, message envoyé).
def agent_active(user: Optional[Dict[str, Any]], ts: Optional[float] = None) -> bool:
    a = (user or {}).get("agent") or {}
    return bool(a) and (a.get("expires_at") or 0) > (ts or rent_now())


def points_balance(user: Dict[str, Any], ts: Optional[float] = None) -> int:
    """พ้อย utilisables : le solde, moins la part de ตัวแทน dont le rang est fini (pas encore retirée par le passage
    périodique, ffbot.billing.expire_agents)."""
    balance = int(user.get("points") or 0)
    a = user.get("agent") or {}
    if a and not agent_active(user, ts) and a.get("closed") != (a.get("expires_at") or 0):
        balance -= min(balance, int(a.get("points") or 0))
    return balance


def agent_public(user: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Rang de ตัวแทน : None = jamais acheté ; sinon en cours ou fini (date de fin), พ้อย qui expirent avec lui."""
    a = user.get("agent")
    if not a:
        return None
    ts = rent_now()
    active = agent_active(user, ts)
    return {"active": active, "since": a.get("since"), "expires_at": a.get("expires_at"),
            "points": min(int(a.get("points") or 0), int(user.get("points") or 0)) if active else 0,
            "remaining_s": max(0, int((a.get("expires_at") or 0) - ts)), "paid": int(a.get("paid") or 0)}


# ---------- Sérialisation publique (jamais de secrets) ----------
def mask_secret(value: str, keep: int = 6) -> str:
    value = str(value or "")
    if len(value) <= keep:
        return "•" * len(value)
    return value[:keep] + "…" + "•" * 4


def public_account(doc: Dict[str, Any]) -> Dict[str, Any]:
    auth = doc.get("auth", {})
    if auth.get("type") == "guest":
        login = {"type": "guest", "uid": auth.get("uid"), "secret": mask_secret(auth.get("password", ""), 0)}
    else:
        login = {"type": auth.get("type"), "uid": None, "secret": mask_secret(auth.get("access_token", ""))}
    game = doc.get("game") or {}
    return {
        "id": doc["_id"],
        "login": login,
        "label": doc.get("label") or "",
        "panel_id": doc.get("panel_id"),
        "owner_id": doc.get("owner_id"),
        "queue_position": doc.get("queue_position", 0),
        "queue_state": doc.get("queue_state", QueueState.PENDING),
        "game": game,
        "level_progress": level_progress(game.get("level"), game.get("exp")),
        "stats": doc.get("stats", {}),
        "last_error": doc.get("last_error"),
        "last_end_reason": doc.get("last_end_reason"),
        "target": doc.get("target"),
        "created_at": doc.get("created_at"),
        "updated_at": doc.get("updated_at"),
    }


def display_name(doc: Dict[str, Any]) -> str:
    game = doc.get("game") or {}
    auth = doc.get("auth") or {}
    return game.get("nickname") or (f"UID {auth['uid']}" if auth.get("uid") else f"Token {mask_secret(auth.get('access_token', ''))}")
