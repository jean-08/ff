# -*- coding: utf-8 -*-
"""
Réglages du Team Bot modifiables depuis la page (onglet Settings), au lieu du fichier .env.

Trois sortes de réglages :
  - « live » : appliqués tout de suite, y compris aux parties EN COURS (variables de ffbot.protocol envoyées aux
    workers UDP par MatchPool.set_tunables, variables de ffbot.teamlab, LoginGate.set_limits) ;
  - « next » : appliqués tout de suite, mais ne servent qu'au début d'une partie (entrée dans la partie, poursuite…) :
    la partie suivante les prend ;
  - « restart » : HOST, PORT, workers… lus au démarrage : écrits dans .env, pris au prochain lancement de run.py.

Les valeurs changées sur la page sont gardées dans data/teamlab.db (table settings, clé « site_settings ») et
l'emportent sur .env au démarrage. « Reset » sur un réglage retire ce choix : la valeur de .env (ou par défaut)
revient, tout de suite.
"""
import json
import os
import re
from typing import Any, Dict, List, Optional

from . import diag
from .config import ROOT_DIR

ENV_FILE = os.path.join(ROOT_DIR, ".env")
DB_KEY = "site_settings"

GROUPS = [
    ("server", "Server", "Read when run.py starts: saved to .env, used after a restart."),
    ("logins", "Logins", "How fast accounts log in. Applies at once, accounts already waiting included."),
    ("br", "Battle Royale · leaving the match", "Applies at once, matches in progress included."),
    ("cs", "Clash Squad · movement & drone", "Applies at once; the ones marked “next match” are set when a match starts."),
    ("udp", "Match protocol (UDP)", "Low-level match traffic. Change only if you know why."),
    ("lobby", "Lobby & account calls", "Calls made around a match."),
    ("load", "Server load", "Limits that protect the machine when many matches run."),
    ("teams", "Teams & guild", "Applies at once."),
]


def _s(key, label, group, kind, applies, target, help_, attr=None, lo=None, hi=None, step=None):
    return {"key": key, "label": label, "group": group, "kind": kind, "applies": applies, "target": target,
            "help": help_, "attr": attr or key, "min": lo, "max": hi, "step": step}


SPECS: List[Dict[str, Any]] = [
    # ---- serveur (.env, redémarrage) ----
    _s("HOST", "Page address (HOST)", "server", "str", "restart", "env",
       "127.0.0.1 = this computer only. 0.0.0.0 = reachable from the network: the page has no login, keep the port "
       "behind a firewall / VPN."),
    _s("PORT", "Page port (PORT)", "server", "int", "restart", "env", "Port of this page.", lo=1, hi=65535),
    _s("SAVE_LOGS", "Save log files (SAVE_LOGS)", "server", "bool", "restart", "env",
       "Off = no log file at all (debug logs, gateway dump, guild journal, UDP captures). The database is always kept."),
    _s("UDP_WORKERS", "UDP worker processes (UDP_WORKERS)", "server", "int", "restart", "env",
       "Matches are played in this many separate processes (0 = in the main process).", lo=0, hi=64),
    _s("UDP_WORKER_MAX_MATCHES", "Matches per worker (UDP_WORKER_MAX_MATCHES)", "server", "int", "restart", "env",
       "About this many matches per worker process.", lo=1, hi=400),
    # ---- logins ----
    _s("login_parallel", "Logins at the same time", "logins", "int", "live", "gate",
       "Full logins running at once (LOGIN_PARALLEL).", attr="parallel", lo=1, hi=50),
    _s("login_interval_s", "Seconds between two logins", "logins", "float", "live", "gate",
       "LOGIN_INTERVAL_S.", attr="interval_s", lo=0, hi=60, step=0.1),
    _s("login_cooldown_s", "Pause after HTTP 429 (s)", "logins", "float", "live", "gate",
       "No login at all for this long after the login server answers “too many requests” (LOGIN_COOLDOWN_S).",
       attr="cooldown_s", lo=1, hi=3600),
    # ---- BR ----
    _s("br_leave_after_s", "Leave after (s)", "br", "float", "live", "protocol",
       "Leaves a BR match alive after this many seconds (BR_LEAVE_AFTER_S). 0 = stay.", lo=0, hi=3600),
    _s("br_leave_on_death", "Leave on death", "br", "bool", "live", "protocol",
       "Leaves as soon as the bot is dead (BR_LEAVE_ON_DEATH)."),
    _s("br_insta_leave", "Leave instantly on death", "br", "bool", "live", "protocol",
       "Leaves the moment the death is announced, not at low HP (BR_INSTA_LEAVE)."),
    _s("br_leave_hp", "Leave at HP", "br", "int", "live", "protocol",
       "Leaves alive when HP drops to this value (BR_LEAVE_HP). 0 = off.", lo=0, hi=200),
    _s("br_death_max_s", "Backup leave with death watch (s)", "br", "float", "live", "protocol",
       "With “leave on death”: leaves alive after this many seconds anyway (BR_DEATH_MAX_S).", lo=60, hi=3600),
    _s("br_no_data_s", "No game data after (s)", "br", "float", "live", "protocol",
       "Joined but the server sends no game data after this long: match given up (BR_NO_DATA_S). 0 = off.",
       lo=0, hi=3600),
    _s("br_no_data_kb", "… under (KB)", "br", "int", "live", "protocol",
       "Data threshold for the rule above (BR_NO_DATA_KB).", lo=0, hi=100000),
    # ---- CS ----
    _s("cs_zone_first", "Safe zone before the enemy", "cs", "bool", "live", "protocol",
       "Out of the safe zone, the bot goes back in and does nothing else until it is 6 m inside; an enemy at the edge "
       "is circled 4 m inside the zone, never outside (CS_ZONE_FIRST)."),
    _s("cs_heal", "Heal with medkits", "cs", "bool", "live", "protocol",
       "Uses a medkit (item 244, 2 per round) as soon as HP drops to the value below (CS_HEAL)."),
    _s("cs_heal_hp", "Heal at HP", "cs", "int", "live", "protocol", "HP at which the bot heals (out of 200, CS_HEAL_HP).",
       lo=10, hi=190),
    _s("cs_buy", "Buy the pistol at round start", "cs", "bool", "live", "protocol",
       "During the preparation: opens the shop, buys the pistol and takes it in hand, every round (CS_BUY)."),
    _s("cs_item_channel", "Heal / buy channel", "cs", "str", "live", "protocol",
       "auto = reliable with the session key when the bot has it, otherwise like the drone (unreliable, match key); "
       "session; unrel (CS_ITEM_CHANNEL)."),
    _s("cs_lane", "Separate lanes, then chase", "cs", "bool", "live", "protocol",
       "At the red circle each bot takes a different lane of its town (paths of real players, data/cs_lanes.json) "
       "and runs it to the end; an enemy closer than 30 m is chased right away (CS_LANE)."),
    _s("cs_pack", "Keep the team together", "cs", "bool", "live", "protocol",
       "The bots follow one leader (lowest player number) and stay within 2.5 m of him; in a fight they all circle the "
       "same enemy (CS_PACK)."),
    _s("cs_straight", "Go straight to the enemy side", "cs", "bool", "live", "protocol",
       "At the start of a round, with no enemy in view: run straight to the opposite base, inside the zone, until an "
       "enemy is seen (CS_STRAIGHT)."),
    _s("cs_wall_turn", "Change direction at walls", "cs", "bool", "live", "protocol",
       "On: after hitting a wall the bot turns, goes around or slides along it. Off: it keeps its direction "
       "(CS_WALL_TURN)."),
    _s("cs_foe_trace", "Follow the enemy's route", "cs", "bool", "live", "protocol",
       "The bot runs along the path the enemy took (his recorded positions) until it reaches him (CS_FOE_TRACE)."),
    _s("cs_chase", "Chase the enemy", "cs", "bool", "next", "protocol",
       "The bot runs towards the enemy (CS_CHASE). Team Bot teams always chase.", ),
    _s("cs_skill_test", "Drone skill", "cs", "bool", "next", "protocol",
       "Casts the active skill (drone) in Clash Squad (CS_SKILL_TEST)."),
    _s("cs_skill_per_round", "Max drones per round", "cs", "int", "live", "protocol",
       "0 = no limit: cast again as soon as the cooldown is over and an enemy is in range. 1 = old behaviour, one "
       "drone per round (CS_SKILL_PER_ROUND).", lo=0, hi=1),
    _s("cs_skill_every_s", "Drone cooldown (s)", "cs", "float", "live", "protocol",
       "Wait after a drone the server accepted (server cooldown: 60 s) (CS_SKILL_EVERY_S).", lo=10, hi=300),
    _s("cs_drone_range_m", "Drone range (m)", "cs", "float", "live", "protocol",
       "Casts only when the nearest enemy is closer than this (CS_DRONE_RANGE_M).", lo=5, hi=200),
    _s("cs_skill_unreliable", "Drone over unreliable channel", "cs", "bool", "live", "protocol",
       "Skill messages sent unreliable with the match key (CS_SKILL_UNRELIABLE)."),
    _s("cs_skill_relmatch", "Drone over reliable + match key", "cs", "bool", "live", "protocol",
       "Test mode for skill messages (CS_SKILL_RELMATCH). Wins over the one above."),
    _s("cs_route", "Use known routes", "cs", "bool", "live", "protocol", "Patrols through safe cells (CS_ROUTE)."),
    _s("cs_walkmap", "Walk map memory", "cs", "bool", "live", "protocol",
       "Remembers walkable cells between matches (CS_WALKMAP)."),
    _s("cs_loop_walk", "Walk in loops", "cs", "bool", "live", "protocol", "Slow looping walk (CS_LOOP_WALK)."),
    _s("cs_tp_ack", "Answer teleports", "cs", "bool", "live", "protocol",
       "Acknowledges the server's position resets (CS_TP_ACK)."),
    # ---- UDP ----
    _s("udp_state_sync", "Send player state", "udp", "bool", "live", "protocol", "UDP_STATE_SYNC."),
    _s("udp_time_sync", "Answer time sync", "udp", "bool", "live", "protocol", "UDP_TIME_SYNC."),
    _s("udp_quit_on_leave", "Send quit when leaving", "udp", "bool", "live", "protocol",
       "Leaves like the real client (191) instead of closing the socket (UDP_QUIT_ON_LEAVE)."),
    _s("udp_quit_grace_s", "Wait after quit (s)", "udp", "float", "live", "protocol", "UDP_QUIT_GRACE_S.",
       lo=0, hi=30, step=0.1),
    _s("udp_ack_delay_s", "Grouped ACK delay (s)", "udp", "float", "live", "protocol", "UDP_ACK_DELAY_S (0 to 1).",
       lo=0, hi=1, step=0.05),
    _s("udp_loading_end", "Send loading end", "udp", "bool", "next", "protocol", "UDP_LOADING_END."),
    _s("udp_join_seq", "Join sequence", "udp", "bool", "next", "protocol", "UDP_JOIN_SEQ."),
    _s("udp_join_unrel", "Join unreliable", "udp", "bool", "next", "protocol", "UDP_JOIN_UNREL."),
    _s("udp_join_replay", "Replay real client entry", "udp", "bool", "next", "protocol",
       "Replays captures/entry_replay.json in every match (UDP_JOIN_REPLAY)."),
    _s("join_token_split", "Join token split", "udp", "int", "next", "protocol", "JOIN_TOKEN_SPLIT.", lo=1, hi=100000),
    _s("native_search", "Search in the account's region", "udp", "bool", "live", "protocol",
       "Searches in the account's own region instead of BD (NATIVE_SEARCH). Next search."),
    # ---- lobby ----
    _s("lobby_prematch_calls", "Lobby calls before a match", "lobby", "bool", "live", "protocol",
       "LOBBY_PREMATCH_CALLS."),
    _s("activity_lobby_calls", "Activity lobby calls", "lobby", "bool", "live", "protocol", "ACTIVITY_LOBBY_CALLS."),
    _s("activity_rewards_enabled", "Claim activity rewards", "lobby", "bool", "live", "protocol",
       "ACTIVITY_REWARDS_ENABLED."),
    _s("equip_character", "Equip character", "lobby", "bool", "live", "protocol", "EQUIP_CHARACTER."),
    _s("gw_anticheat_report", "Gateway anti-cheat report", "lobby", "bool", "live", "protocol",
       "GW_ANTICHEAT_REPORT."),
    _s("gw_anticheat_oracle", "Anti-cheat oracle", "lobby", "str", "live", "protocol", "GW_ANTICHEAT_ORACLE."),
    _s("strip_device_session_key", "Strip device session key", "lobby", "bool", "live", "protocol",
       "STRIP_DEVICE_SESSION_KEY."),
    # ---- charge ----
    _s("server_max_matches", "Max matches on this server", "load", "int", "live", "protocol",
       "New matches wait above this number (SERVER_MAX_MATCHES). 0 = no limit.", lo=0, hi=100000),
    _s("load_guard_lag_ms", "Hold new matches above lag (ms)", "load", "int", "live", "protocol",
       "LOAD_GUARD_LAG_MS. 0 = off.", lo=0, hi=100000),
    _s("load_guard_resume_ms", "Resume under lag (ms)", "load", "int", "live", "protocol", "LOAD_GUARD_RESUME_MS.",
       lo=0, hi=100000),
    _s("udp_capture", "UDP captures per process", "load", "int", "live", "protocol",
       "Raw packet captures of the first N BR matches of each process (UDP_CAPTURE). 0 = none.", lo=0, hi=100000),
    # ---- équipes / guilde ----
    _s("honor_min", "Ranked: minimum honor", "teams", "int", "live", "teamlab",
       "A Ranked CS bot under this honor score is swapped / its team goes to Clash Squad (TEAMLAB_HONOR_MIN).",
       attr="HONOR_MIN", lo=0, hi=100),
    _s("guild_auto", "Claim guild rewards automatically", "teams", "bool", "live", "teamlab", "GUILD_AUTO.",
       attr="GUILD_AUTO"),
    _s("guild_claim_min_glory", "… from weekly glory", "teams", "int", "live", "teamlab", "GUILD_CLAIM_MIN_GLORY.",
       attr="GUILD_CLAIM_MIN_GLORY", lo=0, hi=1000000),
    _s("guild_claim_every_s", "… at most every (s)", "teams", "float", "live", "teamlab", "GUILD_CLAIM_EVERY_S.",
       attr="GUILD_CLAIM_EVERY_S", lo=0, hi=604800),
    _s("guild_store_buy", "Guild store items (item:price, …)", "teams", "str", "live", "teamlab",
       "Bought every week with the guild tokens, e.g. 10500016:200 (GUILD_STORE_BUY).", attr="GUILD_STORE_BUY"),
]
BY_KEY = {s["key"]: s for s in SPECS}
_STORE_RE = re.compile(r"\d+:\d+")


# ---------- .env ----------
def _read_env_file(path: str = ENV_FILE) -> Dict[str, str]:
    out: Dict[str, str] = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out.setdefault(k.strip(), v.strip().strip('"').strip("'"))   # 1re occurrence, comme _load_dotenv
    except OSError:
        pass
    return out


def write_env(updates: Dict[str, str], path: str = ENV_FILE) -> None:
    """Remplace « KEY=… » (1re ligne active) dans .env, retire les doublons actifs, ajoute les clés absentes ;
    commentaires et autres lignes gardés tels quels."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    except OSError:
        lines = []
    done = set()
    out = []
    for line in lines:
        s = line.strip()
        key = s.split("=", 1)[0].strip() if s and not s.startswith("#") and "=" in s else None
        if key in updates:
            if key in done:
                continue
            out.append(f"{key}={updates[key]}")
            done.add(key)
        else:
            out.append(line)
    missing = [k for k in updates if k not in done]
    if missing:
        out.append("")
        out.append("# set from the Settings page")
        out.extend(f"{k}={updates[k]}" for k in missing)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")
    os.replace(tmp, path)


# ---------- conversion ----------
def _bool(v: Any) -> bool:
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on", "oui")
    return bool(v)


def convert(spec: Dict[str, Any], value: Any) -> Any:
    kind, label = spec["kind"], spec["label"]
    if kind == "bool":
        return _bool(value)
    if kind in ("int", "float"):
        try:
            num = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{label}: a number is expected")
        if num != num:
            raise ValueError(f"{label}: a number is expected")
        if spec["min"] is not None and num < spec["min"]:
            raise ValueError(f"{label}: at least {spec['min']}")
        if spec["max"] is not None and num > spec["max"]:
            raise ValueError(f"{label}: at most {spec['max']}")
        if kind == "int":
            if num != int(num):
                raise ValueError(f"{label}: a whole number is expected")
            return int(num)
        return num
    text = str(value if value is not None else "").strip()
    if len(text) > 500:
        raise ValueError(f"{label}: too long")
    if spec["key"] == "guild_store_buy":
        items = [i for i in text.replace(" ", "").split(",") if i]
        bad = [i for i in items if not _STORE_RE.fullmatch(i)]
        if bad:
            raise ValueError(f"{label}: “{bad[0]}” is not item:price (e.g. 10500016:200)")
        text = ",".join(items)
    if spec["key"] == "HOST" and not re.fullmatch(r"[A-Za-z0-9.:\-]+", text or "-"):
        raise ValueError(f"{label}: invalid address")
    return text


def _env_text(spec: Dict[str, Any], value: Any) -> str:
    if spec["kind"] == "bool":
        return "1" if value else "0"
    return str(value)


class SiteSettings:
    """Lecture / écriture des réglages de la page. `db` : base du TeamLab (setting / set_setting)."""

    def __init__(self, db: Any, protocol: Any, teamlab_module: Any, gate: Any = None):
        self.db = db
        self.p = protocol
        self.tl = teamlab_module
        self.gate = gate
        self.base = {s["key"]: self._current(s) for s in SPECS if s["target"] != "env"}   # .env / défaut
        self.overrides = self._load()

    # ---------- stockage ----------
    def _load(self) -> Dict[str, Any]:
        try:
            raw = json.loads(self.db.setting(DB_KEY) or "{}")
        except ValueError:
            raw = {}
        out = {}
        for k, v in (raw if isinstance(raw, dict) else {}).items():
            spec = BY_KEY.get(k)
            if spec and spec["target"] != "env":
                try:
                    out[k] = convert(spec, v)
                except ValueError:
                    continue
        return out

    def _save(self):
        self.db.set_setting(DB_KEY, json.dumps(self.overrides, ensure_ascii=False))

    # ---------- valeurs en service ----------
    def _current(self, spec: Dict[str, Any]) -> Any:
        t, attr = spec["target"], spec["attr"]
        if t == "protocol":
            return self.p.tunables().get(attr)
        if t == "teamlab":
            v = getattr(self.tl, attr)
            if attr == "GUILD_STORE_BUY":
                return ",".join(f"{a}:{b}" for a, b in v)
            return v
        if t == "gate":
            return getattr(self.gate, attr) if self.gate is not None else None
        env = _read_env_file()
        raw = env.get(attr, os.environ.get(attr))
        if raw is None:
            return None
        try:
            return convert(spec, raw)
        except ValueError:
            return raw

    # ---------- application ----------
    def _apply(self, values: Dict[str, Any]) -> Dict[str, int]:
        """Valeurs (déjà converties) -> modules / workers / .env. Retourne {"workers": n prévenus}."""
        proto, gate, env = {}, {}, {}
        for k, v in values.items():
            spec = BY_KEY[k]
            t, attr = spec["target"], spec["attr"]
            if t == "protocol":
                proto[attr] = v
            elif t == "teamlab":
                if attr == "GUILD_STORE_BUY":
                    v = [tuple(int(x) for x in i.split(":", 1)) for i in str(v).split(",") if _STORE_RE.fullmatch(i)]
                setattr(self.tl, attr, v)
            elif t == "gate":
                gate[attr] = v
            else:
                env[attr] = _env_text(spec, v)
        workers = 0
        if proto:
            self.p.apply_tunables(proto)                       # processus principal (UDP_WORKERS=0 compris)
            pool = getattr(self.p, "_match_pool", None)
            if pool is not None and hasattr(pool, "set_tunables"):
                workers = pool.set_tunables(self.p.tunables())   # workers : parties en cours comprises
        if gate and self.gate is not None:
            self.gate.set_limits(**gate)
        if env:
            write_env(env)
        return {"workers": workers}

    def init_server(self) -> None:
        """Au démarrage : les choix de la page l'emportent sur .env."""
        if self.overrides:
            self._apply(self.overrides)
            diag.event("SETTINGS", "loaded", level="info", n=len(self.overrides), keys=",".join(sorted(self.overrides)))

    def update(self, values: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(values, dict) or not values:
            raise ValueError("nothing to save")
        clean = {}
        for k, v in values.items():
            spec = BY_KEY.get(k)
            if spec is None:
                raise ValueError(f"unknown setting {k!r}")
            clean[k] = convert(spec, v)
        r = self._apply(clean)
        for k, v in clean.items():
            if BY_KEY[k]["target"] != "env":
                self.overrides[k] = v
        self._save()
        diag.event("SETTINGS", "saved", level="info", **{k: str(v)[:60] for k, v in clean.items()})
        return {**self.view(), "applied": r}

    def reset(self, keys: List[str]) -> Dict[str, Any]:
        """Retire les choix de la page : valeur de .env / par défaut, tout de suite."""
        back = {k: self.base[k] for k in keys if k in self.overrides and k in self.base}
        for k in back:
            self.overrides.pop(k, None)
        r = self._apply({k: v for k, v in back.items() if v is not None}) if back else {"workers": 0}
        self._save()
        return {**self.view(), "applied": r}

    def view(self) -> Dict[str, Any]:
        items = []
        for s in SPECS:
            items.append({k: s[k] for k in ("key", "label", "group", "kind", "applies", "help", "min", "max", "step")}
                         | {"value": self._current(s), "default": self.base.get(s["key"]),
                            "changed": s["key"] in self.overrides,
                            "running": os.environ.get(s["attr"]) if s["target"] == "env" else None})
        pool = getattr(self.p, "_match_pool", None)
        workers = sum(1 for w in pool.workers if w.alive) if pool is not None else 0
        return {"groups": [{"id": g, "name": n, "help": h} for g, n, h in GROUPS], "items": items,
                "workers": workers}
