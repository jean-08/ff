# -*- coding: utf-8 -*-
"""Configuration globale, lue depuis les variables d'environnement et le fichier .env."""
import os
from dataclasses import dataclass

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_dotenv(path: str):
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip().strip('"').strip("'")
            os.environ.setdefault(key, value)


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    web_host: str
    web_port: int
    storage: str            # "sqlite" (défaut) | "mongo" | "json"
    sqlite_path: str
    migrate_from_mongo: bool
    mongo_uri: str
    mongo_db: str
    json_store_path: str
    admin_username: str
    admin_password: str
    session_ttl_hours: int
    events_retention_days: int
    migrate_accounts_file: str


def load_settings() -> Settings:
    _load_dotenv(os.path.join(ROOT_DIR, ".env"))
    return Settings(
        web_host=os.environ.get("WEB_HOST", "0.0.0.0"),
        web_port=_int("WEB_PORT", 20335),
        storage=os.environ.get("STORAGE", "sqlite").strip().lower(),
        sqlite_path=os.environ.get("SQLITE_PATH", os.path.join(ROOT_DIR, "data", "ffbot.db")),
        migrate_from_mongo=os.environ.get("MIGRATE_FROM_MONGO", "0").strip().lower() in ("1", "true", "yes", "oui"),
        mongo_uri=os.environ.get("MONGO_URI", "mongodb://localhost:27017"),
        mongo_db=os.environ.get("MONGO_DB", "ffbot"),
        json_store_path=os.environ.get("JSON_STORE_PATH", os.path.join(ROOT_DIR, "data", "store.json")),
        admin_username=os.environ.get("ADMIN_USERNAME", "admin"),
        admin_password=os.environ.get("ADMIN_PASSWORD", ""),
        session_ttl_hours=_int("SESSION_TTL_HOURS", 168),
        events_retention_days=_int("EVENTS_RETENTION_DAYS", 14),
        migrate_accounts_file=os.environ.get("MIGRATE_ACCOUNTS_FILE", os.path.join(ROOT_DIR, "accounts.json")),
    )
