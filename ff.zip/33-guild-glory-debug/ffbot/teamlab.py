# -*- coding: utf-8 -*-
"""
FF Team Bot (dossier autonome, run.py) : équipes de 2 à 4 comptes de test qui jouent ensemble en Clash Squad,
plusieurs équipes en même temps, et bilan de chaque partie. Copie de ffbot/teamlab.py du projet principal
(FIXED-UPD-RANKED5, page ทีมบอท), messages en anglais pour la page web de ce dossier.

Déroulé d'une équipe (le même que tools/team_test.py du projet principal, essayé en direct le 26/10 : 4 bots,
partie trouvée et jouée par les quatre) :
  1. login de chaque compte (token_cache.json, sinon login complet à son tour : LoginGate), personnage du guide du
     nouveau joueur pour un compte neuf (api_client.equip_newbie_character), connexion à la passerelle ;
  2. le 1er compte crée l'équipe CS normale (team_create_msg), les autres y entrent avec son code (team_join_msg) ;
  3. pour chaque partie : tour de recherche de son mode (SEARCH_TURNS : une équipe en recherche à la fois), chacun se
     dit prêt (team_ready_msg), le chef lance la recherche de l'équipe (team_start_msg) ; le « match trouvé »
     (0x03 4 = 5) arrive à tous et chacun joue la partie, avec la course vers l'adversaire (CS_CHASE) forcée pour ces
     parties (opts["cs_chase"]) ;
  4. bilan de chaque partie dans data/teamlab.db : par bot, fin de partie, manches, morts, morts dans la zone,
     corrections du serveur, 144, EXP gagnée…
Une erreur (passerelle fermée, entrée refusée, pas de partie trouvée…) : l'équipe quitte tout, attend, puis se
reforme depuis le login (TEAM_MAX_RESETS fois de suite au plus, compteur remis à zéro par chaque partie jouée).

Niveau objectif (réglage « level_target » de la page, 0 = aucun) : un compte qui l'atteint passe en « maxed » (plus
choisi pour une équipe). Vérifié après chaque partie, jamais pendant (la partie va toujours au bout), et au login :
l'équipe se défait, les comptes arrivés sont remplacés par les suivants de la réserve (même ordre que pour Start),
puis elle se reforme pour la partie suivante. Plus de compte libre : l'équipe continue à moins (2 joueurs au moins),
sinon elle s'arrête.

Comptes : réserve de ce dossier (table accounts de data/teamlab.db). Ne pas y mettre un compte qui joue ailleurs
(Panel du projet principal…) : deux logins du même compte se déconnectent l'un l'autre.

Guilde : demande d'entrée (ffbot.clan, api_client.request_join_clan) pour des comptes de la réserve, voir join_clan.
"""
import asyncio
import base64
import json
import os
import random
import re
import sqlite3
import time
from collections import deque
from typing import Any, Awaitable, Callable, Deque, Dict, List, Optional, Tuple

from . import api_client, diag
from .clan import ClanJobs, SkipAccount
from .config import ROOT_DIR
from .accounts_text import parse_accounts
from .levels import EXP_TABLE, MAX_LEVEL, level_for_exp
from .models import LONE_WOLF_MIN_LEVEL, AccountBanned, new_id

DB_FILE = os.environ.get("TEAMLAB_DB", os.path.join(ROOT_DIR, "data", "teamlab.db"))
TEAM_SIZES = (2, 3, 4)
# modes des équipes (choisis sur la page, équipe par équipe) : CS normal = gabarit de création réécrit par
# team_create_msg (2.2 = 01, 2.9 = 1, sans 2.20 ; essayé de bout en bout le 26/10) ; CS Rank = gabarit Rank du
# client officiel tel quel (_TEAM_CREATE_PLAIN de protocol.py, celui du projet principal) ; Big Head = création CS
# normale en mode 16 (capture du client officiel du 28/10) ; Iron Cage Dual / Duo = Lone Wolf 2v2, carte 11
# (captures ME du 29/10) : Dual = équipe de 2 complète, Duo = aussi lançable par un joueur seul
TEAM_MODES = ("clash_squad", "cs_ranked", "big_head", "iron_cage_dual", "iron_cage_duo", "br_evolution")
TEAM_MODE_NAMES = {"clash_squad": "Clash Squad", "cs_ranked": "Ranked CS", "big_head": "Big Head",
                   "iron_cage_dual": "Iron Cage Dual", "iron_cage_duo": "Iron Cage Duo",
                   "br_evolution": "BR Evolution"}
# tailles d'équipe permises par mode (TEAM_SIZES sinon)
MODE_SIZES = {"iron_cage_dual": (2,), "iron_cage_duo": (1, 2), "br_evolution": (1, 2, 3, 4)}
# niveau minimum des comptes par mode : en dessous, recherche du chef refusée, code 32. Big Head : niveau 3 (table 5.4
# de la liste des modes, refus du 28/10 20:22) ; Iron Cage = Lone Wolf, niveau 3 (équipes de comptes niveau 2 refusées
# code 32 le 29/10 23:00-23:56, confirmé en jeu)
MODE_MIN_LEVEL = {"big_head": LONE_WOLF_MIN_LEVEL, "iron_cage_dual": LONE_WOLF_MIN_LEVEL,
                  "iron_cage_duo": LONE_WOLF_MIN_LEVEL}
TEAM_MODE = os.environ.get("TEAM_MODE", "clash_squad")       # mode par défaut avant le premier choix sur la page
TEAMS_MAX = 25                        # équipes en même temps
TEAM_MAX_RESETS = 4                   # reformations de suite sans partie jouée avant d'abandonner l'équipe
RESET_WAIT_S = 20.0                   # pause avant de reformer l'équipe
# score d'honneur (GetCreditScoreChangeInfo, 100 au départ, -4 par partie CS Rank sans dégâts) : un membre d'une
# équipe CS Rank en dessous -> l'équipe passe en CS normal (vérifié au login et après chaque partie)
HONOR_MIN = int(os.environ.get("TEAMLAB_HONOR_MIN", "95"))
MODE_SWITCH_WAIT_S = 5.0              # départ de l'équipe CS Rank -> nouvelle équipe CS normal
# pause entre deux parties, tirée au hasard : nos équipes ne lancent pas toutes leur recherche au même moment (le
# serveur opposait nos équipes CS Rank entre elles, puis refusait leur recherche, code 57 — 26/10 19:51-20:26)
BETWEEN_MATCHES_S = (5.0, 45.0)
COOLDOWN_57_S = 900.0                 # recherche refusée code 57 (équipes opposées 2-3 fois entre elles) : pause
# une équipe en recherche à la fois, par mode (projet principal, demande du 29/10 : « รอให้แต่ละทีมหาห้องทีละทีมให้เจอห้อง
# ก่อนแล้วค่อยเริ่มทีมอื่น ») : 10 équipes CS Rank en recherche en même temps malgré BETWEEN_MATCHES_S y étaient opposées
# entre elles dans 189 parties sur 286. Le serveur n'oppose que des équipes en file au même moment : tour pris avant le
# « prêt » et la recherche du chef, rendu au « match trouvé » (partie formée), au refus 57, ou une fois l'équipe quittée
# (recherche sans partie, erreur, arrêt). Activé / désactivé depuis la page, tout de suite (choix gardé dans settings,
# TeamLab.set_search_turns) ; TEAMLAB_SEARCH_TURNS : valeur tant qu'aucun choix n'est fait (0 = avant).
SEARCH_TURNS = os.environ.get("TEAMLAB_SEARCH_TURNS", "1").strip().lower() in ("1", "true", "yes", "on")
# tours désactivés : nos équipes peuvent être opposées entre elles (les deux camps sont nos bots). Drone (5506) alors
# lancé un camp à la fois (_DroneTurn) : le camp qui a le tour lance seul, le tour passe à l'autre quand son drone a
# touché ; DRONE_TURN_TIMEOUT_S sans dégâts (drone raté) : tour passé quand même. SELF_MATCH_GATHER_S : attente pour
# que les deux équipes s'inscrivent dans la même partie avant de décider.
DRONE_TURN_TIMEOUT_S = 12.0
SELF_MATCH_GATHER_S = 1.0
START_TRIES = 3                      # recherche refusée au chef (code 9…) : nouveaux essais
START_REPLY_S = 8.0                   # réponse à la recherche du chef (0x03 4 = 11, ou refus)
SEARCH_TIMEOUT_S = 240.0              # partie pas trouvée après… : équipe reformée
SEARCH_TIMEOUT_RANKED_S = 600.0       # CS Rank : file plus lente (26/10 07:34-07:46 : recherche acceptée, aucune
#                                       partie en 4 min, 3 fois de suite)
FOUND_GRACE_S = 3.0                   # les autres membres reçoivent leur « match trouvé » quelques ms après le 1er
LOGIN_TIMEOUT_S = 90.0
CACHE_MIN_LEFT_S = 1800.0             # session gardée qui expire dans moins de… : login complet (partie de ~6 min)
LOG_LINES = 150
RECENT_MATCHES = 40
# messages d'équipe (0x05) et de recherche (0x03) de la passerelle, entrée et sortie : diagnostic d'une recherche
# refusée ou sans réponse (vide = rien d'écrit)
GATEWAY_DUMP = os.environ.get("TEAMBOT_GATEWAY_DUMP", os.path.join(ROOT_DIR, "logs", "teambot-gateway.jsonl"))
CLAN_REFRESH_S = 60.0                 # page de la guilde relue au plus tous les… (équipes en cours, sessions des bots)
HONOR_GAP_S = 0.6                     # entre deux comptes pendant un relevé du score d'honneur
# Guilde (demandes du 27/10) : paliers d'activité de la guilde et personnels réclamés (api_client.claim_clan_act_award,
# claim_personal_act_rewards), puis articles du magasin de la guilde achetés avec les jetons (GUILD_STORE_BUY,
# « article:prix » séparés par des virgules ; limite par semaine : un article acheté n'est plus retenté avant la
# semaine suivante, remise à zéro le lundi vers 5 h).
#   - automatique (GUILD_AUTO) : pour chaque compte après ses parties, dès que sa gloire de la semaine dans la guilde
#     (page de la guilde, weekly_glory) atteint GUILD_CLAIM_MIN_GLORY, puis au plus toutes les GUILD_CLAIM_EVERY_S (les
#     paliers suivants arrivent avec les parties) ;
#   - manuel : bouton « Claim guild rewards » (claim_guild_all), sans condition de gloire ni d'attente.
# Chaque requête et sa réponse (ou l'erreur) : une entrée du tableau JSON de GUILD_JOURNAL (corps en hex et décodés,
# indenté), réécrit en entier à chaque appel (_journal_append).
# Guilde : celle suivie sur la page (clan_id).
GUILD_AUTO = os.environ.get("GUILD_AUTO", "1").strip().lower() not in ("0", "false", "no", "off")
GUILD_CLAIM_MIN_GLORY = int(os.environ.get("GUILD_CLAIM_MIN_GLORY", "800"))
GUILD_CLAIM_EVERY_S = float(os.environ.get("GUILD_CLAIM_EVERY_S", "1800"))
GUILD_STORE_BUY = [tuple(int(v) for v in item.split(":", 1))
                   for item in os.environ.get("GUILD_STORE_BUY", "10500016:200").replace(" ", "").split(",")
                   if re.fullmatch(r"\d+:\d+", item)]
GUILD_JOURNAL = os.environ.get("GUILD_JOURNAL", os.path.join(ROOT_DIR, "logs", "guild-rewards.json"))
GUILD_WEEK_SHIFT_S = 5 * 3600         # la semaine de la guilde commence le lundi vers 5 h (heure locale)
# champs du bilan de la poursuite (_CsChase.summary : « clé=valeur … ») gardés pour chaque bot
CHASE_FIELDS = ("rounds", "deaths", "zone_deaths", "dmg", "hits", "team", "snaps", "force144", "escapes", "frozen",
                "leads", "ran_m",
                "lag_ms", "zone_runs", "slides", "blocked", "runs", "arrived", "detours",
                "zone_enemies", "zone_spot", "zone_guess", "zone_true", "zone_117", "packs", "foe_routes", "lanes", "own", "lane_fails", "heals", "buys")   # origine du centre de la zone, manche par manche


class _ModeSwitch(Exception):
    """Équipe CS Rank avec des membres sous HONOR_MIN (`members`) : remplacés par des comptes libres d'honneur
    suffisant, sinon l'équipe passe en CS normal ; reformée tout de suite, pas un échec."""

    def __init__(self, members: List["_Member"]):
        super().__init__([m.name for m in members])
        self.members = members


def _honor(r: Dict[str, Any]) -> int:
    """Score d'honneur d'un compte de la réserve, 100 (valeur de départ) s'il n'a pas encore été relevé."""
    return 100 if r.get("honor") is None else r["honor"]


class _Regroup(Exception):
    """Un ou plusieurs membres n'étaient pas dans la partie (« match trouvé » pas reçu, ou absents des joueurs de la
    partie : 3 bots sur 4 en jeu) : partie finie normalement, puis l'équipe entière redémarre (départ, passerelles
    fermées, login complet des absents, nouvelle équipe) avant la suivante. Pas un échec."""

    def __init__(self, members: List["_Member"]):
        super().__init__([m.name for m in members])
        self.members = members


class _LevelSwap(Exception):
    """Des membres ont atteint le niveau objectif : remplacés, l'équipe reformée tout de suite, pas un échec."""

    def __init__(self, members: List["_Member"]):
        super().__init__(", ".join(m.name for m in members))
        self.members = members


class TeamError(Exception):
    """Étape de l'équipe ratée : l'équipe est reformée (ou abandonnée, voir TEAM_MAX_RESETS)."""


def _now() -> float:
    return time.time()


def match_players(p: Any, inner: Dict[int, list]) -> List[Tuple[int, str]]:
    """Joueurs de la partie [(n° de compte, pseudo)] d'après le « match trouvé » (5) : jeton 5.4 (JWT), charge
    « MatchPrepareInfo » (protobuf en base64), champ 145 = {1: compte, 2-3: région, 4: pseudo}, les 8 joueurs.
    Leur ordre n'est pas celui des n° de la partie (relevé du 27/10) : le camp se déduit des comptes de l'équipe."""
    try:
        token = inner.get(4, [b""])[0]
        payload = (token.decode() if isinstance(token, bytes) else str(token)).split(".")[1]
        info = base64.b64decode(json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
                                ["MatchPrepareInfo"])
        out = []
        for raw in p._pb_fields(info).get(145, []):
            f = p._pb_fields(raw) if isinstance(raw, bytes) else {}
            name = f.get(4, [b""])[0]
            if p._pb_int(f, 1):
                out.append((p._pb_int(f, 1), name.decode("utf-8", "replace") if isinstance(name, bytes) else ""))
        return out
    except (ValueError, KeyError, IndexError, TypeError):
        return []


def b_exp(bot: Dict[str, Any]) -> str:
    """EXP gagnée d'un bot dans le bilan d'une partie : « +92 », « ? » si elle n'a pas pu être relue."""
    return "?" if bot.get("exp") is None else f"{bot['exp']:+d}"


def parse_chase(summary: Optional[str]) -> Dict[str, Any]:
    """Bilan de _CsChase.summary -> {rounds: 4, deaths: 3, force144: "10/9" -> 10, …} (champs CHASE_FIELDS)."""
    out: Dict[str, Any] = {}
    for part in (summary or "").split():
        key, _, value = part.partition("=")
        if key not in CHASE_FIELDS:
            continue
        value = value.split("/")[0]
        try:
            out[key] = int(value)
        except ValueError:
            out[key] = None
    return out


# ================= base de données (data/teamlab.db) =================
def _journal_load(path: str) -> List[Any]:
    """Entrées d'un journal JSON : le tableau, ou à défaut tous les objets lisibles du fichier (fichier retouché à la
    main, ancien format une ligne par objet) ; [] s'il n'existe pas."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        return []
    try:
        data = json.loads(text)
        return data if isinstance(data, list) else [data]
    except ValueError:
        pass
    out, i, dec = [], 0, json.JSONDecoder()
    while True:
        while i < len(text) and text[i] in " \t\r\n[],":
            i += 1
        if i >= len(text):
            return out
        try:
            obj, i = dec.raw_decode(text, i)
        except ValueError:
            return out               # fin illisible (entrée coupée) : le reste est perdu
        out.append(obj)


def _journal_append(path: str, rec: Dict[str, Any]) -> None:
    """Ajoute `rec` au tableau JSON de `path` (indenté), en réécrivant le fichier par un fichier temporaire : il
    reste lisible même si le processus s'arrête pendant l'écriture. Un ancien journal « .jsonl » est repris."""
    entries = _journal_load(path)
    old = os.path.splitext(path)[0] + ".jsonl"
    if os.path.exists(old):
        entries = _journal_load(old) + entries
    entries.append(rec)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=4)
        f.write("\n")
    os.replace(tmp, path)
    if os.path.exists(old):
        os.remove(old)


class _Db:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.c = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA journal_mode=WAL")
        self.c.executescript("""
            CREATE TABLE IF NOT EXISTS accounts (uid TEXT PRIMARY KEY, password TEXT NOT NULL, account_id TEXT,
                nickname TEXT, level INTEGER, exp INTEGER, region TEXT, status TEXT NOT NULL DEFAULT 'new',
                note TEXT, added_at REAL, used_at REAL, clan TEXT);
            CREATE TABLE IF NOT EXISTS teams (id TEXT PRIMARY KEY, created_at REAL, ended_at REAL, status TEXT,
                size INTEGER, target INTEGER, done INTEGER NOT NULL DEFAULT 0, mode TEXT, uids TEXT, error TEXT);
            CREATE TABLE IF NOT EXISTS matches (id INTEGER PRIMARY KEY AUTOINCREMENT, team_id TEXT, started_at REAL,
                ended_at REAL, mode TEXT, server TEXT, match_id TEXT, map_id INTEGER, bots TEXT);
            CREATE INDEX IF NOT EXISTS matches_started ON matches (started_at);
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
        """)
        # joueurs de la partie (ffbot.teamlab.match_players) : colonne ajoutée aux bases d'avant
        if "players" not in {r["name"] for r in self.c.execute("PRAGMA table_info(matches)").fetchall()}:
            self.c.execute("ALTER TABLE matches ADD COLUMN players TEXT")
        # score d'honneur (GetCreditScoreChangeInfo) : colonnes ajoutées aux bases d'avant
        have = {r["name"] for r in self.c.execute("PRAGMA table_info(accounts)").fetchall()}
        # + missions du Pass réclamées (claim_rewards) : total et dernière réclamation
        for col, typ in (("honor", "INTEGER"), ("honor_at", "REAL"), ("honor_delta", "INTEGER"),
                         ("honor_change_at", "REAL"), ("ep_claimed", "INTEGER"), ("ep_claimed_at", "REAL"),
                         ("guild_tokens", "INTEGER"), ("guild_claimed_at", "REAL"), ("guild_bought", "TEXT")):
            if col not in have:
                self.c.execute(f"ALTER TABLE accounts ADD COLUMN {col} {typ}")
        # équipes encore « en cours » à l'arrêt précédent du serveur
        self.c.execute("UPDATE teams SET status = 'stopped', ended_at = COALESCE(ended_at, ?) "
                       "WHERE status NOT IN ('ended', 'failed', 'stopped')", (_now(),))

    def all(self, sql: str, args: tuple = ()) -> List[Dict[str, Any]]:
        return [dict(r) for r in self.c.execute(sql, args).fetchall()]

    def run(self, sql: str, args: tuple = ()) -> int:
        return self.c.execute(sql, args).rowcount

    def setting(self, key: str, default: Optional[str] = None) -> Optional[str]:
        row = self.c.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: str):
        self.c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))

    def close(self):
        self.c.close()


# ================= un compte connecté à la passerelle =================
class _Member:
    """Compte d'une équipe : login, passerelle (0x05 équipe, 0x03 recherche / partie trouvée), état reçu."""

    def __init__(self, team: "_Team", cred: Dict[str, Any]):
        self.team, self.cred = team, cred
        self.uid = cred["uid"]
        self.acc: Optional[Dict[str, Any]] = None
        self.id = ""                           # ID de jeu (account_id), connu après le login
        self.name = cred.get("nickname") or self.uid
        self.level, self.exp = cred.get("level"), cred.get("exp")
        self.exp_start: Optional[int] = None   # EXP au 1er relevé du profil dans cette équipe (EXP gagnée affichée)
        self.honor: Optional[int] = cred.get("honor")   # score d'honneur (dernier relevé, base au départ)
        self.reader = self.writer = None
        self.tasks: List[asyncio.Task] = []
        self.closed = False                    # passerelle fermée par le serveur
        self.info: Optional[Dict[str, Any]] = None   # dernier état d'équipe avec ses membres
        self.last: Optional[Dict[str, Any]] = None   # dernier 0x05, refus compris
        self.event = asyncio.Event()
        self.searching = False                 # 0x03 4 = 11 depuis le dernier « prêt »
        self.refused: Optional[int] = None     # code du dernier refus 0x05
        self.search_refused: Optional[int] = None   # refus de la recherche : 0x03 sans champ 4, code en 3 (48…)
        self.found: Optional[Tuple[Dict, Dict]] = None   # « match trouvé » pas encore joué (top, 5)
        self.played: set = set()
        self.state = "wait"                    # affichage : login, online, team, match…
        self.equipped = False
        self.lobby_token: Optional[str] = None     # session pour laquelle le lobby a été ouvert (prepare)
        self.seen: Deque[str] = deque(maxlen=24)   # derniers messages reçus (« 05:10 », « 03:11 »…), diagnostic
        self.live: Optional[Dict[str, Any]] = None   # état de la partie en cours / dernière (dmg, hits en direct)

    @property
    def p(self):
        return self.team.lab.p

    async def login(self):
        """Session du compte : token_cache.json si elle dure encore, sinon login complet à son tour (LoginGate)."""
        p, uid = self.p, self.uid
        self.state = "login"
        entry = p.cache_get(uid)
        ttl = getattr(p, "TOKEN_CACHE_TTL", 7200)
        if entry and _now() - float(entry.get("cached_at") or 0) > ttl - min(CACHE_MIN_LEFT_S, ttl / 2):
            p.cache_invalidate(uid, "teambot: session about to expire, full login")
            entry = None
        try:
            if entry:
                acc = await asyncio.wait_for(p.process_account_uid_pass(uid, self.cred["password"]), LOGIN_TIMEOUT_S)
            else:
                gate = self.team.lab.gate
                if gate is None:
                    acc = await asyncio.wait_for(p.process_account_uid_pass(uid, self.cred["password"]),
                                                 LOGIN_TIMEOUT_S)
                else:
                    async with gate:
                        acc = await asyncio.wait_for(p.process_account_uid_pass(uid, self.cred["password"]),
                                                     LOGIN_TIMEOUT_S)
        except AccountBanned as e:
            self.team.lab.set_account(uid, status="banned", note=str(getattr(e, "label", e))[:120])
            raise TeamError(f"{uid} is banned")
        except asyncio.TimeoutError:
            self.team.lab.set_account(uid, status="login_failed", note="login timed out")
            raise TeamError(f"{uid}: login timed out")
        if not acc:
            self.team.lab.set_account(uid, status="login_failed", note="login failed")
            raise TeamError(f"{uid}: login failed")
        self.acc = acc
        self.id = str(acc["account_id"])
        self.name = acc.get("nickname") or self.name
        self.level = acc.get("level") if acc.get("level") is not None else self.level
        self.team.lab.set_account(uid, account_id=self.id, nickname=self.name, level=self.level,
                                  region=acc.get("region"))
        # login réussi : « ok », sauf un compte « maxed » (niveau objectif atteint, voir TeamLab.set_level_target)
        self.team.lab.db.run("UPDATE accounts SET status = 'ok', note = '' WHERE uid = ? AND status != 'maxed'", (uid,))

    async def prepare(self):
        """Compte neuf : personnage + compétences du guide du nouveau joueur (rien pour un compte qui l'a déjà fait),
        puis EXP de départ (bilan de la première partie) et score d'honneur."""
        if not self.equipped:
            try:
                r = await api_client.equip_newbie_character(self.acc)
                if not r.get("skipped"):
                    self.team.note(f"{self.name}: equipped character {r.get('avatar')} + skills")
            except api_client.GameApiError as e:
                self.team.note(f"{self.name}: could not equip the character ({str(e)[:80]})", "warning")
            self.equipped = True
        if self.lobby_token != self.acc.get("token"):
            # lobby ouvert comme le vrai client, une fois par session, avant la 1re recherche (comme les Panels du projet
            # principal : lobby_login_calls puis match_lobby_calls, dont InitPlayerCSRankingInfoEx, le classement CS du
            # compte ; sans lui, la recherche CS Rank d'un compte neuf restait sans réponse, essai du 26/10 07:21)
            failed = []
            for call in (api_client.lobby_login_calls, api_client.match_lobby_calls):
                try:
                    r = await call(self.acc)
                    results = r[0] if isinstance(r, tuple) else r
                    failed += [f"{ep}: {err}" for ep, err in results if err]
                except Exception as e:
                    failed.append(f"{call.__name__}: {e!r}"[:120])
            if failed:
                self.team.note(f"{self.name}: lobby calls refused: {'; '.join(failed)[:200]}", "warning")
            self.lobby_token = self.acc.get("token")
        await self.refresh()
        # score d'honneur dès le login (avant : seulement après une partie jouée, jamais lu si la recherche échoue)
        await self.update_honor()

    async def update_honor(self):
        r = await self.team.lab.update_honor(self.uid, self.acc)
        if r:
            self.honor = r["score"]

    async def refresh(self) -> Optional[Dict[str, Any]]:
        try:
            data = await self.p.fetch_account_profile(self.acc)
        except Exception:
            data = None
        if data:
            before = self.level
            self.level = data.get("level", self.level)
            self.exp = data.get("exp", self.exp)
            if self.exp_start is None and self.exp is not None:
                self.exp_start = self.exp
            if before and self.level and self.level > before:
                self.team.note(f"{self.name}: level up {before} → {self.level}")
            self.team.lab.set_account(self.uid, level=self.level, exp=self.exp)
        return data

    def current_level(self) -> Optional[int]:
        """Niveau du profil, sinon celui de son EXP (profil pas encore lu)."""
        if self.level:
            return int(self.level)
        return level_for_exp(int(self.exp)) if self.exp is not None else None

    async def connect(self):
        p, acc = self.p, self.acc
        self.state = "connect"
        self.closed = False
        ip, port = acc["functional_addrs"].split(":")
        resolved = await p.resolve_host_cloudflare(ip)
        self.reader, self.writer = await asyncio.wait_for(asyncio.open_connection(resolved, int(port)), 10)
        p.gateway_bind_region(self.writer, acc["region"])
        token = await p.build_tcp_startup_packet(acc["account_id"], acc["token"], acc["server_time"], acc["aes_ak"],
                                                 acc["iv_i"], region=acc["region"], typ="OnLine")
        self.writer.write(bytes.fromhex(token))
        self.writer.write(await p.send_keep_alive(acc["region"]))
        await self.writer.drain()
        await p.gateway_send(self.writer, p.GW_SPECIAL_MODES, acc["aes_ak"], acc["iv_i"])
        self.tasks = [asyncio.create_task(self._read(), name=f"teamlab-gw-{self.uid}"),
                      asyncio.create_task(self._keepalive(), name=f"teamlab-ka-{self.uid}")]
        self.state = "online"

    async def send(self, msg: Tuple[int, bytes]):
        self.event.clear()                     # wait_team : seulement les réponses à cette demande
        self._dump("out", msg[0], msg[1])
        await self.p.gateway_send(self.writer, msg, self.acc["aes_ak"], self.acc["iv_i"])

    async def _keepalive(self):
        try:
            while True:
                await asyncio.sleep(self.p.GATEWAY_KEEPALIVE_S)
                self.writer.write(self.p.gateway_keepalive(self.writer))
                await self.writer.drain()
        except (ConnectionError, OSError, asyncio.TimeoutError):
            self.closed = True

    async def _read(self):
        frames = self.p._GatewayFrames()
        try:
            while True:
                data = await self.reader.read(65536)
                if not data:
                    break
                for typ, body in frames.feed(data):
                    try:
                        self._frame(typ, body)
                    except Exception as e:      # message inattendu : jamais la fin de la lecture
                        diag.event("TEAMLAB", "frame", level="warning", exc=e, typ=typ)
        except (ConnectionError, OSError):
            pass
        self.closed = True

    def _dump(self, way: str, typ: int, body: bytes):
        if not GATEWAY_DUMP or typ not in (0x03, 0x05):
            return
        try:
            with open(GATEWAY_DUMP, "a", encoding="utf-8") as f:
                f.write(json.dumps({"t": round(_now(), 3), "uid": self.uid, "id": self.id, "dir": way, "type": typ,
                                    "hex": body.hex()}) + "\n")
        except OSError:
            pass

    def _frame(self, typ: int, body: bytes):
        p = self.p
        self._dump("in", typ, body)
        if typ == p.GW_TEAM:
            info = p.team_info(body)
            if info is None:
                return
            self.seen.append(f"05:{info['kind']}" if info["kind"] is not None else f"05:refused {info['error']}")
            if info["kind"] == 10:
                self.searching = True          # 4 = 10 : l'équipe passe en recherche (avant le 0x03 4 = 11)
            if info["kind"] is None:
                self.refused = info["error"]
            elif info["members"] or info["kind"] == p.TEAM_LEFT:
                self.info = info
            self.last = info
            self.event.set()
        elif typ == 0x03:
            top = p._pb_fields(body)
            kind = p._pb_int(top, 4)
            self.seen.append(f"03:{kind}" if kind is not None else f"03:refused {p._pb_int(top, 3)}")
            if kind is None and p._pb_int(top, 3) is not None:
                # recherche refusée juste après le 4 = 10 de l'équipe (CS Rank du 26/10 07:29 : {1: compte, 2: 3, 3: 48})
                self.search_refused = p._pb_int(top, 3)
            if kind == 11:
                self.searching = True
            elif kind == 5:
                inner = p._pb_msg(top, 5)
                match_id = p._pb_int(inner, 1)
                if match_id not in self.played:
                    self.played.add(match_id)
                    self.found = (top, inner)

    async def wait_team(self, kinds, timeout: float) -> Optional[Dict[str, Any]]:
        """Prochain 0x05 de type `kinds` (ou refus) reçu depuis le dernier send(), None après `timeout`."""
        end = time.monotonic() + timeout
        while True:
            if self.event.is_set():
                self.event.clear()
                if self.last and (self.last["kind"] in kinds or self.last["kind"] is None):
                    return self.last
            left = end - time.monotonic()
            if left <= 0:
                return None
            try:
                await asyncio.wait_for(self.event.wait(), left)
            except asyncio.TimeoutError:
                return None

    async def close(self):
        for t in self.tasks:
            t.cancel()
        self.tasks = []
        if self.writer:
            try:
                self.writer.close()
            except Exception:
                pass
        self.writer = self.reader = None
        self.info = None
        if self.state not in ("banned",):
            self.state = "wait"

    def view(self) -> Dict[str, Any]:
        live = self.live or {}
        gained = self.exp - self.exp_start if self.exp is not None and self.exp_start is not None else None
        return {"uid": self.uid, "id": self.id, "name": self.name, "level": self.current_level(), "state": self.state,
                "exp": self.exp, "exp_gained": gained, "dmg": live.get("dmg"), "hits": live.get("hits"),
                "hp": live.get("hp"), "heals": live.get("heals"), "healing": bool(live.get("healing")),
                "heals_sent": live.get("heals_sent"), "confirmed": live.get("confirmed")}


# ================= file des recherches =================
class _SearchTurns:
    """Tours de recherche (voir SEARCH_TURNS) : par mode, une équipe en recherche, les autres en file dans l'ordre
    d'arrivée. Désactivés (set_enabled) : la file se vide, chacune cherche aussitôt, sans tour."""

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.holder: Dict[str, Tuple[str, float]] = {}    # mode -> (équipe en recherche, depuis)
        self.waiting: Dict[str, List[str]] = {}           # mode -> équipes en attente, la prochaine d'abord
        self._changed = asyncio.Event()                   # remplacé à chaque changement : réveille toute la file

    def _notify(self):
        ev, self._changed = self._changed, asyncio.Event()
        ev.set()

    async def take(self, mode: str, team_id: str) -> bool:
        """Attend son tour : True une fois pris, False si les tours sont désactivés (recherche sans tour)."""
        queue = self.waiting.setdefault(mode, [])
        queue.append(team_id)
        try:
            while self.enabled:
                if mode not in self.holder and queue[0] == team_id:
                    self.holder[mode] = (team_id, _now())
                    return True
                await self._changed.wait()
            return False
        finally:
            queue.remove(team_id)
            self._notify()

    def give(self, mode: str, team_id: str):
        held = self.holder.get(mode)
        if held and held[0] == team_id:
            del self.holder[mode]
            self._notify()

    def set_enabled(self, on: bool):
        self.enabled = on
        self._notify()

    def place(self, mode: str, team_id: str) -> Optional[int]:
        """Rang de l'équipe dans la file de son mode (1 = la prochaine), None hors de la file."""
        queue = self.waiting.get(mode) or []
        return queue.index(team_id) + 1 if team_id in queue else None

    def view(self) -> Dict[str, Any]:
        return {mode: {"searching": held[0], "since": held[1], "waiting": list(self.waiting.get(mode) or [])}
                for mode, held in self.holder.items()}


class _DroneTurn:
    """Drone lancé un camp à la fois quand nos équipes sont opposées entre elles (tours de recherche désactivés).
    `sides` = id des équipes (camps), triés, les mêmes pour toutes. Le camp qui a le tour lance seul ; le tour passe
    au suivant quand son drone a touché (report_damage) ou DRONE_TURN_TIMEOUT_S après l'avoir reçu (drone raté, pas
    encore lancé : la partie ne reste pas bloquée). Partagé par les équipes de la partie dans le processus principal
    (ces parties ne vont pas dans un worker, qui ne pourrait pas le partager)."""

    def __init__(self, sides: List[str], now: float):
        self.sides = list(sides)
        self.i = 0
        self.until = now + DRONE_TURN_TIMEOUT_S

    def _holder(self) -> str:
        return self.sides[self.i % len(self.sides)]

    def _advance(self, now: float) -> None:
        self.i += 1
        self.until = now + DRONE_TURN_TIMEOUT_S

    def may_cast(self, side: Optional[str], now: float) -> bool:
        """Le camp `side` peut-il lancer maintenant (il a le tour) ? Délai dépassé et un autre camp demande : tour passé."""
        if side is None:
            return True
        if now >= self.until and side != self._holder():
            self._advance(now)
        return side == self._holder()

    def report_damage(self, side: Optional[str], now: float) -> None:
        """Le drone du camp `side` vient de toucher : s'il avait le tour, il passe au camp suivant tout de suite."""
        if side is not None and side == self._holder():
            self._advance(now)


# ================= une équipe =================
class _Team:
    def __init__(self, lab: "TeamLab", tid: str, creds: List[Dict[str, Any]], target: int, mode: str = TEAM_MODE):
        self.lab, self.id, self.target, self.mode = lab, tid, target, mode
        self.members = [_Member(self, c) for c in creds]
        self.size = len(creds)
        self.state = "starting"
        self.code: Optional[str] = None
        self.done = 0
        self.error: Optional[str] = None
        self.created_at = _now()
        self.match_at: Optional[float] = None
        self.match_id: Optional[int] = None    # partie en cours (5.1 du « match trouvé »)
        self.vs: Optional[Dict[str, List[str]]] = None   # pseudos des deux camps de la partie en cours
        self.last_match_at: Optional[float] = None
        self.server: Optional[str] = None
        self.stop_after_match = False
        self.log: Deque[Tuple[float, str, str]] = deque(maxlen=LOG_LINES)
        self.resets = 0
        self.task: Optional[asyncio.Task] = None
        self.turn: Optional[str] = None        # mode du tour de recherche tenu (voir SEARCH_TURNS)
        self._drone_turn: Optional[_DroneTurn] = None   # drone un camp à la fois, contre nos propres équipes

    def note(self, text: str, level: str = "info"):
        self.log.append((_now(), level, text))
        diag.event("TEAMLAB", "note", level="warning" if level == "error" else "debug", team=self.id, msg=text[:200])

    def _save(self, **fields):
        fields.setdefault("done", self.done)
        cols = ", ".join(f"{k} = ?" for k in fields)
        self.lab.db.run(f"UPDATE teams SET {cols} WHERE id = ?", (*fields.values(), self.id))

    @property
    def stopping(self) -> bool:
        return self.stop_after_match

    def _goal_reached(self) -> bool:
        return bool(self.target) and self.done >= self.target

    def leader(self) -> _Member:
        info = next((m.info for m in self.members if m.info and m.info.get("members")), None)
        lead = str((info or {}).get("leader") or "")
        return next((m for m in self.members if m.id == lead), self.members[0])

    async def run(self):
        try:
            while not self.stopping and not self._goal_reached():
                try:
                    await self._form()
                    await self._play_loop()
                except _ModeSwitch as e:
                    # pas un échec : membres d'honneur trop bas remplacés (sinon équipe en CS normal), sans compter
                    # d'essai
                    await self._dissolve()
                    if self.stopping:
                        break
                    await self._honor_swap(e.members)
                    self.state = "retry"
                    await asyncio.sleep(MODE_SWITCH_WAIT_S)
                except _Regroup as e:
                    # pas un échec : partie jouée à moins, l'équipe est refaite au complet pour la suivante
                    await self._dissolve()
                    if self.stopping:
                        break
                    for m in e.members:
                        self.p_invalidate(m, "teambot: not in the team's match")
                    self.state = "retry"
                    self.note(f"Not in the last match: {', '.join(m.name for m in e.members)} · all bots restart and "
                              f"re-form the team ({len(self.members)} players) in {MODE_SWITCH_WAIT_S:.0f} s", "warning")
                    await asyncio.sleep(MODE_SWITCH_WAIT_S)
                except _LevelSwap as e:
                    # pas un échec non plus : les comptes arrivés au niveau objectif sont remplacés, sans compter d'essai
                    await self._dissolve()
                    if self.stopping or not await self._replace(e.members):
                        break
                    self.state = "retry"
                    await asyncio.sleep(MODE_SWITCH_WAIT_S)
                except TeamError as e:
                    self.resets += 1
                    self.note(f"{e}", "error")
                    if self.resets > TEAM_MAX_RESETS:
                        self.error = f"{e} (gave up after {TEAM_MAX_RESETS} retries)"
                        self.state = "failed"
                        break
                    await self._dissolve()
                    if self.stopping:
                        break
                    self.state = "retry"
                    self.note(f"Re-forming the team in {RESET_WAIT_S:.0f} s (retry {self.resets}/{TEAM_MAX_RESETS})")
                    await asyncio.sleep(RESET_WAIT_S)
                except Exception as e:
                    self.resets += 1
                    self.note(f"Error: {e!r}"[:200], "error")
                    diag.event("TEAMLAB", "exception", level="error", exc=e, tb=True, team=self.id)
                    if self.resets > TEAM_MAX_RESETS:
                        self.error = repr(e)[:200]
                        self.state = "failed"
                        break
                    await self._dissolve()
                    if self.stopping:
                        break
                    self.state = "retry"
                    await asyncio.sleep(RESET_WAIT_S)
            if self.state != "failed":
                self.state = "ended"
        except asyncio.CancelledError:
            self.state = "stopped"
            raise
        finally:
            try:
                await self._dissolve()
            except (asyncio.CancelledError, Exception):
                pass                           # 2e annulation (arrêt du serveur) : le bilan ci-dessous d'abord
            for m in self.members:
                m.state = "wait"
            self._save(status=self.state, ended_at=_now(), error=self.error)
            self.note({"ended": f"Finished · {self.done} matches played", "failed": f"Stopped: {self.error}",
                       "stopped": f"Stopped · {self.done} matches played"}.get(self.state, self.state))
            self.lab._team_done(self)

    async def _form(self):
        """Login, passerelle, puis l'équipe : le 1er compte la crée, les autres y entrent."""
        self.state = "login"
        self.code = None
        for m in self.members:
            if self.stopping:
                raise TeamError("stopped during login")
            await m.login()
            await m.prepare()
        self._level_check()                    # niveau du profil lu à l'instant : déjà arrivé = remplacé avant de jouer
        self._honor_check()
        self.state = "connect"
        for m in self.members:
            try:
                await m.connect()
            except (OSError, asyncio.TimeoutError) as e:
                # session gardée refusée par la passerelle : login complet à la prochaine formation
                self.p_invalidate(m, "teambot: gateway connect failed")
                raise TeamError(f"{m.name}: cannot connect to the gateway ({e!r})"[:160])
        await asyncio.sleep(1.5)
        for m in self.members:
            if m.closed:
                self.p_invalidate(m, "teambot: gateway closed at once")
                raise TeamError(f"{m.name}: the gateway closed the connection")
        self.state = "forming"
        p = self.lab.p
        leader, joiners = self.members[0], self.members[1:]
        cv = leader.acc["client_version"]
        # encore dans l'équipe d'un essai précédent (arrêt sans départ) : on la quitte d'abord
        for m in self.members:
            await m.send(p.team_leave_msg(m.id))
            await m.wait_team({p.TEAM_LEFT, p.TEAM_MEMBER_LEFT}, 2)
        await asyncio.sleep(0.3)
        await leader.send(p.team_create_msg(cv, self.mode))
        info = await leader.wait_team({p.TEAM_CREATED}, 10)
        if not info or not info.get("code"):
            raise TeamError("Team creation failed" + (f" (code {info['error']})" if info and info.get("error") else ""))
        self.code = info["code"]
        self.note(f"{leader.name} created team {self.code}")
        for m in joiners:
            await m.send(p.team_join_msg(self.code, m.acc["client_version"], m.acc.get("level")))
            r = await m.wait_team({p.TEAM_JOINED, p.TEAM_CREATED}, 10)
            if not r:
                raise TeamError(f"{m.name}: no answer when joining team {self.code}")
            if r["kind"] is None:
                raise TeamError(f"{m.name}: could not join team {self.code} (code {r['error']})")
            m.state = "team"
        leader.state = "team"
        await asyncio.sleep(2.0)
        count = max((len(m.info["members"]) for m in self.members if m.info), default=0)
        if count < self.size:
            raise TeamError(f"Team {self.code} has only {count}/{self.size} players")
        self.note(f"Team {self.code} complete: {count}/{self.size} players")
        self.state = "team"

    def _honor_check(self):
        """Équipe CS Rank dont des membres ont un score d'honneur < HONOR_MIN : _ModeSwitch (voir _honor_swap)."""
        if self.mode != "cs_ranked":
            return
        low = [m for m in self.members if m.honor is not None and m.honor < HONOR_MIN]
        if low:
            raise _ModeSwitch(low)

    async def _honor_swap(self, low: List[_Member]):
        """Membres `low` (honneur < HONOR_MIN) remplacés par les comptes libres d'honneur suffisant les mieux notés :
        l'équipe reste en CS Rank, les comptes sortis reviennent dans la réserve (pour une équipe d'honneur bas). Pas
        assez de comptes : l'équipe entière passe en CS normal, comme avant."""
        names = ", ".join(f"{m.name} {m.honor}" for m in low)
        async with self.lab.pick_lock:         # deux équipes qui remplacent en même temps : jamais le même compte
            free, _ = await self.lab.free_accounts(None, MODE_MIN_LEVEL.get(self.mode, 0))
            good = sorted((r for r in free if _honor(r) >= HONOR_MIN), key=_honor, reverse=True)[:len(low)]
            if len(good) == len(low):
                new = [_Member(self, c) for c in good]
                for c in good:
                    self.lab.set_account(c["uid"], used_at=_now())
                self.members = [m for m in self.members if m not in low] + new
        if len(good) == len(low):
            self._save(uids=json.dumps([m.uid for m in self.members]))
            self.note(f"Honor score below {HONOR_MIN}: {names} · replaced by "
                      f"{', '.join(f'{m.name} {m.honor}' for m in new)} · team stays in Ranked CS", "warning")
            return
        self.mode = "clash_squad"
        self._save(mode=self.mode)
        self.note(f"Honor score below {HONOR_MIN}: {names} · not enough free accounts with honor ≥ {HONOR_MIN} · "
                  f"switching to normal Clash Squad {self.size}v{self.size}", "warning")

    def _level_check(self):
        """Membres au niveau objectif (TeamLab.level_target) : passés en « maxed », puis _LevelSwap pour les remplacer
        (sauf si l'équipe s'arrête de toute façon : arrêt demandé, nombre de parties atteint)."""
        target = self.lab.level_target()
        if not target:
            return
        done = [m for m in self.members if (m.current_level() or 0) >= target]
        if not done:
            return
        for m in done:
            level = m.current_level()
            self.lab.set_account(m.uid, status="maxed", note=f"Level {level} reached (goal {target})")
            self.note(f"{m.name} reached level {level} (goal {target}) · EXP {m.exp if m.exp is not None else '?'}"
                      f" · leaves the team")
        if not (self.stopping or self._goal_reached()):
            raise _LevelSwap(done)

    async def _replace(self, gone: List[_Member]) -> bool:
        """`gone` remplacés par les comptes libres suivants de la réserve. False : moins de 2 joueurs, l'équipe s'arrête."""
        names = ", ".join(m.name for m in gone)
        async with self.lab.pick_lock:         # deux équipes qui remplacent en même temps : jamais le même compte
            creds, _ = await self.lab.free_accounts(len(gone), MODE_MIN_LEVEL.get(self.mode, 0))
            keep = [m for m in self.members if m not in gone]
            if len(keep) + len(creds) < MODE_SIZES.get(self.mode, TEAM_SIZES)[0]:
                self.note(f"No free account left in the pool to replace {names}: team finished", "warning")
                return False
            new = [_Member(self, c) for c in creds]
            for c in creds:
                self.lab.set_account(c["uid"], used_at=_now())
            self.members = keep + new
        self.size = len(self.members)
        self._save(size=self.size, uids=json.dumps([m.uid for m in self.members]))
        if new:
            self.note(f"Replaced {names} by {', '.join(m.name for m in new)} for the next match")
        if len(new) < len(gone):
            self.note(f"Only {len(new)} free account(s) left in the pool: the team goes on with {self.size} players",
                      "warning")
        return True

    def p_invalidate(self, m: _Member, reason: str):
        try:
            self.lab.p.cache_invalidate(m.uid, reason)
        except Exception:
            pass

    def _check_alive(self):
        for m in self.members:
            if m.closed:
                self.p_invalidate(m, "teambot: gateway closed")
                raise TeamError(f"{m.name}: the gateway closed the connection")

    async def _take_turn(self):
        """Tour de recherche de son mode (voir SEARCH_TURNS) : en file, dans son équipe, tant qu'une autre cherche."""
        turns = self.lab.turns
        if not turns.enabled or self.turn:
            return
        t0 = _now()
        self.state = "queued"
        if await turns.take(self.mode, self.id):
            self.turn = self.mode
        if _now() - t0 >= 1.0:
            self.note(f"Search turn received (waited {_now() - t0:.0f} s)" if self.turn else
                      f"Search turns switched off: searching now (waited {_now() - t0:.0f} s)")

    def _give_turn(self):
        if self.turn:
            self.lab.turns.give(self.turn, self.id)
            self.turn = None

    async def _play_loop(self):
        p = self.lab.p
        while not self.stopping and not self._goal_reached():
            await asyncio.sleep(random.uniform(*BETWEEN_MATCHES_S))
            self._check_alive()
            self._honor_check()
            await self._take_turn()
            if self.stopping:
                self._give_turn()                # arrêt demandé pendant l'attente : plus de recherche
                break
            self._check_alive()                  # (passerelle fermée pendant l'attente : tour rendu par _dissolve)
            leader = self.leader()
            for m in self.members:
                m.found, m.searching, m.refused, m.search_refused = None, False, None, None
            started = cooled = False
            for attempt in range(1, START_TRIES + 1):
                self.state = "searching"
                # « prêt » de chacun (op 15), puis recherche de l'équipe par le chef (op 9)
                for m in self.members:
                    m.refused = None
                    await m.send(p.team_ready_msg(m.id))
                leader.seen.clear()
                await asyncio.sleep(1.0)
                await leader.send(p.team_start_msg(leader.id, leader.acc["region"]))
                end = time.monotonic() + START_REPLY_S
                while time.monotonic() < end and not (leader.searching or any(m.found for m in self.members)
                                                      or leader.refused is not None):
                    await asyncio.sleep(0.2)
                if leader.searching or any(m.found for m in self.members):
                    started = True
                    break
                got = " ".join(leader.seen) or "nothing"
                self.note((f"Leader match search refused (code {leader.refused}"
                           + (": a member is under level 3 for this mode)" if leader.refused == 32 else ")")
                           if leader.refused is not None
                           else f"Leader match search: no answer from the server in {START_REPLY_S:.0f} s")
                          + f", try {attempt}/{START_TRIES} · leader received: {got}", "warning")
                if leader.refused == 57:
                    # pas une erreur de l'équipe : pause puis nouvelle recherche, sans compter les essais ; pas en
                    # recherche : le tour passe à l'équipe suivante pendant la pause
                    self._give_turn()
                    self.state = "cooldown"
                    self.note(f"Code 57: the server blocks this team's search for a while (our bot teams were matched against "
                              f"each other several times) · retrying in {COOLDOWN_57_S / 60:.0f} min", "warning")
                    await asyncio.sleep(COOLDOWN_57_S)
                    cooled = True
                    break
                await asyncio.sleep(5.0)
            if cooled:
                continue
            if not started:
                raise TeamError(f"Leader match search failed {START_TRIES} times "
                                + (f"(code {leader.refused})" if leader.refused is not None else "(no answer from the server)"))
            for m in self.members:
                m.state = "search"
            t0 = time.monotonic()
            limit = SEARCH_TIMEOUT_RANKED_S if self.mode == "cs_ranked" else SEARCH_TIMEOUT_S
            while not any(m.found for m in self.members):
                refused = next((m.search_refused for m in self.members if m.search_refused is not None), None)
                if refused is not None:
                    raise TeamError(f"Matchmaking refused by the server (code {refused}) · leader received: "
                                    f"{' '.join(leader.seen) or 'nothing'}")
                if time.monotonic() - t0 > limit:
                    raise TeamError(f"No match found within {limit / 60:.0f} min")
                self._check_alive()
                await asyncio.sleep(0.5)
            self._give_turn()                    # partie formée : l'équipe suivante peut chercher (SEARCH_TURNS)
            await asyncio.sleep(FOUND_GRACE_S)
            absent = await self._match()
            self._level_check()                # après la fin de la partie (EXP finale relue par _match)
            if absent and not (self.stopping or self._goal_reached()):
                raise _Regroup(absent)

    async def _match(self) -> List["_Member"]:
        """Partie trouvée : jouée par chaque membre qui l'a reçue, bilan enregistré. Rend les membres qui n'étaient
        pas dans la partie (« match trouvé » pas reçu, ou absents des joueurs de la partie), voir _Regroup."""
        players = [m for m in self.members if m.found]
        missing = [m.name for m in self.members if not m.found]
        first = players[0].found[1]
        p = self.lab.p
        server = first.get(2, [b""])[0]
        self.server = server.decode(errors="replace") if isinstance(server, bytes) else None
        self.match_at = _now()
        self.state = "in_match"
        self.match_id = p._pb_int(first, 1)
        # camps : nos comptes contre les autres joueurs de la partie (pas de nom d'équipe dans le jeu)
        ids = {str(m.id) for m in self.members}
        everyone = match_players(p, first)
        self.vs = {"ours": [n for a, n in everyone if str(a) in ids],
                   "theirs": [n for a, n in everyone if str(a) not in ids]} if everyone else None
        # absents : pas de « match trouvé », ou pas dans les joueurs de la partie (liste du jeton, si lisible)
        in_match = {str(a) for a, _ in everyone}
        absent = [m for m in self.members if not m.found or (in_match and str(m.id) not in in_match)]
        own = [t.id for t in self.lab.teams.values() if t is not self and t.match_id == self.match_id]
        if own:
            self.note(f"This match is against one of our own bot teams ({', '.join(own)})", "warning")
        self._drone_turn = None
        if not self.lab.turns.enabled:
            # tours de recherche désactivés : une autre de nos équipes dans la même partie ? -> drone un camp à la fois
            peers = await self.lab.match_gather(self.match_id, self.id)
            if len(peers) >= 2:
                self._drone_turn = self.lab.drone_turn_for(self.match_id, peers)
                self.note(f"Drone one side at a time: {len(peers)} of our bot teams in this match + search turns off "
                          f"(one side casts until its drone hits, then the other side)")
        self.note(f"Match found -> {self.server}" + (f" (not received by: {', '.join(missing)})" if missing else ""))
        exp_before = {m.uid: m.exp for m in players}
        results = await asyncio.gather(*(self._play(m) for m in players), return_exceptions=True)
        if not self.lab.turns.enabled:
            self.lab.match_leave(self.match_id, self.id)
        self._drone_turn = None
        ended = _now()
        bots = []
        for m, r in zip(players, results):
            if isinstance(r, BaseException):
                r = {"reason": "MATCH_EXCEPTION", "error": repr(r)[:200]}
            await m.refresh()                  # EXP finale dès la fin de la partie
            await m.update_honor()
            await self.lab.claim_rewards(m.uid, m.name, m.acc, self.note)
            await self.lab.claim_guild(m.uid, m.name, m.acc, self.note)
            gained = (m.exp - exp_before[m.uid]) if m.exp is not None and exp_before.get(m.uid) is not None else None
            bot = {"uid": m.uid, "id": m.id, "name": m.name, "level": m.level, "exp": gained,
                   "reason": r.get("reason"), "completed": bool(r.get("completed")), "stay_s": r.get("stay_s"),
                   "handshake_ms": r.get("handshake_ms"), "rx": r.get("rx_packets"), "error": r.get("error")}
            bot.update(parse_chase(r.get("chase")))
            bots.append(bot)
            m.state = "team"
        mode_id, match_type = p._pb_int(first, 7) or 1, p._pb_int(first, 8) or 1
        self.lab.db.run("INSERT INTO matches (team_id, started_at, ended_at, mode, server, match_id, map_id, bots, "
                        "players) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (self.id, self.match_at, ended, self._match_mode(mode_id, match_type), self.server,
                         str(p._pb_int(first, 1) or ""), match_type, json.dumps(bots, ensure_ascii=False),
                         json.dumps(self.vs, ensure_ascii=False) if self.vs else None))
        self.done += 1
        self.resets = 0
        self.last_match_at = ended
        self._save()
        ok = sum(1 for b in bots if b["completed"])
        deaths = sum(b.get("deaths") or 0 for b in bots)
        dmg = sum(b.get("dmg") or 0 for b in bots)
        self.note(f"Match {self.done} over: {ok}/{len(bots)} finished normally · {deaths} deaths · damage {dmg} · "
                  f"EXP {', '.join(b_exp(b) + ' (Lv ' + str(b['level'] or '?') + ')' for b in bots)}")
        self.match_at = self.server = self.match_id = self.vs = None
        self.state = "team"
        return absent

    def _match_mode(self, mode_id: int, match_type: int) -> str:
        """Mode d'une partie trouvée (mode_for_match) ; Iron Cage (mode 43 comme Lone Wolf dans le « match trouvé ») :
        celui de l'équipe."""
        mode = self.lab.p.mode_for_match(mode_id, match_type)
        return self.mode if mode == "lone_wolf" and self.mode in self.lab.p.IRON_CAGE_MODES else mode

    async def _play(self, m: _Member) -> Dict[str, Any]:
        """Partie lancée par le chef : jouée comme après une recherche du bot (dans un worker UDP s'il y en a),
        mode d'après le « match trouvé » (5.7 / 5.8)."""
        p, acc = self.lab.p, m.acc
        top, inner = m.found
        m.found = None
        m.state = "match"

        def text(k):
            v = inner.get(k, [None])[0]
            return v.decode() if isinstance(v, bytes) else None

        server, udp_key, token, code = text(2), text(3), text(4), text(42)
        mode_id, match_type = p._pb_int(inner, 7) or 1, p._pb_int(inner, 8) or 1
        mode = self._match_mode(mode_id, match_type)
        ranked = mode if mode in p.RANKED_BASE_MODE else None
        if mode in p.IRON_CAGE_MODES:
            map_id = p.MATCH_MODE_IDS[mode][1]  # carte 11, comme une partie Lone Wolf
        else:
            map_id = (p._pb_int(inner, 6) if ranked else match_type) or 1
        state: Dict[str, Any] = {"completed": False, "reason": None}
        m.live = state                         # dégâts en direct : écrits ici ou reçus du worker (on_live)
        thunder, sharma = await p.build_match_startup_packets(
            token, udp_key, code, p._pb_int(top, 1) or acc["account_id"], p._pb_int(inner, 1) or 0,
            server_ip=server, region=p._join_region(acc, acc["region"]), client_version=acc["client_version"],
            access_token=acc.get("access_token") or "", mode_id=mode_id, map_id=map_id, ranked=ranked)
        opts = {"revive_check": bool(p.REVIVE_CHECK), "revive_wait_s": int(p.REVIVE_WAIT_S),
                "tunables": p.tunables(), "sysinfo": p.account_system_info(acc), "cs_chase": True}
        if self._drone_turn is not None:
            # drone un camp à la fois : tour partagé avec l'autre équipe -> partie jouée dans le processus principal
            # (un worker est un autre processus : il ne partagerait pas l'objet)
            opts["drone_turn"] = self._drone_turn
            opts["drone_side"] = self.id
        args = (server, thunder, sharma, udp_key, code, acc["account_id"], "BD", acc["client_version"],
                acc["aes_ak"], acc["iv_i"], self.done + 1, m.id, mode)
        pool = getattr(p, "_match_pool", None)
        if pool is not None and pool.available() and self._drone_turn is None:
            state["completed"] = await pool.run(args, on_diag=lambda rec, w=None: diag.ingest(rec, w=w), info=state,
                                                on_live=lambda live: state.update(
                                                    (k, live[k]) for k in ("dmg", "hits", "hp", "heals", "healing", "heals_sent", "confirmed")
                                                    if k in live),
                                                opts=opts)
        else:
            await p.play_match_core(*args, state=state, opts=opts)
        return state

    async def _dissolve(self):
        """Départ de l'équipe (membres d'abord, un à un, le chef en dernier : tous ensemble, les départs des membres
        sont refusés, code 76) puis fermeture des passerelles. Équipe quittée : plus en recherche, tour rendu."""
        p = self.lab.p
        try:
            live = [m for m in self.members if m.writer is not None and not m.closed]
            if live:
                lead = self.leader().id
                for m in sorted(live, key=lambda x: x.id == lead):
                    try:
                        await m.send(p.team_leave_msg(m.id))
                        await m.wait_team({p.TEAM_LEFT, p.TEAM_MEMBER_LEFT}, 3)
                    except Exception:
                        pass
                await asyncio.sleep(0.5)
            for m in self.members:
                await m.close()
            self.code = None
        finally:
            self._give_turn()

    def view(self) -> Dict[str, Any]:
        level_target = self.lab.level_target()
        return {"id": self.id, "state": self.state, "code": self.code, "size": self.size, "target": self.target,
                "mode": self.mode, "level_target": level_target, "goal_exp": EXP_TABLE.get(level_target),
                "done": self.done, "error": self.error, "created_at": self.created_at, "match_at": self.match_at,
                "last_match_at": self.last_match_at, "server": self.server, "vs": self.vs,
                "region": next((m.acc.get("region") for m in self.members if m.acc), None), "stop_after_match": self.stop_after_match, "resets": self.resets,
                "queue": self.lab.turns.place(self.mode, self.id),
                "members": [m.view() for m in self.members],
                "log": [{"t": t, "level": lv, "text": tx} for t, lv, tx in list(self.log)[-40:]]}


# ================= le laboratoire =================
class TeamLab:
    """Réserve de comptes de test, équipes en cours, bilan des parties, demandes d'entrée en guilde.
    `busy(uid)` : nom du Panel où ce compte (UID invité) joue en ce moment, sinon None (compte refusé ici)."""

    def __init__(self, protocol: Any, login_gate: Any = None,
                 busy: Optional[Callable[[str], Awaitable[Optional[str]]]] = None, db_file: str = DB_FILE):
        self.p = protocol
        self.gate = login_gate
        self.busy = busy
        self.db = _Db(db_file)
        self.teams: Dict[str, _Team] = {}
        self.finished: Deque[Dict[str, Any]] = deque(maxlen=20)   # équipes terminées (affichage)
        self.clans = ClanJobs()                                    # demandes d'entrée en guilde (join_clan)
        self.clan_info: Optional[Dict[str, Any]] = None            # dernière page de la guilde suivie (refresh_clan)
        self.clan_error: Optional[str] = None
        self._clan_lock = asyncio.Lock()
        self._clan_task: Optional[asyncio.Task] = None
        self._clan_tried = 0.0
        self.honor_job: Optional[Dict[str, Any]] = None            # relevé du score d'honneur (refresh_honor)
        self._honor_task: Optional[asyncio.Task] = None
        self.claim_job: Optional[Dict[str, Any]] = None            # bouton « Claim pass rewards » (claim_all)
        self._claim_task: Optional[asyncio.Task] = None
        self._guild_tried: Dict[str, float] = {}                   # dernière tentative de claim_guild par compte
        self.guild_job: Optional[Dict[str, Any]] = None            # bouton « Claim guild rewards » (claim_guild_all)
        self._guild_task: Optional[asyncio.Task] = None
        self.pick_lock = asyncio.Lock()                            # choix de comptes libres (start, _replace)
        self.turns = _SearchTurns(self.search_turns())             # une équipe en recherche à la fois (SEARCH_TURNS)
        self._match_reg: Dict[str, Dict[str, Any]] = {}            # id de partie -> {teams, turn} (voir _DroneTurn)

    # ---------- parties entre nos propres équipes (voir _DroneTurn) ----------
    async def match_gather(self, match_id: Any, team_id: str) -> set:
        """Inscrit l'équipe dans la partie, attend SELF_MATCH_GATHER_S que les autres s'inscrivent : id de toutes nos
        équipes dans cette partie."""
        key = str(match_id)
        self._match_reg.setdefault(key, {"teams": set(), "turn": None})["teams"].add(team_id)
        await asyncio.sleep(SELF_MATCH_GATHER_S)
        return set(self._match_reg.get(key, {"teams": set()}).get("teams") or ())

    def drone_turn_for(self, match_id: Any, sides: set) -> Optional["_DroneTurn"]:
        """Tour de drone commun à nos équipes de cette partie (créé une fois, camps triés par id d'équipe)."""
        reg = self._match_reg.get(str(match_id))
        if reg is None:
            return None
        if reg["turn"] is None:
            reg["turn"] = _DroneTurn(sorted(sides), _now())
        return reg["turn"]

    def match_leave(self, match_id: Any, team_id: str) -> None:
        key = str(match_id)
        reg = self._match_reg.get(key)
        if reg:
            reg["teams"].discard(team_id)
            if not reg["teams"]:
                self._match_reg.pop(key, None)

    # ---------- réserve de comptes ----------
    def set_account(self, uid: str, **fields):
        if not fields:
            return
        cols = ", ".join(f"{k} = ?" for k in fields)
        self.db.run(f"UPDATE accounts SET {cols} WHERE uid = ?", (*fields.values(), uid))

    def add_accounts(self, text: str) -> Dict[str, Any]:
        """Comptes invités collés (UID:mot de passe, guest_account_info…, voir accounts_text) ajoutés à la réserve."""
        accounts, invalid, errors = parse_accounts(text)
        added = dup = 0
        for uid, pwd in accounts:
            if self.db.all("SELECT uid FROM accounts WHERE uid = ?", (uid,)):
                dup += 1
                continue
            self.db.run("INSERT INTO accounts (uid, password, added_at) VALUES (?, ?, ?)", (uid, pwd, _now()))
            added += 1
        return {"added": added, "duplicates": dup, "invalid": invalid, "errors": errors}

    def in_use(self) -> Dict[str, str]:
        """UID -> équipe en cours qui l'utilise."""
        return {m.uid: t.id for t in self.teams.values() for m in t.members}

    def remove_accounts(self, uids: List[str]) -> int:
        used = self.in_use()
        gone = 0
        for uid in uids:
            if uid not in used:
                gone += self.db.run("DELETE FROM accounts WHERE uid = ?", (str(uid),))
        return gone

    def reset_accounts(self, uids: List[str]) -> int:
        """Comptes « login_failed » remis à « new » (de nouveau choisis pour une équipe)."""
        n = 0
        for uid in uids:
            n += self.db.run("UPDATE accounts SET status = 'new', note = '' WHERE uid = ? AND status = 'login_failed'",
                             (str(uid),))
        return n

    def accounts(self) -> List[Dict[str, Any]]:
        used = self.in_use()
        rows = self.db.all("SELECT uid, account_id, nickname, level, exp, region, status, note, added_at, used_at, "
                           "clan, honor, honor_at, honor_delta, honor_change_at, ep_claimed, ep_claimed_at "
                           "FROM accounts ORDER BY added_at, uid")
        for r in rows:
            r["team"] = used.get(r["uid"])
        return rows

    # ---------- niveau objectif ----------
    def level_target(self) -> int:
        """Niveau auquel un compte quitte son équipe et n'est plus choisi (0 = aucun)."""
        try:
            return max(0, int(self.db.setting("level_target") or 0))
        except ValueError:
            return 0

    def set_level_target(self, level: int) -> Dict[str, Any]:
        """Nouveau niveau objectif, pour les équipes en cours aussi (à la fin de leur partie). Comptes « maxed » sous ce
        niveau (ou objectif retiré) : de nouveau libres ; comptes libres déjà à ce niveau : « maxed »."""
        level = int(level)
        if not 0 <= level <= MAX_LEVEL:
            raise ValueError(f"Level goal from 1 to {MAX_LEVEL} (0 = no goal)")
        self.db.set_setting("level_target", str(level))
        freed = self.db.run("UPDATE accounts SET status = 'ok', note = '' WHERE status = 'maxed' "
                            "AND (? = 0 OR level IS NULL OR level < ?)", (level, level))
        maxed = 0
        if level:
            maxed = self.db.run("UPDATE accounts SET status = 'maxed', note = 'Level ' || level || ' reached (goal ' "
                                "|| ? || ')' WHERE status IN ('new', 'ok') AND level >= ?", (level, level))
        return {"level_target": level, "freed": freed, "maxed": maxed}

    async def free_accounts(self, limit: Optional[int] = None,
                            min_level: int = 0) -> Tuple[List[Dict[str, Any]], List[str]]:
        """Comptes libres de la réserve dans l'ordre de passage (le moins récemment utilisé d'abord), sous le niveau
        objectif, au moins `min_level` (MODE_MIN_LEVEL), pas dans une équipe ni occupés ailleurs (`busy`) ; au plus
        `limit`. Rend aussi les comptes occupés."""
        target = self.level_target()
        used = self.in_use()
        free, skipped = [], []
        for r in self.db.all("SELECT uid, password, nickname, level, exp, honor FROM accounts "
                             "WHERE status IN ('new', 'ok') ORDER BY COALESCE(used_at, 0), added_at, uid"):
            if limit is not None and len(free) >= limit:
                break
            if r["uid"] in used:
                continue
            level = r["level"] or (level_for_exp(r["exp"]) if r["exp"] is not None else 0)
            if target and level >= target:
                self.set_account(r["uid"], status="maxed", note=f"Level {level} reached (goal {target})")
                continue
            if level < min_level:
                continue
            panel = await self.busy(r["uid"]) if self.busy else None
            if panel:
                skipped.append(f"{r['uid']} ({panel})")
                continue
            free.append(r)
        return free, skipped

    # ---------- équipes ----------
    def team_mode(self) -> str:
        """Mode choisi en dernier sur la page (CS normal / CS Rank), sinon TEAM_MODE."""
        mode = self.db.setting("mode") or TEAM_MODE
        return mode if mode in TEAM_MODES else TEAM_MODES[0]

    def search_turns(self) -> bool:
        """Une équipe en recherche à la fois par mode (SEARCH_TURNS) : dernier choix de la page, sinon .env."""
        v = self.db.setting("search_turns")
        return SEARCH_TURNS if v is None else v == "1"

    def set_search_turns(self, on: bool) -> bool:
        """Tours de recherche activés / désactivés tout de suite (désactivés : les équipes en file cherchent aussitôt)."""
        self.db.set_setting("search_turns", "1" if on else "0")
        self.turns.set_enabled(on)
        return on

    async def start(self, teams: int, size: int, matches: int, mode: Optional[str] = None,
                    level_target: Optional[int] = None) -> Dict[str, Any]:
        """`teams` équipes de `size` comptes libres de la réserve (dans l'ordre), `matches` parties chacune
        (0 = jusqu'à l'arrêt), en mode `mode` (TEAM_MODES ; par défaut le dernier choisi, gardé pour la page).
        `level_target` : nouveau niveau objectif (set_level_target), sinon celui en service."""
        mode = mode or self.team_mode()
        if mode not in TEAM_MODES:
            raise ValueError(f"Unknown mode {mode!r} (expected {' or '.join(TEAM_MODES)})")
        sizes = MODE_SIZES.get(mode, TEAM_SIZES)
        if size not in sizes:
            raise ValueError(f"{TEAM_MODE_NAMES.get(mode, mode)}: teams of {' or '.join(map(str, sizes))} players")
        teams = max(1, int(teams))
        if len(self.teams) + teams > TEAMS_MAX:
            raise ValueError(f"At most {TEAMS_MAX} teams at once ({len(self.teams)} running)")
        if level_target is not None:
            self.set_level_target(level_target)
        async with self.pick_lock:
            return await self._start(teams, size, matches, mode)

    async def _start(self, teams: int, size: int, matches: int, mode: str) -> Dict[str, Any]:
        need = teams * size
        min_level = MODE_MIN_LEVEL.get(mode, 0)
        ranked = mode == "cs_ranked"
        free, skipped = await self.free_accounts(None if ranked else need, min_level)
        if ranked:
            # CS Rank : comptes d'honneur >= HONOR_MIN d'abord (dans l'ordre de passage), puis équipes d'honneur voisin
            # (du mieux noté au moins bien noté) : un seul compte à 89 ne fait plus passer toute une équipe en CS
            # normal ; les comptes d'honneur bas jouent ensemble (leur équipe passe en CS normal)
            free = sorted(sorted(free, key=lambda r: _honor(r) < HONOR_MIN)[:need], key=_honor, reverse=True)
        if len(free) < need:
            goal = self.level_target()
            raise ValueError(f"Not enough free accounts: {need} needed ({teams} teams × {size}), {len(free)} free"
                             + (f" from level {min_level}" if min_level else "")
                             + (f" under level {goal}" if goal else "")
                             + (f" · {len(skipped)} skipped (busy elsewhere)" if skipped else ""))
        self.db.set_setting("mode", mode)
        made = []
        for k in range(teams):
            creds = free[k * size:(k + 1) * size]
            tid = new_id()[:8]
            team = _Team(self, tid, creds, max(0, int(matches)), mode)
            self.db.run("INSERT INTO teams (id, created_at, status, size, target, mode, uids) VALUES (?, ?, ?, ?, ?, ?, ?)",
                        (tid, team.created_at, "running", size, team.target, mode,
                         json.dumps([c["uid"] for c in creds])))
            for c in creds:
                self.set_account(c["uid"], used_at=_now())
            self.teams[tid] = team
            team.task = asyncio.create_task(team.run(), name=f"teamlab-{tid}")
            made.append(tid)
            goal = self.level_target()
            team.note(f"Team started · {TEAM_MODE_NAMES.get(mode, mode)} · {size} players · "
                      f"{'unlimited matches' if not team.target else f'{team.target} matches'}"
                      + (f" · accounts swapped at level {goal}" if goal else ""))
        return {"teams": made, "skipped": skipped}

    def _team_done(self, team: _Team):
        self.teams.pop(team.id, None)
        v = team.view()
        v["ended_at"] = _now()
        self.finished.appendleft(v)

    async def stop(self, team_id: str, now: bool = False) -> bool:
        """Arrêt après la partie en cours (ou tout de suite : `now`, la partie est coupée)."""
        team = self.teams.get(team_id)
        if team is None:
            return False
        team.stop_after_match = True
        if now or team.state not in ("in_match",):
            if team.task and not team.task.done():
                team.task.cancel()
        team.note("Stop requested" + (" (now)" if now else " (after this match)" if team.state == "in_match" else ""))
        return True

    async def stop_all(self, now: bool = False) -> int:
        ids = list(self.teams)
        for tid in ids:
            await self.stop(tid, now)
        return len(ids)

    async def shutdown(self, timeout: float = 10.0):
        """Arrêt du serveur : toutes les équipes quittent (parties en cours coupées)."""
        tasks = [t.task for t in self.teams.values() if t.task and not t.task.done()]
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.wait(tasks, timeout=timeout)
        self.clans.cancel()
        for t in (self._honor_task, self._clan_task, self._claim_task, self._guild_task):
            if t and not t.done():
                t.cancel()
        self.db.close()

    # ---------- bilan ----------
    def matches(self, since: float = 0.0, limit: int = RECENT_MATCHES, mode: Optional[str] = None) -> List[Dict[str, Any]]:
        """Dernières parties depuis `since`, d'un seul mode si `mode` (celui du « match trouvé », mode_for_match)."""
        rows = self.db.all("SELECT * FROM matches WHERE started_at >= ? AND (? IS NULL OR mode = ?) "
                           "ORDER BY id DESC LIMIT ?", (since, mode, mode, limit))
        for r in rows:
            r["bots"] = json.loads(r["bots"] or "[]")
            r["players"] = json.loads(r["players"]) if r.get("players") else None
        return rows

    def summary(self, since: float = 0.0, mode: Optional[str] = None) -> Dict[str, Any]:
        """Moyennes de toutes les parties depuis `since` (d'un seul mode si `mode`) : par partie et par bot (une ligne
        de bot = un compte dans une partie)."""
        rows = self.db.all("SELECT started_at, ended_at, bots FROM matches WHERE started_at >= ? "
                           "AND (? IS NULL OR mode = ?)", (since, mode, mode))
        bots = [b for r in rows for b in json.loads(r["bots"] or "[]")]
        n = len(bots)

        def total(key):
            return sum(b.get(key) or 0 for b in bots)

        def avg(key, of=None):
            vals = [b.get(key) for b in (of if of is not None else bots) if b.get(key) is not None]
            return round(sum(vals) / len(vals), 2) if vals else None

        rounds = total("rounds")
        reasons: Dict[str, int] = {}
        for b in bots:
            reasons[b.get("reason") or "?"] = reasons.get(b.get("reason") or "?", 0) + 1
        durations = [r["ended_at"] - r["started_at"] for r in rows if r["ended_at"] and r["started_at"]]
        return {"matches": len(rows), "bots": n,
                "completed": sum(1 for b in bots if b.get("completed")),
                "rounds_avg": avg("rounds"), "deaths": total("deaths"), "zone_deaths": total("zone_deaths"),
                "death_rate": round(total("deaths") / rounds, 3) if rounds else None,
                "snaps_avg": avg("snaps"), "force144_avg": avg("force144"), "escapes_avg": avg("escapes"),
                "frozen_avg": avg("frozen"), "ran_m_avg": avg("ran_m"), "lag_ms_avg": avg("lag_ms"),
                "exp_avg": avg("exp"), "exp_total": total("exp"), "dmg_total": total("dmg"), "dmg_avg": avg("dmg"),
                "duration_avg_s": round(sum(durations) / len(durations)) if durations else None,
                "reasons": reasons}

    def export(self) -> List[Dict[str, Any]]:
        return self.matches(0.0, 100000)

    # ---------- guilde ----------
    def join_clan(self, clan_id: int, uids: Optional[List[str]] = None) -> Dict[str, Any]:
        """Demande d'entrée dans la guilde `clan_id` pour les comptes `uids` de la réserve (tous sauf les bannis si
        None), un à la fois, en arrière-plan (état : self.clans.job). Compte d'une équipe en cours : sa session ;
        sinon session gardée ou login (à son tour, LoginGate)."""
        rows = self.db.all("SELECT uid, password, nickname, level, exp FROM accounts WHERE status != 'banned' "
                           "ORDER BY added_at, uid")
        if uids:
            want = {str(u) for u in uids}
            rows = [r for r in rows if r["uid"] in want]
        members = self._live_members()

        def done(uid):
            self.set_account(uid, clan=f"{clan_id} · requested {time.strftime('%d/%m %H:%M')}")

        return self.clans.start(clan_id, [(r["uid"], r.get("nickname") or r["uid"], self._session(r, members))
                                          for r in rows], done)

    def _live_members(self) -> Dict[str, _Member]:
        """UID -> compte d'une équipe en cours déjà connecté (sa session sert, pas de nouveau login)."""
        return {m.uid: m for t in self.teams.values() for m in t.members if m.acc}

    def _session(self, row: Dict[str, Any], members: Dict[str, _Member]) -> Callable[[], Awaitable[Dict[str, Any]]]:
        """Session du compte `row` au moment de son tour : celle de son équipe en cours, sinon session gardée ou
        login (à son tour, LoginGate). Lève SkipAccount si le login échoue."""
        async def get():
            m = members.get(row["uid"])
            if m is None:
                m = _Member(_ClanTeam(self), row)
                try:
                    await m.login()
                except TeamError as e:
                    raise SkipAccount(str(e))
            return m.acc
        return get

    # ---------- score d'honneur ----------
    async def update_honor(self, uid: str, acc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Score d'honneur du compte relu (GetCreditScoreChangeInfo) et gardé en base ; None si la lecture échoue."""
        if not acc:
            return None
        try:
            r = await api_client.credit_score(acc)
        except Exception as e:
            diag.event("TEAMLAB", "honor_failed", level="warning", exc=e, uid=uid)
            return None
        last = r["changes"][0] if r["changes"] else None
        self.set_account(uid, honor=r["score"], honor_at=_now(), honor_delta=last["delta"] if last else None,
                         honor_change_at=last["time"] if last else None)
        return r

    # ---------- missions du Pass ----------
    async def claim_rewards(self, uid: str, name: str, acc: Optional[Dict[str, Any]],
                            note: Optional[Callable[..., None]] = None, quiet: bool = True) -> Optional[Dict[str, Any]]:
        """Défis du Pass atteints (toutes les semaines) et paliers quotidiens réclamés pour le compte `uid`
        (api_client.claim_ep_rewards), total gardé en base ; None si la lecture échoue (jamais d'exception).
        `quiet` : rien dans `note` quand il n'y a rien à réclamer (après chaque partie)."""
        if not acc:
            return None
        try:
            r = await api_client.claim_ep_rewards(acc)
        except Exception as e:
            diag.event("TEAMLAB", "ep_claim_failed", level="warning", exc=e, uid=uid)
            if note:
                note(f"{name}: could not read the pass missions ({str(e)[:80]})", "error")
            return None
        got = len(r["challenges"]) + len(r["daily"])
        if got:
            self.db.run("UPDATE accounts SET ep_claimed = COALESCE(ep_claimed, 0) + ?, ep_claimed_at = ? WHERE uid = ?",
                        (got, _now(), uid))
        if note and (got or r["failed"]):
            note(f"{name}: claimed {len(r['challenges'])} pass mission(s)"
                 + (f" {', '.join(map(str, r['challenges']))}" if r["challenges"] else "")
                 + (f" + daily reward {', '.join(map(str, r['daily']))}" if r["daily"] else "")
                 + f" · {r['awards']} reward(s)"
                 + (f" · refused: {'; '.join(f'{i} ({err})' for i, err in r['failed'])}" if r["failed"] else ""),
                 "warning" if r["failed"] else "info")
        elif note and not quiet:
            note(f"{name}: nothing to claim · {r['pending']} mission(s) still in progress")
        return r

    # ---------- guilde : récompenses d'activité et magasin ----------
    def member_glory(self, account_id: Any) -> Optional[int]:
        """Gloire de la semaine du compte dans la guilde suivie (dernière page lue), None s'il n'y est pas."""
        for m in (self.clan_info or {}).get("members") or []:
            if account_id and m.get("id") == str(account_id):
                return m.get("weekly_glory")
        return None

    def _guild_journal(self, uid: str, name: str, acc: Dict[str, Any], source: str) -> api_client.GuildJournal:
        """Journal des appels de la guilde d'un compte (voir GUILD_JOURNAL) : une entrée par requête."""
        def write(endpoint: str, body: bytes, content: Optional[bytes], error: Optional[BaseException]):
            if not GUILD_JOURNAL:              # GUILD_JOURNAL= vide (ou SAVE_LOGS=0) : rien d'écrit
                return
            rec = {"time": time.strftime("%Y-%m-%dT%H:%M:%S"), "t": round(_now(), 3), "source": source, "uid": uid,
                   "account_id": str(acc.get("account_id") or ""), "name": name, "endpoint": endpoint,
                   "request": {"hex": body.hex(), "decoded": api_client.pb_json(body)},
                   "response": None if content is None else {"hex": content.hex(),
                                                             "decoded": api_client.pb_json(content)},
                   "error": None if error is None else str(error)[:500],
                   "status": getattr(error, "status", None)}
            try:
                _journal_append(GUILD_JOURNAL, rec)
            except OSError as e:
                diag.event("TEAMLAB", "guild_journal_failed", level="warning", exc=e)
        return write

    async def claim_guild(self, uid: str, name: str, acc: Optional[Dict[str, Any]],
                          note: Optional[Callable[..., None]] = None, manual: bool = False) -> Optional[Dict[str, Any]]:
        """Paliers d'activité de la guilde et personnels réclamés, puis articles GUILD_STORE_BUY pas encore achetés
        cette semaine. Automatique (GUILD_AUTO) : seulement à partir de GUILD_CLAIM_MIN_GLORY de gloire de la semaine,
        au plus toutes les GUILD_CLAIM_EVERY_S par compte ; `manual` : sans ces conditions. Retourne {tokens, bought,
        refused, glory} ; None si rien n'est tenté (jamais d'exception)."""
        cid = self.clan_id()
        if not acc or not cid or not (manual or GUILD_AUTO):
            return None
        now = _now()
        glory = self.member_glory(acc.get("account_id"))
        if not manual and (glory is None or glory < GUILD_CLAIM_MIN_GLORY
                           or now - self._guild_tried.get(uid, 0.0) < GUILD_CLAIM_EVERY_S):
            return None
        self._guild_tried[uid] = now
        journal = self._guild_journal(uid, name, acc, "manual" if manual else "auto")
        out: Dict[str, Any] = {"tokens": 0, "bought": [], "refused": [], "glory": glory}
        for what, call in (("guild", lambda: api_client.claim_clan_act_award(acc, journal=journal)),
                           ("personal", lambda: api_client.claim_personal_act_rewards(acc, int(cid), journal=journal))):
            try:
                out["tokens"] += await call()
            except Exception as e:          # rien à réclamer : refusé aussi
                diag.event("TEAMLAB", "guild_claim_refused", level="debug", uid=uid, what=what, exc=e)
        rows = self.db.all("SELECT guild_bought FROM accounts WHERE uid = ?", (uid,))
        try:
            bought = json.loads((rows[0] if rows else {}).get("guild_bought") or "{}")
        except ValueError:
            bought = {}
        week = time.strftime("%G-W%V", time.localtime(now - GUILD_WEEK_SHIFT_S))
        for commodity, price in GUILD_STORE_BUY:
            if bought.get(str(commodity)) == week:
                continue
            try:
                r = await api_client.guild_store_purchase(acc, commodity, price, journal=journal)
                bought[str(commodity)] = week
                out["bought"].append(f"{commodity} -> " + ", ".join(f"{item} x{n}" for item, n in r["items"]))
            except Exception as e:          # jetons insuffisants ou limite de la semaine atteinte
                out["refused"].append(f"{commodity} ({str(e)[:80]})")
                diag.event("TEAMLAB", "guild_buy_refused", level="debug", uid=uid, commodity=commodity, exc=e)
        self.db.run("UPDATE accounts SET guild_tokens = COALESCE(guild_tokens, 0) + ?, guild_claimed_at = ?, "
                    "guild_bought = ? WHERE uid = ?", (out["tokens"], now, json.dumps(bought), uid))
        if note and (out["tokens"] or out["bought"] or manual):
            note(f"{name}: guild" + (f" ({glory} glory)" if glory is not None else "")
                 + f" · {out['tokens']} token(s) claimed"
                 + (f" · bought {'; '.join(out['bought'])}" if out["bought"] else "")
                 + (f" · not bought: {'; '.join(out['refused'])}" if manual and out["refused"] else ""),
                 "info" if out["tokens"] or out["bought"] else "warning")
        return out

    def claim_guild_all(self, uids: Optional[List[str]] = None) -> Dict[str, Any]:
        """Bouton « Claim guild rewards » : claim_guild (manuel) pour les comptes `uids` de la réserve (tous sauf les
        bannis si None), un à la fois, en arrière-plan ; état et journal dans self.guild_job."""
        if self._guild_task and not self._guild_task.done():
            raise ValueError("A guild claim is already running, wait for it to finish")
        if not self.clan_id():
            raise ValueError("Enter the clan ID first")
        rows = self.db.all("SELECT uid, password, nickname, level, exp FROM accounts WHERE status != 'banned' "
                           "ORDER BY added_at, uid")
        if uids:
            want = {str(u) for u in uids}
            rows = [r for r in rows if r["uid"] in want]
        if not rows:
            raise ValueError("No accounts to claim for")
        job: Dict[str, Any] = {"total": len(rows), "done": 0, "ok": 0, "fail": 0, "tokens": 0, "bought": 0,
                               "running": True, "started_at": _now(), "ended_at": None, "log": []}
        self.guild_job = job
        members = self._live_members()

        def log(text: str, level: str = "info"):
            job["log"].append({"t": _now(), "level": level, "text": text})
            del job["log"][:-LOG_LINES]

        async def run():
            log(f"Claiming guild rewards for {len(rows)} account(s)")
            try:
                for row in rows:
                    name = row.get("nickname") or row["uid"]
                    try:
                        acc = await self._session(row, members)()
                        r = await self.claim_guild(row["uid"], (acc or {}).get("nickname") or name, acc, log,
                                                   manual=True)
                    except SkipAccount as e:
                        r = None
                        log(f"{name}: skipped ({str(e)[:120]})", "error")
                    except Exception as e:
                        r = None
                        log(f"{name}: {e!r}"[:200], "error")
                    job["done"] += 1
                    if r is None:
                        job["fail"] += 1
                    else:
                        job["ok"] += 1
                        job["tokens"] += r["tokens"]
                        job["bought"] += len(r["bought"])
                    await asyncio.sleep(HONOR_GAP_S)
                log(f"Done · {job['tokens']} token(s) claimed · {job['bought']} item(s) bought"
                    + (f" · {job['fail']} account(s) failed" if job["fail"] else ""))
            finally:
                job["running"] = False
                job["ended_at"] = _now()

        self._guild_task = asyncio.create_task(run(), name="teamlab-guild")
        return job

    def claim_all(self, uids: Optional[List[str]] = None) -> Dict[str, Any]:
        """Bouton « Claim pass rewards » : claim_rewards pour les comptes `uids` de la réserve (tous sauf les bannis si
        None), un à la fois, en arrière-plan ; état et journal dans self.claim_job."""
        if self._claim_task and not self._claim_task.done():
            raise ValueError("A claim is already running, wait for it to finish")
        rows = self.db.all("SELECT uid, password, nickname, level, exp FROM accounts WHERE status != 'banned' "
                           "ORDER BY added_at, uid")
        if uids:
            want = {str(u) for u in uids}
            rows = [r for r in rows if r["uid"] in want]
        if not rows:
            raise ValueError("No accounts to claim for")
        job: Dict[str, Any] = {"total": len(rows), "done": 0, "ok": 0, "fail": 0, "missions": 0, "daily": 0,
                               "awards": 0, "running": True, "started_at": _now(), "ended_at": None, "log": []}
        self.claim_job = job
        members = self._live_members()

        def log(text: str, level: str = "info"):
            job["log"].append({"t": _now(), "level": level, "text": text})
            del job["log"][:-LOG_LINES]

        async def run():
            log(f"Claiming pass rewards for {len(rows)} account(s)")
            try:
                for row in rows:
                    name = row.get("nickname") or row["uid"]
                    try:
                        acc = await self._session(row, members)()
                        r = await self.claim_rewards(row["uid"], (acc or {}).get("nickname") or name, acc, log,
                                                     quiet=False)
                    except SkipAccount as e:
                        r = None
                        log(f"{name}: skipped ({str(e)[:120]})", "error")
                    except Exception as e:
                        r = None
                        log(f"{name}: {e!r}"[:200], "error")
                    job["done"] += 1
                    if r is None:
                        job["fail"] += 1
                    else:
                        job["ok"] += 1
                        job["missions"] += len(r["challenges"])
                        job["daily"] += len(r["daily"])
                        job["awards"] += r["awards"]
                    await asyncio.sleep(HONOR_GAP_S)
                log(f"Done · {job['missions']} mission(s) + {job['daily']} daily reward(s) claimed · "
                    f"{job['awards']} reward(s)" + (f" · {job['fail']} account(s) failed" if job["fail"] else ""))
            finally:
                job["running"] = False
                job["ended_at"] = _now()

        self._claim_task = asyncio.create_task(run(), name="teamlab-claim")
        return job

    def refresh_honor(self, uids: Optional[List[str]] = None) -> Dict[str, Any]:
        """Relevé du score d'honneur des comptes `uids` de la réserve (tous sauf les bannis si None), un à la fois, en
        arrière-plan (état : self.honor_job)."""
        if self._honor_task and not self._honor_task.done():
            raise ValueError("An honor score check is already running, wait for it to finish")
        rows = self.db.all("SELECT uid, password, nickname, level, exp FROM accounts WHERE status != 'banned' "
                           "ORDER BY added_at, uid")
        if uids:
            want = {str(u) for u in uids}
            rows = [r for r in rows if r["uid"] in want]
        if not rows:
            raise ValueError("No accounts to check")
        job = {"total": len(rows), "done": 0, "ok": 0, "fail": 0, "running": True, "started_at": _now(),
               "ended_at": None, "last_error": None}
        self.honor_job = job
        members = self._live_members()

        async def run():
            try:
                for r in rows:
                    try:
                        acc = await self._session(r, members)()
                        ok = await self.update_honor(r["uid"], acc) is not None
                        if not ok:
                            job["last_error"] = f"{r.get('nickname') or r['uid']}: game server did not answer"
                    except SkipAccount as e:
                        ok, job["last_error"] = False, str(e)[:160]
                    except Exception as e:
                        ok, job["last_error"] = False, repr(e)[:160]
                    job["done"] += 1
                    job["ok" if ok else "fail"] += 1
                    await asyncio.sleep(HONOR_GAP_S)
            finally:
                job["running"] = False
                job["ended_at"] = _now()

        self._honor_task = asyncio.create_task(run(), name="teamlab-honor")
        return job

    # ---------- historique des matchs ----------
    async def match_history(self, uid: str) -> Dict[str, Any]:
        """Derniers matchs d'un compte de la réserve vus par le jeu (GetMatchStatsHistory), avec la session de son
        équipe en cours, sinon login. Lève ValueError / GameApiError."""
        row = next(iter(self.db.all("SELECT uid, password, nickname, level, exp FROM accounts WHERE uid = ?",
                                    (str(uid),))), None)
        if row is None:
            raise ValueError("Account not in the pool")
        try:
            acc = await self._session(row, self._live_members())()
        except SkipAccount as e:
            raise ValueError(f"Could not log in to read the match history: {e}")
        matches = await api_client.match_stats_history(acc)
        return {"uid": row["uid"], "nickname": (acc or {}).get("nickname") or row.get("nickname") or row["uid"],
                "matches": matches, "fetched_at": _now()}

    # ---------- page de la guilde ----------
    def clan_id(self) -> str:
        return self.db.setting("clan_id") or os.environ.get("CLAN_ID", "")

    async def refresh_clan(self, clan_id: Any = None) -> Dict[str, Any]:
        """Page de la guilde suivie relue (GetClanMainPageInfo) avec la session d'un bot en équipe, sinon celle d'un
        compte de la réserve (login si besoin). `clan_id` : nouvelle guilde suivie. Lève ValueError / GameApiError."""
        if clan_id:
            self.db.set_setting("clan_id", str(int(clan_id)))
        cid = self.clan_id()
        if not cid:
            raise ValueError("Enter the clan ID first")
        async with self._clan_lock:
            members = self._live_members()
            live = next((m for m in members.values() if not m.closed), None)
            if live:
                acc = live.acc
            else:
                row = next(iter(self.db.all("SELECT uid, password, nickname, level, exp FROM accounts "
                                            "WHERE status IN ('ok', 'new') ORDER BY status = 'ok' DESC, added_at")),
                           None)
                if row is None:
                    raise ValueError("Add an account to the pool first (it reads the clan page)")
                try:
                    acc = await self._session(row, members)()
                except SkipAccount as e:
                    raise ValueError(f"Could not log in to read the clan page: {e}")
            try:
                info = await api_client.clan_main_page(acc, int(cid))
            except Exception as e:
                self.clan_error = str(e)[:200]
                raise
            info["fetched_at"] = _now()
            self.clan_info, self.clan_error = info, None
            return info

    def _clan_auto(self):
        """Équipes en cours : page de la guilde relue en arrière-plan toutes les CLAN_REFRESH_S (sessions des bots)."""
        if not self.teams or not self.clan_id() or (self._clan_task and not self._clan_task.done()):
            return
        last = max(self._clan_tried, self.clan_info["fetched_at"] if self.clan_info else 0.0)
        if _now() - last < CLAN_REFRESH_S:
            return
        if not any(m.acc and not m.closed for t in self.teams.values() for m in t.members):
            return
        self._clan_tried = _now()                  # échec : pas de nouvel essai à chaque relevé de la page

        async def run():
            try:
                await self.refresh_clan()
            except Exception as e:
                diag.event("TEAMLAB", "clan_refresh", level="warning", exc=e)

        self._clan_task = asyncio.create_task(run(), name="teamlab-clan")

    # ---------- page ----------
    def status(self, since: float = 0.0, mode: Optional[str] = None) -> Dict[str, Any]:
        """État de la page ; bilan et dernières parties depuis `since`, d'un seul mode si `mode`."""
        mode = mode if mode in TEAM_MODES else None
        self._clan_auto()
        accounts = self.accounts()
        counts = {"total": len(accounts), "free": 0, "in_team": 0, "banned": 0, "failed": 0, "maxed": 0}
        for a in accounts:
            if a["team"]:
                counts["in_team"] += 1
            elif a["status"] == "banned":
                counts["banned"] += 1
            elif a["status"] == "maxed":
                counts["maxed"] += 1
            elif a["status"] == "login_failed":
                counts["failed"] += 1
            else:
                counts["free"] += 1
        return {"teams": [t.view() for t in self.teams.values()], "finished": list(self.finished),
                "accounts": accounts, "counts": counts, "summary": self.summary(since, mode),
                "matches": self.matches(since, mode=mode), "clan": self.clans.job, "sizes": list(TEAM_SIZES),
                "mode_sizes": {k: list(v) for k, v in MODE_SIZES.items()},
                "teams_max": TEAMS_MAX, "server_time": _now(), "mode": self.team_mode(), "modes": list(TEAM_MODES),
                "level_target": self.level_target(), "max_level": MAX_LEVEL,
                "clan_id": self.clan_id(), "clan_info": self.clan_info, "clan_error": self.clan_error,
                "honor_job": self.honor_job, "claim_job": self.claim_job,
                "guild_job": self.guild_job, "turns": self.turns.view(), "search_turns": self.turns.enabled}


class _ClanTeam:
    """Équipe fictive d'un compte connecté seulement pour une demande de guilde (login + journal)."""

    def __init__(self, lab: TeamLab):
        self.lab = lab

    def note(self, text: str, level: str = "info"):
        pass
