# -*- coding: utf-8 -*-
"""FreeFire Level Up Bot — plateforme multi-panels."""
