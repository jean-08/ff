# -*- coding: utf-8 -*-
"""
Pont entre le code protocole (ffbot.protocol) et le moteur de panels.

Le protocole appelle `bot_state.<hook>(...)`. Chaque appel est routé vers
l'AccountRunner qui possède la tâche courante (ContextVar héritée par toutes
les sous-tâches asyncio), ou à défaut vers le runner lié à l'account_id du jeu.
Un hook ne doit jamais faire planter le protocole : toutes les erreurs sont avalées.
"""
import asyncio
import contextvars
from typing import Any, Callable, Dict, Optional

from ffbot.models import GameMode

current_runner: contextvars.ContextVar = contextvars.ContextVar("ffbot_runner", default=None)


class ProtocolHooks:
    def __init__(self):
        # Utilisé tel quel par protocol.py (exp_refresher, refresh_account_profile)
        self.account_credentials: Dict[str, Dict[str, Any]] = {}
        self._by_game_id: Dict[str, Any] = {}
        self.log_sink: Optional[Callable[[str, str, Any], None]] = None

    # ---------- liaison runner <-> account_id du jeu ----------
    def bind(self, game_id: Any, runner: Any):
        self._by_game_id[str(game_id)] = runner

    def unbind(self, game_id: Any, runner: Any):
        if self._by_game_id.get(str(game_id)) is runner:
            del self._by_game_id[str(game_id)]

    def bound_runner(self, game_id: Any):
        """Runner dont la session en cours joue ce compte de jeu (None entre deux sessions)."""
        return self._by_game_id.get(str(game_id))

    def forget_credentials(self, account_data: Dict[str, Any]):
        for key in (str(account_data.get("account_id", "")),
                    str(account_data.get("auth_uid", "")),
                    f"tok_{str(account_data.get('auth_token', ''))[:20]}"):
            self.account_credentials.pop(key, None)

    def _runner(self, uid: Any = None):
        runner = current_runner.get()
        if runner is not None:
            return runner
        if uid is not None:
            return self._by_game_id.get(str(uid))
        return None

    # ---------- hooks appelés par le protocole ----------
    def log(self, message: str, level: str = "info", uid: Any = None):
        try:
            if self.log_sink:
                self.log_sink(level, message, self._runner(uid))
        except Exception:
            pass

    def register_account(self, uid, nickname, region, level, exp, likes=0):
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_profile(game_id=uid, nickname=nickname, region=region,
                                  level=level, exp=exp, likes=likes)
        except Exception:
            pass

    def update_profile(self, uid, level=None, exp=None, likes=None, nickname=None, profile=None):
        """`profile` : relevé complet (GetPlayerPersonalShow), dont l'avatar et la bannière de la carte de profil."""
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_profile(game_id=uid, nickname=nickname, level=level, exp=exp, likes=likes, profile=profile)
        except Exception:
            pass

    def update_status(self, uid, status: str, active_matches: Optional[int] = None, reason: Optional[str] = None):
        """`reason` (état WAITING) : pourquoi le compte attend une place (WORKERS_FULL, PANEL_SHARE… voir ffbot.diag)."""
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_protocol_status(status, active_matches, reason)
        except Exception:
            pass

    def tuning(self, uid, key: str, default: float) -> float:
        """Réglage de cadence du panel du compte (start_interval_s, relaunch_delay_s, exp_refresh_s)."""
        try:
            runner = self._runner(uid)
            return float(runner.settings.get(key, default)) if runner else default
        except Exception:
            return default

    def panel_key(self, uid) -> Optional[str]:
        """Panel du compte : clé de l'état des matchs dans le protocole (None hors moteur de panels)."""
        try:
            runner = self._runner(uid)
            return runner.panel_id if runner else None
        except Exception:
            return None

    def can_start_match(self, uid, active_matches: int, by_mode: Optional[Dict[str, int]] = None) -> bool:
        """`by_mode` : parties en cours du compte par mode (plafonds par mode du réglage mode_mix)."""
        try:
            runner = self._runner(uid)
            return True if runner is None else bool(runner.can_start_match(active_matches, by_mode))
        except Exception:
            return True

    def game_mode(self, uid, by_mode: Optional[Dict[str, int]] = None) -> Optional[str]:
        """Mode de la prochaine recherche : "lone_wolf", "br", "br_ranked", "br_ranked_rank", "clash_squad" ou
        "cs_ranked" (réglage du panel + niveau du compte). Plusieurs modes (mode_mix) : un mode qui a encore de la place d'après `by_mode`
        (parties en cours du compte par mode), None si tous sont pleins."""
        try:
            runner = self._runner(uid)
            return runner.mode_for_search(by_mode) if runner else GameMode.DEFAULT
        except Exception:
            return GameMode.DEFAULT

    def match_started(self, uid, match_index: int, server: str, mode: Optional[str] = None):
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_match_started(match_index, server, mode)
        except Exception:
            pass

    def match_finished(self, uid, completed: bool, duration: float, mode: Optional[str] = None,
                       reason: Optional[str] = None):
        """`reason` : cause de fin de la partie (MATCH_END, HANDSHAKE_TIMEOUT, WORKER_LOST… voir ffbot.diag)."""
        try:
            task = asyncio.current_task()
            aborted = bool(task and task.cancelling())
            runner = self._runner(uid)
            if runner:
                result = "completed" if completed else ("aborted" if aborted else "failed")
                runner.on_match_finished(result, duration, mode, reason)
        except Exception:
            pass

    def match_hp(self, uid, match_index: int, hp: Optional[int], mode: Optional[str] = None):
        """PV en direct d'une partie BR en cours (None : partie finie), affichés sur le site."""
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_match_hp(match_index, hp, mode)
        except Exception:
            pass

    def reward_result(self, uid, ok: bool, message: str, data: Optional[Dict[str, Any]] = None,
                      level: Optional[str] = None):
        """Résultat d'une récompense d'activité réclamée (GetActivityRewards) : inscrit dans l'historique du compte."""
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_reward(ok, message, data, level)
        except Exception:
            pass

    def gateway_connected(self, uid):
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_gateway_connected()
        except Exception:
            pass

    def gateway_error(self, uid, message: str):
        try:
            runner = self._runner(uid)
            if runner:
                runner.on_gateway_error(message)
        except Exception:
            pass


bot_state = ProtocolHooks()
