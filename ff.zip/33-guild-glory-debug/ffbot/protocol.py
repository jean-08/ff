# -*- coding: utf-8 -*-
"""
Protocole FreeFire (login, passerelle TCP, matchs UDP).

Code extrait tel quel de l'ancien Main.py. Les seules différences :
  - `bot_state` vient de ffbot.hooks (pont vers le moteur de panels) ;
  - chemins de fichiers relatifs au dossier du projet ;
  - points d'accroche : limite de matchs parallèles (can_start_match),
    début/fin de match, erreurs de passerelle, rafraîchissement du profil ;
  - mode de jeu (game_mode) : Lone Wolf, Battle Royale ou Clash Squad. Les trois modes suivent la même
    logique : dès qu'un match est trouvé il est joué en arrière-plan (UDP) et une nouvelle recherche part
    aussitôt, sans attendre la fin de la partie (matchs en parallèle).
  - aucune partie n'est quittée avant sa fin réelle (sinon « Abandonné » en jeu, sans EXP), même quand la
    session du compte s'arrête (voir UNINTERRUPTIBLE_MODES) ; seul un compte banni voit ses parties coupées.
  - relevé d'EXP / niveau par GetPlayerPersonalShow (ffbot.api_client) : GetLoginData ne sert qu'au login
    (et de secours, rarement) ; une session de jeu est réutilisée tant que son token est valable (TOKEN_CACHE_TTL).
  - limite de matchs simultanés PAR PANEL (PANEL_MAX_MATCHES / réglage panel_max_matches) : chaque panel a ses
    propres compteurs, lancer d'autres panels ne réduit plus les places (ni l'EXP) d'un panel.
"""
# ==================== STANDARD IMPORTS ====================
import sys
import asyncio
import contextvars
import httpx
import random
import json
import math
import socket
import struct
import time
import os
import uuid
import heapq
import itertools
import threading
import weakref
from collections import deque
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple, Any

if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        if hasattr(sys.stderr, 'reconfigure'):
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# ==================== ORIGINAL IMPORTS ====================
from google_play_scraper.constants.request import Formats as PlayFormats
from google_play_scraper.features.app import parse_dom as play_parse_dom
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from protobuf_decoder.protobuf_decoder import Parser
from message_ids import MESSAGE_ID_TO_NAME
import thunderFF_pb2
import ban_pb2

# ==================== ENGINE HOOKS ====================
from ffbot import api_client, diag, udp_codec
from ffbot.monitor import monitor
from ffbot.hooks import bot_state
from ffbot.models import AccountBanned

# ==================== CONFIGURATION ====================
_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Chemins remplaçables (Docker : fichiers dans le volume data/)
TOKEN_CACHE_FILE = os.environ.get("TOKEN_CACHE_FILE") or os.path.join(_ROOT_DIR, "token_cache.json")
DEVICES_FILE = os.environ.get("DEVICES_FILE") or os.path.join(_ROOT_DIR, "devices.json")  # appareils persistants
# Session de jeu (token_cache.json) réutilisée sans nouveau MajorLogin / GetLoginData pendant TOKEN_CACHE_TTL
# secondes (.env, 2 h par défaut ; fast-old-ui : 1200 = un login complet toutes les 20 min), jamais au-delà de
# la validité du token (8 h, moins TOKEN_EXPIRY_MARGIN). Si la passerelle refuse la session gardée
# (GATEWAY_REJECTS_BEFORE_RELOGIN connexions fermées de suite sans réponse), le compte refait un login complet.
try:
    TOKEN_CACHE_TTL = max(300, int(os.environ.get("TOKEN_CACHE_TTL", "7200")))
except ValueError:
    TOKEN_CACHE_TTL = 7200
TOKEN_EXPIRY_MARGIN = 600
GATEWAY_REJECTS_BEFORE_RELOGIN = 3
GATEWAY_REJECT_WINDOW_S = 10.0      # connexion fermée par le serveur moins de 10 s après l'envoi du token = refus
GATEWAY_CONNECT_TIMEOUT_S = 15.0    # connexion TCP à la passerelle (sinon ~21 s de délai système, WinError 121)
GATEWAY_WRITE_TIMEOUT_S = 10.0      # envoi du token
GATEWAY_BACKOFF_MAX_S = 30.0        # erreurs de passerelle répétées : 1, 2, 4, 8… s (± 20 %) au plus, pas de rafale
# Présence « en ligne » dans le jeu (liste d'amis) : le client officiel garde sa connexion à la passerelle ouverte en
# permanence, partie en cours comprise, et envoie « 02 02 » toutes les 8 s sur ses deux connexions (passerelle et
# chat ; captures des 16 et 17/10). Le bot coupait la passerelle à chaque partie trouvée (3 s hors ligne toutes les
# ~20 s) et pendant toute l'attente d'une place (parties en cours = limite du compte atteinte) : le compte apparaissait
# hors ligne pendant qu'il montait de niveau. GATEWAY_STAY_ONLINE=1 (.env, défaut) : connexion gardée (ou rouverte
# aussitôt) pendant l'attente et après une partie trouvée ; 0 = ancien comportement (attente hors ligne).
GATEWAY_STAY_ONLINE = os.environ.get("GATEWAY_STAY_ONLINE", "1").strip().lower() not in ("0", "false", "no", "off", "non")
GATEWAY_KEEPALIVE = b"\x02\x02"     # maintien du client officiel (OB55), identique sur la passerelle et le chat
GATEWAY_KEEPALIVE_S = 8.0
# 2e octet des messages du client vers la passerelle et le chat ([type][octet][longueur 4 octets], maintien
# [02][octet]) : 02 chez le client officiel TH (captures du 16 au 23/10), 14 chez le client officiel IND (3 captures
# du 24/10 sur 3 : 02 14, 03 14, 28 14, 12 14 — l'octet du jeton 7114 / 9214 de build_tcp_startup_packet). Les autres
# régions restent à 02 faute de capture. L'octet est attaché à la connexion (gateway_bind_region) : gateway_send et
# le maintien le reprennent sans qu'on le passe à chaque appel.
GATEWAY_REGION_BYTE = {"IND": 0x14}
_gateway_writer_byte: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()


def gateway_region_byte(region) -> int:
    return GATEWAY_REGION_BYTE.get(str(region or "").strip().upper(), 0x02)


def gateway_bind_region(writer, region):
    """Connexion (passerelle ou chat) d'un compte de `region` : ses messages portent l'octet de la région."""
    _gateway_writer_byte[writer] = gateway_region_byte(region)


def gateway_keepalive(writer) -> bytes:
    return bytes([0x02, _gateway_writer_byte.get(writer, 0x02)])


# Début de connexion à la passerelle comme le client officiel TH 1.132.13 (capture du 24/10 16:37, enregistrée dès le
# lancement du jeu, messages du client déchiffrés) : jeton [xx][02]…, PAS de maintien juste après (le 1er arrive ~8 s
# plus tard), 0x28 type 2 (+0,09 s), 0x28 type 11 et 0x1d {1: 6, 2: {1: 3, 2: "2019121229", 3: 1, 4: 1}} (+0,84 s),
# puis 0x0e. Le bot envoyait le jeton [71][15] (octet du script d'origine, jamais vu dans le jeu : 02 dans les
# 6 captures TH du 15 au 24/10 où le jeton est visible), un maintien aussitôt, et ni 0x28 ni 0x1d.
# GW_CLIENT_INIT=1 : jeton 02 en TH, pas de maintien immédiat, 0x1d d'initialisation (contenu fixe).
# GW_CLIENT_INIT_0x28=1 : en plus, les deux 0x28 de la capture (blocs du SDK anti-triche d'une AUTRE session,
# data/gw_client_init.json ; ce que le serveur en fait n'est pas connu : à l'essai). Les deux à 0 par défaut.
GW_CLIENT_INIT = os.environ.get("GW_CLIENT_INIT", "0").strip().lower() in ("1", "true", "yes", "on")
GW_CLIENT_INIT_0x28 = os.environ.get("GW_CLIENT_INIT_0x28", "0").strip().lower() in ("1", "true", "yes", "on")
GW_CLIENT_INIT_FILE = os.path.join(_ROOT_DIR, "data", "gw_client_init.json")
_GW_SDK_INIT_0x1D = bytes.fromhex("080612120803120a3230313931323132323918012001")
_gw_client_init_memo: Optional[List[bytes]] = None


def _gw_client_init_0x28() -> List[bytes]:
    """Les deux 0x28 du début de session du client officiel (data/gw_client_init.json), [] si le fichier manque."""
    global _gw_client_init_memo
    if _gw_client_init_memo is None:
        try:
            with open(GW_CLIENT_INIT_FILE, encoding="utf-8") as f:
                _gw_client_init_memo = [bytes.fromhex(h) for h in json.load(f).get("init_0x28", [])]
        except (OSError, ValueError, AttributeError) as e:
            print_error(f"[GATEWAY] {GW_CLIENT_INIT_FILE} : {e!r}"[:200])
            _gw_client_init_memo = []
    return _gw_client_init_memo
# Anti-triche 0x28 : le client officiel envoie 4 rapports par session (2 à la connexion, 2 pendant/après le match).
# Le serveur répond avec des défis (champ 4=12/1/6). Depuis ~17:00 le 22/10 (1.132.13), les parties sans 0x28
# ne donnent plus d'EXP. Test du 22/10 19:40 : des données ALÉATOIRES font couper → le contenu est validé.
# Mode « replay » (22/10 20:xx) : les 4 blocs 0x28 + 13 blocs 0x1d capturés d'un vrai client (data/anticheat_replay.json)
# sont rejoués aux bons moments (connexion + pendant le match). La passerelle reste ouverte pendant la partie pour ça.
GW_ANTICHEAT_REPORT = os.environ.get("GW_ANTICHEAT_REPORT", "0").strip().lower() not in ("0", "false", "no", "off", "non")
GW_ANTICHEAT_ORACLE = os.environ.get("GW_ANTICHEAT_ORACLE", "").strip()
# Après une partie trouvée, la passerelle n'est rouverte qu'au bout de GATEWAY_FOUND_RECONNECT_S (.env) : rouverte 5 ms
# après (17/10 21:52-22:10), l'entrée dans la partie (UDP) échouait 4 fois plus souvent (HANDSHAKE_TIMEOUT 3,1 % des
# parties contre 0,7 % le 16/10 avec la reconnexion 3 s après) : le joueur met ~0,3 s à entrer dans la partie.
try:
    GATEWAY_FOUND_RECONNECT_S = max(0.0, float(os.environ.get("GATEWAY_FOUND_RECONNECT_S", "1.5")))
except ValueError:
    GATEWAY_FOUND_RECONNECT_S = 1.5

# 🔥 Match control
START_MATCH_INTERVAL = 3.0
NEW_MATCH_DELAY = 3.0
# Matchs simultanés PAR PANEL (tous les comptes du panel, 0 = illimité ; PANEL_MAX_MATCHES dans .env).
# Valeur par défaut de chaque panel, remplacée par son réglage `panel_max_matches` s'il est >= 0.
# Les panels ne se partagent plus de plafond : N panels = N fois cette limite sur la machine.
# Mesuré sur l'historique : au-delà de ~120 parties en parallèle sur la machine, elles ne sont plus créditées.
try:
    PANEL_MAX_MATCHES = int(os.environ.get("PANEL_MAX_MATCHES", "60"))
except ValueError:
    PANEL_MAX_MATCHES = 60
MAX_MATCH_DURATION = 700
MATCH_IDLE_TIMEOUT = 8.0
PRIORITY_REGIONS = ["BD","IND", "SG", "TH", "PH", "VN", "MY", "ID", "HK", "TW"]

# 🔥 Modes de jeu : "lone_wolf" | "br" | "br_pony" | "br_ranked" | "br_ranked_rank" | "clash_squad" | "cs_ranked" |
#    "big_head" | "br_evolution", tous en matchs parallèles (match trouvé -> joué en arrière-plan, nouvelle recherche aussitôt)
MODE_TAGS = {"lone_wolf": "LONE WOLF", "br": "BR", "br_pony": "BR PONY", "br_ranked": "RANKED BR",
             "br_ranked_rank": "RANKED BR (RANK)", "clash_squad": "CLASH SQUAD", "cs_ranked": "RANKED CS 4VS4",
             "big_head": "BIG HEAD", "iron_cage_dual": "IRON CAGE DUAL", "iron_cage_duo": "IRON CAGE DUO",
             "br_evolution": "BR EVOLUTION"}
# (mode_id, map_id) du paquet UDP de chargement ; mêmes valeurs que les champs 5.7 / 5.8 du paquet « match trouvé »
MATCH_MODE_IDS = {"lone_wolf": (43, 11), "br": (1, 1), "br_pony": (1, 1), "br_ranked": (1, 1), "br_ranked_rank": (1, 1),
                  "clash_squad": (15, 1), "cs_ranked": (15, 1), "big_head": (16, 1),
                  "iron_cage_dual": (43, 11), "iron_cage_duo": (43, 11), "br_evolution": (85, 1)}
# mode / carte relus dans le « match trouvé »
SERVER_MAP_MODES = ("br", "br_pony", "br_ranked", "br_ranked_rank", "clash_squad", "cs_ranked", "big_head", "br_evolution")
# Modes dérivés (événement / carte) : StartMatch du mode de base avec le mode (2.2), le type de file (2.8) et les
# cartes (2.1) du mode (team_mode) ; carte du 448 = 5.6 du « match trouvé » ; 448 et partie comme une partie normale.
#   Big Head 2.0 (capture du 28/10 20:02, client officiel TH 1.132.14) : liste des modes « Big Head 2.0 », 13 = 16,
#                       14 = 1, escouade seule (19 = "4"), ouvert du 23/10 04:00 au 30/10 03:59 ; équipe 5.8 = 16,
#                       5.10 = 1, 5.7 = 01 ; accusé de recherche 0x03 {1: 01, 2: 16, 4: 1} ; match trouvé 5.7 = 16,
#                       5.8 = 1, 5.6 = 1 ; 448 : 16 / 1 en tête. Partie à réapparitions (256 / 393 après chaque 107,
#                       téléportation 145), sans avion ni manches, ~7 min jusqu'au MatchEnd (103) : +78 EXP (0x04).
#                       Niveau 3 minimum (table 5.4 {1: carte, 2: mode, 3: niveau} de la liste des modes : {1, 16, 3}) ;
#                       chef d'une équipe niveau 2 : recherche refusée, code 32 (teamlab, 28/10 20:22).
#   BR Pony (capture du 28/10 20:58, client officiel TH) : « Classic Mode (pony) » de la liste des modes (1 = 29,
#                       13 = 1, 14 = 1), BR normal sur la carte 29 seule ; accusé de recherche 0x03 {1: 1d, 2: 1,
#                       4: 1} ; match trouvé 5.7 = 1, 5.8 = 1, 5.6 = 29 ; 448 : 1 / 29 en tête ; partie BR (cabine,
#                       944 / 1250, parachute) ; aucun niveau minimum (pas de ligne mode 1 dans la table 5.4).
#   Iron Cage 2v2 (captures du 29/10, client officiel ME 1.132.15, création d'équipe op 1 + recherche op 9) : Lone Wolf
#                       (2.3 = 43) sur la carte 11 seule (2.2 = 0b), 2 places (2.4 = 1), file normale (2.9 = 1), sans
#                       2.20. Deux modes, même création à un champ près : « Iron Cage Dual » porte 2.22 = 1 et ne se lance
#                       pas seul (équipe de 2 complète) ; « Iron Cage Duo » n'a pas 2.22 et se lance aussi à 1 joueur.
#                       Recherche du chef identique aux autres modes (team_start_msg). Match trouvé (Duo, 29/10 23:20 en
#                       solo et 23:32 à 2) : 5.7 = 43, 5.8 = 1, 5.6 = 11, comme Lone Wolf (mode_for_match), partie
#                       jouée comme une partie Lone Wolf. Niveau 3 minimum (Lone Wolf) : chef niveau 2 refusé, code 32.
DERIVED_BASE_MODE = {"big_head": "clash_squad", "br_pony": "br", "iron_cage_dual": "lone_wolf",
                     "iron_cage_duo": "lone_wolf"}
IRON_CAGE_MODES = ("iron_cage_dual", "iron_cage_duo")
IRON_CAGE_FULL_TEAM = ("iron_cage_dual",)         # 2.22 = 1 dans la création : équipe complète obligatoire
# cartes (2.1 du StartMatch / 5.2 de l'équipe) des modes dérivés qui ne jouent pas la carte 1 (voir team_mode)
MODE_MAPS = {"br_pony": bytes([29]), "iron_cage_dual": bytes([11]), "iron_cage_duo": bytes([11])}
# Modes classés : StartMatch du mode de base, champ 8 de « main » au type de file classé (1 = partie normale) et liste
# de cartes (champ 1) du client officiel (le serveur en choisit une, 5.6 du « match trouvé »). Relevé dans l'accusé de
# recherche de la passerelle (5.1 = cartes, 5.2 = mode, 5.4 = type de file) et dans la liste des modes (0x03 {1: 7} :
# 13 = mode, 14 = type de file).
#   Ranked BR (16/10) : mode 1, type 2, cartes [1, 22, 29] ; avec ce paquet, le MatchPrepareInfo reçu a les mêmes
#                       champs classés que celui du client officiel (18 = 2, 34, 173 / 180 / 181, bloc de rang 5.18).
#                       Deux modes, même file et même partie : "br_ranked" part en cours de partie (BR_LEAVE_AFTER_S,
#                       EXP / niveau), "br_ranked_rank" reste jusqu'à la fin (points de rang ; test du 16/10 :
#                       1000 -> 1008 points, 0 EXP).
#   CS Rank 4vs4 (25/10, client officiel TH 1.132.13) : mode 15 (Clash Squad), type 6 (« CS Rank » de la liste des
#                       modes), cartes [1, 29, 22] ; match trouvé 5.7 = 15, 5.8 = 6, 5.6 = 1 (carte du 448), partie
#                       jouée jusqu'au MatchEnd (103) comme un Clash Squad : +92 EXP (résultat 0x04 ; 5.7.104 ->
#                       5.7.105 = 1100 -> 1100, sans doute les points de rang CS).
# Le reste suit le mode de base.
RANKED_BASE_MODE = {"br_ranked": "br", "br_ranked_rank": "br", "cs_ranked": "clash_squad"}
RANKED_MATCH_TYPES = {"br_ranked": 2, "br_ranked_rank": 2, "cs_ranked": 6}
RANKED_MAPS = {"br_ranked": bytes([1, 22, 29]), "br_ranked_rank": bytes([1, 22, 29]), "cs_ranked": bytes([1, 29, 22])}
# Fin du bloc « csoversea » du 448 (33 octets après la dernière adresse IP, avant l'heure) : partie normale = type de
# file 1 en avant-dernier octet ; parties classées du client officiel, par mode de base : Ranked BR (16/10, 24/10)
# type 2 ; CS Rank 4vs4 (25/10) type 6 précédé de 03, et 01 en 3e octet.
_JOIN_TAIL_NORMAL = bytes.fromhex("0000000000000100000000000000000000000001" "00000800000100000000000100")
RANKED_JOIN_TAILS = {
    "br": bytes.fromhex("0000000000000100000000000000000000000001" "00000000000100000000000200"),
    "clash_squad": bytes.fromhex("0000010000000100000000000000000000000001" "00000000000100000000030600"),
}
BR_MODES = ("br", "br_pony", "br_ranked", "br_ranked_rank", "br_evolution")   # parties BR : fin à la mort / au MATCH_END
STAY_TO_END_MODES = ("br_ranked_rank",)             # BR jamais quittés en cours de partie (BR_LEAVE_AFTER_S ignoré)
# Le joueur est déjà inscrit dans la partie trouvée : renoncer à s'y connecter = abandon. On insiste 60 s
# (hello renvoyé toutes les 7 s), dans tous les modes (avant : 25 s en Lone Wolf / Clash Squad).
HANDSHAKE_TIMEOUT = 60.0
# Envoi de Thunder / Sharma refusé par le système (WinError 10055…) : nouvel essai chaque seconde, abandon après 20 s
SEND_RETRY_EVERY_S = 1.0
SEND_GIVE_UP_S = 20.0
# Entrée dans la partie comme le client officiel (captures du 21/10, 2 parties classées) : HELLO -> ACK + HELLO du
# serveur (7 ms) -> notre accusé « 01 00 » -> 1er PING à ~1 s -> 447 (Thunder) puis 448 (Sharma) 30 ms plus tard, les
# deux ~1,2 s après le HELLO (0,9 s le 19/10). Le bot envoyait le PING avec le HELLO, le 447 dès l'ACK du serveur
# (8 ms), un accusé « 01 00 » de plus entre les deux, puis le 448 0,3 s après.
JOIN_DELAY_MIN_S = 1.05               # > PING_EVERY_S : le 1er PING précède toujours le 447, comme dans les captures
JOIN_DELAY_MAX_S = 1.3
THUNDER_SHARMA_GAP_S = 0.03
# BR : jusqu'au 15/10 vers 17:00, l'EXP arrivait à la mort du joueur, en cours de partie (83 % des relevés 0 à 5 min
# avant la fin). Depuis vers 17:30, un joueur resté connecté jusqu'à la fin ne reçoit plus d'EXP (0 sur plus de 12 000
# parties, comptes créés dans le jeu compris), alors qu'un joueur parti en cours de partie la reçoit, ~10 min après
# son départ (fin de la partie sur le serveur) : test du 15/10, compte du jeu, départ à 330 s -> +342 EXP ; resté
# jusqu'à la fin -> 0. Le Clash Squad n'est pas touché.
# BR_LEAVE_AFTER_S (.env) : départ de la partie BR après N s de connexion (partie comptée terminée). 0 = rester jusqu'à
# la fin (ancien comportement). Les bornes ci-dessous ne servent que de filet de sécurité.
try:
    BR_LEAVE_AFTER_S = max(0.0, float(os.environ.get("BR_LEAVE_AFTER_S", "330")))
except ValueError:
    BR_LEAVE_AFTER_S = 330.0
# BR_LEAVE_ON_DEATH (.env) : rester dans la partie BR jusqu'à la mort du joueur, puis la quitter aussitôt. Un départ
# en vie (BR_LEAVE_AFTER_S) est marqué « ABANDONED » dans l'historique (crédit : ReportType_LEAVING), un départ après
# la mort non. Mort repérée sans lire les messages chiffrés : tant que le joueur vit, le serveur corrige sa position
# (RUDP_FORCE_SYNC_PLAYER_STATE, ~4/s) ; ces corrections s'arrêtent dans la même seconde qu'un RUDP_DEAD (12 morts
# du bot sur 12 dans les captures du 14/10, UDP_BYEBYE du serveur 55 s après). Encore en vie à BR_DEATH_MAX_S :
# départ en vie comme avant, avant la fin de la partie (rester jusqu'à la fin = 0 EXP depuis le 15/10).
# 0 = désactivé ; 1 = tous les comptes ; sinon ID de jeu / UID séparés par des virgules (essai sur quelques comptes).
# À l'essai (16/10) : EXP d'un départ juste après la mort pas encore vérifiée.
_LEAVE_ON_DEATH = os.environ.get("BR_LEAVE_ON_DEATH", "0").strip()
BR_LEAVE_ON_DEATH_IDS = frozenset(x.strip() for x in _LEAVE_ON_DEATH.split(",")
                                  if x.strip() and _LEAVE_ON_DEATH not in ("0", "1"))
try:
    BR_DEATH_MAX_S = max(60.0, float(os.environ.get("BR_DEATH_MAX_S", "540")))
except ValueError:
    BR_DEATH_MAX_S = 540.0
# BR_LEAVE_HP (.env) : avec BR_LEAVE_ON_DEATH, départ EN VIE dès que les PV estimés tombent à ce seuil (0 = désactivé).
# Mourir = 0 EXP (mesuré le 16/10 : 3 morts sur 3, même en partant aussitôt), partir en vie la donne. PV estimés =
# ATTENTION, le « mourir = 0 EXP » ne vaut que pour le bot : chez le VRAI client, mourir donne l'EXP tout de suite.
# Capture du 23/10 12:32 (BR classé, mode 1, carte 1) : RUDP_DEAD à 62,0 s de partie, position #50 (mort parmi les
# premiers), et 0,9 s plus tard la passerelle envoie 0x0b + 0x04 : +154 EXP (48 -> 202), niveau 2 -> 3, 800 pièces,
# points de rang 2500 -> 2509. Idem dans les 2 parties du 21/10 (EXP 0,08 s après le RUDP_DEAD). Les 3 morts du
# 16/10 ne mesurent donc pas « la mort ne paye pas » mais « la mort du bot ne paye pas » : ce qui manque est
# ailleurs (voir UDP_JOIN_SEQ : des 12 messages fiables d'entrée du vrai client, le bot n'en sait écrire que 3,
# les autres sont des blocs anti-triche chiffrés avec une clé de session qu'on ne sait pas produire).
# Conséquence pratique : avec BR_LEAVE_ON_DEATH, le départ en vie passe à BR_DEATH_MAX_S (540 s) et le bot AFK
# meurt presque toujours dans la zone avant d'y arriver. Pour comparer, mettre br_leave_on_death à l'arrêt :
# le départ redevient br_leave_after_s (330 s), avant la zone. PV estimés =
# PLAYER_MAX_HP - dégâts reçus : UDP_PLAYER_HURT (2010, lisible avec la clé du match) dont la victime est le joueur
# local (LOCAL_PLAYER_ID) ; contenu = varints [victime, attaquant, arme, horloge, 0, dégâts…]. Le bot AFK meurt
# surtout dans la zone (1-2 PV par tick d'~1 s, 94 à 114 s entre les premiers dégâts et la mort, captures du 16/10) ;
# un tir retire 25 à 89 PV d'un coup.
try:
    BR_LEAVE_HP = max(0, int(os.environ.get("BR_LEAVE_HP", "0")))
except ValueError:
    BR_LEAVE_HP = 0
# BR_INSTA_LEAVE (.env, essai du 19/10, « ตายปุ๊บออกปั๊บ ») : quitter la partie BR dans la milliseconde où le serveur
# annonce la mort du joueur local, sans attendre (ni silence des corrections, ni réanimation) ; pas de départ à PV bas
# (BR_LEAVE_HP ignoré : on reste jusqu'à 0 PV) ; encore en vie à BR_DEATH_MAX_S : départ en vie comme avant.
# Mort du joueur local = RUDP_MATCH_EVENT_ACHIEVEMENT (872) reçu avec un RUDP_DEAD (107) : captures du bot, 30 872 sur
# 30 à sa propre mort, chacun avec un 107 à la même milliseconde, plus jamais d'état du joueur local ensuite ; vrai client
# (5 captures 17-18/10) : 872 à chacune de ses 5 morts (réanimable comprise), aucun aux autres morts de la partie. Le 872
# arrive 0,03 à 0,2 s après le dernier état du joueur ; la partie s'arrête aussitôt, depuis la lecture du paquet.
# Déjà mesuré le 16/10 18:11 : 3 bots partis 0,9 à 3 s après leur mort, 0 EXP sur 3.
# Depuis le 21/10 : AUCUN 191 à la mort (ni ici ni avec BR_LEAVE_ON_DEATH). Captures du vrai client du 21/10 (2 parties
# classées, morts à 59,6 s et 129,2 s) : l'EXP arrive 0,08 s après le RUDP_DEAD, le client se tait dans la seconde
# (2 derniers PING) sans envoyer de 191, et le serveur ferme lui-même (UDP_BYEBYE) ~55 s plus tard. Le 191 du 16/10
# était une sortie volontaire du joueur (menu), pas une mort.
# 0 = désactivé ; 1 = tous les comptes ; sinon ID de jeu / UID séparés par des virgules (comptes de test).
_INSTA_LEAVE = os.environ.get("BR_INSTA_LEAVE", "0").strip()
BR_INSTA_LEAVE_IDS = frozenset(x.strip() for x in _INSTA_LEAVE.split(",")
                               if x.strip() and _INSTA_LEAVE not in ("0", "1"))
RUDP_MATCH_EVENT_ACHIEVEMENT = 872
INSTA_PAIR_S = 0.5               # 872 et 107 reçus à moins de 0,5 s l'un de l'autre (0 ms dans toutes les captures)
UDP_PLAYER_HURT = 2010
LOCAL_PLAYER_ID = 16777217       # le joueur local (0x01000001) dans UDP_PLAYER_HURT : victime / attaquant
PLAYER_MAX_HP = 200
BR_DEATH_GAP_S = 3.0             # plus de correction de position depuis au moins 3 s…
BR_DEATH_GAP_FACTOR = 3.0        # … et 3 fois leur intervalle habituel (~0,2 s avec UDP_STATE_SYNC, 10 s sans : 14/10)
BR_DEATH_MATCH_S = 2.0           # … et un RUDP_DEAD à moins de 2 s de la dernière correction
# BR_NO_DATA_S / BR_NO_DATA_KB (.env) : partie BR rejointe (Sharma envoyé, le serveur répond aux PING) mais sans aucune
# donnée de jeu : quittée après BR_NO_DATA_S s si moins de BR_NO_DATA_KB Ko reçus, et le compte cherche aussitôt une
# autre partie. Relevé du 16/10 20:37 (compte …733) : 9 min de PING seuls, 2 Ko en tout, 0 EXP. 130 parties BR normales
# capturées : au moins 222 Ko reçus dans les 60 premières secondes (136 Ko à 30 s). BR_NO_DATA_S=0 : désactivé.
try:
    BR_NO_DATA_S = max(0.0, float(os.environ.get("BR_NO_DATA_S", "60")))
except ValueError:
    BR_NO_DATA_S = 60.0
try:
    BR_NO_DATA_KB = max(0, int(os.environ.get("BR_NO_DATA_KB", "20")))
except ValueError:
    BR_NO_DATA_KB = 20
# LOG_EVENTS (.env) : envoyer les LogEvent d'analytique du vrai client au serveur « event » de la région (voir
# ffbot.api_client.log_event), p.ex. EventTypeBRDeadInfo à la mort du joueur en BR. 0 = désactivé (défaut).
# Capture connue partielle (payload tronqué après map_id) : à n'activer qu'après avoir complété le payload.
LOG_EVENTS = os.environ.get("LOG_EVENTS", "0").strip().lower() not in ("", "0", "false", "no", "off")
# MATCH_HTTP_CALLS (.env) : requêtes HTTP du vrai client pendant une partie BR (api_client.MATCH_START_BODIES…) :
# GetQuickMsgSettings à +3 s, GetAccountExternalIconInfoByAccountIDs à +MATCH_ICON_CALL_S, et à la fin de la partie
# (mort ou départ) UpdateGuideOfNewPlayer {2: [187]} + GetAllAchievementDesc puis GetMatchmakingBlacklist. 0 = arrêt.
MATCH_HTTP_CALLS = os.environ.get("MATCH_HTTP_CALLS", "0").strip().lower() in ("1", "true", "yes", "on")
MATCH_ICON_CALL_S = 48.0      # relevés : 48,6 s (IND) et 49,0 s (TH) après le « match trouvé »


def _hurt_info(content: bytes) -> Optional[Tuple[int, int]]:
    """(victime, dégâts) d'après le contenu d'un UDP_PLAYER_HURT, None si illisible."""
    vals, i, n = [], 0, len(content)
    while i < n and len(vals) < 6:
        v = s = 0
        while i < n:
            b = content[i]
            i += 1
            v |= (b & 0x7F) << s
            s += 7
            if b < 0x80:
                break
        vals.append(v)
    if len(vals) < 6 or not 0 < vals[5] < PLAYER_MAX_HP:
        return None
    return vals[0], vals[5]


def _hurt_on_local(content: bytes) -> int:
    """Dégâts reçus par le joueur LOCAL_PLAYER_ID (0 si un autre joueur est touché)."""
    hit = _hurt_info(content)
    return hit[1] if hit and hit[0] == LOCAL_PLAYER_ID else 0


# Joueur local dans une partie : identifiant (place dans la partie) donné par le serveur, PAS toujours 0x01000001 comme
# le supposait LOCAL_PLAYER_ID. Le client l'écrit en tête de ses UDP_PLAYER_STATE_SYNC (2001) ; le serveur lui envoie
# des 2001 « 00 02 <n°> » avec le n° du joueur suivi : le sien tant qu'il vit (= 24 bits bas de son identifiant), celui
# qu'il regarde après sa mort, de nouveau le sien après une réanimation. Captures :
#   - vrai client, 12 parties du 15 au 17/10 : 0x01000001 (2001 envoyés 81 80 80 08, reçus 00 02 01) ;
#   - vrai client du 18/10 22:11 (nouvelle version du jeu) : 0x20000021 (a1 80 80 80 02, reçus 00 02 21, dégâts sur
#     0x20000021 ; 0x01000001 est alors un autre joueur) ;
#   - bot : 35 parties sur 251 avec un autre n° (14-18/10 : 3, 4, 48 à 50…). Ex. 18/10 01:25, deux bots d'une même
#     partie (n° 3 et 4) partis « PV bas » à la même seconde sur les dégâts identiques de 0x01000001, un autre joueur ;
#     un troisième (n° 4, 0x04000004 touché) jamais parti à PV bas, mort.
# _BrLife retient le n° des premiers 2001 reçus (le joueur vit) : joueur local = la victime de UDP_PLAYER_HURT dont les
# 24 bits bas sont ce n° ; avant (île d'attente, avion) : 0x01000001 comme avant. Les 2001 du bot (UDP_STATE_SYNC)
# portent cet identifiant ; n° connu mais identifiant complet pas encore (pas encore touché) : pas d'envoi.
LOCAL_INDEX_VOTES = 5            # 2001 reçus avec le même n° avant de le retenir comme celui du joueur local


def _next_interval(avg: float, gap: float) -> float:
    """Moyenne glissante de l'intervalle entre deux corrections de position."""
    return gap if not avg else avg * 0.8 + gap * 0.2


def _death_gap(avg: float) -> float:
    return max(BR_DEATH_GAP_S, BR_DEATH_GAP_FACTOR * avg)


def _leave_on_death(account_id, owner_uid) -> bool:
    if _LEAVE_ON_DEATH == "1":
        return True
    return str(account_id) in BR_LEAVE_ON_DEATH_IDS or str(owner_uid) in BR_LEAVE_ON_DEATH_IDS


def _insta_leave(account_id, owner_uid) -> bool:
    if _INSTA_LEAVE == "1":
        return True
    return str(account_id) in BR_INSTA_LEAVE_IDS or str(owner_uid) in BR_INSTA_LEAVE_IDS


# Réanimation (« เกิดใหม่ ») — captures du vrai client du 16/10 (13:06 et 22:09, BR) : à la 1re mort, le serveur envoie
# à la même seconde RUDP_DEAD, RUDP_S2C_SYNC_INVENTORY_INFO_FORDEATH (946) et RUDP_PLAYER_Notify_Enter_PENDING_REVIVE
# (256) ; le joueur ACHÈTE alors sa réanimation (RUDP_BuySelfRevive 767, envoyé 3,6 s et 9,1 s après) et le serveur
# répond RUDP_NOTIFYREVIVE (393), RUDP_S2C_KILLCAM_REVIVE_NOTIFY (1249, au seul joueur réanimé) et 767 : PV pleins
# (200 de dégâts jusqu'à la mort suivante, dans les deux parties). 2e mort : ni 256 ni réanimation, 191 ~5 s après.
# 7 autres morts du vrai client (60 à 248 s) : pas de 256, partie finie pour lui (résultat 0x04 < 1 s après la mort).
# 256 / 393 sont diffusés à toute la partie (7 bots d'une même partie les reçoivent à la même seconde) : un 256 n'est
# une offre pour le bot que s'il arrive à sa propre mort. Bots (19 morts dans logs/capture, 16-18/10) : aucun 256 à
# leur mort, jamais réanimés. Le bot n'envoie pas 767 (achat, coût inconnu).
# Morts vues à tort : le serveur suspend parfois ses corrections de position 60 à 250 s alors que le joueur vit
# (capture du 18/10 01:43 : 61 s, PV pleins, sorti plus tard à PV bas) ; si un autre joueur meurt à ce moment, la règle
# corrections + RUDP_DEAD conclut à la mort. Relevé des 17-18/10 : 179 départs BR_DIED_LEFT avec résultat, 19 avec le
# résultat à la mort (vraie mort), les 160 autres ~3 min après le départ, comme un départ en vie (83 % avec EXP).
# REVIVE_CHECK (réglage du site, หลังบ้าน → ตั้งค่าระบบ → การเล่นแมตช์ ; transmis à chaque partie, workers compris) :
# avant de quitter après une mort,
#   1. la mort doit être crédible d'après les PV : estimés <= DEATH_CONFIRM_HP, ou dernier coup reçu au même moment
#      assez fort pour tuer ; sinon elle est écartée et la partie continue (départ en vie plus tard : PV bas, durée) ;
#   2. réanimation proposée (256 à la mort) : attente de REVIVE_WAIT_S secondes ; joueur de retour (1249, ou
#      corrections de position / état du joueur local reprises) -> la partie continue, PV pleins ; sinon départ.
# Et la mort n'est repérée que si l'état du joueur local (2001 du serveur, voir LOCAL_INDEX_VOTES) s'est arrêté lui
# aussi : 140 des 230 pauses de plus de 10 s des corrections (16-18/10) se faisaient alors que cet état arrivait
# toujours (joueur vivant) ; à la mort du bot, les deux s'arrêtent à la même seconde (19 morts sur 19).
# 0 = ancien comportement : départ dès la mort repérée.
REVIVE_CHECK = 1
REVIVE_WAIT_S = 15
DEATH_CONFIRM_HP = 40            # PV estimés trop hauts de 10 à 20 à la mort (mort dans la zone : 9 et 19 PV estimés)
DEATH_HIT_WINDOW_S = 2.0         # coup mortel reçu à la même seconde que RUDP_DEAD (captures du vrai client)
REVIVE_OFFER_WINDOW_S = 3.0      # 256 à moins de 3 s de la mort : offre de réanimation pour le joueur local
LETHAL_HOLD_S = 6.0              # PV bas avec une réanimation proposée au même moment : départ retenu (mort ?)
# … une correction arrivée dans les 0,6 s qui suivent le coup ne prouve rien : le serveur envoie parfois la dernière
# juste après le coup mortel (vrai client du 18/10 : coup mortel à 381,40 s, dernière correction à 381,43 s)
LIFE_PROOF_S = 0.6
RUDP_INVENTORY_FOR_DEATH = 946
RUDP_PENDING_REVIVE = 256
RUDP_NOTIFY_REVIVE = 393
RUDP_KILLCAM_REVIVE_NOTIFY = 1249


class _BrLife:
    """Vie du joueur local dans une partie BR, lue sans la clé de session : PV estimés (UDP_PLAYER_HURT du joueur local,
    voir LOCAL_INDEX_VOTES), corrections de position et état du joueur (envoyés tant qu'il vit), morts annoncées
    (RUDP_DEAD), offre et retour de réanimation (256, 1249). step() dit à la partie quoi faire à chaque tour (voir
    BR_LEAVE_ON_DEATH, BR_LEAVE_HP, REVIVE_CHECK). `watch` : départs sur la mort et les PV bas (BR_LEAVE_ON_DEATH) ;
    sans, seuls les PV sont suivis (affichage)."""
    __slots__ = ("watch", "revive_check", "wait_s", "sync_last", "sync_iv", "dead_at", "victims", "local_id",
                 "local_idx", "idx_votes", "state_last", "base", "lethal_at", "offer_at", "notify_at", "death_t",
                 "death_until", "death_src", "doubt_t", "revivals", "ach_at")
    _VICTIMS_MAX = 128

    def __init__(self, watch: bool, revive_check: bool, wait_s: float):
        self.watch = watch
        self.revive_check = revive_check
        self.wait_s = max(0.0, float(wait_s))
        self.sync_last = 0.0         # dernière correction de position reçue
        self.sync_iv = 0.0           # intervalle habituel entre deux corrections (moyenne glissante)
        self.dead_at: deque = deque(maxlen=64)   # RUDP_DEAD reçus (morts dans la partie)
        # dégâts par victime : [total, coups, heure du dernier, dégâts du dernier, PV estimés avant lui] ; le joueur
        # local n'est pas toujours 0x01000001 (voir LOCAL_INDEX_VOTES)
        self.victims: Dict[int, List[Any]] = {}
        self.local_id: Optional[int] = None      # identifiant du joueur local, connu à son 1er coup reçu
        self.local_idx: Optional[int] = None     # son n° dans les 2001 du serveur (appris des premiers reçus)
        self.idx_votes: Dict[int, int] = {}
        self.state_last = 0.0        # dernier 2001 du serveur sur le joueur local (il vit)
        self.base = 0                # dégâts du joueur local avant sa dernière réanimation (PV pleins ensuite)
        self.lethal_at = 0.0         # PV estimés tombés à 0 à…
        self.offer_at = 0.0          # dernier 256 reçu (diffusé : offre pour le bot seulement à sa mort)
        self.notify_at = 0.0         # dernier 1249 reçu (réanimation du joueur local)
        self.death_t = 0.0           # mort en cours d'examen (dernière correction avant le silence), 0 = aucune
        self.death_until = 0.0       # départ à cette heure si le joueur n'est pas revenu
        self.death_src: Optional[str] = None   # "watch" (corrections + RUDP_DEAD) | "packet" (RUDP_DEAD lisible)
        self.doubt_t = 0.0           # silence écarté (PV encore hauts) : pas réexaminé
        self.revivals = 0
        self.ach_at = 0.0            # dernier 872 reçu (mort du joueur local avec un 107, voir BR_INSTA_LEAVE)

    def _local(self) -> int:
        """Identifiant du joueur local : n° pas encore appris -> 0x01000001 (ancienne règle) ; n° appris mais pas encore
        touché -> -1 (aucun dégât)."""
        if self.local_id is not None:
            return self.local_id
        return LOCAL_PLAYER_ID if self.local_idx is None else -1

    def state_id(self) -> Optional[int]:
        """Identifiant à écrire en tête des 2001 du bot (UDP_STATE_SYNC) ; None : pas encore connu, pas d'envoi."""
        if self.local_id is not None:
            return self.local_id
        if self.local_idx is None or self.local_idx == LOCAL_PLAYER_ID & 0xFFFFFF:
            return LOCAL_PLAYER_ID
        return None

    @property
    def lost(self) -> int:
        v = self.victims.get(self._local())
        return v[0] - self.base if v else 0

    @property
    def hits(self) -> int:
        v = self.victims.get(self._local())
        return v[1] if v else 0

    @property
    def last_hit(self) -> Optional[Tuple[float, int, int]]:
        """(heure, dégâts, PV estimés avant le coup) du dernier coup reçu par le joueur local."""
        v = self.victims.get(self._local())
        return (v[2], v[3], v[4]) if v and v[2] else None

    @property
    def hp(self) -> int:
        return max(0, PLAYER_MAX_HP - self.lost)

    def examining(self) -> bool:
        return bool(self.death_t)

    def on_packet(self, first: Optional[int], cmd: Optional[int], now: float) -> None:
        if first == RUDP_FORCE_SYNC_PLAYER_STATE:
            if self.sync_last:
                self.sync_iv = _next_interval(self.sync_iv, now - self.sync_last)
            self.sync_last = now
        elif first == RUDP_PENDING_REVIVE:
            self.offer_at = now
        elif first == RUDP_KILLCAM_REVIVE_NOTIFY:
            self.notify_at = now
        elif first == RUDP_MATCH_EVENT_ACHIEVEMENT:
            self.ach_at = now
        if first == RUDP_DEAD or cmd == RUDP_DEAD:
            self.dead_at.append(now)

    def own_death(self, now: float) -> bool:
        """Le joueur local vient de mourir : 872 et 107 reçus ensemble, à l'instant (voir BR_INSTA_LEAVE)."""
        return bool(self.ach_at) and now - self.ach_at <= INSTA_PAIR_S \
            and any(abs(t - self.ach_at) <= INSTA_PAIR_S for t in self.dead_at)

    def on_state(self, idx: int, now: float) -> None:
        """2001/2012 du serveur « 00 02 <n°> » : n° du joueur dont il envoie l'état (le joueur local tant qu'il vit)."""
        if self.local_idx is None:
            votes = self.idx_votes[idx] = self.idx_votes.get(idx, 0) + 1
            if votes < LOCAL_INDEX_VOTES:
                return
            self.local_idx = idx
            # joueur local : victime dont les 24 bits bas sont ce n° (coups reçus avant compris)
            self.local_id = next((v for v in self.victims if v & 0xFFFFFF == idx), None)
            if idx != LOCAL_PLAYER_ID & 0xFFFFFF:
                diag.event("MATCH", "local_player", level="info", idx=idx,
                           id=hex(self.local_id) if self.local_id is not None else None)
        if idx == self.local_idx:
            self.state_last = now

    def on_hit(self, victim: int, dmg: int, now: float) -> bool:
        """Dégâts reçus par un joueur (UDP_PLAYER_HURT : le bot reçoit aussi ceux des joueurs proches). True : joueur
        local."""
        v = self.victims.get(victim)
        if v is None:
            if len(self.victims) >= self._VICTIMS_MAX:
                return False
            v = self.victims[victim] = [0, 0, 0.0, 0, PLAYER_MAX_HP]
            if self.local_id is None and self.local_idx is not None and victim & 0xFFFFFF == self.local_idx:
                self.local_id = victim
                if self.local_idx != LOCAL_PLAYER_ID & 0xFFFFFF:
                    diag.event("MATCH", "local_player", level="info", idx=self.local_idx, id=hex(victim))
        local = victim == self._local()
        hp_before = PLAYER_MAX_HP - (v[0] - (self.base if local else 0))
        v[0] += dmg
        v[1] += 1
        v[2], v[3], v[4] = now, dmg, hp_before
        if local and self.lost >= PLAYER_MAX_HP and not self.lethal_at:
            self.lethal_at = now
        return local

    def packet_death(self, now: float) -> None:
        """RUDP_DEAD lisible qui désigne le compte (rare : son contenu ne se déchiffre presque jamais)."""
        if not self.death_t:
            self.death_t, self.death_src = now + 0.5, "packet"
            self.death_until = now + (self.wait_s if self.revive_check and self._offered(now) else 0.0)

    def _alive_state(self, now: float) -> bool:
        """L'état du joueur local (2001 du serveur) arrive toujours : il vit, quoi que disent les corrections."""
        return bool(self.state_last) and now - self.state_last < BR_DEATH_GAP_S

    def _died(self, now: float) -> bool:
        if not (self.sync_last and self.sync_iv and now - self.sync_last >= _death_gap(self.sync_iv)
                and any(abs(t - self.sync_last) <= BR_DEATH_MATCH_S for t in self.dead_at)):
            return False
        return not (self.revive_check and self._alive_state(now))

    def _credible(self, t_death: float) -> bool:
        if PLAYER_MAX_HP - self.lost <= DEATH_CONFIRM_HP:
            return True
        hit = self.last_hit
        return bool(hit and abs(hit[0] - t_death) <= DEATH_HIT_WINDOW_S
                    and hit[1] >= max(20, hit[2] - DEATH_CONFIRM_HP))

    def _offered(self, t_death: float) -> bool:
        return bool(self.offer_at) and abs(self.offer_at - t_death) <= REVIVE_OFFER_WINDOW_S

    def step(self, now: float, leave_hp: int) -> Optional[Tuple[str, Dict[str, Any]]]:
        """("low_hp" | "dead", infos) : partir ; ("death" | "doubt" | "revived" | "alive", infos) : à journaliser, la
        partie continue ; None : rien à faire."""
        if self.death_t:
            if self.notify_at > self.death_t or self.sync_last > self.death_t \
                    or self.state_last > self.death_t + 1.0:
                offer = self._offered(self.death_t)
                revived = self.notify_at > self.death_t or offer
                data = {"dead_s": round(now - self.death_t, 1), "offer": offer,
                        "notify": self.notify_at > self.death_t, "hp_est": self.hp}
                if revived:
                    # réanimé : PV pleins (captures du vrai client du 16/10 et du 18/10 : 200 de dégâts jusqu'à la
                    # mort suivante)
                    self.base += self.lost
                    v = self.victims.get(self._local())
                    if v:
                        v[2] = 0.0
                    self.lethal_at = 0.0
                    self.revivals += 1
                self.death_t = self.death_until = 0.0
                self.death_src = None
                return ("revived" if revived else "alive"), data
            if now >= self.death_until:
                return "dead", {"src": self.death_src, "offer": self._offered(self.death_t),
                                "waited_s": round(max(0.0, now - self.death_t), 1), "hp_est": self.hp}
            return None
        if not self.watch:
            return None
        low = bool(leave_hp) and PLAYER_MAX_HP - self.lost <= leave_hp
        if not self.revive_check:
            # ancien comportement : PV bas d'abord, puis mort repérée -> départ aussitôt
            if low:
                return "low_hp", {"hp": self.hp, "hits": self.hits}
            if self._died(now):
                self.death_t, self.death_src = self.sync_last, "watch"
                return "dead", {"src": "watch", "offer": self._offered(self.sync_last), "waited_s": 0.0,
                                "hp_est": self.hp, "new": True}
            return None
        if self._died(now) and self.sync_last != self.doubt_t:
            t_death = self.sync_last
            if self._credible(t_death):
                offer = self._offered(t_death)
                self.death_t, self.death_src = t_death, "watch"
                self.death_until = now + (self.wait_s if offer else 0.0)
                return "death", {"hp_est": self.hp, "offer": offer, "wait_s": self.wait_s if offer else 0,
                                 "silent_s": round(now - t_death, 1), "deaths": len(self.dead_at)}
            self.doubt_t = t_death
            hit = self.last_hit
            return "doubt", {"hp_est": self.hp, "silent_s": round(now - t_death, 1),
                             "last_hit": hit[1] if hit else None,
                             "hit_ago_s": round(now - hit[0], 1) if hit else None}
        if low:
            hit = self.last_hit
            if hit and max(self.sync_last, self.state_last) <= hit[0] + LIFE_PROOF_S:
                # pas de correction de position / d'état du joueur depuis le coup (la suivante, ~0,2 s, prouve qu'il
                # vit : départ en vie) :
                if now - hit[0] < LETHAL_HOLD_S and self._offered(hit[0]):
                    return None      # réanimation proposée au même moment (256) : la mort est vérifiée d'abord
                if now - hit[0] < LIFE_PROOF_S and any(abs(t - hit[0]) <= DEATH_HIT_WINDOW_S for t in self.dead_at):
                    return None      # mort annoncée avec le coup : l'offre éventuelle suit de quelques ms
            # sans offre : départ aussitôt, comme avant (attendre sous le feu, c'est risquer la mort)
            return "low_hp", {"hp": self.hp, "hits": self.hits}
        return None


BR_MAX_MATCH_DURATION = 1500     # au-delà de toute partie BR (~15 min)
BR_MATCH_IDLE_TIMEOUT = 60.0     # silence du serveur UDP : une coupure réseau / un pic de charge ne fait pas quitter
BR_HANDSHAKE_TIMEOUT = 60.0
# Clash Squad / Lone Wolf : parties en manches. L'ancienne borne de 700 s coupait ~15 % des parties CS en cours
# (historique : 5 parties CS sur 33 « interrompues après 700 s », les autres finies entre 5 et 11,5 min).
CS_MAX_MATCH_DURATION = 1200
LW_MAX_MATCH_DURATION = 1200
# mode -> (durée max. d'un match, silence max. du serveur UDP avant de considérer le match fini, délai de connexion)
MATCH_TIMING = {
    "lone_wolf": (LW_MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "br": (BR_MAX_MATCH_DURATION, BR_MATCH_IDLE_TIMEOUT, BR_HANDSHAKE_TIMEOUT),
    "br_pony": (BR_MAX_MATCH_DURATION, BR_MATCH_IDLE_TIMEOUT, BR_HANDSHAKE_TIMEOUT),
    "br_ranked": (BR_MAX_MATCH_DURATION, BR_MATCH_IDLE_TIMEOUT, BR_HANDSHAKE_TIMEOUT),
    "br_ranked_rank": (BR_MAX_MATCH_DURATION, BR_MATCH_IDLE_TIMEOUT, BR_HANDSHAKE_TIMEOUT),
    "clash_squad": (CS_MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "cs_ranked": (CS_MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "big_head": (CS_MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "iron_cage_dual": (LW_MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "iron_cage_duo": (LW_MAX_MATCH_DURATION, MATCH_IDLE_TIMEOUT, HANDSHAKE_TIMEOUT),
    "br_evolution": (BR_MAX_MATCH_DURATION, BR_MATCH_IDLE_TIMEOUT, BR_HANDSHAKE_TIMEOUT),
}
# Coupure réseau de la machine : un serveur de partie muet veut dire « partie finie » seulement si les autres
# parties (sur d'autres serveurs) reçoivent toujours. Si toutes se taisent en même temps, c'est le réseau (ou la
# boucle bloquée) : la partie est gardée jusqu'à OUTAGE_GRACE_S de plus, le ping continue, elle reprend au retour.
# Historique : 41 parties BR (23:36:55) puis 25 (01:36:50) quittées à la même seconde, 60 s après une coupure
# (GetLoginData en ConnectTimeout / WinError 1236), certaines après 74 s de jeu, et comptées « terminées ».
NETWORK_SILENCE_S = 5.0
OUTAGE_GRACE_S = 240.0
# Arrêt du serveur (Ctrl+C) : les parties en cours peuvent finir (SHUTDOWN_WAIT_S dans .env, 0 = coupées aussitôt).
try:
    SHUTDOWN_WAIT_S = max(0, int(os.environ.get("SHUTDOWN_WAIT_S", "1500")))
except ValueError:
    SHUTDOWN_WAIT_S = 1500
# Modes dont les parties ne sont jamais coupées par l'arrêt de la session (passer le compte, arrêt du panel,
# objectif atteint, watchdog, nouveau login) : elles continuent en arrière-plan jusqu'à leur fin réelle.
# Quitter une partie en cours = « Abandonné », sans EXP : tous les modes sont protégés.
UNINTERRUPTIBLE_MODES = ("br", "br_pony", "br_ranked", "br_ranked_rank", "clash_squad", "cs_ranked", "lone_wolf",
                         "big_head", "iron_cage_dual", "iron_cage_duo", "br_evolution")

# Commandes UDP (message_ids.py)
RUDP_MATCH_END = 103
# Mort d'un joueur. BR : fin de la partie seulement s'il désigne notre compte (la mort d'un autre joueur est ignorée).
# Clash Squad / Lone Wolf : jamais une fin de partie. Ces modes se jouent en manches (RUDP_CS_CURROUND_RESULT,
# RUDP_S2C_LWSO_CURROUND_RESULT) : une mort termine la manche, pas la partie. Avant, n'importe quelle mort (même
# celle d'un autre joueur) y faisait quitter la partie = « Abandonné ».
RUDP_DEAD = 107
# Sortie de partie (markdown ระยะ 5) : RUDP_PLAYER_QUIT_REQ (191, SendQuitRequest). Capture du vrai client du 16/10
# 13:06 (BR, mort, réanimation 767, 2e mort à 152,8 s, sortie) : 191 envoyé 4,8 s après la mort, fiable, n° d'ordre
# suivant, 26 octets = contenu VIDE (même taille que 899 LOADING_END, vide) ; puis le client se tait aussitôt (plus
# d'accusés : le serveur renvoie son dernier message à 0,5 / 1,1 / 2,3 / 4,7 s) et AUCUN 192 n'arrive. L'absence de
# 192 côté bot (4 envois le 16/10) est donc normale. L'EXP des parties quittées arrive avec ou sans 191.
RUDP_FORCE_SYNC_PLAYER_STATE = 144
RUDP_PLAYER_QUIT_REQ = 191
RUDP_PLAYER_QUIT_RES = 192
# Seules commandes auxquelles play_game réagit : les autres paquets (état de la partie) ne sont pas déchiffrés
_UDP_CONTROL_CMDS = frozenset({1, 2, 3, 100, 101, RUDP_MATCH_END, RUDP_DEAD})
# PING (cmd 3) : notre réponse a exactement le format d'un PING (compteur + 3 zéros), comme notre PING de maintien
# envoyé toutes les 3 s. Le serveur répondait donc à nos réponses et nous aux siennes : une boucle sans fin par
# compteur, une boucle de plus toutes les 3 s (relevé du 14/10 : trafic par partie de 376 à 685 paquets/s entre la
# 1re et la 10e minute, et une réponse envoyée pour 70 à 85 % des paquets reçus). Un compteur envoyé ou répondu il y a
# moins de PING_ECHO_WINDOW_S n'est plus répondu : chaque PING du serveur reçoit toujours sa réponse, une fois.
# UDP_PING_DEDUP=0 dans .env : ancien comportement (le journal compte alors les échos sans les bloquer).
# Cause de ces boucles : notre compteur était un entier 32 bits, alors que le serveur lit un varint et ne renvoie que
# lui (« 48 » pour 48 b0 8f 52) : écho méconnu, donc répondu. PING du client officiel (4 parties du 19/10) : toutes les
# ~1 s, contenu = millisecondes depuis le lancement du jeu en zigzag varint + 00 00 00 (même compteur d'une partie à
# l'autre : 7,5 min puis 92,7 min à 85 min d'écart), écho du serveur = le varint seul, et AUCUNE réponse du client aux
# PING reçus (tous des échos des siens). Le bot fait pareil (PING_EVERY_S, _client_launch) ; la déduplication reste.
UDP_PING_DEDUP = os.environ.get("UDP_PING_DEDUP", "1").strip().lower() not in ("0", "false", "no", "off")
PING_ECHO_WINDOW_S = 2.5
PING_EVERY_S = 1.0
_CLIENT_LAUNCH: Dict[str, float] = {}


def _client_launch(account_id) -> float:
    """« Lancement du jeu » d'un compte (origine du compteur de PING) : 2 à 30 min avant sa 1re partie, puis le même
    pour toutes ses parties (comme le compteur du client officiel)."""
    return _CLIENT_LAUNCH.setdefault(str(account_id), time.time() - random.uniform(120.0, 1800.0))


def _ping_counter(content: bytes) -> bytes:
    """Compteur d'un PING : le varint en tête du contenu (ce que le serveur renvoie en écho)."""
    for i, b in enumerate(content[:10]):
        if not b & 0x80:
            return bytes(content[:i + 1])
    return bytes(content[:4])
# Commandes relevées dans le journal de fin de partie (nombre, 1re et dernière réception) : déconnexion par le
# serveur (UDP_BYEBYE, UDP_LONGTIMENOSEE), sortie / mort du joueur, fin de partie, résultat, spectateur, début de la
# bataille (110, fin de l'île d'attente) et élimination d'équipe Clash Squad (455, même handler que 103 côté client).
_UDP_WATCH_CMDS = frozenset({4, 5, 102, 103, 107, 110, 130, 188, 191, 192, 305, 407, 455, 604, 798, 861,
                             RUDP_INVENTORY_FOR_DEATH, RUDP_PENDING_REVIVE, RUDP_NOTIFY_REVIVE,
                             RUDP_KILLCAM_REVIVE_NOTIFY})   # réanimation (voir REVIVE_CHECK)
# Messages fiables du serveur de partie (en-tête RUDP avec numéro d'ordre, sendOption >= 1) : le client en accuse
# réception (UDP_ACK, contenu = PROCHAIN numéro attendu, N+1, sur 2 octets : le serveur accuse ainsi nos Thunder (0)
# et Sharma (1) par « 01 00 » et « 02 00 »). Le bot n'accusait que les deux premiers : le serveur renvoyait tous les
# autres sans fin (relevé du 14/10 : RUDP_JOIN_MATCH_FINISHED reçu ~175 fois par partie, toutes les 2,3 s) puis coupait
# la connexion (UDP_BYEBYE : dernier paquet de 43 parties sur 43, entre 5 et 7,5 min) = partie « Abandonnée » en jeu.
# Captures du 14/10 : un accusé « N » n'accusait pas N (renvois > 2 s après, 149 cas) ; les renvois de N cessaient
# dès l'accusé « N+1 » (390 cas sur 402), et le dernier message de la partie était renvoyé 55 s jusqu'au BYEBYE.
# UDP_RUDP_ACK : 1 (défaut) accuse chaque message fiable ; 0 = ancien comportement ; ab = seulement les comptes à
# UID impair (comparaison des deux comportements sur la même période).
_rack_mode = os.environ.get("UDP_RUDP_ACK", "1").strip().lower()
UDP_RUDP_ACK = "ab" if _rack_mode == "ab" else "0" if _rack_mode in ("0", "false", "no", "off") else "1"
_NO_ACK_CMDS = frozenset({1, 2, 3, 4, 5, 6})     # contrôle UDP (HELLO, ACK, PING, BYEBYE…) : jamais accusé
# Fin de chargement (RUDP_C2S_LOADING_END, 899), envoyée par le client du jeu ~3 s après JOIN_MATCH_POST (Sharma) et
# jamais par le bot. Contenu vide (relevé du 15/10, client 1.132.11 : même chiffré que 1446, vide). Le client la chiffre
# avec sa clé de session (créée par l'anti-triche) ; sans clé de session, client et serveur se replient sur la clé du
# match (UDPSession::GetPayloadKey), celle qu'utilise le bot. UDP_LOADING_END=1 : envoi (test).
UDP_LOADING_END = os.environ.get("UDP_LOADING_END", "0").strip().lower() in ("1", "true", "yes", "on")
RUDP_C2S_LOADING_END = 899
# Séquence d'entrée du client officiel, identique dans les 4 captures du vrai client (19, 21, 22 et 23/10 ; clé de
# session lue le 22/10, donc contenus déchiffrés) : après le 448, DOUZE messages fiables à la suite, toujours dans
# le même ordre, numéros d'ordre CONTIGUS, aux mêmes délais après le 448 (un numéro manquant bloque tous les
# suivants : le serveur attend le message perdu avant de traiter la file).
#   +0,2 à 0,5 s  1364 RUDP_C2S_GGPInfoExt                       (blob anti-triche, illisible)
#   +1,5 à 2,4 s  1079 RUDP_C2S_GIN_CHECK_INFO                   (blob anti-triche, illisible)
#   +1,5 à 2,4 s  1026 RUDP_C2S_SYSTEM_INFO                      <- reproductible (voir _system_info_content)
#   +1,6 à 2,5 s  1446 RUDP_SYNC_ALL_LOADOUT_SUPPORT_SLOT_STATE  <- reproductible (contenu vide)
#   +1,8 à 2,7 s   899 RUDP_C2S_LOADING_END                      <- reproductible (contenu vide)
#   +1,9 à 2,8 s   308 RUDP_CLIENT_CLOTHES                       (identifiants des pièces portées par le compte)
#   +3,5 à 3,9 s   431 / 1672 / 453 x3                           (blobs anti-triche, illisibles)
# Le bot n'envoie que le 899, en numéro d'ordre 2 (la place du 1364). UDP_JOIN_SEQ=1 : les trois qu'on sait écrire
# octet pour octet, à la suite (2 = 1026, 3 = 1446, 4 = 899) et aux délais du vrai client.
#
# ARRÊTÉ PAR DÉFAUT, et voici pourquoi (mesure du 23/10 sur les captures du bot lui-même, logs/capture) : le serveur
# accuse chaque message fiable reçu, soit par un UDP_ACK seul, soit joint à un paquet qu'il envoie (en-tête étendu,
# flags & 4) ; le contenu est le PROCHAIN numéro attendu. Vrai client : accusés 1, 2, 3, 7, 14, 26, 27 + 14 à 36
# accusés joints — tout est accepté. Bot, 14 parties sur 14 : accusés 1 puis 2 (ou 1 puis 5 avec un jeton en
# 4 morceaux), AUCUN accusé joint. Autrement dit le serveur accepte le 447 et le 448, puis N'ACCUSE JAMAIS le 899
# — ni le 191 qui suit : sa file reste bloquée sur le numéro 2 pour toute la partie. Même forme de paquet que le
# vrai client (sendOption 2, flags 1, corps 16), donc ce qu'il refuse est le chiffrement : passé le 448, le serveur
# attend la clé de session créée par le SDK anti-triche. Elle n'apparaît nulle part en clair (cherchée dans les
# 4 captures ; celles qui se déchiffrent ont eu la clé lue en mémoire par frida) et ne se dérive ni de la clé du
# match, ni du jeton, ni du JWT. Envoyer 3 messages refusés au lieu d'1 n'apporte donc rien et laisse une trace de
# plus. Le code reste prêt pour le jour où une clé de session sera disponible ; rel_out / ack_next dans le journal
# de fin de partie disent en direct jusqu'où le serveur a accepté (voir _MatchTraffic).
UDP_JOIN_SEQ = os.environ.get("UDP_JOIN_SEQ", "0").strip().lower() in ("1", "true", "yes", "on")
# Essai 28/10 : le canal fiable + clé de session cale (ack_next=2, le serveur n'accuse jamais le 899 — voir plus haut).
# Comparaison client réel vs bot (capture ffcap_20261028_191735) : le vrai client envoie après le 448 une série de
# messages d'entrée (1364, 1079, 1026, 1446, 899 LOADING_END, 308, 431/1672/453 anti-triche) que le bot n'envoie
# jamais — candidats au blocage de l'EXP. On ne sait reconstruire que 1026 / 1446 / 899 (les autres sont des blobs
# anti-triche propres à la session). UDP_JOIN_UNREL=1 : envoyer ces trois-là en NON FIABLE + clé du match (comme le
# 248 qui marche), pour voir si le serveur nous compte alors comme « chargé » et crédite l'EXP.
UDP_JOIN_UNREL = os.environ.get("UDP_JOIN_UNREL", "0").strip().lower() in ("1", "true", "yes", "on")
# UDP_JOIN_REPLAY=1 : au lieu des trois messages reconstruits, rejouer TOUTE la séquence d'entrée capturée (1364,
# 1079, 1026, 1446, 899, 308, 431, 1672, 453×3 — y compris les blobs anti-triche qu'on ne sait pas fabriquer) depuis
# un fichier JSON, en NON FIABLE + clé du match. À N'UTILISER QUE sur le compte d'où vient la capture (le 1026/1364
# portent son appareil / jeton GGP) : sur un autre, l'écart serait un signal. Les blobs anti-triche ont un nonce
# propre à la partie -> rejoués dans une autre, ils peuvent être périmés. Essai 28/10 (l'utilisateur : « ต้องลอง »).
UDP_JOIN_REPLAY = os.environ.get("UDP_JOIN_REPLAY", "0").strip().lower() in ("1", "true", "yes", "on")
UDP_JOIN_REPLAY_FILE = os.environ.get("UDP_JOIN_REPLAY_FILE") or os.path.join(_ROOT_DIR, "captures", "entry_replay.json")
RUDP_C2S_SYSTEM_INFO = 1026
RUDP_SYNC_ALL_LOADOUT_SUPPORT_SLOT_STATE = 1446
SYSTEM_INFO_DELAY_S = 2.3      # 1026, délai après le 448 (relevés : 1,51 · 2,05 · 2,22 · 2,40 s)
LOADOUT_SLOT_DELAY_S = 2.45    # 1446 (1,61 · 2,17 · 2,38 · 2,51 s)
LOADING_END_DELAY_S = 2.7      # 899  (1,82 · 2,53 · 2,70 · 2,74 s ; 3,0 avant, sans les deux messages qui précèdent)
# Informations système du client officiel (1026, contenu lu le 22/10 avec la clé de session) : identifiant de
# l'appareil, processeur et mémoire — exactement les trois valeurs que le MajorLogin du même client a déjà
# déclarées (user_id, cpu_info, total_ram). Le bot envoie donc celles de SON login (LOGIN_CPU_INFO, LOGIN_TOTAL_RAM
# et l'appareil du compte, devices.json) : un écart entre les deux serait précisément ce qu'un contrôle croisé
# regarde. Chaque texte est précédé de sa longueur en zigzag varint, la mémoire est un zigzag varint.
LOGIN_CPU_INFO = "ARMv7 VFPv3 NEON | 2000 | 4"
LOGIN_TOTAL_RAM = 3940
# Synchro de l'heure (UDP_SYNC_SERVER_TIME, 2000, non chiffrée) : le serveur envoie un compteur toutes les ~2 s
# (3c00, 7800, b40100… : varint + 1 octet) et le client du jeu le renvoie aussitôt sans le dernier octet (3c, 78, b401…),
# relevé du 15/10 (1.132.11). Le bot ne répondait jamais. UDP_TIME_SYNC=1 : réponse (test).
UDP_TIME_SYNC = os.environ.get("UDP_TIME_SYNC", "0").strip().lower() in ("1", "true", "yes", "on")
UDP_SYNC_SERVER_TIME = 2000
# État du joueur (UDP_PLAYER_STATE_SYNC, 2001, non chiffré). UDP_STATE_SYNC=1 : envoi toutes les STATE_SYNC_EVERY_S
# d'un état « debout, immobile » relevé sur le client 1.132.11 (15/10, île d'attente) ; seuls changent l'octet avant
# 000000 et l'heure du client en ms (varint final), comme dans le relevé.
# Phases du client officiel (captures des 19 et 21/10, session key lue) : sur l'île d'attente ~7-8 états/s ; dès
# l'embarquement dans l'avion (RUDP_S2C_CABINWAITING_TeamParachuteInfo 944 + CabinWaitingPassTime 1250, 13,8 s et 14,0 s
# après le HELLO) PLUS AUCUN 2001 (16 à 25 s de silence) ; reprise ~10/s après son saut (3582 -> 3583 autorisé par le
# serveur), position qui bouge. Il ne reçoit JAMAIS de RUDP_FORCE_SYNC_PLAYER_STATE (144). Le bot, lui, envoyait la
# position de l'île 5 fois/s du début à la fin : dès l'embarquement (+3 s) le serveur le corrigeait à chaque 2001
# (144 x1063 dans la partie du 20/10 22:10, 5/s jusqu'au départ) — un joueur « faux » aux yeux du serveur (0 EXP à la
# mort ?). Depuis le 21/10 : cadence de l'île (STATE_SYNC_EVERY_S), arrêt définitif des 2001 à l'embarquement (944 /
# 1250, le bot ne saute pas et ne connaît pas sa position ensuite : éjecté par l'avion, il reste où il tombe, le
# serveur le déplace lui-même), et arrêt au 1er 144 reçu (filet : le serveur refuse notre état, on cesse de l'affirmer).
UDP_STATE_SYNC = os.environ.get("UDP_STATE_SYNC", "0").strip().lower() in ("1", "true", "yes", "on")
# Cadence et départ relevés dans les 4 captures du vrai client (19, 21, 22 et 23/10) : intervalle médian 0,099 s
# (~10 états/s, et non 7-8 comme estimé d'abord), premier 2001 de 2,1 à 3,1 s après le 448 — juste après le dernier
# message de la séquence d'entrée (voir UDP_JOIN_SEQ). Un seul silence par partie dans tout le relevé : celui de
# l'avion (8 à 26 s), là où le bot s'arrête pour de bon.
STATE_SYNC_EVERY_S = 0.1
STATE_SYNC_START_S = 3.0      # après le 448 (était lié à LOADING_END_DELAY_S, qui vaut maintenant 2,7)
UDP_PLAYER_STATE_SYNC = 2001
UDP_PLAYER_STATE_SYNC_V2 = 2012
RUDP_S2C_CABINWAITING_TEAMPARACHUTEINFO = 944
RUDP_S2C_CABINWAITINGPASSTIME = 1250
_BOARDING_CMDS = frozenset({RUDP_S2C_CABINWAITING_TEAMPARACHUTEINFO, RUDP_S2C_CABINWAITINGPASSTIME})
# Sortie comme le vrai client à la fin du séjour BR (markdown phase 5) : RUDP_PLAYER_QUIT_REQ (191, contenu vide,
# confirmé par la capture du 16/10) juste avant de quitter EN VIE (BR_LEAVE_AFTER_S, BR_LEAVE_HP). UDP_QUIT_ON_LEAVE=1
# pour activer. Jamais après la mort : le client officiel se tait simplement (voir BR_INSTA_LEAVE, captures du 21/10).
# QUIT_GRACE_S : attente après le 191 avant de fermer. Le vrai client n'attend pas (silence immédiat, pas de 192) :
# 0 par défaut ; une valeur > 0 garde la partie ouverte (accusés, pings) quelques secondes de plus.
UDP_QUIT_ON_LEAVE = os.environ.get("UDP_QUIT_ON_LEAVE", "0").strip().lower() in ("1", "true", "yes", "on")
# Accusés de réception groupés (capture du 16/10, client 1.132.11) : le client du jeu n'accuse pas chaque message fiable
# du serveur à part (le bot : un ACK par message, ~6 par seconde) mais « prochain n° attendu » pour tout ce qu'il a reçu,
# joint à un paquet qu'il envoie de toute façon (2001 / 2000 / PING / messages fiables : en-tête étendu, flags | 4 +
# 3 octets) ou, à défaut, seul peu après (~1,9 ACK seuls par seconde) : bien moins de paquets envoyés par partie. Le
# serveur renvoie un message non accusé après ~2 s : UDP_ACK_DELAY_S reste bien en dessous. 0 = ancien comportement
# (un ACK par message, aussitôt). Un ACK du serveur (nos HELLO / 447 / 448) n'est JAMAIS accusé en retour : le client
# officiel n'en renvoie aucun (0 sur 9, capture du 21/10) ; le bot répondait à chaque ACK reçu par le même ACK.
try:
    UDP_ACK_DELAY_S = max(0.0, min(1.0, float(os.environ.get("UDP_ACK_DELAY_S", "0.2"))))
except ValueError:
    UDP_ACK_DELAY_S = 0.2
# Jeton de partie partagé entre 447 (Thunder) et 448 (Sharma). Règle du client officiel (relevés du 16 au 19/10,
# jetons de 892 à 6 428 octets, tous conformes) : morceaux de JOIN_TOKEN_SPLIT (1060) tant qu'il en reste plus, puis UN
# morceau de JOIN_TOKEN_SECOND (660) s'il reste plus que ça, le reste à la fin du 448 (donc au plus 660 octets ; au-delà
# de ~950 le serveur ignorait la demande d'entrée). Ex. 6 428 -> 6 x 1060 + 68 ; 5 031 -> 4 x 1060 + 660 + 131 ;
# 892 -> 660 + 232. Les « 660 avant le 16/10, 1060 depuis » relevés au début étaient cette même règle.
try:
    JOIN_TOKEN_SPLIT = max(1, int(os.environ.get("JOIN_TOKEN_SPLIT", "1060")))
except ValueError:
    JOIN_TOKEN_SPLIT = 1060
JOIN_TOKEN_SECOND = 660
try:
    QUIT_GRACE_S = max(0.0, float(os.environ.get("UDP_QUIT_GRACE_S", "0")))
except ValueError:
    QUIT_GRACE_S = 0.0
# 2001 du client 1.132.11 : identifiant du joueur (varint, 81 80 80 08 = 0x01000001, voir LOCAL_INDEX_VOTES) puis l'état
_STATE_SYNC_REST = bytes.fromhex("eb8301d2eaa901edb8170000c80100000000000000bdb6e1f30300c4b6e1fb0b0000")
_STATE_SYNC_KEYS = (0x6C, 0x69, 0x68, 0x64, 0x66, 0x6D, 0x65)


def _varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)


def _dotnet_ticks(unix_ts: float) -> int:
    """Heure UNIX -> ticks .NET (100 ns depuis le 01/01/0001 UTC)."""
    return int(unix_ts * 10_000_000) + 621_355_968_000_000_000


def _zig(n: int) -> bytes:
    """Entier positif en zigzag varint (équivalent synchrone de has_ssan_zig)."""
    return _varint(n << 1)


def _system_info_content(device_id: str) -> bytes:
    """Contenu du RUDP_C2S_SYSTEM_INFO (1026) : appareil, processeur, mémoire (voir LOGIN_CPU_INFO).
    Relevé du 22/10 (clé de session lue), contenu du vrai client, octet pour octet :
        56 "Google|29ee4742-227a-48d3-85af-5e0a0be39e0d"  (0x56 = 86 = 43 x 2)
        5a "x86-64 SSE3 SSE4.1 SSE4.2 AVX AVX2 | 2000 | 4" (0x5a = 90 = 45 x 2)
        c83d                                               (= 7880 = 3940 x 2, la mémoire du MajorLogin)
    Les trois valeurs sont celles que le MajorLogin du même client a déclarées."""
    device = str(device_id or "").encode("utf-8")
    cpu = LOGIN_CPU_INFO.encode("utf-8")
    return _zig(len(device)) + device + _zig(len(cpu)) + cpu + _zig(LOGIN_TOTAL_RAM)


def account_system_info(account_data: Optional[Dict[str, Any]]) -> Optional[str]:
    """Contenu du 1026 d'un compte connecté (hex), à passer à la partie (opts["sysinfo"]) ; None si l'appareil du
    compte est inconnu. Appelé dans le processus principal : lui seul écrit devices.json."""
    if not account_data:
        return None
    device_id = account_data.get("device_id")
    if not device_id:
        key = account_data.get("auth_uid") or account_data.get("open_id")
        if not key:
            return None
        device_id = (get_device_for_account(str(key)) or {}).get("unique_device_id")
    return _system_info_content(device_id).hex() if device_id else None


async def state_sync_loop(sock, addr, key_bytes: bytes, lays, stop_event: asyncio.Event, t0: float, on_tx=None,
                          acker=None, ident=None):
    """État « immobile » envoyé toutes les STATE_SYNC_EVERY_S jusqu'à `stop_event` : embarquement dans l'avion, 1er 144
    reçu ou fin de la partie (voir UDP_STATE_SYNC).
    `on_tx(paquet)` : capture (UDP_CAPTURE), sinon ces envois manquaient dans logs/capture.
    `ident()` : identifiant du joueur local en tête du 2001 (None : pas encore connu, rien n'est envoyé ; voir
    LOCAL_INDEX_VOTES) ; sans : 0x01000001."""
    loop = asyncio.get_event_loop()
    i = 0
    sent_id: Optional[int] = LOCAL_PLAYER_ID
    head = _varint(LOCAL_PLAYER_ID) + _STATE_SYNC_REST
    while not stop_event.is_set():
        player = ident() if ident is not None else LOCAL_PLAYER_ID
        if player != sent_id:
            # autre identifiant que 0x01000001 (n° du joueur local appris) : en tête des 2001 suivants, ou envoi
            # suspendu tant qu'il n'est pas connu (le 2001 d'un autre joueur ne doit pas partir)
            diag.event("MATCH", "state_sync_id", level="info", id=hex(player) if player is not None else None,
                       prev=hex(sent_id) if sent_id is not None else None, sent=i)
            sent_id = player
            if player is not None:
                head = _varint(player) + _STATE_SYNC_REST
        if player is not None:
            ms = int((time.time() - t0) * 1000) + 1500
            content = head + bytes([0x1A + (i % 40)]) + b"\x00\x00\x00" + _varint(ms)
            pkt = udp_codec.build_packet(_STATE_SYNC_KEYS[i % len(_STATE_SYNC_KEYS)], lays[1], 0,
                                         UDP_PLAYER_STATE_SYNC, None, 0, content, key_bytes, CRC7_TABLE,
                                         encrypted=False, ext=acker.take() if acker is not None else None)
            if on_tx is not None:
                on_tx(pkt)
            try:
                await loop.sock_sendto(sock, pkt, addr)
            except Exception:
                _udp_stats.send_errors += 1
            i += 1
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=STATE_SYNC_EVERY_S)
        except asyncio.TimeoutError:
            pass


# ---------- Clash Squad : course vers l'équipe adverse (CS_CHASE) ----------
# Capture du 25/10 (CS Rank 4vs4, client officiel TH 1.132.13, session key lue) ; tout ce qui suit se lit avec la clé
# du match, sans la clé de session :
#   - 2012 du serveur : « 00 <2n> » puis n entrées [n° du joueur][x][y][z][vx][vy][vz] (zigzag varint ; position en
#     mm, vitesse en cm/s) + 7 octets, varint final. Les autres joueurs : coéquipiers toujours, adversaires vivants et
#     à portée (~100 m) seulement ;
#   - 2001 du serveur : « 00 02 <n°> » puis x, y, z, regard x100 du joueur suivi (le joueur local tant qu'il vit, un
#     coéquipier après sa mort) ; la nouvelle position y est dès la téléportation d'une manche (RUDP_TELEPORT_PLAYER
#     145, illisible) ;
#   - identifiant d'un joueur : (équipe << 24) | n°, équipe 1 = n° 1-4, équipe 2 = n° 5-8 (dégâts 2010 des 8 joueurs) ;
#   - 2001 du client, ~10/s toute la partie : identifiant, x, y, z (mm), regard x100 (3), joystick x100 (x, z, repère
#     du monde), vitesse cm/s (3), en l'air (0 / -1), allure (0 arrêt ou marche, 1 course, -6 saut), regard en float
#     (3), 0, 0, durée d'image en ms (13-24), 0, 0, 0, ms depuis la connexion (+330) ;
#   - chaque manche : téléportations (145, par rafales de 8) avec un RUDP_SAFE_ZONE_CHANGE (117) ; le joueur reste
#     bloqué dans sa base (joystick poussé, position immobile) jusqu'au 117 suivant, 27 à 28 s après le début ; il court
#     alors droit sur l'équipe adverse (4,5 à 5 m/s) et s'arrête à moins d'un mètre d'elle (3 manches sur 4).
# CS_CHASE (หลังบ้าน, essai) : le bot fait de même en Clash Squad / Ranked CS 4vs4 — pendant la préparation (position
# bloquée par le serveur) il tourne la tête, puis il ne s'arrête plus (essai du 25/10 18:40 : un bot planté après sa
# course paraît « bloqué ») : course en ligne droite vers l'adversaire visible le plus proche, au contact il tourne
# autour de lui, sans adversaire en vue il va là où il en a vu un en dernier, sinon il marche au hasard. Sans carte :
# les obstacles ne sont pas connus et la hauteur suit une droite jusqu'à celle de la cible. Position reprise sur celle
# du serveur dès qu'elles s'écartent (téléportation, correction : un mur) ; après une correction en marche, détour d'un
# quart de tour environ pendant ~1 s avant de reprendre sa route. La position renvoyée par le serveur suit la nôtre avec
# du retard (essai du 25/10 19:11 : « corrections » de 3,0 à 3,8 m toutes les ~0,7 s chez les 3 bots, en terrain
# découvert = ~0,7 s de retard à 4,5 m/s ; la reprendre ramenait le bot en arrière sans fin) : une position du serveur
# proche (CS_LAG_MATCH_M) de l'une des nôtres des CS_LAG_S dernières secondes n'est pas une correction, sauf si elle
# ne bouge plus depuis CS_STUCK_S alors que le bot marche : il est arrêté (mur ; sans cela le bot continuait 2 s à
# travers un mur simulé, puis y revenait sans fin).
# Équipes : le n° de joueur ne dit pas l'équipe (essai du 25/10 19:59 : coéquipiers pris pour des adversaires, bots
# qui suivaient leur équipe, zone estimée au ras de leur base). Relevées pendant la préparation — dans la base du bot
# (< CS_MATE_M) : coéquipier, au loin (> CS_FOE_M) : adversaire, pour toute la partie — et dans les dégâts
# (UDP_PLAYER_HURT : identifiant de la victime = (équipe << 24) | n°) ; le n° ne sert qu'en dernier recours.
# Hauteur : le bot flottait (même essai) ; elle est prise au sol relevé sous les autres joueurs (2012, vitesse verticale
# faible : au sol), case de CS_GROUND_CELL_M la plus proche, au lieu d'une droite vers la hauteur de la cible.
# Obstacles (pas de carte) : grille de cases de CS_GROUND_CELL_M — franchissables celles où un joueur (ou le bot,
# position confirmée par le serveur) a marché, inconnues plus chères (CS_UNKNOWN_COST), évitées CS_BLOCK_S celles où
# le serveur a arrêté le bot (correction en marche), et pas de montée de plus de CS_STEP_M d'une case à l'autre (mur,
# rebord ; la descente est permise). Vers une cible (adversaire, centre de la zone, dernier adversaire vu, coéquipier,
# base) : chemin A* recalculé toutes les CS_PATH_EVERY_S, le bot vise la 3e case ; en marche libre (tour autour d'une
# cible, au hasard) : direction changée si la case devant n'est pas franchissable. Arrêté en allant vers une cible : il
# longe l'obstacle (perpendiculairement à sa route, d'un côté) CS_SLIDE_S, puis reprend sa route ; arrêté de nouveau peu
# après : il le longe plus longtemps (x1,5, jusqu'à CS_SLIDE_MAX_S), et change de côté si c'est en le longeant (essai sur
# un mur simulé de 50 m : la grille seule, de 2 m, ne voyait pas un mur fin, le bot y restait collé).
# Immobilisé (essai du 25/10 20:35, logs/teamtest-chase.jsonl : position du serveur figée 30 s, toutes les directions
# refusées, puis mort — à terre, en attente de réanimation, le 256 qui accompagne chaque 107) : position du serveur
# immobile depuis CS_FROZEN_S en combat -> le bot ne court plus (plus de corrections en rafale) ; il rampe
# (CS_CRAWL_CM_S) vers le coéquipier le plus proche (réanimation), sinon vers le centre de la zone, CS_CRAWL_TRY_S
# toutes les CS_CRAWL_EVERY_S, à l'arrêt le reste du temps ; dès que la position du serveur bouge de nouveau, retour à
# la normale. À terre seulement avec au moins CS_KNOCK_HP de dégâts reçus dans la manche (2010 dont le bot est la
# victime) : essai du 25/10 22:23, 2 bots sur 3 coincés dans un recoin de leur base (x 1231-1234, z 107-122 : les
# joueurs réels en sortent en diagonale, au nord-est ou au sud-est), sans un dégât, pris pour « à terre » au bout de
# 3 s, ont rampé sur place 36 s jusqu'à leur mort. Sans ces dégâts (CS_ESCAPE_S) : coincé -> le bot suit, point par
# point, la trace d'un coéquipier (positions des 2012 de la manche) passé près de lui, jusqu'à CS_ESCAPE_DONE_M du
# recoin. Essai du 25/10 23:20 (même base) : un bot est passé sans correction par un passage d'~1 m (z 118,8-119,7,
# x 1231-1235), les deux autres, 1 m plus au nord, ont buté — la grille de 2 m ne voit pas un tel passage, et
# l'escape suivait la trace la plus proche (souvent celle d'un autre coincé), atteinte à 1,5 m près. D'où : trace la
# plus avancée vers le but (adversaire / centre), points tous les CS_TRACE_STEP_M, atteints à CS_ESCAPE_REACH_M, et
# après une correction, reprise au point de la trace le plus proche. Puis d'emblée, sans attendre d'être coincé : vers
# un adversaire (ou là où on l'a vu) à plus de CS_LEAD_FAR_M, la trace d'un coéquipier passée à moins de
# CS_LEAD_NEAR_M et allée CS_LEAD_GAIN_M plus près du but est suivie de la même façon jusqu'à son point le plus proche
# du but, puis course directe (chemins acceptés par le serveur : moins de corrections que la ligne droite). (Essayé aussi : cases inconnues plus chères après des corrections récentes — le chemin autour du mur simulé
# de 50 m passait de 18 s à 31 s, 6 fois sur 10 seulement : abandonné.)
# RUDP_FORCE_SYNC_PLAYER_STATE (144, contenu chiffré, en-tête lisible) : capture du bot du 25/10 22:48 (logs/capture,
# 3 bots) — c'était la vraie raison des bots « coincés » : en rafales de 4 à 16 (une toutes les 0,1 s, jusqu'à 1,6 s),
# position du serveur figée, tant que nos 2001 ne reviennent pas à la position imposée (le vrai client la confirme par
# un 146, chiffré avec la clé de session : le bot ne peut pas). Deux causes : hauteur fausse (un bot : 1 à 3 m
# au-dessus du sol du serveur à chaque 144 ; 6 à 14 % des 2001 à plus de 0,5 m — le sol relevé sous un joueur monté
# sur une caisse vaut pour toute sa case de 2 m) et écart au sol de 1 à 3 m (mur). D'où : hauteur = celle du serveur
# (sol relevé seulement sans position du serveur récente) ; dès un 144, position reprise sur celle du serveur comme
# une correction (cases bloquées, longer l'obstacle), CS_FORCE_HOLD_S à l'arrêt, au plus une par CS_FORCE_EVERY_S.
# Fin de la préparation : le 117 pris pour le début du combat arrive parfois avant que le serveur ne lâche les joueurs
# (essai du 25/10 22:58 : combat vu à +22 s, bots retenus dans leur base jusqu'à ~+28 s, corrections de 2 à 5 m, cases
# de la sortie de la base bloquées 45 s, « coincés » au départ). Le bot n'est libéré qu'une fois déplacé de
# CS_RELEASE_M par le serveur (ou CS_RELEASE_WAIT_S après) ; avant, ses corrections ne bloquent pas de cases et ne
# comptent pas pour « coincé ». Captures du bot des 25/10 22:48, 22:58 et 23:10 (12 manches-bot) : sans 144 pendant
# la préparation, le serveur le déplace à +23-27 s ; avec un 144 à ~+10 s (préparation, position envoyée = la sienne,
# cause invisible ; 4 fois, toujours en manche 1), seulement à +63-73 s — le 146 de confirmation exige la clé de
# session. Retenu : à l'arrêt sur la position du serveur, essai de CS_PROBE_S toutes les CS_PROBE_EVERY_S (directions
# CS_PROBE_DEG) au lieu de courir et d'être corrigé des dizaines de fois ; 144 reçu avant : CS_PINNED_WAIT_S.
# Allure (repris de GG.GLORY, app.py MovementTracker « circle » : angle +0,1 à 0,3 rad et pas de 120 à 280 tirés à
# chaque envoi) : marche au hasard en virage continu (CS_CURVE_DEG_S, retiré toutes les CS_CURVE_EVERY_S) au lieu de
# demi-tours brusques, léger louvoiement vers une cible (CS_WEAVE_DEG), vitesse ±CS_SPEED_JITTER. Pas repris : son
# cercle autour de l'origine de la carte (position du serveur ignorée), son 2001 (UID du compte au lieu de
# l'identifiant du joueur, autre disposition) et ses envois à ~4/s (le vrai client : ~10/s, comme le bot).
# Marche en boucles (CS_LOOP_WALK, demande du 25/10 23:45 : « marcher en tournant, mais en avançant ») : vers une cible
# (chase / search / follow), avance CS_LOOP_FWD_CM_S + rotation CS_LOOP_SPIN_CM_S de période CS_LOOP_PERIOD_S (cycloïde
# allongée : petites boucles), en marche ; aussi sur une trace suivie d'emblée (lead) là où elle est droite, pas dans
# ses virages (passages étroits) ; pas près d'un obstacle connu, ni juste après une correction, ni à moins de
# CS_LOOP_NEAR_M de la cible, ni en s'échappant (escape), ni pour revenir dans la zone (course droite).
# Début de manche = téléportation du bot lui-même (saut de sa position > CS_TELEPORT_M, ou 1re position connue), pas les
# rafales de 145 (téléportations de n'importe quel joueur) : même essai, 145 non vus au passage à la manche 2 (le bot
# courait vers le centre de la zone de la manche 1, à 990 m, et est mort hors de la zone) et rafale de 145 en plein
# combat prise pour une nouvelle manche (bots remis « en préparation », immobiles, tués en 12 s).
# Zone de la manche (la quitter = dégâts) : RUDP_SAFE_ZONE_CHANGE (117) et RUDP_SYNC_CSGAMEZONE_INFO (411) sont chiffrés
# avec la clé de session (capture du 25/10 déchiffrée : 117 = [rayon final][centre x][centre z][rayon de départ][centre]
# [22][étape][début ms][fin ms]…, étapes 0 = préparation, 1 = combat, 2 = resserrement de 70 s), illisibles pour le bot,
# qui n'en voit que l'arrivée (en-tête). Il l'estime donc : centre = milieu entre sa base et celle des adversaires vus
# pendant la préparation (écart au vrai centre : 1,1 / 4,4 / 8,7 m sur les 3 manches où ils étaient en vue ; sinon milieu
# avec le premier adversaire vu), rayon de départ = distance base-centre + 12 m (vrais : +10 à +17), resserrement
# linéaire à partir du 117 qui suit celui du combat, pendant CS_ZONE_SHRINK_S, jusqu'à CS_ZONE_FINAL_M. Le bot reste à
# l'intérieur du rayon qu'aura la zone dans CS_ZONE_AHEAD_S, moins CS_ZONE_MARGIN_M : au-delà il court vers le centre ;
# une cible au dehors n'est suivie que jusqu'au bord. Centre encore inconnu (aucun adversaire vu, manche 4 de la capture :
# bases à ~170 m) : il suit le coéquipier le plus proche (toujours dans les 2012 ; un joueur réel reste dans la zone),
# sinon il ne s'éloigne pas de plus de CS_HOME_M de sa base (dans la zone de départ).
# Dégâts de zone (essai du 25/10 23:53 : 3 bots morts dans la zone, estimée 5 à 9 m plus large) : UDP_PLAYER_HURT dont
# l'attaquant est la victime, arme CS_ZONE_WEAPON, 50 à 65 par seconde. Reçus par le bot : hors zone pendant
# CS_ZONE_HURT_S (course vers le centre, sans boucles), rayon estimé ramené à sa distance au centre moins
# CS_ZONE_HURT_CAP_M pour la manche ; toujours touché CS_ZONE_LOST_S après : course vers le milieu des joueurs vus
# qui n'en reçoivent pas (eux sont dans la zone).
CS_CHASE = os.environ.get("CS_CHASE", "0").strip().lower() in ("1", "true", "yes", "on")
CS_MODES = ("clash_squad", "cs_ranked") + BR_MODES
RUDP_SAFE_ZONE_CHANGE = 117
RUDP_TELEPORT_PLAYER = 145
CS_TEAM_SIZE = 4
CS_RUN_CM_S = 450             # course (allure 1) du joueur réel : 4,5 à 5 m/s
CS_STOP_M = 1.5               # fin de la course à cette distance de la cible : on tourne autour d'elle…
CS_RESUME_M = 2.5             # … et la course reprend au-delà de celle-ci (adversaires qui bougent) ; 4 m avant le
#                               29/10 (demande : « เข้าไปวนเลย … วนๆ อยู่ตัวสัตรู » : collé à lui, pas de décrochage)
CS_ORBIT_M = 1.2              # rayon visé autour de la cible (2 m avant le 29/10), parcouru en course (CS_ORBIT_RUN)
CS_ORBIT_RUN = True           # tour autour de la cible à l'allure de course (pas de 2001 CS_RUN_STEP_M), pas en marche
CS_WALK_CM_S = 250            # marche (recherche, au hasard ; autour de la cible sans CS_ORBIT_RUN)
CS_ORBIT_FLIP_S = (1.5, 3.0)  # changement de sens autour de la cible / de direction au hasard
CS_DETOUR_S = (0.8, 1.6)      # durée d'un détour après une correction du serveur
CS_DETOUR_DEG = (70.0, 110.0)
CS_AIM_DEG_S = 40.0           # préparation : rotation de la tête
CS_ZONE_EXTRA_M = 12.0        # rayon de départ de la zone = distance base-centre + ceci
CS_ZONE_FINAL_M = 12.0        # rayon visé à la fin du resserrement (vrai : 22 m, 117 déchiffrés de 4 captures du vrai
#                               client, 26/10 ; centre estimé à 0,3-8 m du vrai : 22 - 8 - marge)
CS_ZONE_SHRINK_S = 70.0       # durée du resserrement (étape 2 du 117, 4 manches sur 4)
CS_ZONE_SHRINK_AFTER_S = 20.0  # sans le 117 du resserrement : il commence 20 s après celui du combat (relevé)
CS_ZONE_AHEAD_S = 4.0
CS_ZONE_MARGIN_M = 3.0
CS_ZONE_HURT_S = 2.0          # dégâts de zone (2010, attaquant = la victime, arme 1) depuis moins de 2 s : hors zone…
CS_ZONE_HURT_CAP_M = 5.0      # … rayon estimé ramené à la distance au centre moins 5 m (pour la manche)…
CS_ZONE_LOST_S = 3.0          # … et encore touché 3 s après : centre faux, course vers les joueurs épargnés
CS_ZONE_WEAPON = 1
CS_FOLLOW_M = 4.0             # zone inconnue : on suit un coéquipier jusqu'à cette distance
CS_HOME_M = 15.0              # zone inconnue, personne en vue : rayon de marche autour de la base
# Vraie zone (08/11) : le bot a la clé de session (session_keys.json / replay, rel_key) : le contenu du 117 est lu en
# partie (on_zone) — centre, rayon, centre visé, rayon final, étape, durée — au lieu de l'estimer. Estimation gardée si
# le 117 reste illisible.
CS_ZONE_TRUE_MARGIN_M = 4.0
# Zone d'abord (demande du 08/11, capture d'écran : bot au bord de la zone qui hésitait entre y rentrer et tourner autour de
# l'adversaire, va-et-vient jusqu'à mourir dans la zone) : sorti du rayon sûr (ou touché par la zone), le bot rentre et ne
# reprend rien d'autre avant d'être CS_ZONE_BACK_M à l'intérieur (hystérésis) ; et toute cible (adversaire, orbite, dernier vu,
# route de l'adversaire, chef, base d'en face) est ramenée CS_ZONE_INNER_M à l'intérieur du bord : l'orbite (CS_ORBIT_M) autour
# d'un adversaire resté dehors se fait dans la zone.
# Zone qui se déplace (capture du vrai client du 08/11 05:33, 117 déchiffrés, 4 manches) : après le resserrement (étape 2,
# 70 s, R -> 20/22 m), étape 6 (5 s) qui annonce le nouveau centre (centre visé à 22-30 m), étape 7 (30 s) : le centre glisse
# vers lui, rayon inchangé ; puis étape 6 / 4 (fixe). Vraie zone lue : étape 7 = centre interpolé ; étape 6 avec un centre visé
# différent = cercle sûr pour les deux (milieu des centres, rayon R - écart / 2) : le bot s'y place avant le glissement.
# Sans 117 lisible (pas de clé de session) : 4e 117 après le combat = déplacement annoncé (zone_moving) ; touché par la zone
# alors : refuge (joueurs épargnés) tout de suite, sans attendre CS_ZONE_LOST_S.
CS_ZONE_FIRST = os.environ.get("CS_ZONE_FIRST", "1").strip().lower() in ("1", "true", "yes", "on")
CS_ZONE_BACK_M = 6.0
CS_ZONE_INNER_M = 4.0   # vraie zone : le bot reste à 4 m à l'intérieur du rayon qu'elle aura dans CS_ZONE_AHEAD_S
# Groupe (demande du 08/11 : « les 4 bots toujours à la même position ») : les coéquipiers suivent un chef commun, le
# coéquipier vivant de plus petit n° (tous les bots de l'équipe font le même choix sans se parler) ; le chef joue comme
# avant, les autres restent à CS_PACK_M de lui (course au-delà, petit tour autour de lui en deçà). La zone passe avant.
CS_PACK = os.environ.get("CS_PACK", "1").strip().lower() in ("1", "true", "yes", "on")
CS_PACK_M = 2.5
CS_PACK_ORBIT_M = 1.2
# Début de manche sans adversaire en vue (demande du 08/11 : « aller tout droit jusqu'à le trouver ») : course droite de
# la base vers la base d'en face (symétrique par rapport au centre de la zone), ramenée dans la zone, au lieu de patrouiller.
CS_STRAIGHT = os.environ.get("CS_STRAIGHT", "1").strip().lower() in ("1", "true", "yes", "on")
CS_STRAIGHT_DONE_M = 4.0      # arrivé à la base d'en face sans rien voir : patrouille comme avant
# Mur (demande du 08/11 : bouton pour l'enlever) : CS_WALL_TURN = 0 -> plus de changement de direction devant un obstacle
# (ni détour après une correction du serveur, ni longer l'obstacle, ni virage devant une case bloquée connue) ; le bot
# reprend la position du serveur et garde sa direction.
CS_WALL_TURN = os.environ.get("CS_WALL_TURN", "1").strip().lower() in ("1", "true", "yes", "on")
# Route de l'adversaire (demande du 08/11 : « suivre la route de leur ennemi toujours ») : vers un adversaire (vu, ou vu
# en dernier), le bot suit la trace de ses positions (2012, un point tous les CS_TRACE_STEP_M) jusqu'à lui — chemin où
# un joueur est passé, donc praticable ; loin de la trace : il la rejoint d'abord (au point le plus proche).
CS_FOE_TRACE = os.environ.get("CS_FOE_TRACE", "1").strip().lower() in ("1", "true", "yes", "on")
CS_FOE_TRACE_NEAR_M = 2.5     # sur la trace à moins de… : on avance de point en point
CS_FOE_TRACE_REACH_M = 1.0    # point atteint à 1 m : le suivant
CS_FOE_TRACE_JOIN_M = 80.0    # trace plus loin que ça : pas suivie (poursuite comme avant)
# Soin (capture du vrai client du 08/11 04:09, CS, clé de session lue) : RUDP_TRYUSE_INVENTORY (131) [objet][01][horloge ms
# du match, comme le 2001] -> 204 PLAYER_DO_ACTION [joueur][00 01 …][objet][01] (soin en cours) -> ~3 s : 571
# USEMEDKIT_SUCCESS [01] et 112 (trousses restantes) -> ~5 s : 310 MEDKITHP_SYNC_UPDATE [joueur][PV] (175 puis 200 : PV
# rendus en 5 s). Trousse = objet 244, 2 par manche. Mort pendant le soin : 132 du serveur [joueur…], le client répond 132
# [objet]. CS_HEAL : le bot se soigne dès que ses PV (200 - dégâts reçus dans la manche, recalés par le 310) tombent à
# CS_HEAL_HP, au plus CS_HEAL_MAX fois par manche ; pas de 204 dans CS_HEAL_REPLY_S : plus de trousse pour la manche.
CS_HEAL = os.environ.get("CS_HEAL", "1").strip().lower() in ("1", "true", "yes", "on")
CS_HEAL_HP = 120
CS_HEAL_ITEM = 244
CS_HEAL_MAX = 2
CS_HEAL_EVERY_S = 4.0         # utilisation de ~3 s : pas de nouvel essai avant 4 s
CS_HEAL_REPLY_S = 1.5
# Immobile pendant le soin (demande du 08/11 : en marchant, le soin ne passe pas) : jamais lancé hors de la zone sûre (le bot
# y rentre d'abord) ; ensuite à l'arrêt jusqu'au 571 (soin fait), au plus CS_HEAL_HOLD_S ; zone qui le touche ou se resserre
# sur lui pendant ce temps : il bouge quand même pour y rentrer (soin perdu, nouvel essai une fois dedans).
CS_HEAL_HOLD_S = 3.6
CS_HEAL_IN_M = 6.0           # soin lancé seulement à 6 m au moins à l'intérieur du bord sûr (sinon : vers le centre d'abord)
# Achat d'arme (même capture) : en préparation, 1492 C2S_SYNC_USE_CSSHOP [01] (boutique ouverte), 413 PURCHASE_CSITEMS
# [00 02 09 01] -> 413 du serveur (achat fait) et 112 (arme 56 rendue) ; puis 108 CHANGE_INVENTORY_ON_HAND [joueur][90]
# (le pistolet acheté en main) et 1492 [00] (boutique fermée). Même achat à chaque manche (argent insuffisant : le serveur
# ne répond pas 413, la boutique est refermée après CS_BUY_REPLY_S).
CS_BUY = os.environ.get("CS_BUY", "1").strip().lower() in ("1", "true", "yes", "on")
CS_BUY_ITEM = bytes.fromhex("00020901")
# Canal du soin et de l'achat (essai du 08/11 05:31-05:36 : 1 à 4 soins envoyés par bot et par match, aucun accepté ; 117
# jamais lu) : sans clé de session (captures/session_keys.json et capture « replay » absents), un message fiable part chiffré
# avec la clé du match et le serveur l'ignore, et ses réponses (204 / 571 / 310, clé de session) sont illisibles. Le drone,
# lui, passe en non fiable avec la clé du match (CS_SKILL_UNRELIABLE). CS_ITEM_CHANNEL : "auto" = fiable + clé de session si
# le bot l'a, sinon comme le drone (non fiable, clé du match) ; "session" ; "unrel".
CS_ITEM_CHANNEL = os.environ.get("CS_ITEM_CHANNEL", "auto").strip().lower() or "auto"
CS_BUY_WEAPON = 90
CS_BUY_AFTER_S = 3.0          # après le début de la manche (préparation)
CS_BUY_REPLY_S = 2.0
RUDP_CHANGE_INVENTORY_ON_HAND = 108
RUDP_TRYUSE_INVENTORY = 131
RUDP_CANCELUSE_INVENTORY = 132
RUDP_PLAYER_DO_ACTION = 204
RUDP_MEDKITHP_SYNC_UPDATE = 310
RUDP_PURCHASE_CSITEMS = 413
RUDP_USEMEDKIT_SUCCESS = 571
RUDP_C2S_SYNC_USE_CSSHOP = 1492
_CS_ITEM_CMDS = frozenset({RUDP_PLAYER_DO_ACTION, RUDP_USEMEDKIT_SUCCESS, RUDP_MEDKITHP_SYNC_UPDATE,
                           RUDP_CANCELUSE_INVENTORY, RUDP_PURCHASE_CSITEMS})
CS_ROUND_GAP_S = 10.0         # au plus une nouvelle manche toutes les 10 s (téléportations successives du début)
CS_FIGHT_AFTER_S = 15.0       # 117 au moins 15 s après le début de la manche : fin de la préparation (relevé 19 à 28 s)
CS_FIGHT_FALLBACK_S = 32.0    # sans ce 117 : départ quand même 32 s après le début de la manche
CS_SEEN_S = 1.5               # adversaire vu dans un 2012 depuis moins de 1,5 s (sinon mort ou hors de portée)
CS_SNAP_M = 3.0               # écart avec la position du serveur au-delà duquel on la reprend…
CS_TELEPORT_M = 30.0          # … au-delà de celui-ci, c'est une téléportation (début de manche), pas un mur
CS_LAG_S = 2.0                # positions envoyées gardées pour reconnaître le retard du serveur
CS_LAG_MATCH_M = 1.0
CS_STUCK_S = 0.6              # position du serveur immobile depuis 0,6 s alors qu'on marche : arrêté (mur), pas en retard
                              # (au moins 1,5 x le retard relevé + 0,3 s : un serveur en retard de 0,7 s montre encore
                              # notre position de départ 0,7 s après qu'on s'est mis en marche)
CS_STUCK_GAP_M = 1.2          # … dès 1,2 m d'écart
CS_LEASH_M = 1.5              # position du serveur immobile depuis CS_LEASH_STILL_S : pas plus de 1,5 m au-delà
CS_LEASH_STILL_S = 0.3        # (on ne s'enfonce pas dans le mur ; 144 précédés d'écarts > 1,5 m : 48 % contre 19 %)
CS_MATE_M = 25.0              # préparation : joueur à moins de 25 m de la base du bot = coéquipier…
CS_FOE_M = 40.0               # … à plus de 40 m = adversaire
CS_GROUND_CELL_M = 2.0        # sol relevé sous les autres joueurs : taille de case
CS_GROUND_NEAR_M = 4.0        # case utilisée jusqu'à cette distance…
CS_GROUND_FAR_M = 12.0        # … sinon jusqu'à celle-ci ; sinon hauteur du joueur au sol vu le plus proche
CS_GROUND_VY = 80             # vitesse verticale (cm/s) au-delà de laquelle un joueur n'est pas au sol (saut, chute)
CS_STEP_M = 1.2               # montée max d'une case à la suivante (au-delà : mur, rebord) ; descente jusqu'à CS_DROP_M
CS_UNKNOWN_COST = 2.5         # case où personne n'a marché : franchissable, mais 2,5 fois plus chère
CS_BLOCK_S = 45.0             # case où le serveur a arrêté le bot : évitée pendant 45 s
CS_PATH_EVERY_S = 0.5         # recalcul du chemin
CS_PATH_MAX_NODES = 4000      # au-delà, pas de chemin : ligne droite
CS_PATH_MARGIN = 10           # cases autour du départ et de l'arrivée explorées
CS_SLIDE_S = 1.5              # arrêté en route : longe l'obstacle 1,5 s…
CS_SLIDE_MAX_S = 6.0          # … plus longtemps s'il est arrêté de nouveau dans les CS_SLIDE_AGAIN_S
CS_SLIDE_AGAIN_S = 8.0
CS_FROZEN_S = 3.0             # position du serveur figée depuis 3 s en combat : immobilisé (à terre ?)
CS_CRAWL_CM_S = 100           # immobilisé : reptation…
CS_CRAWL_TRY_S = 1.0          # … pendant 1 s…
CS_CRAWL_EVERY_S = 5.0        # … toutes les 5 s, à l'arrêt sinon
CS_KNOCK_HP = 150             # immobilisé ET au moins 150 PV perdus dans la manche (2010) : à terre ; sinon coincé
CS_ESCAPE_S = 2.5             # position du serveur figée depuis 2,5 s en combat, sans ces dégâts : coincé (recoin)…
CS_ESCAPE_NEAR_M = 10.0       # … on suit la trace d'un coéquipier passé à moins de 10 m (celle qui s'est le plus
#                               approchée du but : le coéquipier sorti, pas un autre coincé)…
CS_ESCAPE_REACH_M = 0.6       # … point par point (atteint à 0,6 m : passages de ~1 m, essai du 25/10 23:20)…
CS_ESCAPE_DONE_M = 10.0       # … jusqu'à 10 m du point où l'on était coincé…
CS_ESCAPE_MAX_S = 12.0        # … au plus 12 s…
CS_ESCAPE_SNAPS = 4           # … et 4 corrections (trace abandonnée pour la manche)
CS_ESCAPE_PAUSE_S = 3.0       # échec : pas de nouvel essai avant 3 s
CS_LEAD_NEAR_M = 4.0          # en route vers un but : trace d'un coéquipier passée à moins de 4 m du bot…
CS_LEAD_GAIN_M = 5.0          # … et allée au moins 5 m plus près du but que le bot ne l'est : suivie d'emblée…
CS_LEAD_FAR_M = 15.0          # … tant que le but est à plus de 15 m (au-delà : course directe)
CS_LEAD_EVERY_S = 0.5         # recherche d'une telle trace
CS_LEAD_SNAPS = 2             # 2 corrections sur une trace : laissée pour la manche…
CS_LEAD_PAUSE_S = 5.0         # … et plus de trace pendant 5 s (mur simulé de 50 m : traces des joueurs réels au
#                               travers, essayées l'une après l'autre à 4 corrections chacune -> 2 passages sur 10)
CS_TRACE_STEP_M = 0.75        # trace d'un joueur dans la manche : un point tous les 0,75 m…
CS_TRACE_MAX = 600            # … au plus 600
CS_SERVER_FRESH_S = 1.0       # coincé seulement si le serveur envoie encore notre position (sinon : rien de neuf)
CS_FORCE_HOLD_S = 0.3         # 144 (position imposée par le serveur) : à l'arrêt sur sa position pendant 0,3 s…
CS_FORCE_EVERY_S = 0.4        # … une correction au plus toutes les 0,4 s (il les répète toutes les 0,1 s)
# ยืนยันการย้ายตำแหน่ง (146) : 144 [ident, 1, x, y, z, …] / 145 [ident, 2, x, y, z, …] ส่งถึงทุกคน ; client จริงตอบ
# เฉพาะของตัวเองด้วย 146 [ident ตัวเอง, ms (นาฬิกาเดียวกับ 2001), 1|2] ภายใน 14–40 ms (ffcap_20261026_085812 3.05 วิ,
# 162321 42.09 วิ). บอทไม่เคยตอบ : เซิร์ฟเลิกรับอินพุต (ค่า joystick ที่สะท้อนใน 2001 ลดลงจนเป็น 0) แล้วย้ายซ้ำทุก
# 0.5–1.5 วิ = บอท "ยืนนิ่ง" ในฐานจนตายวง (แมตช์ 27/10 20:19 บอท 3 : 145 ที่ 35.57 วิ แล้วค้าง 36 วิ). เนื้อ 144/145 อ่าน
# ไม่ได้ (session key) : ของเราคือตัวที่ตามด้วยตำแหน่งของเราจากเซิร์ฟกระโดด (CS_TP_JUMP_M จากที่คาด) หรือเซิร์ฟเลิก
# สะท้อนอินพุตทั้งที่เรากำลังเดิน ภายใน CS_TP_ACK_WINDOW_S. ส่งแบบ non fiable + clé du match (comme 248 / 543).
CS_TP_ACK = os.environ.get("CS_TP_ACK", "1").strip().lower() in ("1", "true", "yes", "on")
CS_TP_ACK_WINDOW_S = 3.0
CS_TP_JUMP_M = 0.5
RUDP_TELEPORT_ACK = 146
CS_RELEASE_M = 1.0            # combat vu, mais libéré de sa base seulement quand le serveur l'a déplacé de 1 m…
CS_RELEASE_WAIT_S = 8.0       # … (ou 8 s après) : avant, ses corrections ne sont pas des murs (ni cases, ni coincé)…
CS_PINNED_WAIT_S = 75.0       # … 75 s s'il a reçu un 144 avant (retenu presque toute la manche, voir CS_CHASE)
CS_PROBE_EVERY_S = 1.0        # retenu : à l'arrêt sur la position du serveur, avec un essai de CS_PROBE_S…
CS_PROBE_S = 0.4
CS_PROBE_FOLLOW_M = 0.5       # le serveur a suivi l'essai d'au moins 0,5 m : libéré
CS_PIN_AFTER_144_S = 60.0     # en combat, 144 depuis moins de 60 s et position figée CS_FROZEN_S : mêmes essais
#                               (captures du 25/10 : 62 des 328 144 suivis de 11 à 63 s d'immobilité)
CS_PROBE_DEG = (0.0, 60.0, -60.0, 120.0, -120.0, 180.0)   # … dans une direction qui change (vers la cible d'abord)
CS_CURVE_DEG_S = (10.0, 35.0)  # marche au hasard : virage continu (façon GG.GLORY), vitesse angulaire tirée…
CS_CURVE_EVERY_S = (1.5, 4.0)  # … et retirée (sens compris) toutes les 1,5 à 4 s
CS_WEAVE_DEG = 0.0             # vers une cible : louvoiement de ±N° (12 : écart latéral ~0,5 m à la course)… ARRÊTÉ :
#                                mur simulé de 50 m passé 3-4 fois sur 10 avec (10 sans), cause pas encore trouvée
CS_WEAVE_PERIOD_S = (2.0, 3.5)  # … de période 2 à 3,5 s, pas juste après une correction ni près de la cible…
CS_WEAVE_CLEAR = 3             # … ni à moins de 3 cases (6 m) d'une case évitée (obstacle connu)
# ARRÊTÉ par défaut (25/10 23:58, demande de l'admin : trop lent, « pas ce qu'on veut ») ; CS_LOOP_WALK=1 pour l'essayer
CS_LOOP_WALK = os.environ.get("CS_LOOP_WALK", "0").strip().lower() in ("1", "true", "yes", "on")
CS_LOOP_FWD_CM_S = 150        # vers une cible, en marche en boucles (CS_LOOP_WALK) : avance de 1,5 m/s…
CS_LOOP_SPIN_CM_S = 170       # … plus un tour de 1,7 m/s (plus que l'avance : des boucles, rayon ~0,7 m)…
CS_LOOP_PERIOD_S = 2.5        # … en 2,5 s ; vitesse de 0,2 à 3,2 m/s, en marche (pas de course)
CS_LOOP_NEAR_M = 6.0          # pas de boucles à moins de 6 m de la cible (tour autour d'elle à la place)
CS_LOOP_STRAIGHT_PTS = 5      # sur une trace (lead) : boucles seulement là où elle est droite (virage < 35° entre
CS_LOOP_STRAIGHT_DEG = 35.0   # ses 5 points suivants et les 5 d'après, ~3,8 m chacun ; 3 points / 25° : boucles sur
#                               10 % seulement du trajet, les traces réelles ondulent)
CS_RUN_STEP_M = 0.45           # course : 0,45 m par 2001 (toutes les STATE_SYNC_EVERY_S = 4,5 m/s)…
CS_RUN_MAX_CM_S = 500          # … sans dépasser 5 m/s (joueurs réels : 4,5 à 5) si l'intervalle est plus court
CS_SPEED_JITTER = 0.08         # vitesse ±8 % (course 4,1 à 4,9 m/s : celle des joueurs réels), retirée toutes les…
CS_SPEED_EVERY_S = (1.0, 3.0)  # … 1 à 3 s
CS_TIME_OFFSET_MS = 330
_CS_CHASE_CMDS = frozenset({UDP_PLAYER_STATE_SYNC, UDP_PLAYER_STATE_SYNC_V2, RUDP_TELEPORT_PLAYER,
                            RUDP_SAFE_ZONE_CHANGE, UDP_PLAYER_HURT, RUDP_FORCE_SYNC_PLAYER_STATE})

# Carte des passages (CS_WALKMAP, demande du 26/10 00:15 : « qu'il s'en souvienne ») : le bot n'a pas la carte du jeu
# et ne découvrait un mur qu'en s'y cognant (correction, souvent un 144 et des secondes figé). Toute position au sol
# d'un joueur (2012 des autres, position du serveur pour soi : acceptées par le serveur) marque sa case de
# CS_WALK_CELL_M comme praticable, avec sa hauteur ; gardées d'une partie à l'autre dans CS_WALK_FILE (fusion à
# l'écriture, dans un thread, en fin de partie). Le chemin A* (cases de 2 m) compte ces cases comme connues ; dans une
# zone déjà bien relevée (CS_WALK_KNOWN_N cases de 2 m connues sur les 5 x 5 autour du bot), une case inconnue coûte
# CS_UNKNOWN_COST_MAPPED (sans doute un mur) ; et le point visé dans une case de 2 m est le milieu de ses cases de
# 1 m praticables, pas son centre (passages d'~1 m).
CS_WALKMAP = os.environ.get("CS_WALKMAP", "1").strip().lower() in ("1", "true", "yes", "on")
CS_WALK_CELL_M = 1.0
CS_WALK_FILE = os.path.join(_ROOT_DIR, "data", "cs_walkmap.json")
CS_WALK_MAX = 800_000         # cases gardées au plus (~16 Mo de JSON)
CS_WALK_KNOWN_N = 8
CS_UNKNOWN_COST_MAPPED = 6.0
_cs_walk1: Dict[Tuple[int, int], float] = {}   # case de 1 m -> hauteur du sol (m)
_cs_walk2: Dict[Tuple[int, int], float] = {}   # case de 2 m (celle de l'A*) -> hauteur, d'après _cs_walk1
_cs_walk_state = {"loaded": False, "new": 0}


def _cs_walk_add(x: float, z: float, y: float) -> None:
    """Case de 1 m de (x, z) praticable (hauteur y), voir CS_WALKMAP."""
    c = (int(x // CS_WALK_CELL_M), int(z // CS_WALK_CELL_M))
    if c in _cs_walk1 or len(_cs_walk1) >= CS_WALK_MAX:
        return
    _cs_walk1[c] = y
    _cs_walk2.setdefault((c[0] // 2, c[1] // 2), y)
    _cs_walk_state["new"] += 1


# Emplacements de zone connus (data/cs_zone_spots.json, tools/cs_zone_spots.py : 117 déchiffrés des captures du vrai
# client — le bot ne peut pas lire le 117, chiffré avec la clé de session). Le serveur n'envoie PAS les adversaires
# pendant la préparation quand les deux bases sont à plus de ~100 m (zones de R >= 67 : bases à 55-83 m du centre) :
# le milieu « base - adversaires vus » n'existait alors pas, et l'estimation de secours (milieu base - premier
# adversaire vu en combat) tombait à 30-225 m du vrai centre (captures du bot du 25-26/10) -> morts de zone de toute
# l'équipe. Base du bot dans la zone de départ d'un emplacement connu (base relevée ou symétrique à CS_SPOT_BASE_M
# près, sinon le plus proche relativement à R) : centre et R de l'emplacement ; sinon CS_ZONE_GUESS_M vers le premier
# adversaire vu.
CS_ZONE_SPOTS_FILE = os.path.join(_ROOT_DIR, "data", "cs_zone_spots.json")
CS_SPOT_BASE_M = 25.0
CS_ZONE_GUESS_M = 60.0
_cs_spots: List[Dict[str, Any]] = []
_cs_spots_state = {"loaded": False}


def _cs_spots_load() -> None:
    """Emplacements de zone connus (CS_ZONE_SPOTS_FILE), une fois par processus."""
    if _cs_spots_state["loaded"]:
        return
    _cs_spots_state["loaded"] = True
    try:
        with open(CS_ZONE_SPOTS_FILE, encoding="utf-8") as f:
            _cs_spots[:] = [s for s in json.load(f) if s.get("center") and s.get("R")]
    except FileNotFoundError:
        pass
    except Exception as e:
        diag.event("MATCH", "cs_spots_load_failed", level="warning", exc=e)


def _cs_zone_spot(x: float, z: float) -> Optional[Dict[str, Any]]:
    """Emplacement connu dont la zone de départ contient la base (x, z), ou None (voir CS_ZONE_SPOTS_FILE)."""
    best = None
    for s in _cs_spots:
        cx, cz = s["center"]
        d = math.hypot(x - cx, z - cz)
        if d > s["R"] - 3:
            continue
        bases = list(s.get("bases") or ())
        bases += [(2 * cx - b[0], 2 * cz - b[1]) for b in bases]     # l'autre équipe : base symétrique (à ~20 m près)
        bd = min((math.hypot(x - b[0], z - b[1]) for b in bases), default=None)
        key = (0, bd) if bd is not None and bd <= CS_SPOT_BASE_M else (1, d / s["R"])
        if best is None or key < best[0]:
            best = (key, s)
    return best[1] if best else None


# Trajets des vrais joueurs (data/cs_routes.json, tools/cs_routes.py ; demande du 28/10 : « ต้องการมูฟเม้นตามนี้ ให้อ่านชื่อ
# เมืองและฝั่งให้ดี เพื่อทำตาม »). Depuis le 29/10 (« เส้นทางใหม่คือเส้นทางที่สามารถเดินได้โดยไม่ติดสิ่งกรีดขวาง … แต่ไม่ต้องอ้อม …
# เส้นทางที่ทำมาสามารถใช้ได้หมด จะไปตรงไหนก็ได้ … ทำระบบคำนวณเองคิดว่าทางไหนดีสุด ») : plus de trajet refait tel quel depuis la
# même base (les trajets du 29/10 13:02 font des boucles de 115-196 m pour 44-59 m à vol d'oiseau). TOUS les trajets
# relevés, toutes villes et bases confondues, sont des passages sans obstacle : leurs cases (CS_GROUND_CELL_M, points
# reliés tous les 0,5 m s'ils sont à moins de CS_SAFE_GAP_M) coûtent CS_SAFE_COST dans l'A* (_toward) au lieu de 1 —
# le bot calcule lui-même le meilleur chemin, par ces passages s'ils ne rallongent pas trop, sans leurs détours. Avec
# eux, au cercle rouge (pas d'adversaire en vue, voir CS_NET_CHASE) : course vers le centre de la zone (la case sûre la plus
# proche, à CS_PATROL_CENTER_M près) ; puis, personne en vue (au lieu de la marche au hasard) : patrouille de case sûre
# en case sûre dans la zone, chaque but à au moins CS_PATROL_MIN_M du bot et le plus loin des buts déjà visités (parmi
# CS_PATROL_PICK tirées), laissé atteint à CS_PATROL_REACH_M, sans progrès depuis CS_PATROL_STALL_S, après
# CS_PATROL_GOAL_S ou CS_ROUTE_SNAPS corrections. La
# zone, la poursuite et la recherche du dernier adversaire vu passent avant. Zone sans case sûre : comme avant.
# Essai du 29/10 13:27 (« บอทมันเดินออกวงครับ มันไม่ได้ตามแคปเจอร์จริง ที่วางไว้ ») : la préférence de l'A* ne suffisait pas,
# le bot coupait hors des trajets. Course d'ouverture et patrouille marchent donc SUR le réseau des trajets : leurs points
# (CS_NET), reliés à leurs voisins du même trajet (à moins de CS_SAFE_GAP_M) et, aux croisements, aux points d'autres
# trajets (ou du même, boucles) à moins de CS_NET_LINK_M au même niveau (CS_NET_LINK_DY_M) ; chemin le plus court
# (A* sur ce graphe) du bot au point visé, entrée par un point à moins de CS_NET_ENTRY_M (distance à vol d'oiseau comptée
# CS_NET_OFF_COST fois, rejointe par l'A* des cases), jamais par un point hors de la zone sûre (+ CS_NET_ZONE_M) ; buts =
# points du réseau dans la zone, joignables. Passage où le serveur a corrigé le bot : retiré du réseau pour la partie.
CS_NET_LINK_M = 2.0
CS_NET_LINK_DY_M = 1.0
CS_NET_GRID_M = 4.0            # recherche des voisins / entrées : cases de 4 m
CS_NET_ENTRY_M = 25.0
CS_NET_OFF_COST = 2.0
CS_NET_ON_M = 3.0              # à moins de 3 m du point suivant du chemin : sur le réseau (sinon : on le rejoint)
CS_NET_REACH_M = 2.0           # point du chemin atteint (1 m : passé à 1,5 m d'un point d'un chemin tendu, le bot y
#                                revenait sans fin)…
CS_NET_AHEAD_M = 2.0           # … point visé : le premier à plus de 2 m devant
CS_NET_REPLAN_S = 2.0
CS_NET_ZONE_M = 3.0
CS_NET_MAX_POPS = 20000
# Raccourcis (« ไม่ต้องอ้อม ») : un trajet relevé peut faire une boucle (13:02 : 115-196 m pour 44-59 m), et le chemin
# le plus court du réseau la suivre faute de croisement. Le chemin calculé est donc tendu : d'un point, saut direct au
# point le plus loin du chemin (à CS_NET_CUT_M au plus) dont la ligne droite ne passe que sur des cases de 1 m où des
# joueurs ont marché (carte des passages, trajets), loin des obstacles de la carte du jeu (CS_OBSTACLES_FILE, case et
# ses 4 voisines), hors des cases bloquées, sans marche de plus de CS_NET_CUT_DY_M d'une case à la suivante.
CS_NET_CUT_M = 15.0
CS_NET_CUT_DY_M = 0.8
# Poursuite (CS_NET_CHASE, essai du 29/10 13:40 : « บอทมันยังไม่เข้าไปใกล้กับสัตรูเลย … มีบอทเดินตกน้ำ เพราะมันไม่ไปตาม
# เส้นทางที่กำหนด และไม่ไปหาสัตรู » — poursuite hors réseau : 25-34 « longe un obstacle » et 34-45 corrections par bot et
# par partie, deux bots tombés dans l'eau du barrage) : adversaire vu (ou dernier vu) à plus de CS_NET_DIRECT_M, le bot
# va par le réseau jusqu'à son point le plus proche de l'adversaire (à CS_NET_GOAL_M près, dans la zone), puis droit
# dessus. Plus de course d'ouverture vers le centre quand un adversaire est en vue : on va vers lui. Adversaire à plus
# de CS_DROP_M sous le bot : pas suivi ; et l'A* des cases ne descend plus de plus de CS_DROP_M d'une case à la suivante.
CS_NET_GOAL_M = 25.0
CS_NET_DIRECT_M = 10.0
CS_NET_GOAL_EVERY_S = 0.5
CS_DROP_M = 3.0
CS_OBSTACLES_FILE = os.path.join(_ROOT_DIR, "data", "cs_obstacles.json")
_cs_obst: Set[Tuple[int, int]] = set()          # cases de 1 m d'obstacle de la carte (extraites du jeu, voir ci-dessus)
CS_ROUTE = os.environ.get("CS_ROUTE", "1").strip().lower() in ("1", "true", "yes", "on")
CS_ROUTES_FILE = os.path.join(_ROOT_DIR, "data", "cs_routes.json")
CS_ROUTE_SNAPS = 3             # corrections du serveur vers le même but : but suivant
CS_SAFE_COST = 0.8             # case d'un trajet relevé : préférée tant que le chemin n'est pas 1,25 fois plus long
CS_SAFE_GAP_M = 3.0
CS_PATROL_CENTER_M = 10.0
CS_PATROL_REACH_M = 6.0
CS_PATROL_MIN_M = 20.0
CS_PATROL_IN = 0.75            # buts de patrouille à 75 % du rayon sûr au plus
CS_PATROL_PICK = 40
CS_PATROL_GOAL_S = 30.0
CS_PATROL_STALL_S = 5.0        # pas 1 m plus près du but depuis 5 s (rebord, chemin qui hésite) : but suivant
_cs_routes: List[Dict[str, Any]] = []
_cs_routes_state = {"loaded": False}
_cs_safe1: Set[Tuple[int, int]] = set()          # cases de 1 m des trajets relevés (point visé, voir _waypoint)
_cs_safe2: Dict[Tuple[int, int], float] = {}     # cases de 2 m (celles de l'A*) -> hauteur du sol
_cs_net_pts: List[Tuple[float, float, float]] = []      # réseau des trajets (CS_NET) : points (x, y, z)…
_cs_net_adj: List[List[Tuple[int, float]]] = []         # … voisins (point, longueur)…
_cs_net_grid: Dict[Tuple[int, int], List[int]] = {}     # … par case de CS_NET_GRID_M…
_cs_net_comp: List[int] = []                            # … et morceau du réseau (points reliés entre eux)


def _cs_net_near(x: float, z: float, r: float) -> List[int]:
    """Points du réseau (CS_NET) à moins de `r` m de (x, z)."""
    g, n = CS_NET_GRID_M, int(r // CS_NET_GRID_M) + 1
    cx, cz = int(x // g), int(z // g)
    return [i for gx in range(cx - n, cx + n + 1) for gz in range(cz - n, cz + n + 1)
            for i in _cs_net_grid.get((gx, gz), ())
            if math.hypot(_cs_net_pts[i][0] - x, _cs_net_pts[i][2] - z) <= r]


def _cs_net_build() -> None:
    """Réseau des trajets relevés (voir CS_NET) : points, liens du même trajet et des croisements, morceaux."""
    pts, adj = _cs_net_pts, _cs_net_adj
    for r in _cs_routes:
        first = len(pts)
        for k, p in enumerate(r["pts"]):
            pts.append((p[0], p[1], p[2]))
            adj.append([])
            if k:
                a, b = first + k - 1, first + k
                d = math.hypot(pts[b][0] - pts[a][0], pts[b][2] - pts[a][2])
                if d <= CS_SAFE_GAP_M:
                    adj[a].append((b, d))
                    adj[b].append((a, d))
    for i, p in enumerate(pts):
        _cs_net_grid.setdefault((int(p[0] // CS_NET_GRID_M), int(p[2] // CS_NET_GRID_M)), []).append(i)
    for i, p in enumerate(pts):
        for j in _cs_net_near(p[0], p[2], CS_NET_LINK_M):
            if j > i and abs(pts[j][1] - p[1]) <= CS_NET_LINK_DY_M and all(n != j for n, _ in adj[i]):
                d = math.hypot(pts[j][0] - p[0], pts[j][2] - p[2])
                adj[i].append((j, d))
                adj[j].append((i, d))
    _cs_net_comp[:] = [-1] * len(pts)
    for s in range(len(pts)):
        if _cs_net_comp[s] < 0:
            _cs_net_comp[s], todo = s, [s]
            while todo:
                for j, _ in adj[todo.pop()]:
                    if _cs_net_comp[j] < 0:
                        _cs_net_comp[j] = s
                        todo.append(j)


# Voies (CS_LANE, data/cs_lanes.json — méthode du projet 36-ffmodz, reprise le 08/11 : « couloirs séparés, puis course sur
# l'ennemi ») : trajets de joueurs réels rangés par ville et par côté (d'après le 117 de leur manche) et regroupés en voies
# (axe central, flancs). Au cercle rouge, le bot reconnaît sa ville et son côté à sa base (à CS_LANE_BASE_M près ; sinon pas
# de voie) et choisit : coût = longueur + sauts (CS_LANE_JUMP_COST) + échecs dans ce processus (CS_LANE_FAIL_COST) - confiance
# (CS_LANE_N_COST) + tirage commun à l'équipe (CS_LANE_JITTER_M, même graine : code du match, ville, côté, manche). D'abord les
# trajets du vrai client (own), puis les autres voies à moins de CS_LANE_SPREAD_M de la meilleure ; chacun prend celle de son
# rang dans l'équipe (n° triés des coéquipiers, décalés d'un cran à chaque manche) : équipe répartie sans se parler. Le bot y
# court jusqu'au bout, sauf adversaire à moins de CS_LANE_FOE_M (poursuite) ; la zone passe avant. Pas d'avancée depuis
# CS_LANE_STALL_S : voie retirée pour la manche, autre voie du même côté à moins de CS_LANE_REJOIN_M (au plus CS_LANE_TRIES).
CS_LANE = os.environ.get("CS_LANE", "1").strip().lower() in ("1", "true", "yes", "on")
CS_LANES_FILE = os.path.join(_ROOT_DIR, "data", "cs_lanes.json")
CS_LANE_BASE_M = 20.0
CS_LANE_JUMP_COST = 8.0        # (m) par saut, comptés jusqu'à…
CS_LANE_JUMP_MAX = 4           # … 4
CS_LANE_N_COST = 6.0           # (m) par doublement du nombre de joueurs passés
CS_LANE_FAIL_COST = 25.0
CS_LANE_JITTER_M = 20.0
CS_LANE_SPREAD_M = 50.0
CS_LANE_FOE_M = 30.0
CS_LANE_STALL_S = 6.0
CS_LANE_REJOIN_M = 15.0
CS_LANE_TRIES = 3
CS_LANE_REACH_M = 1.5          # point visé : le premier à plus de 1,5 m devant (points tous les ~1 m)
CS_LANE_AROUND_M = 8.0         # case bloquée devant : chemin A* vers le point de la voie à 8 m (contournement)
_cs_lanes: List[Dict[str, Any]] = []             # villes -> côtés -> voies (CS_LANES_FILE)
_cs_lanes_state = {"loaded": False}
_cs_lane_fails: Dict[str, int] = {}              # voie -> échecs dans ce processus (CS_LANE_FAIL_COST)


def _cs_lanes_load() -> None:
    """Voies de chaque ville (CS_LANES_FILE), une fois par processus ; chacune reçoit un nom et ses longueurs cumulées."""
    if _cs_lanes_state["loaded"]:
        return
    _cs_lanes_state["loaded"] = True
    try:
        with open(CS_LANES_FILE, encoding="utf-8") as f:
            _cs_lanes[:] = json.load(f).get("towns", [])
    except FileNotFoundError:
        return
    except Exception as e:
        diag.event("MATCH", "cs_lanes_load_failed", level="warning", exc=e)
        return
    for t in _cs_lanes:
        for k, sd in enumerate(t["sides"]):
            for n, l in enumerate(sd["lanes"]):
                l["id"] = f"{t['map']}.{t['area']}.{k}.{n}"
                cum = [0.0]
                for a, b in zip(l["pts"], l["pts"][1:]):
                    cum.append(cum[-1] + math.hypot(b[0] - a[0], b[2] - a[2]))
                l["cum"] = cum
    diag.event("MATCH", "cs_lanes_loaded", level="info", towns=len(_cs_lanes),
               lanes=sum(len(sd["lanes"]) for t in _cs_lanes for sd in t["sides"]))


def _cs_lane_side(x: float, z: float) -> Optional[Tuple[Dict[str, Any], int]]:
    """(ville, n° du côté) de la base relevée la plus proche de (x, z), à CS_LANE_BASE_M au plus ; None sinon (CS_LANE)."""
    best = None
    for t in _cs_lanes:
        for k, sd in enumerate(t["sides"]):
            d = math.hypot(x - sd["base"][0], z - sd["base"][1])
            if d <= CS_LANE_BASE_M and (best is None or d < best[0]):
                best = (d, t, k)
    return best[1:] if best else None


def _cs_routes_load() -> None:
    """Trajets relevés (CS_ROUTES_FILE) et leurs cases sûres, une fois par processus."""
    if _cs_routes_state["loaded"] or not CS_ROUTE:
        return
    _cs_routes_state["loaded"] = True
    try:
        with open(CS_ROUTES_FILE, encoding="utf-8") as f:
            _cs_routes[:] = [r for r in json.load(f) if len(r.get("pts") or ()) >= 5]
    except FileNotFoundError:
        pass
    except Exception as e:
        diag.event("MATCH", "cs_routes_load_failed", level="warning", exc=e)
    _cs_lanes_load()
    _cs_routes.extend(l for t in _cs_lanes for sd in t["sides"] for l in sd["lanes"])   # les voies aussi (CS_LANE)
    for r in _cs_routes:
        pts = r["pts"]
        for a, b in zip(pts, pts[1:] + pts[-1:]):
            gap = math.hypot(b[0] - a[0], b[2] - a[2])
            n = int(gap / 0.5) + 1 if gap <= CS_SAFE_GAP_M else 1
            for k in range(n):
                x, z = a[0] + (b[0] - a[0]) * k / n, a[2] + (b[2] - a[2]) * k / n
                _cs_safe1.add((int(x // 1.0), int(z // 1.0)))
                _cs_safe2.setdefault((int(x // CS_GROUND_CELL_M), int(z // CS_GROUND_CELL_M)), a[1])
    _cs_net_build()
    try:
        with open(CS_OBSTACLES_FILE, encoding="utf-8") as f:
            _cs_obst.update(tuple(int(v) for v in c.split(",")) for c in json.load(f).get("obstacles", ()))
    except FileNotFoundError:
        pass
    except Exception as e:
        diag.event("MATCH", "cs_obstacles_load_failed", level="warning", exc=e)


def _cs_walk_load() -> None:
    """Carte des passages des parties précédentes (CS_WALK_FILE), une fois par processus."""
    if _cs_walk_state["loaded"] or not CS_WALKMAP:
        return
    _cs_walk_state["loaded"] = True
    try:
        with open(CS_WALK_FILE, encoding="utf-8") as f:
            cells = json.load(f).get("cells", {})
        for k, y in cells.items():
            ix, iz = k.split(",")
            c = (int(ix), int(iz))
            _cs_walk1[c] = y / 100
            _cs_walk2.setdefault((c[0] // 2, c[1] // 2), y / 100)
        diag.event("MATCH", "cs_walkmap_loaded", level="info", cells=len(_cs_walk1))
    except FileNotFoundError:
        pass
    except Exception as e:
        diag.event("MATCH", "cs_walkmap_load_failed", level="warning", exc=e)


def _cs_walk_write(cells: Dict[str, int]) -> int:
    """(thread) Fusion avec le fichier (autres processus) puis écriture atomique ; nombre de cases écrites."""
    try:
        with open(CS_WALK_FILE, encoding="utf-8") as f:
            old = json.load(f).get("cells", {})
    except (FileNotFoundError, ValueError):
        old = {}
    for k, y in cells.items():
        old.setdefault(k, y)
    os.makedirs(os.path.dirname(CS_WALK_FILE), exist_ok=True)
    tmp = CS_WALK_FILE + f".{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"cell_m": CS_WALK_CELL_M, "cells": old}, f, separators=(",", ":"))
    os.replace(tmp, CS_WALK_FILE)
    return len(old)


async def cs_walk_save() -> None:
    """Fin de partie : cases nouvelles de la carte des passages écrites dans CS_WALK_FILE (thread)."""
    if not CS_WALKMAP or not _cs_walk_state["new"]:
        return
    new, _cs_walk_state["new"] = _cs_walk_state["new"], 0
    cells = {f"{x},{z}": round(y * 100) for (x, z), y in _cs_walk1.items()}
    try:
        total = await asyncio.to_thread(_cs_walk_write, cells)
        diag.event("MATCH", "cs_walkmap_saved", level="info", new=new, cells=total)
    except Exception as e:
        _cs_walk_state["new"] += new
        diag.event("MATCH", "cs_walkmap_save_failed", level="warning", exc=e)


# Compétence active (essai, CS_SKILL_TEST) : RUDP_USE_ACTIVE_SKILL (248) du client officiel, capture du 25/10 20:31
# (CS 4vs4, clé de session lue) : fiable (sendOption 2), clé de message 0x5a à 0x63, contenu
# [joueur][compétence][x][y][z][vx][vy][vz][0] (varints ; position en mm et vitesse en cm/s en zigzag), ex. joueur
# 0x1000004, compétence 5506, (438.06, 15.70, -246.00), vitesse (-476, 0, -87). Le serveur répond par
# RUDP_SYNC_ACTIVE_SKILL_STATE (250) à tous dans les 10 ms (état 1 = active, 2 = rechargement). Chez le client
# officiel le 248 est chiffré avec la clé de session ; le bot n'en a pas et l'envoie avec la clé du match. L'essai dit
# si le serveur l'accepte : accusé (ack_next au-delà de son n° d'ordre) et 250 reçu dans la seconde (journal
# MATCH skill_result, bilan de partie « skill »). Une compétence équipée du personnage du guide (5506, emplacement 1).
# Essai du 25/10 20:57 (CS 4vs4, 3 bots, 6 envois) : ni accusé ni 250 ; le serveur l'ignore. Capture 20:37 (clé de
# session lue, 100 % du trafic lisible) : le 248 est le seul message du client à chaque pression, et tous ses messages
# fiables après 448 (tir, recharge, objets, compétence…) sont chiffrés avec la clé de session.
#
# 5506 = โดรน. ลำดับของ client จริง (ffcap_20261026_085812 / 162321) :
#   248 → 250 + 538 [n° โดรน, เจ้าของ, …] (n° นับต่อแมตช์ เริ่ม 3, 538 ส่งถึงทุกคน) → ~2.97 วิ 542 [n°, 02, จุดเกิด]
#   (พร้อมรับเป้า) → client ส่ง 543 [n°, ident ศัตรู, x, y, z] (mm zigzag) ภายใน 31 ms → 542 [n°, 06, เป้า] ล็อกแล้ว
#   → 541 ตำแหน่งโดรน (match key) → 542 [n°, 08] ชน → 2010 weapon 61 ดาเมจ 25.
# บอทเดิมไม่ส่ง 543 : โดรนไม่มีเป้า ไม่มี 541 ไม่มีดาเมจ (แมตช์ 27/10 19:46). บอทอ่านเนื้อ 538 ไม่ได้ (session key)
# แต่ header อ่านได้ด้วย match key : นับ 538 (ไม่นับซ้ำตาม n° ลำดับ) = n° โดรน ; ของเราคือ 538 ตัวเดียวที่มาหลัง 248
# ภายใน CS_DRONE_PICK_S (กดพร้อมกันหลายตัว = ไม่รู้ว่าตัวไหน → ข้าม, CS_SKILL_SLOT_S กันไว้ ; แมตช์ 27/10 บอท 3 ตัว
# กดพร้อมกัน : 538 [4, 5, 6] ในช่วงเดียวกัน).
# คูลดาวน์ของเซิร์ฟ 60 วิ ไม่รีเซ็ตตามรอบ (float 60.0 ใน 250 ; แมตช์ 27/10 : กดทุก 20 วิ ได้ 250 แค่ 1 ใน 3).
CS_SKILL_TEST = os.environ.get("CS_SKILL_TEST", "1").strip().lower() in ("1", "true", "yes", "on")
CS_SKILL_ID = 5506
CS_SKILL_FIRST_S = 0.0        # วงแดงเปิด (เริ่มสู้) : กดทันทีถ้าศัตรูอยู่ในระยะ (CS_DRONE_RANGE_M)
CS_DRONE_RANGE_M = 100.0      # ระยะถึงศัตรูใกล้สุดตอนกด (ชนจริงถึง 108 ม. : 27/10 20:08 รอบ 4)
CS_SKILL_EVERY_S = 61.0       # หลังกดติด (คูลดาวน์ 60 วิ)
CS_SKILL_RETRY_S = 10.0       # หลังกดไม่ติด (ไม่มี 250)
CS_SKILL_SLOT_S = 0.4         # กดได้เฉพาะช่องของตัวเอง : วงแดงเปิด + (n° - 1) × 0.4 วิ + k × รอบช่อง (538 มาหลัง
#                               248 ภายใน 6–105 ms, หน้าต่าง CS_DRONE_PICK_S 0.3 วิ) — ไม่เลื่อน = 538 มาพร้อมกัน แยกไม่ออก
CS_SKILL_SLOTS = 10           # ช่องต่อรอบ (n° ในแมตช์ CS ไปถึง 9 : 0x1000009 วันที่ 28/10) → รอบช่อง 4 วิ.
# นับจากวงแดงเปิด (ทุกตัวในแมตช์เห็น 117 ในมิลลิวินาทีเดียวกัน) ไม่ใช่จากตอนที่ตัวเองพร้อม : 28/10 00:15:38 บอท n° 8
# พร้อมก่อน n° 5 ราว 1.2 วิ เท่ากับส่วนต่างของการเลื่อนพอดี → กดห่างกัน 15 ms, 538 สองตัวในหน้าต่างเดียว ไม่มีใครล็อก
CS_DRONE_FIRST_ID = 3
CS_DRONE_PICK_S = 0.3         # 538 ของเรามาหลัง 248 ภายใน… (จริง 40–100 ms)
CS_DRONE_LOCK_S = 3.0         # ส่ง 543 หลัง 538 ของเรา (จริง : 542 พร้อมรับเป้าที่ +2.97 วิ, 543 ที่ +3.0)
CS_DRONE_WAIT_S = 8.0         # 28/10 : รอ 541 (match key) ของโดรนเราโผล่ สูงสุดเท่านี้หลังกด (จริงมาที่ ~3.0–3.4 วิ) แล้วค่อยยอมแพ้
CS_DRONE_PRECAST_S = 4.0      # เปิดรอบ 4 คนกดโดรนพร้อมกันใน ~3 วิ → 541 โดรนเราอาจโผล่ "ก่อน" เวลา cast ของเราเล็กน้อย : รับย้อนหลังได้
CS_DRONE_SELF_M = 80.0        # โดรนเราออกจากตัวเรา (จริง ≤~40 ม. หลังบิน 3 วิ) ; เกินนี้ = โดรนคนอื่น/ไกล → ไม่ล็อก (กันยิงมั่ว 442–959 ม. ที่เจอ 28/10 22:48)
# รอบ 1 นับ 538 ได้เลขตรง (ทีมเรากดก่อน ได้เลขต่ำ 3,4,5 → ยิงโดน 100%) ; รอบ 2+ นับขาด (ไม่ได้รับ 538 ของโดรนศัตรู)
# เลขจริงกระโดด (เห็น 18 ตอนนับได้ 9). เลขจริง ≥ เลขที่นับเสมอ และ 541 ของโดรนเราไม่เคยมา → เดาเป๊ะไม่ได้.
# วิธี : ยิง 543 ครอบช่วง [นับ .. นับ+SPAN] เป้าเดียวกัน. ปลอดภัย: เซิร์ฟบังคับเฉพาะโดรนที่เราเป็นเจ้าของ (28/10 23:41:
# 543 เลขผิดรอบ 2 ไม่ทำอะไรเลย = ไม่ให้แย่งโดรนคนอื่น) ; เลขที่ไม่ใช่ของเราถูกเมิน.
CS_DRONE_ID_SPAN = 60         # ช่วงเลขโดรนที่กวาดยิง 543 เหนือเลขที่นับได้ (ครอบส่วนต่างที่นับขาดสะสมหลายรอบ)
CS_DRONE_WEAPON = 61
CS_DRONE_FOREIGN_S = 0.1      # dégâts de drone d'un autre si tôt après notre 543 : c'est notre 543 qui l'a lancé
# กดโดรนครั้งเดียวต่อแมตช์ ในรอบแรก (CS_DRONE_ROUNDS). เลขโดรนนับจาก 538 ถูกเฉพาะรอบแรก : ผู้เล่นที่อยู่
# ไกลกดโดรนแล้วเซิร์ฟไม่ส่งอะไรมาให้บอทเลย (ไม่มี 538 / 250 / 541) แต่เลขถูกใช้ไป — 27/10 20:41 และ 20:49 : ระหว่างจบ
# รอบ 1 ถึงบอทกดรอบ 2 ไม่มีแพ็กเก็ตโดรนสักตัว เลขกระโดด +2 ; 20:19 : +1, +4, +14. รอบแรกล็อกถูกทุกแมตช์ (4/4) ; รอบหลัง
# ถูกแค่ 1 ใน 5. เดาผิด = โดรนเราลอยเฉย ๆ ("ปล่อยแต่ไม่ไป") หรือไปสั่งโดรนคนอื่น (เซิร์ฟไม่เช็คเจ้าของ). เลขจริงอยู่ในเนื้อ
# 538 (clé de session).
CS_DRONE_ROUNDS = 99         # กดได้ทุกรอบ ; รอบ 2+ กดเฉพาะตอนมี 541 สด (รู้เลขจริงปัจจุบัน) ไม่งั้นรอ
# Plusieurs drones par manche (demande du 08/11 : « compétence rechargée, ennemi tout près, il ne l'utilise pas ») : avant,
# un seul 248 par manche (round_fired) — rechargé au milieu d'une manche, ou lancement refusé par le serveur (pas de 250),
# le bot attendait la manche suivante. CS_SKILL_PER_ROUND = 0 : relancé dès que la recharge (CS_SKILL_EVERY_S, ou
# CS_SKILL_RETRY_S après un refus) est passée, ennemi à portée ; 1 : ancien comportement.
CS_SKILL_PER_ROUND = int(os.environ.get("CS_SKILL_PER_ROUND", "0") or 0)
CS_DRONE_FRESH_S = 3.0       # รอบ 2+ : 541 ล่าสุดต้องไม่เก่ากว่านี้ = มีโดรนบินอยู่ = shift ปัจจุบันเชื่อถือได้
# TEST: ส่ง 248 แบบ unreliable + match key (เหมือน 2001) แทน reliable + session key
# (real client ส่ง reliable+session; อันนี้ลองว่า server รับ match key แบบ unreliable ไหม)
# 27/10 19:46 : รับ (250 กลับใน 2–5 ms) ; 543 ใช้ทางเดียวกัน
CS_SKILL_UNRELIABLE = os.environ.get("CS_SKILL_UNRELIABLE", "0").strip().lower() in ("1", "true", "yes", "on")
# TEST 28/10 : ส่ง 248/543 แบบ reliable + match key (เหมือน Thunder/Sharma 447/448 ที่เวิร์ค) แทน unreliable —
# เผื่อการสร้างตัวโดรนต้องใช้ช่อง reliable (unreliable เซิร์ฟตอบ 250 แต่ไม่สร้างโดรน : เทสต์ 22:48/23:04/23:18)
CS_SKILL_RELMATCH = os.environ.get("CS_SKILL_RELMATCH", "0").strip().lower() in ("1", "true", "yes", "on")
RUDP_USE_ACTIVE_SKILL = 248
RUDP_SYNC_ACTIVE_SKILL_STATE = 250
RUDP_SKILL_OBJECT_SPAWN = 538
RUDP_DRONE_POS = 541          # [n° drone, x, y, z, horloge] non chiffré : seul n° réel lisible
RUDP_DRONE_TARGET = 543


def cs_skill_content(ident: int, skill: int, pos, vel) -> bytes:
    """Contenu d'un RUDP_USE_ACTIVE_SKILL (voir CS_SKILL_TEST) : position en m, vitesse en cm/s.
    (client จริงใส่จุดเล็ง ~80 ม. ใกล้ศัตรู ; บอทใส่ตำแหน่งตัวเอง เซิร์ฟก็รับ)"""
    return (_varint(ident) + _varint(skill) + b"".join(_svarint(round(v * 1000)) for v in pos)
            + b"".join(_svarint(round(v)) for v in vel) + b"\x00")


def cs_drone_target_content(drone: int, target: int, pos) -> bytes:
    """Contenu d'un 543 (ล็อกเป้าโดรน) : n° โดรน, ident ศัตรู, ตำแหน่งศัตรู (m), เช่น 03 84808008 9aa040 fede01 8aea3b."""
    return _varint(drone) + _varint(target) + b"".join(_svarint(round(v * 1000)) for v in pos)


def _dist2(a, b) -> float:
    """Distance au carré entre deux positions 3D (m) — pour apparier notre drone à notre propre position."""
    return sum((x - y) ** 2 for x, y in zip(a, b))


def _svarint(n: int) -> bytes:
    """Entier signé en zigzag varint."""
    return _varint(n << 1 if n >= 0 else (-n << 1) - 1)


def _f32varint(f: float) -> bytes:
    """Float 32 bits écrit comme un varint de ses 4 octets (regard des 2001)."""
    return _varint(struct.unpack("<I", struct.pack("<f", f))[0])


def _svarints(data: bytes, i: int, count: int) -> Tuple[List[int], int]:
    """`count` entiers signés (zigzag varint) lus dans `data` à partir de `i` ; IndexError si trop court."""
    out = []
    for _ in range(count):
        v = s = 0
        while True:
            b = data[i]
            i += 1
            v |= (b & 0x7F) << s
            s += 7
            if b < 0x80:
                break
        out.append((v >> 1) ^ -(v & 1))
    return out, i


def cs_state_content(ident: int, pos: Tuple[float, float, float], aim: Tuple[float, float, float],
                     vel: Tuple[float, float, float], ms: int, running: bool, frame_ms: int = 16) -> bytes:
    """Contenu d'un 2001 du client (disposition relevée le 25/10, voir CS_CHASE) : position en m, regard unitaire,
    vitesse en cm/s ; joystick dans le sens de la vitesse, à fond en course (`running`, allure 1), à proportion de la
    vitesse en marche (allure 0)."""
    speed = math.hypot(vel[0], vel[2])
    push = 100 if running else min(100.0, speed * 100 / CS_RUN_CM_S)
    joy = (round(vel[0] / speed * push), round(vel[2] / speed * push)) if speed else (0, 0)
    fields = (round(pos[0] * 1000), round(pos[1] * 1000), round(pos[2] * 1000),
              round(aim[0] * 100), round(aim[1] * 100), round(aim[2] * 100), joy[0], joy[1],
              round(vel[0]), round(vel[1]), round(vel[2]), 0, 1 if running else 0)
    return (_varint(ident) + b"".join(_svarint(v) for v in fields) + b"".join(_f32varint(a) for a in aim)
            + b"\x00\x00" + _varint(frame_ms) + b"\x00\x00\x00" + _varint(ms))


class _CsChase:
    """Joueur local d'une partie Clash Squad (voir CS_CHASE) : son n° et sa position d'après les 2001 du serveur,
    les autres joueurs d'après les 2012, les manches d'après les 145 / 117 ; step() donne le prochain 2001."""

    def __init__(self, now: float):
        self.idx: Optional[int] = None       # n° du joueur local (appris des premiers 2001 du serveur)
        self.votes: Dict[int, int] = {}
        self.alive = False                   # le serveur envoie l'état du joueur local (sinon il en suit un autre)
        self.server: Optional[Tuple[float, float, float]] = None   # sa position d'après le serveur (m)
        self.server_moved = (None, 0.0)      # (position, heure) du dernier déplacement de la position du serveur
        self.moving_since = 0.0              # en marche depuis… (préparation : à l'arrêt)
        self.server_new = False
        self.pos: Optional[List[float]] = None   # position envoyée (m)
        self.aim = (0.0, 0.0, 1.0)
        self.players: Dict[int, Tuple[float, float, float, float]] = {}   # n° -> (vu à, x, y, z)
        self.round_at = now                  # début de la manche en cours (1er 145 d'une rafale)
        self.last_tp = 0.0                   # dernier 145 reçu
        self.fight = False                   # préparation finie : on bouge
        self.snaps = 0                       # corrections du serveur en marche dans cette manche
        self.running = False                 # course (allure 1) vers la cible
        self.moving = False                  # en mouvement (course ou marche)
        self.doing = "wait"                  # prep | chase | orbit | search | wander | detour (affichage)
        self.near = False                    # arrivé au contact (course reprise au-delà de CS_RESUME_M)
        self.heading = (0.0, 0.0, 1.0)       # direction de marche en cours
        self.detour_until = 0.0
        self.turn_at = 0.0                   # prochain changement de sens (autour de la cible / au hasard)
        self.orbit_sign = 1
        self.last_enemy: Optional[Tuple[float, float, float]] = None   # dernier adversaire vu (recherche)
        self.last_step = 0.0
        self.trail: deque = deque(maxlen=int(CS_LAG_S / STATE_SYNC_EVERY_S) + 5)   # (t, x, y, z) envoyés
        self.team_of: Dict[int, int] = {}          # n° -> équipe, d'après les dégâts (exact)
        self.mates: Set[int] = set()               # coéquipiers / adversaires relevés en préparation (toute la partie)
        self.foes: Set[int] = set()
        self.ground: Dict[Tuple[int, int], float] = {}   # case (x, z) -> hauteur du sol (m)
        self.blocked: Dict[Tuple[int, int], float] = {}  # case -> évitée jusqu'à (serveur nous y a arrêtés)
        self.path: List[Tuple[int, int]] = []             # chemin en cours (cases), vers path_goal
        self.path_goal: Optional[Tuple[int, int]] = None
        self.path_at = 0.0
        self.plans = 0
        self.slide_until = 0.0               # longe un obstacle jusqu'à… (direction slide_dir)
        self.slide_dir = (0.0, 0.0, 1.0)
        self.slide_len = CS_SLIDE_S
        self.slide_side = 1
        self.stuck_at = 0.0
        self.slides = 0
        self.fight_seen_at = 0.0             # combat vu pour la 1re fois dans cette manche (step)
        self.step_last = None                # dernier résultat de step()
        self.frozen_since = 0.0              # immobilisé depuis… (0 : non)
        self.frozen_count = 0
        self.server_vel = (0.0, 0.0)         # vitesse (cm/s, x z) dans le dernier 2001 du serveur pour nous
        self.server_joy = (0, 0)             # joystick qu'il a retenu de nos 2001 (0 : il ne les prend plus)
        self.tp_pending: Optional[Tuple[float, int]] = None   # 144 / 145 reçu (heure, type 1 / 2), à qui ? (CS_TP_ACK)
        self.tp_ack_due = 0                  # 146 à envoyer (type), par cs_state_loop
        self.tp_acks = 0
        self.slide_route = (0.0, 0.0, 1.0)   # route suivie quand l'obstacle a été rencontré
        self.hp_lost = 0                     # dégâts reçus dans la manche (2010 dont le bot est la victime)
        self.hp_hits = 0                     # … dont ceux des autres joueurs (sans la zone) : « à terre » (CS_KNOCK_HP)
        self.zone_hurt: Dict[int, float] = {}    # n° -> dernier dégât de zone (voir CS_ZONE_HURT_S)
        self.zone_hurt_since = 0.0           # dégâts de zone du bot sans interruption depuis…
        self.zone_cap: Optional[float] = None    # rayon estimé plafonné après des dégâts de zone (manche)
        self.traces: Dict[int, List[Tuple[float, float]]] = {}   # n° -> points (x, z) de la manche (CS_TRACE_STEP_M)
        self.escape: Optional[Dict[str, Any]] = None   # coincé : trace suivie (voir _escaping)
        self.escape_bad: Set[int] = set()    # traces abandonnées dans la manche
        self.lead: Optional[Dict[str, Any]] = None   # trace suivie d'emblée vers le but (voir _leading)
        self.lead_next = 0.0
        self.leads = 0
        self.patrol: Optional[Dict[str, Any]] = None   # but en cours par les cases sûres (voir CS_ROUTE)
        self.patrol_seen: List[Tuple[float, float]] = []   # base et buts de la manche (patrouille : le plus loin)
        self.patrol_centered = False         # centre de la zone atteint (ou laissé) dans la manche
        self.net_goal: Optional[Tuple[Optional[int], float, float, float]] = None   # (point, x, z, heure) : CS_NET_CHASE
        self.patrol_bad: Set[int] = set()    # buts injoignables par le réseau dans la manche
        self.net: Optional[Dict[str, Any]] = None   # chemin en cours sur le réseau des trajets (CS_NET)
        self.net_bad: Set[Tuple[int, int]] = set()  # passages du réseau où le serveur a corrigé le bot (partie)
        self.net_cuts = 0
        self.routes = self.routes_done = 0   # buts pris / atteints
        self.escape_next = 0.0
        self.escapes = 0
        self.server_at = 0.0                 # dernier 2001 du serveur avec notre position
        self.curve = 0.0                     # marche au hasard : vitesse angulaire (°/s, CS_CURVE_DEG_S)
        self.speed_k, self.speed_at = 1.0, 0.0   # facteur de vitesse (CS_SPEED_JITTER), retiré à speed_at
        self.weave_period = random.uniform(*CS_WEAVE_PERIOD_S)
        self.forced_new = False              # 144 reçu depuis le dernier step (voir on_force)
        self.forced_at = self.hold_until = 0.0
        self.forces = self.forces_used = 0
        self.unknown_cost = CS_UNKNOWN_COST  # coût d'une case inconnue au dernier calcul de chemin (CS_WALKMAP)
        self.br_mode = False                 # BR Evolution : combat dès le départ (pas de préparation CS)
        _cs_walk_load()
        _cs_spots_load()
        _cs_routes_load()
        _cs_lanes_load()
        self.seed = ""                       # commun à l'équipe : code du match (tirage du choix de voie, CS_LANE)
        self.lane: Optional[Dict[str, Any]] = None   # voie suivie (voir CS_LANE)
        self.lane_over = False               # plus de voie dans cette manche (finie, quittée ou aucune)
        self.lane_tries = 0
        self.lane_bad: Set[str] = set()      # voies retirées pour la manche
        self.lanes = self.lanes_done = self.lanes_failed = 0   # voies prises / menées au bout / sans avancée
        self.lanes_own = 0                   # … dont des trajets appris du vrai client
        self.zone_src = {"enemies": 0, "spot": 0, "guess": 0, "true": 0}   # manches : origine du centre (_zone)
        self.zone_true: Optional[Dict[str, Any]] = None   # dernier 117 lu (voir on_zone)
        self.zone_true_n = 0                 # 117 lus dans la partie
        self.straight_done = False           # base d'en face atteinte dans la manche (voir CS_STRAIGHT)
        self.packs = 0                       # retours vers le chef du groupe (voir CS_PACK)
        self.target_idx: Optional[int] = None      # n° de l'adversaire visé (voir CS_FOE_TRACE)
        self.last_enemy_idx: Optional[int] = None  # n° de l'adversaire vu en dernier
        self.foe_routes = 0                  # poursuites sur la route de l'adversaire (voir CS_FOE_TRACE)
        self.hurt_seen: Set[Tuple[Optional[int], Optional[int]]] = set()   # 2010 reçus 2-3 fois : comptés une fois
        self.skill_urgent = False                # touché par un joueur : drone lancé immédiatement
        self.last_attacker_id: Optional[int] = None   # n° du dernier attaquant (pour le ciblage urgent)
        self.heal_left, self.heal_at, self.heal_wait = CS_HEAL_MAX, 0.0, 0.0   # trousses (voir CS_HEAL)
        self.heals = self.heals_ok = 0
        self.healing_until = 0.0             # à l'arrêt jusqu'à… (soin en cours, voir CS_HEAL_HOLD_S)
        self.zone_return = False             # rentre dans la zone jusqu'à CS_ZONE_BACK_M à l'intérieur (CS_ZONE_FIRST)
        self.zone_msgs = 0                   # 117 de la manche après le début du combat
        self.zone_moving = False             # déplacement de la zone annoncé (voir CS_ZONE_FIRST)
        self.heal_blocked = False            # soin voulu mais trop près du bord : vers le centre d'abord
        self.buy_round, self.buy_at, self.buy_open = -1, 0.0, False         # achat d'arme (voir CS_BUY)
        self.equip_due = False
        self.buys = self.buys_ok = 0
        self.item_out: List[Tuple[int, bytes]] = []    # messages à envoyer (réponses : 132…)
        self.replies_readable = True         # réponses du serveur au soin lisibles (clé de session connue)
        self.released = False                # libéré de sa base par le serveur (voir CS_RELEASE_M), à released_at
        self.released_at = 0.0
        self.pinned = False                  # 144 reçu avant d'être libéré (voir CS_PINNED_WAIT_S)
        self.probe_from: Optional[Tuple[float, float, float]] = None   # position du serveur au début de l'essai
        self.lags: deque = deque(maxlen=200)       # retards relevés du serveur sur nos positions (s)
        # zone de la manche, estimée (voir CS_CHASE) : base du bot, adversaires vus en préparation, centre, resserrement
        self.spawn: Optional[Tuple[float, float]] = None
        self.enemy_first: Dict[int, Tuple[float, float]] = {}
        self.center: Optional[Tuple[float, float]] = None
        self.zone_r0 = 0.0
        self.fight_at = 0.0
        self.shrink_at = 0.0
        # bilan de la partie (journal de fin de partie)
        self.rounds = self.runs = self.arrived = self.snaps_total = self.detours = self.zone_runs = 0
        self.lag_skips = 0                   # écarts dus au retard du serveur, pas des corrections
        self.ran_m = 0.0
        self.deaths = self.zone_deaths = 0   # manches où le bot est mort, dont dans la zone
        self.dmg_dealt = self.hits_dealt = 0  # dégâts infligés par le bot (2010 dont il est l'attaquant)
        self.dealt_seen: Set[Tuple[int, Optional[int]]] = set()
        self.died_round = -1

    @staticmethod
    def team(idx: int) -> int:
        return (idx - 1) // CS_TEAM_SIZE + 1

    def ident(self) -> Optional[int]:
        return self.ident_of(self.idx) if self.idx else None

    def ident_of(self, idx: int) -> int:
        """Identifiant (équipe << 24) | n° d'un joueur de la partie (équipe d'après le n° si inconnue, voir team_for)."""
        return (self.team_for(idx) or self.team(idx)) << 24 | idx

    def team_for(self, idx: int) -> Optional[int]:
        """Équipe d'un joueur : celle des dégâts, sinon déduite d'un coéquipier ou d'un adversaire dont l'équipe est
        connue (2 équipes : 1 et 2), sinon du n° 1, toujours dans l'équipe 1 ; None si rien de tout ça. Le n° ne la
        donne pas en CS : n° 2, 3, 4, 5 ensemble (parties du 27/10 19:35 et 20:08), 1 à 4 ensemble (19:46), 1, 2, 6, 7
        (22:00) — mais le n° 1 est dans l'équipe 1 dans les 23 parties CS capturées du 25 au 27/10 : avec les
        coéquipiers relevés dans la base (préparation), l'équipe de chacun est connue avant le 1er dégât. Avant :
        équipe de la cible du 543 devinée d'après son n° (team_guess), 0x1000003 au lieu de 0x2000003 à 22:00."""
        team = self.team_of.get(idx)
        if team is None and self.idx:
            mine = self.team_of.get(self.idx)
            if mine is None:
                mine = next((self.team_of[i] for i in self.mates if i in self.team_of), None)
            if mine is None:
                foe = next((self.team_of[i] for i in self.foes if i in self.team_of), None)
                mine = 3 - foe if foe in (1, 2) else None
            if mine is None:
                mine = 1 if self.idx == 1 or 1 in self.mates else 2 if 1 in self.foes else None
            if mine in (1, 2):
                team = mine if idx == self.idx or not self.enemy(idx) else 3 - mine
        return team

    def enemy(self, idx: int) -> bool:
        """`idx` est-il un adversaire ? Équipe des dégâts, sinon relevé de la préparation, sinon n° (voir CS_CHASE)."""
        if idx == self.idx:
            return False
        if idx in self.team_of and self.idx in self.team_of:
            return self.team_of[idx] != self.team_of[self.idx]
        if idx in self.mates:
            return False
        if idx in self.foes:
            return True
        if self.mates:
            return True              # coéquipiers connus (relevés ensemble dans la base) : tout autre est adversaire
        return self.team(idx) != self.team(self.idx)

    def on_hurt(self, c: bytes, now: Optional[float] = None) -> None:
        """UDP_PLAYER_HURT : identifiant de la victime = (équipe << 24) | n° ; dégâts du bot comptés (CS_KNOCK_HP) ;
        dégâts de zone (attaquant = victime, arme CS_ZONE_WEAPON) relevés par joueur (voir CS_ZONE_HURT_S)."""
        victim, i = _read_varint(c, 0)       # varint brut (pas zigzag), comme _hurt_info
        if victim is None:
            return
        team, idx = victim >> 24, victim & 0xFFFFFF
        if 0 < team < 64 and 0 < idx < 256:
            self.team_of[idx] = team
        attacker, i = _read_varint(c, i)
        weapon, i = _read_varint(c, i) if attacker is not None else (None, i)
        clock, _ = _read_varint(c, i) if weapon is not None else (None, i)
        now = time.time() if now is None else now
        if attacker == victim and weapon == CS_ZONE_WEAPON:
            if idx == self.idx and now - self.zone_hurt.get(idx, 0.0) > CS_ZONE_HURT_S:
                self.zone_hurt_since = now       # début d'une série de dégâts de zone
            self.zone_hurt[idx] = now
            if idx == self.idx and self.center is not None and self.pos is not None:
                d = math.hypot(self.pos[0] - self.center[0], self.pos[2] - self.center[1]) - CS_ZONE_HURT_CAP_M
                self.zone_cap = max(CS_ZONE_FINAL_M, min(self.zone_cap or d, d))
        hit = _hurt_info(c)
        if hit and self.idx is not None and idx == self.idx and (attacker, clock) not in self.hurt_seen:
            self.hurt_seen.add((attacker, clock))
            self.hp_lost += hit[1]
            if not (attacker == victim and weapon == CS_ZONE_WEAPON):
                self.hp_hits += hit[1]
                self.skill_urgent = True
                att_idx = attacker & 0xFFFFFF if attacker is not None else None
                if att_idx is not None and att_idx != self.idx:
                    self.last_attacker_id = att_idx
        if hit and self.idx is not None and attacker is not None and attacker != victim \
                and attacker & 0xFFFFFF == self.idx and (victim, clock) not in self.dealt_seen:
            # dégâts infligés par le bot (bilan de la partie, ffbot.teamlab) : le même 2010 arrive souvent 2-3 fois
            self.dealt_seen.add((victim, clock))
            self.dmg_dealt += hit[1]
            self.hits_dealt += 1

    def on_force(self, now: float) -> None:
        """RUDP_FORCE_SYNC_PLAYER_STATE (144) : position imposée par le serveur, traitée au prochain step (voir CS_CHASE)."""
        self.forces += 1
        if self.alive:
            self.tp_pending = (now, 1)           # le nôtre ? (voir CS_TP_ACK)
        if not self.released:
            self.pinned = True                   # avant d'être libéré : retenu longtemps (CS_PINNED_WAIT_S)
        if self.alive and now - self.forced_at >= CS_FORCE_EVERY_S:
            self.forced_new, self.forced_at = True, now

    def ground_y(self, x: float, z: float, near: float = CS_GROUND_NEAR_M) -> Optional[float]:
        """Hauteur du sol relevée la plus proche de (x, z) à moins de `near` m, ou None (voir CS_CHASE)."""
        cx, cz = int(x // CS_GROUND_CELL_M), int(z // CS_GROUND_CELL_M)
        n = int(near // CS_GROUND_CELL_M) + 1
        best = None
        for gx in range(cx - n, cx + n + 1):
            for gz in range(cz - n, cz + n + 1):
                y = self.ground.get((gx, gz))
                if y is None:
                    continue
                d = math.hypot((gx + 0.5) * CS_GROUND_CELL_M - x, (gz + 0.5) * CS_GROUND_CELL_M - z)
                if d <= near and (best is None or d < best[0]):
                    best = (d, y)
        return best[1] if best else None

    @staticmethod
    def _cell(x: float, z: float) -> Tuple[int, int]:
        return int(x // CS_GROUND_CELL_M), int(z // CS_GROUND_CELL_M)

    @staticmethod
    def _middle(c: Tuple[int, int]) -> Tuple[float, float]:
        return (c[0] + 0.5) * CS_GROUND_CELL_M, (c[1] + 0.5) * CS_GROUND_CELL_M

    def _step_cost(self, a: Tuple[int, int], b: Tuple[int, int], now: float,
                   ya: Optional[float] = None) -> Optional[float]:
        """Coût du passage de la case `a` (hauteur `ya` si connue : celle du bot pour sa case) à sa voisine `b`, None
        si infranchissable (voir CS_CHASE)."""
        if self.blocked.get(b, 0.0) > now:
            return None
        ya, yb = (self.ground.get(a) if ya is None else ya), self.ground.get(b)
        if ya is None:
            ya = _cs_walk2.get(a, _cs_safe2.get(a))   # carte des passages (CS_WALKMAP), trajets relevés (CS_ROUTE)
        if yb is None:
            yb = _cs_walk2.get(b, _cs_safe2.get(b))
        if ya is not None and yb is not None and (yb - ya > CS_STEP_M or ya - yb > CS_DROP_M):
            return None                          # mur / rebord à monter, ou chute (eau, contrebas : voir CS_NET_CHASE)
        k = CS_SAFE_COST if b in _cs_safe2 else 1.0 if yb is not None else self.unknown_cost
        return (1.4142 if a[0] != b[0] and a[1] != b[1] else 1.0) * k

    def _waypoint(self, c: Tuple[int, int]) -> Tuple[float, float]:
        """Point visé dans la case de 2 m `c` : milieu de ses cases de 1 m d'un trajet relevé (CS_ROUTE), sinon
        praticables (CS_WALKMAP), sinon son milieu."""
        cells = [(ix, iz) for ix in (2 * c[0], 2 * c[0] + 1) for iz in (2 * c[1], 2 * c[1] + 1)]
        pts = [(ix + 0.5, iz + 0.5) for ix, iz in cells if (ix, iz) in _cs_safe1] or \
              [(ix + 0.5, iz + 0.5) for ix, iz in cells if (ix, iz) in _cs_walk1]
        if not pts:
            return self._middle(c)
        return sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)

    def _mapped(self, c: Tuple[int, int]) -> bool:
        """Zone déjà bien relevée autour de la case `c` (CS_WALK_KNOWN_N cases connues sur 5 x 5) ?"""
        n = 0
        for i in range(-2, 3):
            for j in range(-2, 3):
                k = (c[0] + i, c[1] + j)
                if k in self.ground or k in _cs_walk2 or k in _cs_safe2:
                    n += 1
        return n >= CS_WALK_KNOWN_N

    def _astar(self, start: Tuple[int, int], goal: Tuple[int, int], now: float) -> List[Tuple[int, int]]:
        """Chemin de cases de `start` (exclue) à `goal` ; [] si aucun dans les limites (ligne droite alors)."""
        lo = (min(start[0], goal[0]) - CS_PATH_MARGIN, min(start[1], goal[1]) - CS_PATH_MARGIN)
        hi = (max(start[0], goal[0]) + CS_PATH_MARGIN, max(start[1], goal[1]) + CS_PATH_MARGIN)
        h = lambda c: max(abs(c[0] - goal[0]), abs(c[1] - goal[1])) + 0.4142 * min(abs(c[0] - goal[0]),
                                                                                   abs(c[1] - goal[1]))
        came: Dict[Tuple[int, int], Tuple[int, int]] = {}
        cost = {start: 0.0}
        heap = [(h(start), 0.0, start)]
        done = 0
        while heap and done < CS_PATH_MAX_NODES:
            _, g, c = heapq.heappop(heap)
            if c == goal:
                path = [c]
                while path[-1] in came and came[path[-1]] != start:
                    path.append(came[path[-1]])
                return path[::-1]
            if g > cost.get(c, 1e18):
                continue
            done += 1
            for dx in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    n = (c[0] + dx, c[1] + dz)
                    if n == c or not (lo[0] <= n[0] <= hi[0] and lo[1] <= n[1] <= hi[1]):
                        continue
                    # l'arrivée est toujours atteignable ; depuis la case du bot : sa hauteur à lui, pas celle relevée
                    # pour la case (étages : celle d'un autre niveau faisait changer le chemin à chaque case, 29/10)
                    step = self._step_cost(c, n, now, self.pos[1] if c == start else None) if n != goal else 1.0
                    if step is None:
                        continue
                    ng = g + step
                    if ng < cost.get(n, 1e18):
                        cost[n], came[n] = ng, c
                        heapq.heappush(heap, (ng + h(n), ng, n))
        return []

    def _toward(self, gx: float, gz: float, now: float) -> Tuple[float, float, float]:
        """Direction à prendre pour aller en (gx, gz) en contournant les obstacles connus (chemin A*, voir CS_CHASE)."""
        start, goal = self._cell(self.pos[0], self.pos[2]), self._cell(gx, gz)
        if (self.path_goal is None or now - self.path_at >= CS_PATH_EVERY_S
                or max(abs(goal[0] - self.path_goal[0]), abs(goal[1] - self.path_goal[1])) > 2
                or self.path and start not in self.path[:4]):
            # zone bien relevée (CS_WALKMAP) : une case où personne n'a marché est sans doute un mur
            self.unknown_cost = CS_UNKNOWN_COST_MAPPED if CS_WALKMAP and self._mapped(start) else CS_UNKNOWN_COST
            self.path, self.path_goal, self.path_at = self._astar(start, goal, now), goal, now
            self.plans += 1
        if start in self.path:
            self.path = self.path[self.path.index(start) + 1:]
        if len(self.path) <= 2:
            return _flat_dir(gx - self.pos[0], gz - self.pos[2])
        wx, wz = self._waypoint(self.path[2])
        return _flat_dir(wx - self.pos[0], wz - self.pos[2])

    def _free(self, heading: Tuple[float, float, float], now: float) -> Tuple[float, float, float]:
        """Marche libre : `heading`, ou tournée à ±60/±90/±135° si la case devant n'est pas franchissable."""
        if not CS_WALL_TURN:
            return heading                       # bouton « changer de direction au mur » coupé (CS_WALL_TURN)
        here = self._cell(self.pos[0], self.pos[2])
        for deg in (0, 60, -60, 90, -90, 135, -135):
            d = _turn(heading, deg) if deg else heading
            ahead = self._cell(self.pos[0] + d[0] * CS_GROUND_CELL_M, self.pos[2] + d[2] * CS_GROUND_CELL_M)
            if ahead == here or self._step_cost(here, ahead, now) is not None:
                return d
        return _turn(heading, 180)

    def _new_round(self, now: float) -> None:
        """Début de manche (rafale de 145 ou téléportation du bot), une fois par manche."""
        if self.rounds and now - self.round_at < CS_ROUND_GAP_S:
            return
        self.round_at, self.fight, self.snaps, self.near = now, self.br_mode, 0, False
        self.zone_msgs, self.zone_moving = 0, False
        self.last_enemy, self.detour_until = None, 0.0
        self.spawn, self.enemy_first, self.center, self.fight_at, self.shrink_at = None, {}, None, 0.0, 0.0
        self.trail.clear()
        self.path, self.path_goal = [], None
        self.fight_seen_at = self.frozen_since = 0.0
        self.hp_lost, self.escape, self.escape_next, self.released, self.pinned = 0, None, 0.0, False, False
        self.hp_hits = 0
        self.probe_from, self.lead, self.lead_next = None, None, 0.0
        self.patrol, self.patrol_centered, self.net, self.net_goal = None, False, None, None
        self.patrol_seen = []
        self.patrol_bad.clear()
        self.zone_hurt, self.zone_hurt_since, self.zone_cap = {}, 0.0, None
        self.zone_return = False
        self.straight_done = False
        self.lane, self.lane_over, self.lane_tries = None, False, 0
        self.lane_bad.clear()
        self.hurt_seen.clear()
        self.heal_left, self.heal_wait, self.healing_until = CS_HEAL_MAX, 0.0, 0.0
        self.traces.clear()
        self.escape_bad.clear()
        self.rounds += 1

    def on_round(self, cmd: int, now: float) -> None:
        if cmd == RUDP_TELEPORT_PLAYER:
            self.last_tp = now       # début de manche : téléportation du bot lui-même (voir step), pas les 145
            self.tp_pending = (now, 2)           # le nôtre ? (voir CS_TP_ACK ; mort : on_state ne le confirmera pas)
        elif cmd == RUDP_SAFE_ZONE_CHANGE and now - self.round_at >= CS_FIGHT_AFTER_S:
            # 117 de la manche : préparation (avant), combat, puis resserrement de la zone
            self.zone_msgs += 1
            if not self.fight:
                self.fight, self.fight_at = True, now
            elif not self.shrink_at:
                self.shrink_at = now
            elif self.zone_msgs >= 3 and not self.zone_moving:
                self.zone_moving = True          # déplacement de la zone annoncé (étape 6, voir CS_ZONE_FIRST)

    def on_zone(self, c: bytes, now: float) -> bool:
        """Contenu déchiffré d'un 117 : [0] centre x, z (mm, zigzag), rayon (m), centre visé x, z, rayon visé, étape
        (0 préparation, 1 attente, 2 resserrement, 6 déplacement annoncé, 7 déplacement, 4 fixe), début et fin de l'étape
        (ms). False si illisible / incohérent."""
        v, i = [], 1
        while i < len(c) and len(v) < 9:
            val, i = _read_varint(c, i)
            if val is None:
                break
            v.append(val)
        if len(v) < 9:
            return False
        zz = lambda n: (n >> 1) ^ -(n & 1)
        x, z, R, tx, tz, r, phase = zz(v[0]) / 1000, zz(v[1]) / 1000, v[2], zz(v[3]) / 1000, zz(v[4]) / 1000, v[5], v[6]
        dur = (v[8] - v[7]) / 1000 if v[8] >= v[7] else 0.0
        if phase > 15 or not 1 <= R <= 2000 or r > R or max(abs(x), abs(z), abs(tx), abs(tz)) > 20000 or dur > 600:
            return False
        if r <= 0:
            r, tx, tz = R, x, z
        self.zone_true = {"c0": (x, z), "R": float(R), "c1": (tx, tz), "r": float(r), "phase": phase, "t0": now,
                          "dur": dur}
        self.zone_true_n += 1
        diag.event("MATCH", "cs_zone_true", level="debug", center=[round(x, 1), round(z, 1)], R=R, r=r,
                   to=[round(tx, 1), round(tz, 1)], phase=phase, dur_s=round(dur, 1))
        return True

    def _true_zone(self, t: float) -> Optional[Tuple[Tuple[float, float], float]]:
        """(centre, rayon) de la vraie zone à l'heure `t` d'après le dernier 117 lu de la manche, sinon None."""
        zt = self.zone_true
        if zt is None or zt["t0"] < self.round_at - 5.0:
            return None                          # 117 d'une manche précédente
        (x0, z0), (x1, z1) = zt["c0"], zt["c1"]
        gap = math.hypot(x1 - x0, z1 - z0)
        f = min(1.0, max(0.0, (t - zt["t0"]) / zt["dur"])) if zt["dur"] > 0 else 1.0
        if zt["phase"] == 2:
            # resserrement : rayon R -> r, centre fixe
            return (x0, z0), zt["R"] + (zt["r"] - zt["R"]) * f
        if zt["phase"] == 7:
            # déplacement : centre c0 -> c1, rayon inchangé (voir CS_ZONE_FIRST, zone qui se déplace)
            return (x0 + (x1 - x0) * f, z0 + (z1 - z0) * f), zt["R"]
        if zt["phase"] == 6 and gap > 0.5 and zt["R"] - gap / 2 >= 3.0:
            # déplacement annoncé : cercle sûr pour l'ancien et le nouveau centre
            return ((x0 + x1) / 2, (z0 + z1) / 2), zt["R"] - gap / 2
        return (x0, z0), zt["R"]

    def on_state(self, cmd: int, c: bytes, now: float) -> None:
        try:
            if cmd == UDP_PLAYER_STATE_SYNC:
                if len(c) < 3 or c[0] != 0 or c[1] != 2 or c[2] >= 0x80:
                    return
                idx = c[2]
                if self.idx is None:
                    votes = self.votes[idx] = self.votes.get(idx, 0) + 1
                    if votes < LOCAL_INDEX_VOTES:
                        return
                    self.idx = idx
                    diag.event("MATCH", "cs_local", level="debug", idx=idx, id=hex(self.ident()))
                alive = idx == self.idx
                if self.alive and not alive and self.fight and self.died_round != self.rounds:
                    # mort dans la manche (le serveur suit un autre joueur) : une fois par manche, de zone si le bot
                    # en subissait les dégâts juste avant (bilan de la partie, ffbot.teamlab)
                    self.died_round = self.rounds
                    self.deaths += 1
                    if now - self.zone_hurt.get(self.idx, 0.0) <= CS_ZONE_HURT_S:
                        self.zone_deaths += 1
                self.alive = alive
                if self.alive:
                    v, i = _svarints(c, 3, 6)
                    prev, prev_at, prev_vel = self.server, self.server_at, self.server_vel
                    self.server = (v[0] / 1000, v[1] / 1000, v[2] / 1000)
                    self.server_new, self.server_at = True, now
                    try:
                        w, _ = _svarints(c, i, 5)        # joystick (x, z) puis vitesse (x, y, z) qu'il a retenus
                        self.server_joy, self.server_vel = (w[0], w[1]), (w[2], w[4])
                    except IndexError:
                        pass
                    if self.tp_pending is not None:
                        if now - self.tp_pending[0] > CS_TP_ACK_WINDOW_S:
                            self.tp_pending = None   # 144 / 145 d'un autre joueur
                        elif prev is not None:
                            dt = now - prev_at
                            jump = math.hypot(self.server[0] - prev[0] - prev_vel[0] / 100 * dt,
                                              self.server[2] - prev[2] - prev_vel[1] / 100 * dt)
                            # (en marche depuis 0,6 s : l'écho du joystick a ~0,2 s de retard au départ)
                            ignored = self.moving and now - self.moving_since >= 0.6 and self.server_joy == (0, 0)
                            if jump > CS_TP_JUMP_M or ignored:
                                # le nôtre : 146 au prochain 2001, et à l'arrêt sur la position imposée (comme un 144)
                                self.tp_ack_due, self.tp_pending = self.tp_pending[1], None
                                self.forced_new, self.forced_at = True, now
                    if CS_WALKMAP:
                        _cs_walk_add(self.server[0], self.server[2], self.server[1])   # accepté par le serveur
                    if self.server_moved[0] is None or math.dist(self.server, self.server_moved[0]) > 0.25:
                        self.server_moved = (self.server, now)
                    if self.pos is None and (v[3] or v[5]):
                        self.aim = _flat_dir(v[3], v[5])
            elif len(c) >= 2 and c[0] == 0:
                i = 2
                for _ in range(c[1] // 2):
                    idx = c[i]
                    v, i = _svarints(c, i + 1, 6)
                    i += 7
                    x, z = v[0] / 1000, v[2] / 1000
                    self.players[idx] = (now, x, v[1] / 1000, z)
                    tr = self.traces.setdefault(idx, [])
                    gap = math.hypot(x - tr[-1][0], z - tr[-1][1]) if tr else CS_TRACE_STEP_M
                    if gap > CS_TELEPORT_M:
                        tr.clear()                   # téléporté (manche suivante) avant le bot : trace repartie
                    if gap >= CS_TRACE_STEP_M and len(tr) < CS_TRACE_MAX:
                        tr.append((x, z))
                    if abs(v[4]) <= CS_GROUND_VY:
                        if CS_WALKMAP:
                            _cs_walk_add(x, z, v[1] / 1000)      # carte des passages (voir CS_WALKMAP)
                        # au sol : hauteur relevée pour la case (voir CS_CHASE)
                        self.ground[(int(v[0] / 1000 // CS_GROUND_CELL_M), int(v[2] / 1000 // CS_GROUND_CELL_M))] = \
                            v[1] / 1000
        except IndexError:
            return

    def _target(self, now: float) -> Optional[Tuple[float, float, float, float]]:
        """Adversaire vu le plus proche : (distance au sol, x, y, z)."""
        foe = self.nearest_foe(now)
        self.target_idx = foe[1] if foe else None
        return foe[:1] + foe[2:] if foe else None

    def nearest_foe(self, now: float) -> Optional[Tuple[float, int, float, float, float]]:
        """Adversaire vu le plus proche : (distance au sol, n°, x, y, z)."""
        best = None
        for idx, (seen, x, y, z) in self.players.items():
            if not self.enemy(idx) or now - seen > CS_SEEN_S:
                continue
            d = math.hypot(x - self.pos[0], z - self.pos[2])
            if best is None or d < best[0]:
                best = (d, idx, x, y, z)
        return best

    def zone_radius(self, t: float) -> float:
        """Rayon estimé de la zone à l'heure `t` (voir CS_CHASE)."""
        start = self.shrink_at or (self.fight_at + CS_ZONE_SHRINK_AFTER_S if self.fight_at else 0.0)
        if not start or t <= start:
            return self.zone_r0
        done = min(1.0, (t - start) / CS_ZONE_SHRINK_S)
        return self.zone_r0 + (CS_ZONE_FINAL_M - self.zone_r0) * done

    def _zone(self, now: float, target) -> Optional[float]:
        """Rayon sûr de la zone (ou None si son centre n'est pas encore estimé) ; estime le centre au début du combat."""
        now_zone = self._true_zone(now)
        if now_zone is not None:
            # vraie zone (117 lu) : centre actuel, rayon qu'elle aura dans CS_ZONE_AHEAD_S, moins la marge
            if self.center is None:
                self.zone_src["true"] += 1
            self.center, self.zone_r0 = now_zone[0], self.zone_true["R"]
            ahead = self._true_zone(now + CS_ZONE_AHEAD_S)
            r = min(now_zone[1], ahead[1] if ahead else now_zone[1])
            if self.zone_cap is not None:
                r = min(r, self.zone_cap)
            return max(2.0, r - CS_ZONE_TRUE_MARGIN_M)
        if self.center is None and self.spawn is not None:
            town = _cs_lane_side(*self.spawn) if CS_LANE else None
            spot = None if self.enemy_first or town else _cs_zone_spot(*self.spawn)
            if town:
                # ville reconnue à sa base (voir CS_LANE) : son vrai centre et son vrai rayon (117 de ses manches)
                self.center, self.zone_r0, src = (town[0]["center"][0], town[0]["center"][1]), float(town[0]["R"]), "spot"
            elif self.enemy_first:
                # adversaires vus dans leur base pendant la préparation : milieu des deux bases
                ex = sum(p[0] for p in self.enemy_first.values()) / len(self.enemy_first)
                ez = sum(p[1] for p in self.enemy_first.values()) / len(self.enemy_first)
                self.center = ((self.spawn[0] + ex) / 2, (self.spawn[1] + ez) / 2)
                self.zone_r0 = math.hypot(self.spawn[0] - self.center[0],
                                          self.spawn[1] - self.center[1]) + CS_ZONE_EXTRA_M
                src = "enemies"
            elif spot is not None:
                # bases trop éloignées pour se voir : emplacement connu (voir CS_ZONE_SPOTS_FILE)
                self.center, self.zone_r0, src = (spot["center"][0], spot["center"][1]), float(spot["R"]), "spot"
            elif target is not None:
                # emplacement inconnu : CS_ZONE_GUESS_M vers le premier adversaire vu (bases à 55-83 m du centre)
                d = math.hypot(target[1] - self.spawn[0], target[3] - self.spawn[1]) or 1.0
                reach = max(CS_ZONE_GUESS_M, d / 2)
                self.center = (self.spawn[0] + (target[1] - self.spawn[0]) / d * reach,
                               self.spawn[1] + (target[3] - self.spawn[1]) / d * reach)
                self.zone_r0, src = reach + CS_ZONE_EXTRA_M, "guess"
            else:
                return None
            self.zone_src[src] += 1
            diag.event("MATCH", "cs_zone", level="debug", center=[round(v, 1) for v in self.center],
                       r0=round(self.zone_r0, 1), seen=len(self.enemy_first), src=src)
        if self.center is None:
            return None
        r = self.zone_radius(now + CS_ZONE_AHEAD_S)
        if self.zone_cap is not None:
            r = min(r, self.zone_cap)            # touché par la zone plus près du centre que l'estimation (CS_CHASE)
        return max(CS_ZONE_FINAL_M, r - CS_ZONE_MARGIN_M)

    def _zone_refuge(self, now: float) -> Optional[Tuple[float, float]]:
        """Milieu des autres joueurs vus qui ne reçoivent pas de dégâts de zone (dans la zone), None sans eux."""
        pts = [(x, z) for idx, (seen, x, _, z) in self.players.items()
               if idx != self.idx and now - seen <= CS_SEEN_S and now - self.zone_hurt.get(idx, 0.0) > CS_ZONE_HURT_S]
        if not pts:
            return None
        return sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)

    def _mate(self, now: float) -> Optional[Tuple[float, float, float]]:
        """Coéquipier vu le plus proche (autre que le bot) : (distance au sol, x, z)."""
        best = None
        for idx, (seen, x, _, z) in self.players.items():
            if idx == self.idx or self.enemy(idx) or now - seen > CS_SEEN_S:
                continue
            d = math.hypot(x - self.pos[0], z - self.pos[2])
            if best is None or d < best[0]:
                best = (d, x, z)
        return best

    def item_actions(self, now: float, ms: int) -> List[Tuple[int, bytes]]:
        """Messages fiables à envoyer maintenant : achat d'arme en préparation (CS_BUY), soin (CS_HEAL), réponses."""
        out, self.item_out = self.item_out, []
        if self.idx is None or not self.alive:
            return out
        ident = self.ident()
        if CS_BUY and self.rounds and self.buy_round != self.rounds and not self.fight \
                and now - self.round_at >= CS_BUY_AFTER_S:
            # boutique ouverte, achat (réponse 413 du serveur : arme en main, voir on_item)
            self.buy_round, self.buy_at, self.buy_open = self.rounds, now, True
            self.buys += 1
            out += [(RUDP_C2S_SYNC_USE_CSSHOP, b"\x01"), (RUDP_PURCHASE_CSITEMS, CS_BUY_ITEM)]
        if self.equip_due:
            self.equip_due = False
            out.append((RUDP_CHANGE_INVENTORY_ON_HAND, _varint(ident) + _varint(CS_BUY_WEAPON)))
        if self.buy_open and (self.buys_ok and now - self.buy_at >= 0.4 or now - self.buy_at >= CS_BUY_REPLY_S):
            self.buy_open = False
            out.append((RUDP_C2S_SYNC_USE_CSSHOP, b"\x00"))
        if self.heal_wait and now - self.heal_wait > CS_HEAL_REPLY_S:
            if self.replies_readable:
                self.heal_wait, self.heal_left = 0.0, 0     # pas de 204 : plus de trousse dans cette manche
                self.healing_until = 0.0
            else:
                self.heal_wait = 0.0             # réponses illisibles (pas de clé de session) : rien à conclure
        hp = PLAYER_MAX_HP - self.hp_lost
        want = (CS_HEAL and self.fight and self.heal_left > 0 and not self.heal_wait and hp <= CS_HEAL_HP
                and now - self.heal_at >= CS_HEAL_EVERY_S)
        self.heal_blocked = want and not self._in_safe_zone(now, CS_HEAL_IN_M)
        if want and not self.heal_blocked:
            # dans la zone sûre seulement (sinon il y rentre d'abord) ; puis à l'arrêt (voir CS_HEAL_HOLD_S)
            self.heal_at = self.heal_wait = now
            self.healing_until = now + CS_HEAL_HOLD_S
            self.heal_left -= 1
            self.heals += 1
            out.append((RUDP_TRYUSE_INVENTORY, _varint(CS_HEAL_ITEM) + b"\x01" + _varint(max(0, ms))))
            diag.event("MATCH", "cs_heal", level="debug", hp=hp, left=self.heal_left)
        return out

    def _in_safe_zone(self, now: float, margin: float = 0.0) -> bool:
        """Bot dans la zone sûre (position du serveur), sans dégâts de zone récents ; zone inconnue : oui."""
        if now - self.zone_hurt.get(self.idx, 0.0) <= CS_ZONE_HURT_S:
            return False                         # la zone le touche : dehors
        if self.server is None:
            return True
        safe = self._zone(now, None)
        if safe is None or self.center is None:
            return True
        return math.hypot(self.server[0] - self.center[0], self.server[2] - self.center[1]) <= safe - margin

    def on_item(self, cmd: int, c: bytes, now: float) -> None:
        """Réponses du serveur au soin et à l'achat (contenu déchiffré, voir CS_HEAL / CS_BUY)."""
        mine = self.ident()
        who, i = _read_varint(c, 0)
        if cmd == RUDP_PURCHASE_CSITEMS:
            if self.buy_open:
                self.buys_ok += 1
                self.equip_due = True            # pistolet acheté : en main
        elif cmd == RUDP_PLAYER_DO_ACTION and who == mine and self.heal_wait:
            self.heal_wait = 0.0                 # soin en cours
        elif cmd == RUDP_USEMEDKIT_SUCCESS:
            self.heals_ok += 1
            self.healing_until = 0.0             # soin fait : il peut repartir
        elif cmd == RUDP_MEDKITHP_SYNC_UPDATE and who == mine:
            hp, _ = _read_varint(c, i)
            if hp is not None and 0 < hp <= PLAYER_MAX_HP:
                self.hp_lost = PLAYER_MAX_HP - hp
                self.hp_hits = min(self.hp_hits, self.hp_lost)
        elif cmd == RUDP_CANCELUSE_INVENTORY and who == mine:
            self.item_out.append((RUDP_CANCELUSE_INVENTORY, _varint(CS_HEAL_ITEM)))   # comme le client
            self.heal_wait, self.healing_until = 0.0, 0.0

    def _lane_cost(self, lane: Dict[str, Any]) -> float:
        """Coût d'une voie en mètres, tirage à part (voir CS_LANE)."""
        return (lane["len"] + CS_LANE_JUMP_COST * min(lane["jumps"], CS_LANE_JUMP_MAX)
                - CS_LANE_N_COST * math.log2(max(1, lane["n"])) + CS_LANE_FAIL_COST * _cs_lane_fails.get(lane["id"], 0))

    def _lane_pick(self, now: float) -> Optional[Dict[str, Any]]:
        """Voie à suivre (voir CS_LANE) : au cercle rouge celle du rang du bot dans l'équipe parmi les meilleures, après un
        échec la voie du même côté qui mène au bout par le moins de chemin depuis le bot ; None sans voie possible."""
        found = _cs_lane_side(*self.spawn) if self.spawn is not None else None
        if found is None or self.lane_tries >= CS_LANE_TRIES:
            return None
        town, side = found
        lanes = town["sides"][side]["lanes"]
        if not lanes:
            return None
        x, z = self.pos[0], self.pos[2]

        def join(lane: Dict[str, Any]) -> Tuple[float, int, float]:
            # point d'entrée : le moins de chemin jusqu'au bout (voie restante + bot -> point, CS_NET_OFF_COST fois)
            return min((lane["cum"][-1] - c + CS_NET_OFF_COST * math.hypot(p[0] - x, p[2] - z), i,
                        math.hypot(p[0] - x, p[2] - z)) for i, (p, c) in enumerate(zip(lane["pts"], lane["cum"])))
        slot = of = None
        if not self.lane_tries:
            # (tirage pour toutes les voies, dans l'ordre du fichier : même résultat chez tous les bots de l'équipe)
            rng = random.Random(f"{self.seed}:{town['map']}:{town['area']}:{side}:{self.rounds}")
            ranked = sorted((self._lane_cost(l) + rng.uniform(0.0, CS_LANE_JITTER_M), k) for k, l in enumerate(lanes))
            good = [k for _, k in ranked if lanes[k]["own"]] + [
                k for cost, k in ranked if not lanes[k]["own"] and cost <= ranked[0][0] + CS_LANE_SPREAD_M]
            team = sorted(self.mates | {self.idx})
            slot, of = (team.index(self.idx) + self.rounds) % len(team), len(good)
            lane = lanes[good[slot % of]] if good else None
        else:
            near = [(join(l), n) for n, l in enumerate(lanes) if l["id"] not in self.lane_bad]
            near = [c for c in near if c[0][2] <= CS_LANE_REJOIN_M]
            lane = lanes[min(near)[1]] if near else None
        if lane is None:
            return None
        self.lane_tries += 1
        self.lanes += 1
        self.lanes_own += bool(lane["own"])
        diag.event("MATCH", "cs_lane", level="info", town=town["town"], area=town["area"], side=side, lane=lane["id"],
                   len_m=round(lane["len"]), n=lane["n"], own=lane["own"], slot=slot, of=of, tries=self.lane_tries)
        return {"lane": lane, "k": join(lane)[1], "best_at": now}

    def _lane_leave(self, why: str, over: bool = True) -> None:
        """Voie quittée (`over` : plus de voie dans cette manche)."""
        e = self.lane
        if e is not None:
            self.lanes_done += why == "end"
            diag.event("MATCH", "cs_lane_left", level="info", lane=e["lane"]["id"], why=why, k=e["k"],
                       pts=len(e["lane"]["pts"]))
            self.lane = None
        self.lane_over = self.lane_over or over

    def _laning(self, now: float, chase) -> Optional[Tuple[float, float, float]]:
        """Direction à suivre sur la voie (choisie au premier appel de la manche, voir CS_LANE) ; None sans voie."""
        if self.lane_over or not _cs_lanes:
            return None
        if chase is not None and chase[0] <= CS_LANE_FOE_M:
            self._lane_leave("foe")
            return None
        e = self.lane
        if e is None:
            e = self.lane = self._lane_pick(now)
            if e is None:
                self.lane_over = True
                return None
        pts, x, z = e["lane"]["pts"], self.pos[0], self.pos[2]
        dist = lambda i: math.hypot(pts[i][0] - x, pts[i][2] - z)
        last, k = len(pts) - 1, e["k"]
        while k < last and (dist(k) <= CS_LANE_REACH_M or dist(k + 1) < dist(k)):
            k += 1
        if k > e["k"] or now - e.get("tick", now) > 1.0 and self.doing != "slide":
            e["k"], e["best_at"] = k, now
        e["tick"] = now
        if k == last and dist(k) <= CS_LANE_REACH_M:
            self._lane_leave("end")
            return None
        if now - e["best_at"] >= CS_LANE_STALL_S and self.server_moved[1] <= self.fight_seen_at:
            e["best_at"] = now       # jamais déplacé par le serveur depuis le cercle rouge : retenu, pas la faute de la voie
        if now - e["best_at"] >= CS_LANE_STALL_S:
            # n'avance plus : mur, saut que le bot ne fait pas ; une autre voie du même côté si possible
            lane_id = e["lane"]["id"]
            self.lanes_failed += 1
            _cs_lane_fails[lane_id] = _cs_lane_fails.get(lane_id, 0) + 1
            self.lane_bad.add(lane_id)
            self._lane_leave("stall", over=False)
            return self._laning(now, chase)
        px, pz = pts[k][0], pts[k][2]
        if k >= 1:
            a, b = pts[k - 1], pts[k]
            dx, dz = b[0] - a[0], b[2] - a[2]
            t = max(0.0, min(1.0, ((x - a[0]) * dx + (z - a[2]) * dz) / (dx * dx + dz * dz or 1.0)))
            on = math.hypot(x - a[0] - t * dx, z - a[2] - t * dz) <= CS_NET_ON_M
        else:
            on = dist(0) <= CS_NET_ON_M
        if on and self.blocked.get(self._cell(px, pz), 0.0) <= now:
            return _flat_dir(px - x, pz - z)
        # pas encore sur la voie (entrée depuis la base), ou arrêté juste devant : par l'A* des cases
        while k < last and dist(k) < CS_LANE_AROUND_M:
            k += 1
        return self._toward(pts[k][0], pts[k][2], now)

    def _pack_leader(self, now: float) -> Optional[Tuple[int, float, float]]:
        """Chef du groupe (CS_PACK) : coéquipier vivant vu de plus petit n°, bot compris — (n°, x, z) ; None si le bot
        est lui-même le chef ou seul."""
        if self.idx is None:
            return None
        best = None
        for idx, (seen, x, _, z) in self.players.items():
            if idx == self.idx or self.enemy(idx) or now - seen > CS_SEEN_S:
                continue
            if best is None or idx < best[0]:
                best = (idx, x, z)
        return best if best is not None and best[0] < self.idx else None

    def _foe_near(self, x: float, z: float, now: float) -> Optional[Tuple[float, float, float, float]]:
        """Adversaire vu le plus proche du point (x, z) : (distance au bot, x, y, z), comme _target."""
        best = None
        for idx, (seen, fx, fy, fz) in self.players.items():
            if not self.enemy(idx) or now - seen > CS_SEEN_S:
                continue
            d = math.hypot(fx - x, fz - z)
            if best is None or d < best[0]:
                best = (d, fx, fy, fz, idx)
        if best is None:
            return None
        self.target_idx = best[4]
        return (math.hypot(best[1] - self.pos[0], best[3] - self.pos[2]),) + best[1:4]

    def _foe_route(self, idx: Optional[int], ex: float, ez: float, safe: Optional[float],
                   now: float) -> Optional[Tuple[float, float, float]]:
        """Direction sur la route de l'adversaire `idx` (sa trace de la manche + sa position (ex, ez)) : point le plus
        proche rejoint d'abord, puis point par point vers lui (voir CS_FOE_TRACE) ; None sans trace utilisable."""
        if idx is None:
            return None
        tr = list(self.traces.get(idx) or [])
        if not tr or math.hypot(tr[-1][0] - ex, tr[-1][1] - ez) > 0.3:
            tr.append((ex, ez))
        if len(tr) < 3:
            return None
        d, i = self._nearest_point(tr)
        if d > CS_FOE_TRACE_JOIN_M:
            return None
        if d > CS_FOE_TRACE_NEAR_M:
            gx, gz = tr[i]                       # loin de la route : on la rejoint (chemin A*)
            if safe is not None:
                gx, gz = self._inside(gx, gz, safe)
            heading = self._toward(gx, gz, now)
        else:
            while i < len(tr) - 1 and math.hypot(tr[i][0] - self.pos[0],
                                                 tr[i][1] - self.pos[2]) <= CS_FOE_TRACE_REACH_M:
                i += 1
            gx, gz = tr[i]
            if safe is not None:
                gx, gz = self._inside(gx, gz, safe)
            heading = _flat_dir(gx - self.pos[0], gz - self.pos[2])
        if self.doing != "foe_route":
            self.foe_routes += 1
        return heading

    def _straight_goal(self, safe: Optional[float]) -> Optional[Tuple[float, float]]:
        """Base d'en face (symétrique de la base du bot par rapport au centre de la zone), ramenée dans la zone ; None
        une fois atteinte dans la manche, ou centre / base inconnus (voir CS_STRAIGHT)."""
        if self.straight_done or self.center is None or self.spawn is None:
            return None
        gx, gz = 2 * self.center[0] - self.spawn[0], 2 * self.center[1] - self.spawn[1]
        if safe is not None:
            gx, gz = self._inside(gx, gz, safe)
        if math.hypot(gx - self.pos[0], gz - self.pos[2]) <= CS_STRAIGHT_DONE_M:
            self.straight_done = True
            return None
        return gx, gz

    def _inside(self, x: float, z: float, r: float) -> Tuple[float, float]:
        """Point (x, z) ramené dans le cercle de rayon `r` autour du centre de la zone."""
        dx, dz = x - self.center[0], z - self.center[1]
        d = math.hypot(dx, dz)
        return (x, z) if d <= r else (self.center[0] + dx / d * r, self.center[1] + dz / d * r)

    def step(self, now: float) -> Optional[Tuple[Tuple[float, float, float], Tuple[float, float, float], bool]]:
        """(position, vitesse cm/s, course ?) du prochain 2001 ; None : rien à envoyer (joueur local inconnu ou mort).
        Le dernier résultat reste dans step_last (position et vitesse du 248, voir CS_SKILL_TEST)."""
        self.step_last = self._step(now)
        return self.step_last

    def _step(self, now: float):
        if self.idx is None or not self.alive or self.server is None:
            return None
        dt = min(0.3, now - self.last_step) if self.last_step else 0.1
        self.last_step = now
        forced, self.forced_new = self.forced_new, False   # 144 du serveur : correction sans attendre (CS_CHASE)
        if self.pos is None:
            self.pos = list(self.server)
            self._new_round(now)
        elif forced or self.server_new and (math.dist(self.pos, self.server) > CS_SNAP_M or self.moving and (
                math.dist(self.pos, self.server) > CS_STUCK_GAP_M
                and now - max(self.server_moved[1], self.moving_since) >= self._stuck_s())):
            gap = math.dist(self.pos, self.server)
            walled = self.moving and now - max(self.server_moved[1], self.moving_since) >= self._stuck_s()
            stuck = forced or walled
            if forced:
                self.forces_used += 1
                self.hold_until = now + CS_FORCE_HOLD_S
            # l'une de nos positions récentes, et le serveur nous suit encore : il est en retard, pas une correction
            past = min(((math.dist((x, y, z), self.server), t) for t, x, y, z in self.trail if now - t <= CS_LAG_S),
                       default=None)
            if gap < CS_TELEPORT_M and not stuck and past is not None and past[0] <= CS_LAG_MATCH_M:
                self.lag_skips += 1
                if now - self.server_moved[1] < 0.3:
                    self.lags.append(now - past[1])   # retard relevé seulement quand le serveur nous suit
                self.ground.setdefault(self._cell(self.server[0], self.server[2]), self.server[1])
            else:
                # téléportation (début de manche) ou position corrigée par le serveur (un mur…) : on la reprend ; une
                # correction en marche bloque la case juste devant l'endroit où il nous a arrêtés (chemin recalculé),
                # et en marche libre on part en détour d'un quart de tour (à gauche ou à droite)
                if gap < CS_TELEPORT_M and self.moving and self.released and not (
                        self.doing == "lane" and now - self.server_moved[1] < 0.3):
                    # mur : cases refusées = celles entre l'endroit où il nous a arrêtés et celui où l'on voulait
                    # aller (la première avec ses deux voisines en travers), la nôtre exceptée
                    here = self._cell(self.server[0], self.server[2])
                    dx, dz = self.pos[0] - self.server[0], self.pos[2] - self.server[2]
                    n, first = int(math.hypot(dx, dz) / 0.5) + 1, True
                    for k in range(1, n + 1):
                        x, z = self.server[0] + dx * k / n, self.server[2] + dz * k / n
                        if self._cell(x, z) == here:
                            continue
                        for side in ((0.0, 1.0, -1.0) if first else (0.0,)):
                            self.blocked[self._cell(x - self.heading[2] * side * CS_GROUND_CELL_M,
                                                    z + self.heading[0] * side * CS_GROUND_CELL_M)] = now + CS_BLOCK_S
                        first = False
                    # toutes les cases voisines refusées : le serveur refuse tout (pas des murs, on est arrivé ici
                    # par l'une d'elles) -> oubliées, sinon le bot se croit enfermé CS_BLOCK_S après
                    ring = [(here[0] + i, here[1] + j) for i in (-1, 0, 1) for j in (-1, 0, 1) if i or j]
                    if all(self.blocked.get(c, 0.0) > now for c in ring):
                        for c in ring:
                            self.blocked.pop(c, None)
                    self.path_goal = None
                self.pos = list(self.server)
                self.moving_since = now          # repart d'ici : le serveur en retard montrera encore ce point un moment
                if gap >= CS_TELEPORT_M:
                    self._new_round(now)
                elif self.moving:
                    self.snaps += 1
                    self.snaps_total += 1
                    if not CS_WALL_TURN:
                        pass                             # bouton coupé (CS_WALL_TURN) : même direction
                    elif self.doing in ("frozen", "escape", "lead", "route", "patrol", "net", "foe_route") \
                            or not self.released or self.doing == "lane" and not walled:
                        pass                             # à terre / sur la trace d'un coéquipier / chemin recalculé
                        #                                  autour de la case bloquée (CS_ROUTE) / encore retenu dans
                        #                                  sa base (CS_RELEASE_M) : pas de détour
                    elif self.doing in ("orbit", "wander", "detour"):
                        self.detours += 1
                        self.heading = _turn(self.heading, random.choice((-1, 1)) * random.uniform(*CS_DETOUR_DEG))
                        self.detour_until = now + random.uniform(*CS_DETOUR_S)
                    else:
                        # en route vers une cible : on longe l'obstacle (voir CS_CHASE)
                        if now - self.stuck_at <= CS_SLIDE_AGAIN_S:
                            if self.doing == "slide":
                                self.slide_side = -self.slide_side        # arrêté en le longeant : autre côté
                            self.slide_len = min(CS_SLIDE_MAX_S, self.slide_len * 1.5)
                            route = self.slide_route
                        else:
                            self.slide_side, self.slide_len = random.choice((-1, 1)), CS_SLIDE_S
                            route = self.slide_route = self.heading
                        self.slide_dir = _flat_dir(-route[2] * self.slide_side, route[0] * self.slide_side)
                        self.slide_until = now + self.slide_len
                        self.stuck_at = now
                        self.slides += 1
                # (trajet gardé : un serveur en retard montrera encore nos positions d'avant la correction)
        elif self.server_new and self.trail:
            # écart faible : retard du serveur sur nos positions, relevé pour le bilan ; case franchissable
            past = min(((math.dist((x, y, z), self.server), t) for t, x, y, z in self.trail), default=None)
            if past is not None and past[0] <= CS_LAG_MATCH_M and now - self.server_moved[1] < 0.3:
                self.lags.append(now - past[1])
                self.ground.setdefault(self._cell(self.server[0], self.server[2]), self.server[1])
        self.server_new = False
        target = self._target(now)
        # groupe (CS_PACK) : chef commun ; en combat, tout le groupe va sur l'adversaire le plus proche du chef (le même
        # pour les 4) et tourne autour de lui (orbite, demande du 08/11 : « tourner autour de l'ennemi »)
        leader = self._pack_leader(now) if CS_PACK else None
        if leader is not None and target is not None:
            target = self._foe_near(leader[1], leader[2], now) or target
        if target is not None and target[2] >= self.pos[1] - CS_DROP_M:
            self.last_enemy = target[1:]         # (pas un adversaire bien plus bas : pas suivi, voir CS_NET_CHASE)
            self.last_enemy_idx = self.target_idx
        fight = self.fight or now - self.round_at >= CS_FIGHT_FALLBACK_S
        was_running = self.running
        self.running = self.moving = False
        if not fight:
            # préparation : position bloquée par le serveur ; la tête tourne doucement (vers l'adversaire s'il est vu).
            # Base du bot et adversaires vus (leur base) : centre de la zone, estimé au début du combat
            self.doing = "prep"
            self.moving_since = now              # à l'arrêt : l'immobilité du serveur ne compte qu'une fois en marche
            self.spawn = (self.pos[0], self.pos[2])
            for idx, (seen, x, _, z) in self.players.items():
                if idx == self.idx or seen < self.round_at + 1.0:
                    continue
                d = math.hypot(x - self.spawn[0], z - self.spawn[1])
                if d <= CS_MATE_M and idx not in self.foes:
                    self.mates.add(idx)          # dans notre base : coéquipier (pour toute la partie)
                elif d >= CS_FOE_M and idx not in self.mates:
                    self.foes.add(idx)
                if self.enemy(idx) and d >= CS_FOE_M:
                    self.enemy_first.setdefault(idx, (x, z))
            if target is not None and target[0] > 0.01:
                self.aim = _flat_dir(target[1] - self.pos[0], target[3] - self.pos[2])
            else:
                self.aim = _turn(self.aim, CS_AIM_DEG_S * dt * (1 if int(now / 4) % 2 else -1))
            return (self.pos[0], self.pos[1], self.pos[2]), (0.0, 0.0, 0.0), False
        if now < self.hold_until:
            # 144 du serveur : à l'arrêt sur la position imposée (voir CS_CHASE), le temps qu'il la voie
            self.moving_since = now
            return (self.pos[0], self.pos[1], self.pos[2]), (0.0, 0.0, 0.0), False
        speed = CS_WALK_CM_S
        safe = self._zone(now, target)
        if not self.fight_seen_at:
            self.fight_seen_at = now
        wait = CS_PINNED_WAIT_S if self.pinned else CS_RELEASE_WAIT_S
        followed = self.probe_from is not None and math.hypot(
            self.server[0] - self.probe_from[0], self.server[2] - self.probe_from[2]) >= CS_PROBE_FOLLOW_M
        # zone d'abord : dégâts de zone reçus, ou position du serveur hors de la zone sûre. Captures du bot du 25-26/10
        # (47 parties, 148 manches-bot) : 23 % des manches sans jamais sortir de la base, et chaque mort de zone avec le
        # bot à 45-63 m du vrai centre (sa base), « retenu » (held / probe), à terre ou longeant un obstacle pendant
        # que la zone se refermait — ni l'attente de la libération ni la reptation ne regardaient la zone.
        zone_hurt = now - self.zone_hurt.get(self.idx, 0.0) <= CS_ZONE_HURT_S
        danger = zone_hurt or (safe is not None and math.hypot(
            self.server[0] - self.center[0], self.server[2] - self.center[1]) > safe)
        if now < self.healing_until:
            if danger:
                self.healing_until = 0.0         # la zone d'abord : il bouge (soin perdu, repris une fois dedans)
            else:
                # soin en cours (voir CS_HEAL_HOLD_S) : à l'arrêt sur la position du serveur, regard inchangé
                self.doing = "heal"
                self.moving_since = now
                self.pos = list(self.server)
                return (self.pos[0], self.pos[1], self.pos[2]), (0.0, 0.0, 0.0), False
        # CS_TP_ACK : la retenue dans la base venait des 144 / 145 non confirmés (voir CS_TP_ACK) ; confirmés par le
        # 146, on part dès l'ouverture du cercle rouge (demande du 27/10 : « หลังวงเปิดให้เดินไปทันที »)
        if not self.released and (CS_TP_ACK or self.spawn is None or now - self.fight_seen_at >= wait or followed
                                  or danger or math.hypot(self.server[0] - self.spawn[0],
                                                          self.server[2] - self.spawn[1]) >= CS_RELEASE_M):
            self.released, self.released_at = True, now   # le serveur nous laisse sortir de la base (CS_RELEASE_M)
            self.moving_since = now
        still = now - max(self.server_moved[1], self.fight_seen_at)
        # à terre : dégâts des AUTRES joueurs seulement — ceux de la zone faisaient passer le bot « à terre » (reptation
        # lente vers un coéquipier) au lieu de courir hors de la zone
        knocked = self.hp_hits >= CS_KNOCK_HP
        # figé par le serveur après un 144 (non confirmé : 146 chiffré avec la clé de session) : même essai court que
        # dans la base, plutôt que de longer / s'échapper sans fin (essai du 25/10 23:43 : 2 bots figés 40 s, ~90
        # corrections chacun) ; jamais dans la zone
        frozen_144 = (not CS_TP_ACK and self.released and not knocked and not danger and self.forced_at
                      and now - self.forced_at <= CS_PIN_AFTER_144_S and still >= CS_FROZEN_S)
        if not self.released or frozen_144:
            # retenu dans sa base (voir CS_CHASE) : à l'arrêt sur la position du serveur, avec un court essai toutes
            # les CS_PROBE_EVERY_S dans une direction qui change (vers la cible d'abord) ; libéré dès qu'il suit
            k, phase = divmod(now - self.fight_seen_at, CS_PROBE_EVERY_S)
            goal = (target[1], target[3]) if target else (self.center or self.spawn)
            base = _flat_dir(goal[0] - self.pos[0], goal[1] - self.pos[2]) if goal else self.aim
            self.aim = base
            if phase >= CS_PROBE_S:
                self.doing = "held"
                self.pos = list(self.server)     # essai refusé : retour sur la position du serveur, sans correction
                self.moving_since = now
                return (self.pos[0], self.pos[1], self.pos[2]), (0.0, 0.0, 0.0), False
            if self.doing != "probe":
                self.probe_from = self.server    # suivi de l'essai par le serveur (CS_PROBE_FOLLOW_M)
            self.doing = "probe"
            self.heading = _turn(base, CS_PROBE_DEG[int(k) % len(CS_PROBE_DEG)])
            self.aim = self.heading          # face à la marche (voir plus bas)
            move = CS_WALK_CM_S / 100 * dt
            self.pos[0] += self.heading[0] * move
            self.pos[2] += self.heading[2] * move
            self.moving = True
            self.trail.append((now, self.pos[0], self.pos[1], self.pos[2]))
            return ((self.pos[0], self.pos[1], self.pos[2]),
                    (self.heading[0] * CS_WALK_CM_S, 0.0, self.heading[2] * CS_WALK_CM_S), False)
        if still >= CS_FROZEN_S and knocked:
            # à terre (voir CS_CHASE) : reptation de temps en temps vers un coéquipier, sinon le centre de la zone
            if not self.frozen_since:
                self.frozen_since = now
                self.frozen_count += 1
            self.doing = "frozen"
            mate = None if danger else self._mate(now)    # dans la zone : vers son centre, pas vers un coéquipier
            goal = (mate[1], mate[2]) if mate else (self.center if self.center else None)
            if goal is not None:
                self.heading = _flat_dir(goal[0] - self.pos[0], goal[1] - self.pos[2])
            self.aim = self.heading          # face à la reptation (voir plus bas)
            crawl = (now - self.frozen_since) % CS_CRAWL_EVERY_S < CS_CRAWL_TRY_S
            if not crawl:
                return (self.pos[0], self.pos[1], self.pos[2]), (0.0, 0.0, 0.0), False
            move = CS_CRAWL_CM_S / 100 * dt
            self.pos[0] += self.heading[0] * move
            self.pos[2] += self.heading[2] * move
            self.moving = True
            self.trail.append((now, self.pos[0], self.pos[1], self.pos[2]))
            return ((self.pos[0], self.pos[1], self.pos[2]),
                    (self.heading[0] * CS_CRAWL_CM_S, 0.0, self.heading[2] * CS_CRAWL_CM_S), False)
        self.frozen_since = 0.0
        out = safe is not None and math.hypot(self.pos[0] - self.center[0], self.pos[2] - self.center[1]) > safe
        inner = safe
        if CS_ZONE_FIRST and safe is not None:
            # zone d'abord (voir CS_ZONE_FIRST) : position du serveur ou la nôtre, la plus loin du centre
            far = max(math.hypot(self.pos[0] - self.center[0], self.pos[2] - self.center[1]),
                      math.hypot(self.server[0] - self.center[0], self.server[2] - self.center[1]))
            if out or zone_hurt or far > safe:
                self.zone_return = True
            elif self.zone_return and far <= safe - CS_ZONE_BACK_M:
                self.zone_return = False         # bien rentré : le reste peut reprendre
            out = out or self.zone_return
            inner = max(2.0, safe - CS_ZONE_INNER_M)
        if self.heal_blocked and self.center is not None:
            out = True                           # soin voulu près du bord : vers le centre d'abord (CS_HEAL_IN_M)
        refuge = None
        if zone_hurt:
            # dégâts de zone (voir CS_CHASE) : hors zone, quoi qu'en dise l'estimation ; toujours touché après
            # CS_ZONE_LOST_S, ou centre inconnu : vers les joueurs qui n'en reçoivent pas
            if self.center is None or now - self.zone_hurt_since >= CS_ZONE_LOST_S or (
                    self.zone_moving and self._true_zone(now) is None):
                refuge = self._zone_refuge(now)
            out = refuge is not None or self.center is not None
        # touché par la zone (~3,5 s à vivre à 50-65 PV/s) : ni trace d'un coéquipier, ni détour, ni longer un obstacle
        # (jusqu'à CS_SLIDE_MAX_S) — course vers le centre par le chemin calculé (_toward évite les cases bloquées)
        escape = None if knocked or zone_hurt else self._escaping(now, still)
        # adversaire à suivre, sauf bien plus bas que le bot (sous un rebord, dans l'eau : essai du 29/10 13:43, deux bots
        # tombés dans l'eau du barrage en suivant un adversaire — « มีบอทเดินตกน้ำ »)
        chase = target if target is None or target[2] >= self.pos[1] - CS_DROP_M else None
        if escape is not None:
            # coincé sans dégâts (voir CS_CHASE) : sur la trace d'un coéquipier, avant tout le reste
            self.doing, self.heading, speed = "escape", escape, CS_RUN_CM_S
        # hors de la zone sûre : ni détour ni longer un obstacle non plus (essai du 29/10 13:27 : bot sorti de 31 à 51 m
        # du centre en 5 s en longeant un obstacle, la zone à 48 m — « บอทมันเดินออกวง »)
        elif now < self.detour_until and not zone_hurt and not out:
            self.doing, speed = "detour", CS_RUN_CM_S
        elif now < self.slide_until and not zone_hurt and not out:
            self.doing, speed = "slide", CS_RUN_CM_S
            self.heading = self._free(self.slide_dir, now)
        elif out:
            # hors de la zone sûre (elle se resserre) : course vers son centre, avant toute autre chose
            if self.doing != "zone":
                self.zone_runs += 1
            self.doing, speed = "zone", CS_RUN_CM_S
            goal = refuge or self.center
            self.heading = self._toward(goal[0], goal[1], now)
            self._lane_leave("zone", over=False)     # (voie reprise une fois dans la zone)
        elif CS_LANE and (lane := self._laning(now, chase)) is not None:
            # voie choisie au cercle rouge (voir CS_LANE) : couloirs séparés, avant la poursuite d'un adversaire loin
            self.doing, self.heading, speed = "lane", lane, CS_RUN_CM_S
            self.running = True
        elif leader is not None and chase is None:
            # groupe (CS_PACK) : pas d'adversaire en vue, on reste collé au chef (ramené dans la zone)
            px, pz = self._inside(leader[1], leader[2], inner) if safe is not None else (leader[1], leader[2])
            pd = math.hypot(px - self.pos[0], pz - self.pos[2])
            if pd > CS_PACK_M:
                if self.doing != "pack":
                    self.packs += 1
                self.doing, speed = "pack", CS_RUN_CM_S
                self.heading = self._toward(px, pz, now)
                self.running = True
            else:
                # à côté du chef : petit tour autour de lui (sens changé de temps en temps)
                self.doing = "pack_orbit"
                if now >= self.turn_at:
                    self.orbit_sign = -self.orbit_sign
                    self.turn_at = now + random.uniform(*CS_ORBIT_FLIP_S)
                to = _flat_dir(px - self.pos[0], pz - self.pos[2])
                back = (pd - CS_PACK_ORBIT_M) / CS_PACK_ORBIT_M
                self.heading = self._free(_flat_dir(-to[2] * self.orbit_sign + to[0] * back,
                                                    to[0] * self.orbit_sign + to[2] * back), now)
        elif chase is not None:
            d, tx, ty, tz = chase
            if safe is not None:
                # cible hors de la zone : suivie seulement jusqu'au bord (CS_ZONE_INNER_M à l'intérieur)
                tx, tz = self._inside(tx, tz, inner)
                d = math.hypot(tx - self.pos[0], tz - self.pos[2])
            to = _flat_dir(tx - self.pos[0], tz - self.pos[2])
            if d > CS_RESUME_M:
                self.near = False
            if not self.near and d > CS_STOP_M:
                # par le réseau des trajets jusqu'à son point le plus proche de la cible, puis droit dessus (CS_NET_CHASE)
                fr = self._foe_route(self.target_idx, tx, tz, inner, now) if CS_FOE_TRACE else None
                net = None if fr else self._net_toward(tx, tz, now, safe)
                lead = None if fr or net else self._leading(now, tx, tz)   # trace d'un coéquipier (CS_CHASE)
                self.doing, self.heading, speed = ("foe_route", fr, CS_RUN_CM_S) if fr else \
                    ("net", net, CS_RUN_CM_S) if net else \
                    ("lead", lead, CS_RUN_CM_S) if lead else ("chase", self._toward(tx, tz, now), CS_RUN_CM_S)
                self.running = True
                if not was_running:
                    self.runs += 1
                if d - CS_RUN_CM_S / 100 * dt <= CS_STOP_M:
                    self.near = True
                    self.arrived += 1
            else:
                # au contact : on tourne autour de la cible (sens changé de temps en temps) à ~CS_ORBIT_M
                self.doing = "orbit"
                if now >= self.turn_at:
                    self.orbit_sign = -self.orbit_sign
                    self.turn_at = now + random.uniform(*CS_ORBIT_FLIP_S)
                back = (d - CS_ORBIT_M) / CS_ORBIT_M
                self.heading = self._free(_flat_dir(-to[2] * self.orbit_sign + to[0] * back,
                                                    to[0] * self.orbit_sign + to[2] * back), now)
                if CS_ORBIT_RUN:
                    speed = CS_RUN_CM_S                  # en course, comme pour y venir (voir CS_ORBIT_RUN)
        elif self.last_enemy is not None and math.hypot(self.last_enemy[0] - self.pos[0],
                                                        self.last_enemy[2] - self.pos[2]) > CS_ORBIT_M:
            # adversaire perdu de vue : on va là où on l'a vu en dernier (sans sortir de la zone)
            self.doing = "search"
            lx, lz = self._inside(self.last_enemy[0], self.last_enemy[2], inner) if safe is not None \
                else (self.last_enemy[0], self.last_enemy[2])
            if math.hypot(lx - self.pos[0], lz - self.pos[2]) <= CS_ORBIT_M:
                self.last_enemy = None
            fr = self._foe_route(self.last_enemy_idx, lx, lz, inner, now) if CS_FOE_TRACE else None
            net = None if fr else self._net_toward(lx, lz, now, safe)
            lead = None if fr or net else self._leading(now, lx, lz)
            if fr:
                self.doing, self.heading, speed = "foe_route", fr, CS_RUN_CM_S   # sur la route de l'adversaire
            elif net:
                self.doing, self.heading = "net", net    # par le réseau des trajets (CS_NET_CHASE)
            elif lead:
                self.doing, self.heading = "lead", lead
            else:
                self.heading = self._toward(lx, lz, now)
        elif safe is None and (mate := self._mate(now)) is not None and mate[0] > CS_FOLLOW_M:
            # zone encore inconnue : on suit le coéquipier le plus proche (un joueur réel reste dans la zone)
            self.doing = "follow"
            self.heading = self._toward(mate[1], mate[2], now)
        elif CS_STRAIGHT and (goal := self._straight_goal(inner)) is not None:
            # personne en vue en début de manche : tout droit vers la base d'en face (voir CS_STRAIGHT)
            self.doing, speed = "straight", CS_RUN_CM_S
            self.heading = self._toward(goal[0], goal[1], now)
            self.running = True
            self.last_enemy = None
        elif (route := self._routing(now, safe)) is not None:
            # personne en vue : vers le centre de la zone, puis patrouille dans la zone, par le réseau (CS_ROUTE)
            self.doing = "route" if self.patrol is not None and self.patrol["center"] else "patrol"
            self.heading, speed = route, CS_RUN_CM_S
            self.last_enemy = None
        else:
            # personne en vue : marche au hasard en virage continu (CS_CURVE_DEG_S, retiré toutes les quelques
            # secondes) ; dans la moitié extérieure de la zone, vers son centre (à ±45° près, sans virage) ; zone
            # inconnue : pas plus loin que CS_HOME_M de la base
            self.doing = "wander"
            self.last_enemy = None
            home = safe is None and self.spawn is not None and math.hypot(
                self.pos[0] - self.spawn[0], self.pos[2] - self.spawn[1]) > CS_HOME_M
            if home:
                self.heading = self._toward(self.spawn[0], self.spawn[1], now)
            else:
                if now >= self.turn_at:
                    if safe is not None and math.hypot(self.pos[0] - self.center[0],
                                                       self.pos[2] - self.center[1]) > safe / 2:
                        self.heading = _turn(_flat_dir(self.center[0] - self.pos[0], self.center[1] - self.pos[2]),
                                             random.uniform(-45.0, 45.0))
                        self.curve = 0.0
                    else:
                        self.curve = random.choice((-1.0, 1.0)) * random.uniform(*CS_CURVE_DEG_S)
                    self.turn_at = now + random.uniform(*CS_CURVE_EVERY_S)
                self.heading = _turn(self.heading, self.curve * dt)
            self.heading = self._free(self.heading, now)
        if self.doing != "lead":
            self.lead = None                     # autre chose qu'en route sur une trace : elle sera recherchée à nouveau
        loop = (CS_LOOP_WALK and (self.doing in ("chase", "search", "follow") or self.doing == "lead"
                                  and self._lead_straight()) and now - self.stuck_at > CS_SLIDE_AGAIN_S
                and (target is None or target[0] > CS_LOOP_NEAR_M) and not self._near_blocked(now))
        if loop:
            # marche en boucles vers la cible (voir CS_CHASE) : avance + rotation, vitesse résultante
            a = 2 * math.pi * now / CS_LOOP_PERIOD_S
            f, s = self.heading, (-self.heading[2], 0.0, self.heading[0])
            vx = f[0] * CS_LOOP_FWD_CM_S + (f[0] * math.cos(a) + s[0] * math.sin(a)) * CS_LOOP_SPIN_CM_S
            vz = f[2] * CS_LOOP_FWD_CM_S + (f[2] * math.cos(a) + s[2] * math.sin(a)) * CS_LOOP_SPIN_CM_S
            speed = max(20.0, math.hypot(vx, vz))
            self.heading = _flat_dir(vx, vz)
            self.running = False
        if self.doing in ("chase", "search", "follow") and now - self.stuck_at > CS_SLIDE_AGAIN_S \
                and (target is None or target[0] > CS_RESUME_M) and not self._near_blocked(now):
            # vers une cible : léger louvoiement (voir CS_CHASE), pas juste après un obstacle, ni le long d'un
            # obstacle connu (mur simulé de 50 m : 4 passages sur 10 au lieu de 10, le louvoiement y ramenait), ni au
            # contact
            self.heading = _turn(self.heading, CS_WEAVE_DEG * math.sin(2 * math.pi * now / self.weave_period))
        # toujours face à la marche (demande du 27/10 : « เดินหน้าเท่านั้น ไม่ใช่เดินถอยหลัง ») : regard = direction suivie,
        # plus vers la cible pendant qu'on va ailleurs (zone, détour, longer un obstacle, orbite, trace) — le bot y
        # reculait ou marchait en crabe
        self.aim = self.heading
        if now >= self.speed_at:
            self.speed_k = random.uniform(1 - CS_SPEED_JITTER, 1 + CS_SPEED_JITTER)
            self.speed_at = now + random.uniform(*CS_SPEED_EVERY_S)
        run = speed >= CS_RUN_CM_S               # allure du 2001 : celle du mode, pas de la vitesse ±CS_SPEED_JITTER
        if run:
            # course : le point suivant à CS_RUN_STEP_M devant à chaque 2001 (demande du 27/10 : « ส่งไปข้างหน้า
            # 0.45 ม. »), sans ±CS_SPEED_JITTER ; jamais plus vite que CS_RUN_MAX_CM_S si un 2001 part en avance
            speed = CS_RUN_CM_S
            move = min(CS_RUN_STEP_M, CS_RUN_MAX_CM_S / 100 * dt)
        else:
            # marche (autour de la cible, recherche, au hasard) : comme avant
            speed *= self.speed_k
            move = speed / 100 * dt
        nx, nz = self.pos[0] + self.heading[0] * move, self.pos[2] + self.heading[2] * move
        if (now - self.server_moved[1] >= CS_LEASH_STILL_S
                and math.hypot(nx - self.server[0], nz - self.server[2]) > CS_LEASH_M):
            move = 0.0                           # laisse : le serveur ne suit plus, on ne s'enfonce pas (CS_LEASH_M)
        else:
            self.pos[0], self.pos[2] = nx, nz
        # hauteur : celle du serveur (il calcule le sol lui-même ; une hauteur fausse = 144, voir CS_CHASE) ; sans
        # position récente du serveur : sol relevé tout près, sinon plus loin, sinon celle du joueur vu le plus proche
        # (au sol : il marche) ; jamais de droite vers la cible (bots montés sur un mur, essai du 25/10 20:00)
        if now - self.server_at <= CS_SERVER_FRESH_S:
            self.pos[1] = self.server[1]
        else:
            y = self.ground_y(self.pos[0], self.pos[2]) or self.ground_y(self.pos[0], self.pos[2], CS_GROUND_FAR_M)
            if y is None:
                seen = [(math.hypot(px - self.pos[0], pz - self.pos[2]), py)
                        for idx, (st, px, py, pz) in self.players.items() if idx != self.idx and now - st <= CS_SEEN_S]
                y = min(seen)[1] if seen else None
            if y is not None:
                self.pos[1] += max(-move, min(move, y - self.pos[1]))
        self.ran_m += move
        self.moving = True
        self.trail.append((now, self.pos[0], self.pos[1], self.pos[2]))
        return ((self.pos[0], self.pos[1], self.pos[2]),
                (self.heading[0] * speed, 0.0, self.heading[2] * speed), run)

    def _routing(self, now: float, safe: Optional[float]) -> Optional[Tuple[float, float, float]]:
        """Direction à suivre sur le réseau des trajets relevés (CS_NET) vers le but en cours de la patrouille (voir
        CS_ROUTE), but suivant pris une fois celui-ci atteint, trop long, sans progrès, corrigé CS_ROUTE_SNAPS fois ou
        injoignable ; None sans point du réseau joignable dans la zone (ou zone inconnue)."""
        if not CS_ROUTE or not _cs_net_pts or safe is None or self.center is None:
            return None
        e = self.patrol
        if e is not None:
            gx, gz = _cs_net_pts[e["goal"]][0], _cs_net_pts[e["goal"]][2]
            d = math.hypot(gx - self.pos[0], gz - self.pos[2])
            # progrès : reste à parcourir sur le réseau (un chemin qui s'éloigne d'abord du but en progresse quand même)
            left = self.net["left"] if self.net is not None and self.net["goal"] == e["goal"] else d
            if left <= e["best"] - 1.0:
                e["best"], e["best_at"] = left, now
            why = ("reached" if d <= CS_PATROL_REACH_M else
                   "time" if now - e["at"] >= CS_PATROL_GOAL_S else
                   "stall" if now - e["best_at"] >= CS_PATROL_STALL_S else
                   "snaps" if self.snaps_total - e["snaps"] >= CS_ROUTE_SNAPS else
                   "zone" if math.hypot(gx - self.center[0], gz - self.center[1]) > safe else None)
            if why is not None:
                self.routes_done += why == "reached"
                if e["center"]:
                    self.patrol_centered = True          # centre atteint (ou laissé) : patrouille ensuite
                diag.event("MATCH", "cs_route_left", level="debug", why=why, center=e["center"],
                           goal=[round(gx, 1), round(gz, 1)])
                e = self.patrol = None
        for _ in range(3):
            if e is None:
                goal, center = self._patrol_goal(safe)
                if goal is None:
                    return None
                gx, gz = _cs_net_pts[goal][0], _cs_net_pts[goal][2]
                e = self.patrol = {"goal": goal, "at": now, "snaps": self.snaps_total, "center": center,
                                   "best": float("inf"), "best_at": now}
                self.patrol_seen.append((gx, gz))
                self.routes += 1
                diag.event("MATCH", "cs_route", level="debug", center=center, goal=[round(gx, 1), round(gz, 1)],
                           from_m=round(math.hypot(gx - self.pos[0], gz - self.pos[2]), 1))
            d = self._net_follow(now, e["goal"], safe)
            if d is not None:
                return d
            self.patrol_bad.add(e["goal"])       # injoignable par le réseau (dans la zone) : un autre but
            e = self.patrol = None
        return None

    def _net_toward(self, gx: float, gz: float, now: float, safe: Optional[float]) -> Optional[Tuple[float, float, float]]:
        """Direction vers (gx, gz) par le réseau des trajets (CS_NET_CHASE) : jusqu'à son point le plus proche (à
        CS_NET_GOAL_M près, dans la zone, joignable, plus près de (gx, gz) que le bot), choisi de nouveau toutes les
        CS_NET_GOAL_EVERY_S ; None (suite en ligne droite) à CS_NET_DIRECT_M de (gx, gz), à ce point, ou sans lui."""
        here = math.hypot(gx - self.pos[0], gz - self.pos[2])
        if not CS_ROUTE or not _cs_net_pts or here <= CS_NET_DIRECT_M:
            return None
        P = _cs_net_pts
        e = self.net_goal
        if e is None or now - e[3] >= CS_NET_GOAL_EVERY_S:
            comps = {_cs_net_comp[i] for i in self._net_entries()}
            cands = [(math.hypot(P[i][0] - gx, P[i][2] - gz), i) for i in _cs_net_near(gx, gz, CS_NET_GOAL_M)
                     if _cs_net_comp[i] in comps and (safe is None or self.center is None or math.hypot(
                         P[i][0] - self.center[0], P[i][2] - self.center[1]) <= safe)]
            best = min(cands, default=None)
            e = self.net_goal = (best[1] if best and best[0] < here - 3.0 else None, gx, gz, now)
        goal = e[0]
        if goal is None or math.hypot(P[goal][0] - self.pos[0], P[goal][2] - self.pos[2]) <= CS_NET_REACH_M:
            return None
        return self._net_follow(now, goal, safe)

    def _patrol_goal(self, safe: float) -> Tuple[Optional[int], bool]:
        """But suivant de la patrouille (voir CS_ROUTE) : (point du réseau, centre ?) — d'abord le point le plus proche
        du centre de la zone, puis un point de la zone à CS_PATROL_MIN_M au moins du bot, le plus éloigné de sa base et
        des buts déjà visités (parmi CS_PATROL_PICK tirés) ; seulement des points du morceau du réseau où le bot peut
        entrer ; (None, False) sans eux."""
        P = _cs_net_pts
        cx, cz = self.center
        x, z = self.pos[0], self.pos[2]
        comps = {_cs_net_comp[i] for i in self._net_entries()}
        inside = [i for i in _cs_net_near(cx, cz, safe) if _cs_net_comp[i] in comps and i not in self.patrol_bad]
        if not inside:
            return None, False
        if not self.patrol_centered and math.hypot(cx - x, cz - z) > CS_PATROL_REACH_M:
            return min(inside, key=lambda i: math.hypot(P[i][0] - cx, P[i][2] - cz)), True
        # bien dans la zone (elle se resserre pendant qu'on y va : but laissé « zone » sinon)
        inside = [i for i in inside if math.hypot(P[i][0] - cx, P[i][2] - cz) <= CS_PATROL_IN * safe] or inside
        far = [i for i in inside if math.hypot(P[i][0] - x, P[i][2] - z) >= CS_PATROL_MIN_M]
        pick = random.sample(far or inside, min(CS_PATROL_PICK, len(far or inside)))
        seen = self.patrol_seen + ([self.spawn] if self.spawn else []) + [(x, z)]
        return max(pick, key=lambda i: min(math.hypot(P[i][0] - p[0], P[i][2] - p[1]) for p in seen)), False

    def _net_entries(self) -> List[int]:
        """Points du réseau (CS_NET) à moins de CS_NET_ENTRY_M du bot (entrées possibles quand il n'y est pas)."""
        return _cs_net_near(self.pos[0], self.pos[2], CS_NET_ENTRY_M)

    def _net_path(self, goal: int, safe: Optional[float], start: Optional[int] = None) -> Optional[List[int]]:
        """Points du réseau (CS_NET) jusqu'au point `goal` par le plus court chemin (A* sur le graphe) : depuis `start`
        (le bot y marche déjà : pas de saut vers un autre trajet, peut-être derrière un mur), sinon depuis une entrée
        (_net_entries, comptée CS_NET_OFF_COST fois sa distance au bot) ; None si `goal` n'est pas joignable sans
        passer hors de la zone sûre (+ CS_NET_ZONE_M) ni par un passage retiré."""
        P, adj = _cs_net_pts, _cs_net_adj
        gx, gz = P[goal][0], P[goal][2]
        x, z = self.pos[0], self.pos[2]
        lim = None
        if safe is not None and self.center is not None:
            # bot encore hors de ce rayon (base, zone qui se resserre) : points pas plus loin du centre que lui
            lim = max(safe + CS_NET_ZONE_M, math.hypot(x - self.center[0], z - self.center[1]))
        h = lambda i: math.hypot(P[i][0] - gx, P[i][2] - gz)
        cost: Dict[int, float] = {}
        came: Dict[int, int] = {}
        heap: List[Tuple[float, float, int]] = []
        for i in ([start] if start is not None else self._net_entries()):
            cost[i] = 0.0 if start is not None else CS_NET_OFF_COST * math.hypot(P[i][0] - x, P[i][2] - z)
            heapq.heappush(heap, (cost[i] + h(i), cost[i], i))
        pops = 0
        while heap and pops < CS_NET_MAX_POPS:
            _, g, i = heapq.heappop(heap)
            if i == goal:
                path = [i]
                while path[-1] in came:
                    path.append(came[path[-1]])
                return path[::-1]
            if g > cost.get(i, 1e18):
                continue
            pops += 1
            for j, d in adj[i]:
                if (i, j) in self.net_bad or lim is not None and j != goal and math.hypot(
                        P[j][0] - self.center[0], P[j][2] - self.center[1]) > lim:
                    continue
                ng = g + d
                if ng < cost.get(j, 1e18):
                    cost[j], came[j] = ng, i
                    heapq.heappush(heap, (ng + h(j), ng, j))
        return None

    def _net_follow(self, now: float, goal: int, safe: Optional[float]) -> Optional[Tuple[float, float, float]]:
        """Direction du chemin par le réseau (CS_NET) vers le point `goal`, recalculé toutes les CS_NET_REPLAN_S ;
        hors du réseau, rejoint par l'A* des cases ; None si `goal` n'est pas joignable."""
        P = _cs_net_pts
        x, z = self.pos[0], self.pos[2]
        dist = lambda i: math.hypot(P[i][0] - x, P[i][2] - z)
        n = self.net
        if n is not None and self.snaps_total != n["snaps"]:
            # corrigé par le serveur en marchant sur le réseau : ce passage retiré pour la partie (croisement à travers
            # un mur, CS_NET_LINK_M)
            if n["on"] and 0 < n["k"] < len(n["path"]):
                a, b = n["path"][n["k"] - 1], n["path"][n["k"]]
                self.net_bad.update(((a, b), (b, a)))
                self.net_cuts += 1
            n = None
        if n is None or n["goal"] != goal or now - n["at"] >= CS_NET_REPLAN_S:
            # sur le réseau : suite du chemin depuis le point visé, le segment en cours gardé devant (pas de saut)
            keep = n["path"][n["k"] - 1:n["k"] + 1] if n is not None and n["on"] and n["k"] >= 1 else None
            path = self._net_path(goal, safe, keep[-1]) if keep else None
            if path is None:
                keep, path = None, self._net_path(goal, safe)   # (hors du réseau, zone resserrée sur le chemin…)
            if path is None:
                self.net = None
                return None
            path = ([keep[0]] if keep else []) + self._net_smooth(path, now)
            cum = [0.0]
            for a, b in zip(path, path[1:]):
                cum.append(cum[-1] + math.hypot(P[b][0] - P[a][0], P[b][2] - P[a][2]))
            n = self.net = {"goal": goal, "path": path, "cum": cum, "k": 1 if keep else 0, "at": now,
                            "snaps": self.snaps_total, "on": False}
        path, k = n["path"], n["k"]
        while k < len(path) - 1 and (dist(path[k]) <= CS_NET_REACH_M or dist(path[k + 1]) < dist(path[k])):
            k += 1
        n["k"] = j = k
        n["left"] = n["cum"][-1] - n["cum"][k] + dist(path[k])   # reste à parcourir (progrès, voir _routing)
        while j < len(path) - 1 and dist(path[j]) < CS_NET_AHEAD_M:
            j += 1
        px, pz = P[path[j]][0], P[path[j]][2]
        if k >= 1:
            # sur le réseau : à moins de CS_NET_ON_M du segment en cours (raccourcis : jusqu'à CS_NET_CUT_M de long)
            a, b = P[path[k - 1]], P[path[k]]
            dx, dz = b[0] - a[0], b[2] - a[2]
            t = max(0.0, min(1.0, ((x - a[0]) * dx + (z - a[2]) * dz) / (dx * dx + dz * dz or 1.0)))
            n["on"] = math.hypot(x - a[0] - t * dx, z - a[2] - t * dz) <= CS_NET_ON_M
        else:
            n["on"] = dist(path[0]) <= CS_NET_ON_M
        return _flat_dir(px - x, pz - z) if n["on"] else self._toward(px, pz, now)

    def _net_clear(self, a: int, b: int, now: float) -> bool:
        """Ligne droite du point `a` au point `b` du réseau praticable (raccourci, voir CS_NET_CUT_M) ?"""
        if (a, b) in self.net_bad:
            return False
        P = _cs_net_pts
        (ax, ay, az), (bx, by, bz) = P[a], P[b]
        length = math.hypot(bx - ax, bz - az)
        if length > CS_NET_CUT_M or abs(by - ay) > CS_NET_LINK_DY_M:
            return False
        n, prev = int(length / 0.5) + 1, ay
        for s in range(n + 1):
            x, z = ax + (bx - ax) * s / n, az + (bz - az) * s / n
            c = (int(x // 1.0), int(z // 1.0))
            y = _cs_walk1.get(c)
            if y is None and c not in _cs_safe1:
                return False
            if any((c[0] + i, c[1] + j) in _cs_obst for i, j in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1))):
                return False
            if self.blocked.get(self._cell(x, z), 0.0) > now:
                return False
            if y is not None:
                if abs(y - prev) > CS_NET_CUT_DY_M:
                    return False
                prev = y
        return True

    def _net_smooth(self, path: List[int], now: float) -> List[int]:
        """Chemin du réseau tendu (voir CS_NET_CUT_M) : de chaque point, au point le plus loin joignable en ligne droite."""
        P = _cs_net_pts
        out, i = [path[0]], 0
        while i < len(path) - 1:
            j = i + 1
            ax, az = P[path[i]][0], P[path[i]][2]
            for m in range(len(path) - 1, i + 1, -1):
                if math.hypot(P[path[m]][0] - ax, P[path[m]][2] - az) <= CS_NET_CUT_M \
                        and self._net_clear(path[i], path[m], now):
                    j = m
                    break
            out.append(path[j])
            i = j
        return out

    def _lead_straight(self) -> bool:
        """La trace suivie (lead) est-elle droite devant le bot (virage < CS_LOOP_STRAIGHT_DEG sur ses points
        suivants) ? Sinon (coin, passage) : suivie au plus près, sans boucles (voir CS_LOOP_WALK)."""
        e = self.lead
        tr = self.traces.get(e["idx"]) if e else None
        if not tr:
            return False
        i, n = e["i"], CS_LOOP_STRAIGHT_PTS
        if i + 2 * n >= len(tr):
            return False
        a = math.atan2(tr[i + n][1] - tr[i][1], tr[i + n][0] - tr[i][0])
        b = math.atan2(tr[i + 2 * n][1] - tr[i + n][1], tr[i + 2 * n][0] - tr[i + n][0])
        return abs((math.degrees(b - a) + 180) % 360 - 180) < CS_LOOP_STRAIGHT_DEG

    def _near_blocked(self, now: float) -> bool:
        """Case évitée (le serveur nous y a arrêtés) à moins de CS_WEAVE_CLEAR cases du bot ?"""
        cx, cz = self._cell(self.pos[0], self.pos[2])
        n = CS_WEAVE_CLEAR
        return any(self.blocked.get((cx + i, cz + j), 0.0) > now for i in range(-n, n + 1) for j in range(-n, n + 1))

    def _nearest_point(self, tr: List[Tuple[float, float]]) -> Tuple[float, int]:
        """(distance, indice) du point de la trace `tr` le plus proche du bot."""
        return min((math.hypot(x - self.pos[0], z - self.pos[2]), k) for k, (x, z) in enumerate(tr))

    def _mate_trace(self) -> Optional[Tuple[int, int]]:
        """Trace d'un coéquipier passé à moins de CS_ESCAPE_NEAR_M du bot et allée au-delà de CS_ESCAPE_DONE_M :
        (n°, indice de son point le plus proche du bot) ; celle qui s'est le plus approchée du but (dernier adversaire
        vu, sinon centre de la zone : le coéquipier qui est sorti), sinon la plus proche ; None sans trace utilisable."""
        goal = (self.last_enemy[0], self.last_enemy[2]) if self.last_enemy else self.center
        here = math.hypot(goal[0] - self.pos[0], goal[1] - self.pos[2]) if goal else 0.0
        best = None
        for idx, tr in self.traces.items():
            if idx == self.idx or idx in self.escape_bad or self.enemy(idx) or len(tr) < 3:
                continue
            d, i = self._nearest_point(tr)
            if d > CS_ESCAPE_NEAR_M or all(math.hypot(x - self.pos[0], z - self.pos[2]) < CS_ESCAPE_DONE_M
                                           for x, z in tr[i:]):
                continue
            # avancée vers le but : distance la plus courte au but des points après celui-ci (plus petit = mieux)
            gain = min(math.hypot(goal[0] - x, goal[1] - z) for x, z in tr[i:]) - here if goal else 0.0
            key = (gain, d)
            if best is None or key < best[0]:
                best = (key, idx, i)
        return best[1:] if best else None

    def _leading(self, now: float, gx: float, gz: float) -> Optional[Tuple[float, float, float]]:
        """Vers le but (gx, gz) à plus de CS_LEAD_FAR_M : direction du prochain point de la trace d'un coéquipier qui y
        mène (passée à moins de CS_LEAD_NEAR_M, allée CS_LEAD_GAIN_M plus près du but), suivie jusqu'à son point le
        plus proche du but ; None sinon (voir CS_CHASE)."""
        here = math.hypot(gx - self.pos[0], gz - self.pos[2])
        if here <= CS_LEAD_FAR_M:
            self.lead = None
            return None
        e = self.lead
        if e is None:
            if now < self.lead_next:
                return None
            self.lead_next = now + CS_LEAD_EVERY_S
            best = None
            for idx, tr in self.traces.items():
                if idx == self.idx or idx in self.escape_bad or self.enemy(idx) or len(tr) < 4:
                    continue
                d, i = self._nearest_point(tr)
                if d > CS_LEAD_NEAR_M:
                    continue
                dj, j = min((math.hypot(gx - x, gz - z), k) for k, (x, z) in enumerate(tr[i:], i))
                if dj > here - CS_LEAD_GAIN_M or j - i < 4:
                    continue
                if best is None or (dj, d) < best[0]:
                    best = ((dj, d), idx, i, j)
            if best is None:
                return None
            e = self.lead = {"idx": best[1], "i": best[2], "end": best[3], "snaps": self.snaps_total,
                             "seen": self.snaps_total}
            self.leads += 1
            diag.event("MATCH", "cs_lead", level="debug", mate=best[1], points=best[3] - best[2])
        tr = self.traces.get(e["idx"]) or []
        if not tr or self.snaps_total - e["snaps"] >= CS_LEAD_SNAPS or e["end"] >= len(tr):
            if tr:
                self.escape_bad.add(e["idx"])     # trace qui ne passe pas pour nous : laissée pour la manche
            self.lead = None
            self.lead_next = now + CS_LEAD_PAUSE_S
            return None
        if self.snaps_total != e["seen"]:
            # corrigé en route (coin coupé) : reprise au point de la trace le plus proche, pas au suivant
            e["seen"], e["i"] = self.snaps_total, min(self._nearest_point(tr)[1], e["end"])
        while e["i"] < e["end"] and math.hypot(tr[e["i"]][0] - self.pos[0],
                                               tr[e["i"]][1] - self.pos[2]) <= CS_ESCAPE_REACH_M:
            e["i"] += 1
        if e["i"] >= e["end"] and math.hypot(tr[e["end"]][0] - self.pos[0],
                                             tr[e["end"]][1] - self.pos[2]) <= CS_ESCAPE_REACH_M:
            self.lead = None                      # au bout utile de la trace : course directe
            return None
        x, z = tr[e["i"]]
        return _flat_dir(x - self.pos[0], z - self.pos[2])

    def _escaping(self, now: float, still: float) -> Optional[Tuple[float, float, float]]:
        """Coincé sans dégâts (position du serveur figée depuis CS_ESCAPE_S en combat) : direction du prochain point de
        la trace d'un coéquipier, jusqu'à CS_ESCAPE_DONE_M du recoin (voir CS_CHASE) ; None sinon."""
        e = self.escape
        if e is None:
            if (still < CS_ESCAPE_S or now < self.escape_next or now - self.server_at > CS_SERVER_FRESH_S
                    or not self.released or now - self.released_at < CS_ESCAPE_S):
                return None
            found = self._mate_trace()
            if found is None:
                self.escape_next = now + CS_ESCAPE_PAUSE_S
                return None
            e = self.escape = {"idx": found[0], "i": found[1], "from": (self.server[0], self.server[2]),
                               "at": now, "snaps": self.snaps_total, "seen": self.snaps_total}
            self.escapes += 1
            self.slide_until = self.detour_until = 0.0
            diag.event("MATCH", "cs_escape", level="debug", mate=found[0], at=[round(v, 1) for v in e["from"]])
        tr = self.traces.get(e["idx"]) or []
        if tr and self.snaps_total != e["seen"]:
            # corrigé en route (coin coupé) : reprise au point de la trace le plus proche, pas au suivant
            e["seen"], e["i"] = self.snaps_total, self._nearest_point(tr)[1]
        while e["i"] < len(tr) - 1 and math.hypot(tr[e["i"]][0] - self.pos[0],
                                                  tr[e["i"]][1] - self.pos[2]) <= CS_ESCAPE_REACH_M:
            e["i"] += 1
        out = math.hypot(self.server[0] - e["from"][0], self.server[2] - e["from"][1]) >= CS_ESCAPE_DONE_M
        failed = (not tr or now - e["at"] > CS_ESCAPE_MAX_S
                  or self.snaps_total - e["snaps"] >= CS_ESCAPE_SNAPS)
        if out or failed:
            if failed and not out:
                self.escape_bad.add(e["idx"])
                self.escape_next = now + CS_ESCAPE_PAUSE_S
            self.escape = None
            self.stuck_at = 0.0
            return None
        x, z = tr[e["i"]]
        return _flat_dir(x - self.pos[0], z - self.pos[2])

    def summary(self) -> str:
        return (f"idx={self.idx} rounds={self.rounds} runs={self.runs} arrived={self.arrived} "
                f"snaps={self.snaps_total} detours={self.detours} zone_runs={self.zone_runs} ran_m={round(self.ran_m)} "
                f"lag_ms={self.lag_ms()} lag_skips={self.lag_skips} plans={self.plans} blocked={len(self.blocked)} "
                f"slides={self.slides} frozen={self.frozen_count} escapes={self.escapes} "
                f"force144={self.forces}/{self.forces_used} tp_ack146={self.tp_acks} leads={self.leads} "
                f"routes={self.routes}/{self.routes_done} net_pts={len(_cs_net_pts)} net_cuts={self.net_cuts} "
                f"deaths={self.deaths} dmg={self.dmg_dealt} hits={self.hits_dealt} team={self.team_for(self.idx) or 0} "
                f"zone_deaths={self.zone_deaths} zone_enemies={self.zone_src['enemies']} "
                f"zone_spot={self.zone_src['spot']} zone_guess={self.zone_src['guess']} "
                f"zone_true={self.zone_src['true']} zone_117={self.zone_true_n} packs={self.packs} "
                f"foe_routes={self.foe_routes} lanes={self.lanes}/{self.lanes_done} own={self.lanes_own} "
                f"lane_fails={self.lanes_failed} heals={self.heals}/{self.heals_ok} buys={self.buys}/{self.buys_ok}")

    def _stuck_s(self) -> float:
        """Immobilité de la position du serveur au-delà de laquelle le bot est arrêté (voir CS_STUCK_S)."""
        # tant que le retard n'est pas relevé (début de partie) : 0,5 s supposées, de quoi ne pas prendre un serveur
        # en retard pour un mur (relevé : ~0,1 s le plus souvent)
        lag = sorted(self.lags)[len(self.lags) // 2] if len(self.lags) >= 5 else 0.5
        return max(CS_STUCK_S, 1.5 * lag + 0.3)

    def lag_ms(self) -> Optional[int]:
        """Retard médian du serveur sur nos positions (ms), None sans relevé."""
        return round(sorted(self.lags)[len(self.lags) // 2] * 1000) if self.lags else None


def _read_any_content(data: bytes, match_key: bytes, session_key: Optional[bytes], lays) -> Optional[bytes]:
    """Contenu d'un paquet du serveur : en-tête avec la clé du match (ou de session), contenu avec la clé de session
    puis celle du match (bourrage OICQ vérifié : une mauvaise clé ne passe pas). None si illisible."""
    keys = [k for k in (session_key, match_key) if k]
    for hk in (match_key, session_key):
        if not hk:
            continue
        for h in udp_codec.headers(data, hk, lays) + _ext_headers(data, hk, lays):
            for ck in keys:
                c = udp_codec.content(data, h, ck)
                if c is not None:
                    return bytes(c)
    return None


def _ext_headers(data: bytes, key: bytes, lays) -> List[Dict[str, Any]]:
    """En-têtes étendus (flags & 4 : accusé de 3 octets joint entre l'en-tête et le contenu ; ~5 % des paquets du
    serveur, dont les 204 du soin — capture du 08/11). udp_codec.scan ne les lit pas : mêmes contrôles sur le paquet
    sans ses 3 derniers octets, puis contenu décalé de 3 (comme tools/ffcapture.ext_headers)."""
    if len(data) < 11:
        return []
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    out = []
    for layout in lays:
        h = udp_codec.read_header(data[:-3], layout, k, v80)
        if h is not None and h.get("flags", 0) & 4:
            h["headerLen"] += 3
            out.append(h)
    return out


def _ext_cmd(data: bytes, match_key: bytes, session_key: Optional[bytes], lays) -> Optional[int]:
    """Commande d'un paquet à en-tête étendu (voir _ext_headers), sinon None."""
    for hk in (match_key, session_key):
        if hk:
            hs = _ext_headers(data, hk, lays)
            if hs:
                return hs[0]["cmd"]
    return None


def _flat_dir(dx: float, dz: float) -> Tuple[float, float, float]:
    """Regard horizontal unitaire vers (dx, dz)."""
    n = math.hypot(dx, dz) or 1.0
    return (dx / n, 0.0, dz / n)


def _turn(d: Tuple[float, float, float], deg: float) -> Tuple[float, float, float]:
    """Direction horizontale `d` tournée de `deg` degrés."""
    a = math.radians(deg)
    c, sn = math.cos(a), math.sin(a)
    return _flat_dir(d[0] * c - d[2] * sn, d[0] * sn + d[2] * c)


async def cs_state_loop(sock, addr, key_bytes: bytes, lays, stop_event: asyncio.Event, t0: float, chase: _CsChase,
                        on_tx=None, acker=None):
    """2001 du joueur local toutes les STATE_SYNC_EVERY_S jusqu'à `stop_event`, d'après `chase` (voir CS_CHASE)."""
    loop = asyncio.get_event_loop()
    while not stop_event.is_set():
        now = time.time()
        st = chase.step(now)
        if st is not None:
            pos, vel, running = st
            ms = int((now - t0) * 1000) + CS_TIME_OFFSET_MS
            if chase.tp_ack_due:
                # 146 : confirme le 144 / 145 qui nous a déplacés (voir CS_TP_ACK), avant le 2001 comme le client
                kind, chase.tp_ack_due = chase.tp_ack_due, 0
                if CS_TP_ACK:
                    pkt = udp_codec.build_packet(random.randint(0x64, 0x6D), lays[1], 0, RUDP_TELEPORT_ACK, None, 0,
                                                 _varint(chase.ident()) + _varint(ms) + _varint(kind), key_bytes,
                                                 CRC7_TABLE, encrypted=False)
                    if on_tx is not None:
                        on_tx(pkt)
                    try:
                        await loop.sock_sendto(sock, pkt, addr)
                        chase.tp_acks += 1
                    except Exception:
                        _udp_stats.send_errors += 1
            content = cs_state_content(chase.ident(), pos, chase.aim, vel, ms, running,
                                       frame_ms=random.randint(14, 19))
            pkt = udp_codec.build_packet(random.randint(0x64, 0x6D), lays[1], 0, UDP_PLAYER_STATE_SYNC, None, 0,
                                         content, key_bytes, CRC7_TABLE, encrypted=False,
                                         ext=acker.take() if acker is not None else None)
            if on_tx is not None:
                on_tx(pkt)
            try:
                await loop.sock_sendto(sock, pkt, addr)
            except Exception:
                _udp_stats.send_errors += 1
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=STATE_SYNC_EVERY_S)
        except asyncio.TimeoutError:
            pass
UDP_BYEBYE = 4
# Fin de partie : UDP_BYEBYE (le serveur ferme la session) termine la partie aussitôt (avant : 60 s de silence en
# plus). RUDP_MATCH_END (lu dans l'en-tête : son contenu ne se déchiffre pas avec la clé du match) : si le BYEBYE
# n'arrive pas dans les MATCH_END_GRACE_S suivantes, la partie est terminée quand même.
MATCH_END_GRACE_S = 30.0
# Un BYEBYE n'est retenu que si le serveur se tait ensuite pendant BYE_CONFIRM_S : un vrai BYEBYE est toujours le
# dernier paquet. Les paquets à en-tête étendu du serveur (flags & 4, ACK joint de 3 octets, que udp_codec ne lit pas)
# passent parfois pour un BYEBYE dans l'autre disposition d'en-tête : relevé des 17-18/10, 117 « SERVER_BYE » sur 120
# à 0,307 s de la connexion, 0 Ko reçu, tous des jonctions en 4 morceaux — la partie continuait côté serveur.
BYE_CONFIRM_S = 1.0
# Capture brute des paquets (logs/capture) des UDP_CAPTURE premières parties BR de chaque processus, pour analyser
# le protocole : 6000 premiers paquets écrits au fil de l'eau, puis les 3000 derniers à la fin. 0 = aucune capture.
try:
    UDP_CAPTURE = max(0, int(os.environ.get("UDP_CAPTURE", "1")))
except ValueError:
    UDP_CAPTURE = 0

# 🔥 Cache invalidation thresholds
MAX_CONSECUTIVE_PARSE_FAILURES = 5.0     
NON_MATCH_RECONNECT_DELAY = 1.0


# ==================== FICHIERS JSON À ÉCRITURE DIFFÉRÉE ====================
class _DeferredSave:
    """Écriture différée d'un fichier JSON : au plus une toutes les `delay` s, sérialisée et écrite dans un thread.
    Avant : le fichier entier était réécrit sur la boucle asyncio à CHAQUE login / invalidation (token_cache.json :
    35 ms à 1 455 sessions, soit ~17 s de boucle bloquée quand 500 comptes se reconnectent ensemble)."""

    def __init__(self, path: str, delay: float, snapshot, dump_kwargs: Dict[str, Any], what: str):
        self.path = path
        self.delay = delay
        self.snapshot = snapshot          # () -> objet à écrire, copie prise sur la boucle (pas dans le thread)
        self.dump_kwargs = dump_kwargs
        self.what = what
        self.dirty = False
        self.saving = False
        self.mtime: Optional[float] = None    # date du fichier après notre dernière lecture / écriture
        self._task: Optional[asyncio.Task] = None
        self._io = threading.Lock()

    def mark(self):
        self.dirty = True
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            self.flush()                  # hors boucle asyncio (script, test) : écriture immédiate
            return
        if self._task is None or self._task.done():
            self._task = loop.create_task(self._run(), name=f"save:{self.what}")

    async def _run(self):
        while self.dirty:
            await asyncio.sleep(self.delay)
            data = self.snapshot()
            self.dirty = False
            self.saving = True
            t0 = time.perf_counter()
            try:
                self.mtime = await asyncio.to_thread(self._write, data)
                diag.event("CACHE", "saved", level="debug", file=self.what, entries=len(data),
                           dur_ms=(time.perf_counter() - t0) * 1000)
            except Exception as e:
                self.dirty = True         # nouvel essai au prochain tour (fichier verrouillé par un antivirus…)
                diag.event("CACHE", "save_failed", level="warning", code="CACHE_SAVE", exc=e, file=self.what)
                await asyncio.sleep(self.delay)
            finally:
                self.saving = False

    def _write(self, data) -> float:
        with self._io:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, **self.dump_kwargs)
            os.replace(tmp, self.path)
            return os.path.getmtime(self.path)

    def flush(self):
        """Écrit tout de suite ce qui reste à écrire (arrêt du serveur)."""
        if not self.dirty:
            return
        data = self.snapshot()
        self.dirty = False
        try:
            self.mtime = self._write(data)
        except Exception as e:
            self.dirty = True
            diag.event("CACHE", "save_failed", level="warning", code="CACHE_SAVE", exc=e, file=self.what)


# ==================== ULTRA SAFE PERSISTENT DEVICE RANDOMIZER ====================
# devices.json lu une seule fois puis gardé en mémoire (avant : relu à chaque login complet, 5 ms, et réécrit en
# entier pour chaque nouveau compte, 17 ms, sur la boucle asyncio).
_devices: Optional[Dict[str, Any]] = None


def _load_devices() -> Dict[str, Any]:
    global _devices
    if _devices is None:
        _devices = {}
        if os.path.exists(DEVICES_FILE):
            try:
                with open(DEVICES_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    _devices = data
            except Exception as e:
                diag.event("CACHE", "devices_unreadable", level="warning", code="CACHE_CORRUPT", exc=e)
    return _devices


_devices_saver = _DeferredSave(DEVICES_FILE, 5.0, lambda: dict(_load_devices()), {"indent": 4}, "devices.json")


# ==================== RÉCOMPENSES D'ACTIVITÉ (GetActivityRewards) ====================
# Récompenses d'événement réclamées pour chaque compte peu après son login, comme le bouton « รับ » du jeu.
# Le login du bot (MajorLogin + GetLoginData + connexion chat) est celui du jeu : une condition « ล็อกอิน » est
# remplie, il ne manquait que la demande de la récompense, que le bot n'envoyait jamais.
# ACTIVITY_REWARDS (.env) = "activité:récompense,…", vide = aucune. 5962201:1 = « ล็อกอิน 1/1 วัน » (objet
# 1102000002 pendant 30 jours, carte d'EXP : relevé du 15/10, fichier « ss »).
# Résultats dans data/activity_rewards.json : une récompense obtenue n'est plus jamais demandée ; un refus
# (condition pas encore remplie, déjà prise…) est redemandé après ACTIVITY_REWARD_RETRY_S.
def _parse_activity_rewards(spec: str) -> List[Tuple[int, int]]:
    out = []
    for part in (spec or "").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        act, _, rew = part.partition(":")
        try:
            out.append((int(act), int(rew or 1)))
        except ValueError:
            print_warning(f"ACTIVITY_REWARDS : « {part} » ignoré (attendu activité:récompense)")
    return out


ACTIVITY_REWARDS = _parse_activity_rewards(os.environ.get("ACTIVITY_REWARDS", "5962201:1"))
ACTIVITY_REWARDS_FILE = os.environ.get("ACTIVITY_REWARDS_FILE") or os.path.join(_ROOT_DIR, "data",
                                                                                 "activity_rewards.json")
# Suite du vrai client (relevé decoded_traffic.jsonl, 18/10 23:32, compte neuf 18760684721 réclamé du premier coup) :
# GetLoginData -> 0,2 s -> requêtes du lobby (LoginGetDesc, LoginGetSplash, LoginGetAccountInfo…) -> ActivityTrigger 34
# ~10 s après le login -> GetActivityRewards 10 s plus tard. Le même soir, le bot essuyait un refus sur 18760684669,
# compte du même lot créé à la même seconde : 3 réussites sur 776 comptes au 18/10.
# Essais en direct du 18/10 sur 18760726460 (compte jamais réclamé) : même avec toute cette suite, et même avec les
# corps RÉELS de MajorLogin/GetLoginData du client, la condition « ล็อกอิน 1/1 วัน » n'est jamais comptée (5962201
# absente de LoginGetSplash à chaque étape) et GetBackpack is_login répond « SignError1 ». Le serveur ne compte que le
# login signé du vrai client : champ 94 du MajorLogin (bloc chiffré de 84 octets, 2aab074f…, nouveau à chaque login et
# lié au compte ; rejoué sur un autre compte ou une autre heure -> SignError1). Un compte connecté une fois par le jeu
# passe à FINISHED (comptes 9240504956, 15564235887 du relevé) et le bot le réclame alors du premier coup (les
# 3 réussites). Le bot lit donc l'état (LoginGetSplash, 7 Ko) avant de réclamer : AWARDED = déjà pris, plus redemandé ;
# refus sans condition comptée = message « ล็อกอินในเกมจริง 1 ครั้ง ».
ACTIVITY_REWARD_DELAY_S = 2.0            # login -> lecture de l'état (et requêtes du lobby)
ACTIVITY_TRIGGER_DELAY_S = 6.0           # état -> ActivityTrigger
ACTIVITY_REWARD_RETRY_S = 6 * 3600.0
# ActivityTrigger envoyé avant de réclamer, comme le client dans le lobby (relevé « dcod » du 16/10).
# ACTIVITY_TRIGGER_EVENT=0 : désactivé.
ACTIVITY_TRIGGER_EVENT = int(os.environ.get("ACTIVITY_TRIGGER_EVENT", "34") or 0)
ACTIVITY_TRIGGER_WAIT_S = 10.0           # entre ActivityTrigger et GetActivityRewards (client : 8 à 10 s)
ACTIVITY_RECLAIM_WAIT_S = 10.0           # refus alors que LoginGetSplash montre la condition remplie : 2e essai
# ACTIVITY_LOBBY_CALLS=1 : requêtes ordinaires du lobby avant ActivityTrigger (api_client.lobby_login_bodies,
# ~575 Ko par compte). Sans effet sur la condition (essais du 18/10 ci-dessus) : désactivé par défaut.
ACTIVITY_LOBBY_CALLS = os.environ.get("ACTIVITY_LOBBY_CALLS", "0").strip() in ("1", "true", "yes", "on")
# LOBBY_PREMATCH_CALLS : les 13 requêtes du lobby liées aux parties et au classement, envoyées une fois par session
# juste avant la première recherche, dans l'ordre et avec les corps du vrai client (api_client.MATCH_LOBBY_BODIES).
# Relevé le 23/10 : le vrai client envoie 107 requêtes à clientbp dans les 14 s qui suivent son login, le bot 7.
# À l'essai contre le « 0 EXP » apparu le 22/10 vers 17 h : depuis cette heure-là le serveur de partie renvoie bien
# un résultat (et les 800 pièces) mais plus aucune EXP, pour tous les comptes et quels que soient les réglages de
# la partie — un joueur qui n'a jamais ouvert son lobby est l'une des différences qui restent avec le vrai client.
# Coût : 13 requêtes HTTP par session (corps de 0 à 4 octets). 0 pour revenir en arrière.
LOBBY_PREMATCH_CALLS = os.environ.get("LOBBY_PREMATCH_CALLS", "1").strip() not in ("0", "false", "no", "off")
# Réclamation des récompenses d'activité (réglage du site « activity_rewards_enabled », หลังบ้าน → ตั้งค่าระบบ) :
# désactivée par défaut depuis le 21/10 (demande). Les comptes du bot ne remplissent jamais la condition (login signé du
# vrai client, voir plus haut) : refus 400 BR_ACTIVITY_NO_REWARDS_AVAILABLE à chaque login, 3 requêtes pour rien.
# Désactivée : aucune requête REWARD (ni LoginGetSplash, ni ActivityTrigger, ni GetActivityRewards).
ACTIVITY_REWARDS_ENABLED = os.environ.get("ACTIVITY_REWARDS_ENABLED", "0").strip().lower() in ("1", "true", "yes", "on")
# Personnage équipé (réglage du site « equip_character », หลังบ้าน → ตั้งค่าระบบ) : après le login, un compte qui n'a
# jamais réclamé le lot de départ (jamais passé par le guide du nouveau joueur) reçoit le lot 3 et équipe le
# personnage 102000007 et ses 4 compétences, comme le client officiel (api_client.equip_newbie_character, essai du
# 25/10 20:30 réussi). Les autres comptes ne sont pas touchés. Une fois par compte et par processus.
EQUIP_CHARACTER = os.environ.get("EQUIP_CHARACTER", "0").strip().lower() in ("1", "true", "yes", "on")
_equip_tried: Set[str] = set()


async def _equip_character(account_data: Dict[str, Any], acc_id: str) -> None:
    """Personnage du guide du nouveau joueur équipé (voir EQUIP_CHARACTER) ; jamais bloquant pour la session."""
    if acc_id in _equip_tried:
        return
    _equip_tried.add(acc_id)
    t0 = time.perf_counter()
    try:
        r = await api_client.equip_newbie_character(account_data)
    except Exception as e:
        diag.event("LOGIN", "equip_character_failed", level="warning", exc=e, gid=acc_id,
                   dur_ms=(time.perf_counter() - t0) * 1000)
        return
    if r.get("skipped"):
        diag.event("LOGIN", "equip_character", level="debug", gid=acc_id, skipped=r.get("claimed"))
        return
    diag.event("LOGIN", "equip_character", level="info" if r.get("ok") else "warning", gid=acc_id,
               given=r.get("given"), ok=r.get("ok"), avatar=r.get("avatar"), skills=[s for _, s in r.get("skills", [])],
               unlocked=r.get("unlocked"), msg="; ".join(r.get("errors") or [])[:300] or None,
               dur_ms=(time.perf_counter() - t0) * 1000)
    if r.get("ok"):
        print_info(f"[LOGIN] สวมใส่ตัวละคร {r.get('avatar')} + สกิล {[s for _, s in r.get('skills', [])]} ({acc_id})")


# Version de la suite de réclamation : un refus obtenu par une suite plus ancienne est redemandé dès le login suivant
# (2 = lecture de l'état dans LoginGetSplash + MajorLogin champ 30 + corps de GetLoginData du client, 18/10).
REWARD_FLOW = 2
_rewards_state: Optional[Dict[str, Dict[str, Any]]] = None


def _load_rewards_state() -> Dict[str, Dict[str, Any]]:
    global _rewards_state
    if _rewards_state is None:
        _rewards_state = {}
        try:
            os.makedirs(os.path.dirname(ACTIVITY_REWARDS_FILE), exist_ok=True)
            if os.path.exists(ACTIVITY_REWARDS_FILE):
                with open(ACTIVITY_REWARDS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    _rewards_state = data
        except Exception as e:
            diag.event("CACHE", "rewards_unreadable", level="warning", code="CACHE_CORRUPT", exc=e)
    return _rewards_state


_rewards_saver = _DeferredSave(ACTIVITY_REWARDS_FILE, 5.0, lambda: dict(_load_rewards_state()),
                               {"indent": 1, "ensure_ascii": False}, "activity_rewards.json")


def _reward_text(items: List[Dict[str, Any]]) -> str:
    parts = []
    for it in items:
        days = int(it.get("duration_s") or 0) // 86400
        parts.append(f"ไอเทม {it.get('id')} x{it.get('count')}" + (f" ({days} วัน)" if days else ""))
    return ", ".join(parts)


def _state_name(states: Optional[Dict[int, Dict[str, int]]], activity: int) -> Optional[str]:
    """État d'une activité lu dans LoginGetSplash : RECEIVED/FINISHED/AWARDED, « - » si absente, None si non lu."""
    if states is None:
        return None
    st = states.get(activity)
    if st is None:
        return "-"
    return api_client.ACTIVITY_STATE_NAMES.get(st.get("state"), str(st.get("state")))


async def _claim_once(session: Dict[str, Any], activity: int, reward: int) -> Dict[str, Any]:
    """Un GetActivityRewards -> {ok, items, text, unavailable, status, state, raw, dur_ms}."""
    t0 = time.perf_counter()
    try:
        res = await api_client.claim_activity_reward(session, activity, reward)
    except api_client.GameApiError as e:
        text = str(e)[:200]
        # « BR_ACTIVITY_NO_REWARDS_AVAILABLE » (HTTP 400) : rien à réclamer pour ce compte (condition non remplie
        # aux yeux du serveur, déjà prise…) : pas une panne
        return {"ok": False, "items": [], "text": text, "unavailable": "NO_REWARDS_AVAILABLE" in text,
                "status": e.status, "state": None, "raw": "", "dur_ms": (time.perf_counter() - t0) * 1000}
    items = res.get("items") or []
    return {"ok": bool(items), "items": items, "text": res.get("condition") or "", "unavailable": False,
            "status": None, "state": res.get("state"), "raw": res.get("raw", ""),
            "dur_ms": (time.perf_counter() - t0) * 1000}


async def claim_activity_rewards(acc_id: str, delay: float = ACTIVITY_REWARD_DELAY_S) -> None:
    """Réclame les récompenses d'ACTIVITY_REWARDS que ce compte n'a pas encore obtenues, avec la suite du vrai client :
    requêtes du lobby (état des activités lu dans LoginGetSplash), ActivityTrigger, puis GetActivityRewards.
    Rien du tout si ACTIVITY_REWARDS_ENABLED est désactivé (relu après l'attente : coupé entre-temps = rien)."""
    if not ACTIVITY_REWARDS or not ACTIVITY_REWARDS_ENABLED:
        return
    await asyncio.sleep(delay)
    if not ACTIVITY_REWARDS_ENABLED:
        return
    state = _load_rewards_state()
    pending = []
    for activity, reward in ACTIVITY_REWARDS:
        rec = state.get(acc_id, {}).get(f"{activity}:{reward}")
        recent = rec and time.time() - float(rec.get("at") or 0) < ACTIVITY_REWARD_RETRY_S
        # un refus obtenu par une suite plus ancienne (avant REWARD_FLOW) est redemandé aussitôt
        if rec and (rec.get("ok") or (recent and int(rec.get("flow") or 0) >= REWARD_FLOW)):
            continue
        pending.append((activity, reward))
    if not pending:
        return

    def save(activity: int, reward: int, ok: bool, items: List[Dict[str, Any]], text: str, message: str,
             level: str, **extra: Any) -> None:
        print_info(f"[REWARD] {acc_id} {activity}:{reward} -> {'OK ' + _reward_text(items) if ok else text}")
        state.setdefault(acc_id, {})[f"{activity}:{reward}"] = {"at": time.time(), "ok": ok, "items": items,
                                                                "msg": text, "flow": REWARD_FLOW, **extra}
        _rewards_saver.mark()
        bot_state.reward_result(acc_id, ok, message, {"activity": activity, "reward": reward, "items": items},
                                level=level)

    session = bot_state.account_credentials.get(acc_id)
    if not session or not session.get("token"):
        return
    before: Optional[Dict[int, Dict[str, int]]] = None
    t0 = time.perf_counter()
    try:
        if ACTIVITY_LOBBY_CALLS:
            results, before = await api_client.lobby_login_calls(session)
            failed = [f"{ep}: {err}" for ep, err in results if err]
            diag.event("REWARD", "lobby_calls", level="warning" if failed else "info", ok=len(results) - len(failed),
                       failed=len(failed), msg="; ".join(failed)[:300] or None,
                       dur_ms=(time.perf_counter() - t0) * 1000)
        else:
            before = await api_client.activity_states(session)
        diag.event("REWARD", "states", states=",".join(f"{a}={_state_name(before, a)}" for a, _ in pending),
                   dur_ms=(time.perf_counter() - t0) * 1000)
    except api_client.GameApiError as e:
        diag.event("REWARD", "states_failed", level="warning", code=diag.classify(str(e)), msg=str(e)[:200],
                   dur_ms=(time.perf_counter() - t0) * 1000)
    # déjà réclamée (état AWARDED : récompense prise par le jeu ou un autre outil) : plus jamais redemandée
    for activity, reward in list(pending):
        if _state_name(before, activity) == "AWARDED":
            pending.remove((activity, reward))
            diag.event("REWARD", "already_awarded", activity=activity, reward=reward)
            save(activity, reward, True, [], "รับไปแล้ว", f"กิจกรรม {activity}: บัญชีนี้รับรางวัลไปแล้ว",
                 "info", already=True, before="AWARDED")
    if not pending:
        return
    await asyncio.sleep(ACTIVITY_TRIGGER_DELAY_S)
    if ACTIVITY_TRIGGER_EVENT:
        session = bot_state.account_credentials.get(acc_id)
        if not session or not session.get("token"):
            return
        t0 = time.perf_counter()
        try:
            await api_client.activity_trigger(session, ACTIVITY_TRIGGER_EVENT)
            diag.event("REWARD", "trigger", event_type=ACTIVITY_TRIGGER_EVENT,
                       dur_ms=(time.perf_counter() - t0) * 1000)
        except api_client.GameApiError as e:
            diag.event("REWARD", "trigger_failed", level="warning", code=diag.classify(str(e)), status=e.status,
                       event_type=ACTIVITY_TRIGGER_EVENT, msg=str(e)[:200], dur_ms=(time.perf_counter() - t0) * 1000)
        await asyncio.sleep(ACTIVITY_TRIGGER_WAIT_S)
    for activity, reward in pending:
        session = bot_state.account_credentials.get(acc_id)
        if not session or not session.get("token"):
            return
        res = await _claim_once(session, activity, reward)
        after = None
        if res["unavailable"]:
            # état après le refus : condition comptée en retard (FINISHED) -> 2e essai ; déjà prise (AWARDED) -> fini
            try:
                after = _state_name(await api_client.activity_states(session), activity)
            except api_client.GameApiError as e:
                diag.event("REWARD", "states_failed", level="warning", code=diag.classify(str(e)), msg=str(e)[:200])
            if after == "FINISHED":
                await asyncio.sleep(ACTIVITY_RECLAIM_WAIT_S)
                res = await _claim_once(session, activity, reward)
            elif after == "AWARDED":
                diag.event("REWARD", "already_awarded", activity=activity, reward=reward)
                save(activity, reward, True, [], "รับไปแล้ว", f"กิจกรรม {activity}: บัญชีนี้รับรางวัลไปแล้ว",
                     "info", already=True, before=_state_name(before, activity), after=after)
                continue
        ok, items, text = res["ok"], res["items"], res["text"]
        states = {"before": _state_name(before, activity), "after": after}
        if res["status"] is not None or res["unavailable"]:
            diag.event("REWARD", "unavailable" if res["unavailable"] else "failed",
                       level="info" if res["unavailable"] else "warning", code=diag.classify(text),
                       status=res["status"], activity=activity, reward=reward, msg=text, dur_ms=res["dur_ms"],
                       **states)
            not_counted = (after or states["before"]) in ("-", "RECEIVED")
            message = (f"กิจกรรม {activity}: เซิร์ฟเวอร์ยังไม่นับ 'ล็อกอิน 1/1 วัน' ให้บัญชีนี้ ต้องล็อกอินบัญชีนี้ในเกมจริง"
                       f" 1 ครั้ง แล้วบอทจะรับให้เอง" if res["unavailable"] and not_counted else
                       f"กิจกรรม {activity}: เซิร์ฟเวอร์แจ้งว่ายังไม่มีรางวัลให้รับ (จะลองใหม่ภายหลัง)" if res["unavailable"]
                       else f"รับรางวัลกิจกรรม {activity} ไม่สำเร็จ: {text}")
        else:
            diag.event("REWARD", "claimed" if ok else "no_item", level="info" if ok else "warning",
                       activity=activity, reward=reward, state=res["state"], condition=text,
                       items=_reward_text(items) or None, raw=None if ok else res["raw"][:160], dur_ms=res["dur_ms"],
                       **states)
            message = (f"รับรางวัลกิจกรรมแล้ว ({text or activity}): {_reward_text(items)}" if ok else
                       f"รับรางวัลกิจกรรม {activity} ไม่ได้ไอเทม ({text or 'ไม่มีรายละเอียด'}"
                       f" · สถานะ {res['state']}) จะลองใหม่ภายหลัง")
        save(activity, reward, ok, items, text, message,
             "success" if ok else "info" if res["unavailable"] else "warning",
             lobby=ACTIVITY_LOBBY_CALLS, **states)


def get_device_for_account(account_identifier: str) -> dict:
    """
    Ensures 1 ID = 1 Specific Device.
    It loads saved devices from devices.json. If the account isn't found,
    it generates a new profile and saves it permanently for this ID.
    """
    devices = _load_devices()
    acc_key = str(account_identifier)
    
    if acc_key in devices:
        return devices[acc_key]
        
    # Generate new device profile for this account
    device_list = [
        ("Samsung", "SM-G998B", "Adreno (TM) 660", "Android OS 12 / API-31"),
        ("Xiaomi", "2201122G", "Adreno (TM) 730", "Android OS 13 / API-33"),
        ("Realme", "RMX3700", "Mali-G710", "Android OS 14 / API-34"),
        ("OnePlus", "CPH2451", "Adreno (TM) 740", "Android OS 13 / API-33"),
        ("OPPO", "CPH2611", "Adreno (TM) 720", "Android OS 14 / API-34"),
        ("Vivo", "V2203", "Mali-G710", "Android OS 12 / API-31"),
        ("Poco", "M2102J20SG", "Adreno (TM) 660", "Android OS 13 / API-33"),
    ]
    brand, model, gpu, os_ver = random.choice(device_list)
    
    new_device = {
        "unique_device_id": f"Google|{str(uuid.uuid4())}",
        "brand": brand,
        "model": model,
        "gpu_renderer": gpu,
        "system_software": os_ver,
        "screen_width": random.choice([1080, 1440, 720, 1280]),
        "screen_height": random.choice([2400, 3200, 1600, 2400]),
        "screen_dpi": str(random.randint(300, 420)),
        "memory": random.randint(2800, 6500),
        "processor_details": f"ARM64 FP ASIMD AES VMH | {random.randint(2200, 3200)} | {random.randint(6, 12)}",
        "client_ip": f"{random.randint(103, 223)}.{random.randint(10, 250)}.{random.randint(10, 250)}.{random.randint(10, 250)}"
    }
    
    devices[acc_key] = new_device
    _devices_saver.mark()      # écrit en arrière-plan (thread), regroupé avec les autres nouveaux comptes
    return new_device


# ==================== CLOUDFLARE DNS RESOLVER & SOCKET OPTIMIZERS ====================
CLOUDFLARE_PRIMARY_DNS = "1.1.1.1"
CLOUDFLARE_SECONDARY_DNS = "1.0.0.1"
_DNS_CACHE: Dict[str, Tuple[str, float]] = {}
_DNS_CACHE_TTL = 300.0  # 5 minutes DNS cache

async def resolve_host_cloudflare(hostname: str) -> str:
    if not hostname:
        return hostname

    parts = hostname.split('.')
    if len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
        return hostname

    now = time.time()
    if hostname in _DNS_CACHE:
        ip, exp = _DNS_CACHE[hostname]
        if now < exp:
            return ip

    def _query_cloudflare(server_ip: str) -> Optional[str]:
        s = None
        try:
            tx_id = random.randint(1000, 65535)
            header = struct.pack(">HHHHHH", tx_id, 0x0100, 1, 0, 0, 0)
            qname = b"".join(bytes([len(part)]) + part.encode('ascii') for part in hostname.split('.')) + b"\x00"
            query_pkt = header + qname + struct.pack(">HH", 1, 1)

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1.2)
            s.sendto(query_pkt, (server_ip, 53))
            resp, _ = s.recvfrom(1024)

            if len(resp) >= 12:
                ancount = struct.unpack(">H", resp[6:8])[0]
                if ancount > 0:
                    offset = 12 + len(qname) + 4
                    for _ in range(ancount):
                        if offset >= len(resp):
                            break
                        if (resp[offset] & 0xC0) == 0xC0:
                            offset += 2
                        else:
                            while offset < len(resp) and resp[offset] != 0:
                                offset += 1 + resp[offset]
                            offset += 1
                        if offset + 10 > len(resp):
                            break
                        rtype, rclass, ttl, rdlen = struct.unpack(">HHIH", resp[offset:offset+10])
                        offset += 10
                        if rtype == 1 and rdlen == 4 and offset + 4 <= len(resp):
                            return socket.inet_ntoa(resp[offset:offset+4])
                        offset += rdlen
        except Exception:
            pass
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass
        return None

    loop = asyncio.get_running_loop()
    ip = await loop.run_in_executor(None, _query_cloudflare, CLOUDFLARE_PRIMARY_DNS)
    if not ip:
        ip = await loop.run_in_executor(None, _query_cloudflare, CLOUDFLARE_SECONDARY_DNS)
    if not ip:
        try:
            ip_info = await loop.getaddrinfo(hostname, None, family=socket.AF_INET)
            if ip_info:
                ip = ip_info[0][4][0]
        except Exception:
            ip = hostname

    if ip:
        _DNS_CACHE[hostname] = (ip, now + _DNS_CACHE_TTL)
    return ip or hostname


def optimize_tcp_socket(sock: socket.socket):
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
    except Exception:
        pass


_SIO_UDP_CONNRESET = 0x9800000C
_wsa_ioctl = None


def _disable_udp_connreset(sock: socket.socket) -> bool:
    """Windows : un ICMP « port fermé » (serveur de partie qui ferme son port…) fait échouer la lecture suivante de
    la socket UDP en WinError 10054. Python n'expose pas SIO_UDP_CONNRESET (l'ancien `hasattr(socket, …)` était
    toujours faux : rien n'était désactivé) : appel direct de WSAIoctl."""
    global _wsa_ioctl
    if os.name != "nt":
        return True
    try:
        if _wsa_ioctl is None:
            import ctypes
            from ctypes import wintypes
            fn = ctypes.WinDLL("ws2_32").WSAIoctl
            fn.argtypes = [ctypes.c_size_t, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p,
                           wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p, ctypes.c_void_p]
            fn.restype = ctypes.c_int
            _wsa_ioctl = (fn, ctypes, wintypes)
        fn, ctypes, wintypes = _wsa_ioctl
        flag, returned = wintypes.BOOL(False), wintypes.DWORD(0)
        return fn(sock.fileno(), _SIO_UDP_CONNRESET, ctypes.byref(flag), ctypes.sizeof(flag), None, 0,
                  ctypes.byref(returned), None, None) == 0
    except Exception:
        return False


def optimize_udp_socket(sock: socket.socket):
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 131072)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 131072)
    except Exception:
        pass
    _disable_udp_connreset(sock)


# ==================== NETWORK & CRYPTO ====================
client = httpx.AsyncClient(
    verify=False,
    timeout=10.0,
    limits=httpx.Limits(max_connections=100, max_keepalive_connections=50)
)

headers = {
    'User-Agent': 'UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'gzip',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Expect': '100-continue',
    'X-Unity-Version': '2018.4.12f1',
    'X-GA-SV': '1789535859',
    'X-GA': 'v1 1',
    'ReleaseVersion': 'OB55'
}

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'

CRC7_TABLE = bytes([
    0, 9, 18, 27, 36, 45, 54, 63, 72, 65, 90, 83, 108, 101, 126, 119,
    25, 16, 11, 2, 61, 52, 47, 38, 81, 88, 67, 74, 117, 124, 103, 110,
    50, 59, 32, 41, 22, 31, 4, 13, 122, 115, 104, 97, 94, 87, 76, 69,
    43, 34, 57, 48, 15, 6, 29, 20, 99, 106, 113, 120, 71, 78, 85, 92,
    100, 109, 118, 127, 64, 73, 82, 91, 44, 37, 62, 55, 8, 1, 26, 19,
    125, 116, 111, 102, 89, 80, 75, 66, 53, 60, 39, 46, 17, 24, 3, 10,
    86, 95, 68, 77, 114, 123, 96, 105, 30, 23, 12, 5, 58, 51, 40, 33,
    79, 70, 93, 84, 107, 98, 121, 112, 7, 14, 21, 28, 35, 42, 49, 56,
    65, 72, 83, 90, 101, 108, 119, 126, 9, 0, 27, 18, 45, 36, 63, 54,
    88, 81, 74, 67, 124, 117, 110, 103, 16, 25, 2, 11, 52, 61, 38, 47,
    115, 122, 97, 104, 87, 94, 69, 76, 59, 50, 41, 32, 31, 22, 13, 4,
    106, 99, 120, 113, 78, 71, 92, 85, 34, 43, 48, 57, 6, 15, 20, 29,
    37, 44, 55, 62, 1, 8, 19, 26, 109, 100, 127, 118, 73, 64, 91, 82,
    60, 53, 46, 39, 24, 17, 10, 3, 116, 125, 102, 111, 80, 89, 66, 75,
    23, 30, 5, 12, 51, 58, 33, 40, 95, 86, 77, 68, 123, 114, 105, 96,
    14, 7, 28, 21, 42, 35, 56, 49, 70, 79, 84, 93, 98, 107, 112, 121,
])

_DELTA = 0x9E3779B9
_ROUNDS = 16
_FIELD_SIZES = {0: 1, 1: 2, 2: 2, 3: 1, 4: 2}
_FIELD_NAMES = {0: "sendOption", 1: "cmd", 2: "orderId", 3: "flags", 4: "length"}

sai_tail_dul = bytes.fromhex(
    "0101030101045452000103000100000410312e3133302e3232"
    "1432303139313231303430ca0163736f7665727365612e737472"
    "6f6e67686f6c642e66726565666972656d6f62696c652e636f6d"
    "3b302e302e302e303b33342e3132362e37362e34353b33342e38"
    "372e3137372e31343b33342e38372e3137302e3233303b33352e"
    "3138352e3138332e353700000000000001000000000000000000"
    "0000000100000000000100000000000100b8eeec91c5d7ffde110200"
)

class Colors:
    HEADER = '\033[95m'
    GREEN = '\033[92m'
    FAIL = '\033[91m'
    WARNING = '\033[93m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    WHITE = '\033[97m'
    ENDC = '\033[0m'

# Sorties console du protocole : désactivées par défaut (CONSOLE_MODE=debug pour les réactiver).
CONSOLE_VERBOSE = False


def print_colored(text, color=Colors.WHITE):
    if not CONSOLE_VERBOSE:
        return
    try:
        print(f"{color}{text}{Colors.ENDC}")
    except Exception:
        try:
            print(f"{color}{text.encode('ascii', errors='replace').decode('ascii')}{Colors.ENDC}")
        except Exception:
            pass

def print_success(text):
    print_colored(f"[+] {text}", Colors.GREEN)
    try:
        bot_state.log(text, "success")
    except Exception:
        pass

def print_error(text):
    print_colored(f"[-] {text}", Colors.FAIL)
    try:
        bot_state.log(text, "error")
    except Exception:
        pass

def print_warning(text):
    print_colored(f"[!] {text}", Colors.WARNING)
    try:
        bot_state.log(text, "warning")
    except Exception:
        pass

def print_info(text):
    print_colored(f"[i] {text}", Colors.CYAN)
    try:
        bot_state.log(text, "info")
    except Exception:
        pass

def _proto_int(value, default):
    """Entier positif d'un champ varint décodé ; `default` s'il est absent ou illisible."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default

def get_proto_field(d, key, default=None):
    if not d or not isinstance(d, dict):
        return default
    if key in d:
        val = d[key].get('data')
        return val if val is not None else default
    if str(key) in d:
        val = d[str(key)].get('data')
        return val if val is not None else default
    return default


# ==================== ÉTAT DES MATCHS PAR PANEL ====================
# Un état par panel (clé : panel_id du runner, None hors moteur de panels). Les compteurs d'un panel ne
# voient jamais ceux des autres : ajouter des panels ne retire ni places ni EXP à un panel.
# Pas de verrou : aucune attente (await) dans ces sections, la boucle asyncio les exécute d'un bloc.
class _PanelMatches:
    """Matchs d'UN panel : matchs en cours par compte (affichage) et comptes en recherche.
    `active` = somme de `counters`, tenue à jour : les vérifications de place (des centaines de comptes, chaque
    seconde) ne parcourent plus tous les comptes. `starved` : comptes du panel qui attendent une place sans avoir
    aucune partie en cours (affichage). `waiting` : comptes du panel qui attendent une place alors que leurs propres
    réglages les autorisent à jouer (partage équitable, voir _fair_share_yield ; partage entre panels, _over_share)."""
    __slots__ = ("key", "counters", "by_mode", "searching", "active", "starved", "waiting", "fewest", "fewest_at")

    def __init__(self, key: Optional[str] = None):
        self.key = key                       # panel_id (clé de _panels et de _panel_shares)
        self.counters: Dict[str, int] = {}   # uid -> matchs en cours (uniquement les comptes qui en ont)
        self.by_mode: Dict[str, Dict[str, int]] = {}   # uid -> mode -> matchs en cours (plafonds par mode, mode_mix)
        self.searching: Set[str] = set()     # comptes dont un StartMatch attend encore son match
        self.active = 0                      # matchs en cours dans tout le panel
        self.starved: Set[str] = set()       # en attente d'une place, aucune partie en cours
        self.waiting: Set[str] = set()       # en attente d'une place, autorisés à jouer par leur session
        self.fewest: Optional[int] = None    # moins de parties en cours parmi `waiting` (voir _fewest_waiting)
        self.fewest_at = 0.0

_panels: Dict[Optional[str], _PanelMatches] = {}

# Partage des places du serveur entre panels (posé toutes les 2 s par le moteur, voir Orchestrator._share_loop) :
# panel_id -> places garanties. Les workers ne jouent que match_capacity() parties en tout ; sans partage, un panel
# aux réglages larges (10 comptes x 50 parties en parallèle) reprenait chaque place libérée et les comptes des autres
# panels attendaient alors que LEUR panel avait encore de la place. Un panel au-delà de sa part laisse les places
# libérées à un panel en dessous de la sienne qui a des comptes en attente ; la part inutilisée d'un panel sert aux
# autres. Les parties en cours ne sont jamais coupées.
_panel_shares: Dict[Optional[str], int] = {}


def set_panel_shares(shares: Dict[Optional[str], int]) -> None:
    global _panel_shares
    _panel_shares = dict(shares)


# Comptes de chaque panel lancés récemment qui n'ont encore trouvé aucune partie (login, connexion, 1re recherche) :
# posé par le moteur à chaque tour de file (PanelSupervisor.newcomers). Tant qu'il y en a, les comptes du panel qui
# jouent déjà ne prennent pas de partie de plus (voir _fair_share_yield).
_panel_newcomers: Dict[Optional[str], int] = {}


def set_panel_newcomers(panel_key: Optional[str], count: int) -> None:
    if count > 0:
        _panel_newcomers[panel_key] = count
    else:
        _panel_newcomers.pop(panel_key, None)


def _panel_matches(uid: str) -> _PanelMatches:
    """État du panel qui fait tourner le compte (runner de la tâche courante, voir ffbot.hooks)."""
    key = bot_state.panel_key(uid)
    panel = _panels.get(key)
    if panel is None:
        panel = _panels[key] = _PanelMatches(key)
    return panel


def _over_share(uid: str, panel: _PanelMatches) -> bool:
    """Le panel a déjà sa part des places du serveur et un autre panel attend en dessous de la sienne :
    la place suivante revient à cet autre panel."""
    if not _panel_shares:
        return False
    share = _panel_shares.get(panel.key)
    if share is None or _panel_busy(uid, panel) < share:
        return False
    for other in _panels.values():
        if other is not panel and other.waiting and \
                other.active + len(other.searching) < _panel_shares.get(other.key, 0):
            return True
    return False

def _panel_limit(uid: str) -> int:
    """Matchs simultanés du panel du compte : réglage `panel_max_matches` (>= 0), sinon PANEL_MAX_MATCHES."""
    limit = int(bot_state.tuning(uid, "panel_max_matches", -1))
    return PANEL_MAX_MATCHES if limit < 0 else limit

async def _inc_match(uid: str, panel: Optional[_PanelMatches] = None, mode: Optional[str] = None) -> int:
    panel = panel or _panel_matches(uid)
    panel.counters[uid] = panel.counters.get(uid, 0) + 1
    panel.active += 1
    panel.starved.discard(uid)
    if mode:
        per = panel.by_mode.setdefault(uid, {})
        per[mode] = per.get(mode, 0) + 1
    return panel.counters[uid]

async def _dec_match(uid: str, panel: Optional[_PanelMatches] = None, mode: Optional[str] = None) -> int:
    panel = panel or _panel_matches(uid)
    n = panel.counters.get(uid, 0)
    if n > 0:
        n -= 1
        panel.active -= 1
        if n:
            panel.counters[uid] = n
        else:
            del panel.counters[uid]     # pas d'entrée à 0 : le dictionnaire ne grossit pas avec les comptes passés
    per = panel.by_mode.get(uid)
    if mode and per and per.get(mode):
        per[mode] -= 1
        if not per[mode]:
            del per[mode]
        if not per:
            del panel.by_mode[uid]
    return n

def _by_mode(uid: str, panel: _PanelMatches) -> Dict[str, int]:
    """Matchs en cours du compte par mode (plafonds par mode du réglage mode_mix ; lecture seule)."""
    return panel.by_mode.get(uid) or {}

async def _get_match_count(uid: str, panel: Optional[_PanelMatches] = None) -> int:
    return (panel or _panel_matches(uid)).counters.get(uid, 0)

async def _get_total_match_count(uid: str, panel: Optional[_PanelMatches] = None) -> int:
    """Matchs en cours de tout le panel du compte (et non plus de toute la machine)."""
    return (panel or _panel_matches(uid)).active

def _panel_busy(uid: str, panel: _PanelMatches) -> int:
    """Places prises dans le panel : matchs en cours + recherches des AUTRES comptes du panel."""
    return panel.active + len(panel.searching) - (uid in panel.searching)

async def _has_match_slot(uid: str, panel: Optional[_PanelMatches] = None) -> bool:
    """Place libre sous la limite du panel (matchs en cours + recherches des autres comptes DU MÊME panel),
    et serveur en état d'en accueillir une de plus (protection anti-saturation, commune à tous les panels)."""
    panel = panel or _panel_matches(uid)
    limit = _panel_limit(uid)
    if limit > 0 and _panel_busy(uid, panel) >= limit:
        return False
    return _load_guard.allows(uid, panel)

_FEWEST_CACHE_S = 0.5


def _fewest_waiting(panel: _PanelMatches) -> Optional[int]:
    """Moins de parties en cours parmi les comptes du panel qui attendent une place (autorisés à jouer), None si aucun.
    Recalculé au plus toutes les _FEWEST_CACHE_S : chaque compte en attente vérifie sa place chaque seconde."""
    t = time.monotonic()
    if t - panel.fewest_at >= _FEWEST_CACHE_S:
        counters = panel.counters
        panel.fewest = min((counters.get(u, 0) for u in panel.waiting), default=None)
        panel.fewest_at = t
    return panel.fewest


def _fair_share_yield(uid: str, panel: _PanelMatches) -> bool:
    """Partage équitable des places du panel, par niveaux : chaque compte a sa 1re partie avant qu'un autre en ait 2,
    sa 2e avant qu'un autre en ait 3… (jusqu'à max_parallel_matches). Un compte qui a déjà N parties laisse la place
    suivante (et abandonne sa recherche en cours) :
      - tant qu'un compte du panel lancé récemment n'a encore aucune partie (login en cours) : avant, les premiers
        connectés prenaient 2 à 4 places chacun pendant que les autres se connectaient ;
      - à un compte du panel qui attend une place avec moins de N parties : avant, seul un compte sans aucune partie
        passait devant, ensuite la place allait au premier qui la demandait (certains 4 parties, d'autres 1)."""
    mine = panel.counters.get(uid, 0)
    if mine <= 0:
        return False
    if _panel_newcomers.get(panel.key, 0) > 0:
        return True
    fewest = _fewest_waiting(panel)
    # Écart d'une partie toléré (sauf pour un compte qui n'en a aucune) : avec « fewest < mine », une partie qui se
    # terminait chez un autre compte faisait annuler la recherche qui venait de partir (17-18/10 : ~4 900 annulations
    # en 2 h 15, la plupart dans les 2 s suivant le StartMatch), puis l'autre compte cherchait à sa place.
    return fewest is not None and (fewest == 0 or fewest < mine - 1)

async def _ready_to_search(uid: str, panel: _PanelMatches) -> bool:
    """Le compte peut lancer une recherche : sa session l'autorise (objectif, matchs parallèles…), aucune partie qu'il
    a quittée n'attend sa fin (MATCH_END_WAIT) et le panel a une place. Aucune attente (await) dans cette vérification :
    celle qui la suit (réservation) est atomique."""
    return (_may_start(uid, panel, await _get_match_count(uid, panel))
            and not _fair_share_yield(uid, panel)
            and await _has_match_slot(uid, panel))

def _slot_block_reason(uid: str, panel: _PanelMatches) -> str:
    """Pourquoi le compte ne peut pas chercher de partie maintenant (journal ; mêmes contrôles, sans effet de bord)."""
    if not bot_state.can_start_match(uid, panel.counters.get(uid, 0), _by_mode(uid, panel)):
        return "ACCOUNT_LIMIT"
    if _left_waiting(uid):
        return "MATCH_END_WAIT"
    if _fair_share_yield(uid, panel):
        return "FAIR_SHARE"
    limit = _panel_limit(uid)
    if limit > 0 and _panel_busy(uid, panel) >= limit:
        return "PANEL_FULL"
    if _load_guard.active:
        return "LOAD_GUARD"
    busy = _server_busy(uid, panel)
    if SERVER_MAX_MATCHES and busy >= SERVER_MAX_MATCHES:
        return "SERVER_MAX"
    capacity = match_capacity()
    if capacity and busy >= capacity:
        return "WORKERS_FULL"
    if _over_share(uid, panel):
        return "PANEL_SHARE"
    return "OTHER"

WAITING_STATUS_EVERY_S = 5.0     # attente hors ligne d'une place : état rafraîchi (parties terminées entre-temps)
# attentes normales d'un compte (partie en cours, partie quittée pas encore finie) : journal au niveau détail
_QUIET_WAIT_CODES = ("ACCOUNT_LIMIT", "MATCH_END_WAIT")


# ==================== PROTECTION ANTI-SATURATION ====================
# Tout le serveur tourne sur un seul thread : au-delà d'un certain nombre de parties simultanées (~160 mesurées
# sur cette machine), il ne suit plus, les réponses aux paquets des parties partent avec plus d'une seconde de
# retard et TOUTES les parties en pâtissent (EXP non créditée). La protection retient les NOUVELLES parties
# (les parties en cours continuent, aucun abandon) tant que le serveur est saturé :
#   - LOAD_GUARD_LAG_MS : retard moyen de la boucle (10 s) au-delà duquel on retient (0 = désactivée) ;
#     on relâche sous LOAD_GUARD_RESUME_MS (hystérésis : pas d'oscillation) ;
#   - SERVER_MAX_MATCHES : plafond fixe de parties sur tout le serveur, tous panels confondus (0 = aucun).
def _env_int(name: str, default: int) -> int:
    try:
        return max(0, int(os.environ.get(name, default)))
    except ValueError:
        return default

LOAD_GUARD_LAG_MS = _env_int("LOAD_GUARD_LAG_MS", 250)
LOAD_GUARD_RESUME_MS = _env_int("LOAD_GUARD_RESUME_MS", 100)
SERVER_MAX_MATCHES = _env_int("SERVER_MAX_MATCHES", 0)


def _server_busy(uid: str, panel: _PanelMatches) -> int:
    """Parties en cours + recherches en attente de match, sur tout le serveur (sans la recherche du compte)."""
    return sum(p.active + len(p.searching) for p in _panels.values()) - (uid in panel.searching)


class _LoadGuard:
    __slots__ = ("active", "since", "trips", "held", "reason")

    def __init__(self):
        self.active = False      # saturation : nouvelles parties retenues
        self.since = 0.0
        self.trips = 0           # déclenchements depuis le démarrage
        self.held = 0            # demandes de nouvelle partie retenues (1 par compte et par seconde d'attente)
        self.reason = ""

    def allows(self, uid: str, panel: _PanelMatches) -> bool:
        if LOAD_GUARD_LAG_MS:
            lag = monitor.recent_lag_ms(10)
            pool = _match_pool
            if pool is not None:
                worker_lag = pool.lag_ms()   # parties dans les workers : leur boucle compte aussi (le moins chargé)
                if worker_lag is not None:
                    lag = max(lag, worker_lag)
            if self.active and lag < LOAD_GUARD_RESUME_MS:
                self.active = False
                print_info(f"[CHARGE] serveur de nouveau fluide ({lag:.0f} ms) : nouvelles parties autorisées")
                diag.event("SYSTEM", "load_guard_off", level="info", lag_ms=round(lag),
                           held_s=round(time.time() - self.since))
            elif not self.active and lag > LOAD_GUARD_LAG_MS:
                self.active, self.since, self.reason = True, time.time(), f"retard de la boucle {lag:.0f} ms"
                self.trips += 1
                print_warning(f"[CHARGE] serveur saturé ({lag:.0f} ms de retard) : nouvelles parties retenues, "
                              f"les parties en cours continuent")
                diag.event("SYSTEM", "load_guard_on", level="warning", code="LOAD_GUARD", lag_ms=round(lag),
                           main_lag_ms=round(monitor.recent_lag_ms(10)), busy=_server_busy(uid, panel),
                           msg="เซิร์ฟเวอร์หน่วง: พักแมตช์ใหม่ไว้ก่อน (แมตช์ที่เล่นอยู่เล่นต่อ)")
            if self.active:
                self.held += 1
                return False
        if SERVER_MAX_MATCHES and _server_busy(uid, panel) >= SERVER_MAX_MATCHES:
            self.held += 1
            return False
        capacity = match_capacity()
        if capacity and _server_busy(uid, panel) >= capacity:
            # workers pleins (UDP_WORKERS x UDP_WORKER_MAX_MATCHES) : même un panel « illimité » attend une place.
            # Sans ce plafond, des centaines de parties par worker saturaient le réseau puis faisaient planter le worker.
            self.held += 1
            return False
        if _over_share(uid, panel):
            # panel au-delà de sa part des places du serveur : un autre panel en dessous de la sienne attend
            self.held += 1
            return False
        return True

    def status(self) -> Dict[str, Any]:
        return {"enabled": bool(LOAD_GUARD_LAG_MS), "active": self.active, "since": self.since or None,
                "reason": self.reason if self.active else "", "trips": self.trips, "held": self.held,
                "lag_ms": LOAD_GUARD_LAG_MS, "resume_ms": LOAD_GUARD_RESUME_MS,
                "server_max_matches": SERVER_MAX_MATCHES,
                "busy": sum(p.active + len(p.searching) for p in _panels.values())}


_load_guard = _LoadGuard()


# ==================== ACTIVITÉ UDP (coupures réseau) ====================
_udp_last_rx = 0.0                     # dernier paquet UDP reçu, toutes parties confondues
_udp_matches: Dict[int, str] = {}      # parties en cours -> serveur UDP (ip:port)


class _UdpStats:
    """Trafic UDP des parties, cumulé depuis le démarrage (supervision : page « Serveur », /api/metrics).
    fast_replies : ACK / PING répondus directement par la tâche de lecture, sans réveiller la partie.
    send_errors : envois refusés par le système (WinError 10055 « tampons pleins »…), réponses ACK / PING comprises.
    ping_echoes : PING reçus qui étaient l'écho d'un PING envoyé / répondu (non répondus si UDP_PING_DEDUP)."""
    __slots__ = ("packets", "bytes", "control", "decoded", "fast_replies", "dropped", "send_errors", "ping_echoes",
                 "by_cmd")
    COUNTERS = ("packets", "bytes", "control", "decoded", "fast_replies", "dropped", "send_errors", "ping_echoes")

    def __init__(self):
        self.packets = self.bytes = self.control = self.decoded = self.fast_replies = self.dropped = 0
        self.send_errors = self.ping_echoes = 0
        self.by_cmd: Dict[int, int] = {}

    def snapshot(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {k: getattr(self, k) for k in self.COUNTERS}
        out["by_cmd"] = {MESSAGE_ID_TO_NAME.get(c, str(c)): n
                         for c, n in sorted(self.by_cmd.items(), key=lambda kv: -kv[1])}
        return out

_udp_stats = _UdpStats()

def udp_status() -> Dict[str, Any]:
    """Parties UDP en cours, compteurs de trafic, TEA natif ou non, protection anti-saturation."""
    return {"matches": len(_udp_matches), "tea_native": udp_codec.NATIVE, **_udp_stats.snapshot(),
            "guard": _load_guard.status(),
            "workers": _match_pool.status() if _match_pool is not None else []}

def slot_summary() -> Dict[str, Any]:
    """Résumé des places de match pour le journal (une ligne par minute) : parties, recherches, attentes."""
    return {"matches": sum(p.active for p in _panels.values()),
            "searching": sum(len(p.searching) for p in _panels.values()),
            "starved": sum(len(p.starved) for p in _panels.values()),
            "waiting": sum(len(p.waiting) for p in _panels.values()),
            "newcomers": sum(_panel_newcomers.values()),
            # par panel : places prises / part garantie / comptes en attente d'une place
            "panels": ",".join(f"{str(p.key)[:6]}:{p.active + len(p.searching)}/{_panel_shares.get(p.key, '-')}"
                               f"/w{len(p.waiting)}" for p in _panels.values() if p.active or p.waiting or p.searching),
            # parties quittées dont le compte attend la fin (MATCH_END_WAIT)
            "end_wait": sum(len(w) for w in _left_waits.values()),
            "udp": len(_udp_matches), "capacity": match_capacity(), "guard": int(_load_guard.active),
            "pkt": _udp_stats.packets, "dropped": _udp_stats.dropped, "send_err": _udp_stats.send_errors,
            "ping_echo": _udp_stats.ping_echoes}

def _network_silent(match_key: int, server: str) -> bool:
    """Coupure réseau probable : d'autres parties tournent sur d'autres serveurs et aucune partie n'a rien reçu
    depuis NETWORK_SILENCE_S. Toutes les parties sur le même serveur (même partie) ne prouvent rien : si elles se
    taisent ensemble, c'est peut-être simplement la fin de cette partie."""
    others = any(k != match_key and s != server for k, s in _udp_matches.items())
    return others and time.time() - _udp_last_rx > NETWORK_SILENCE_S


# ==================== PARTIES QUITTÉES PAS ENCORE FINIES (MATCH_END_WAIT) ====================
# Une partie BR quittée en cours (BR_LEFT, BR_LOW_HP, BR_DIED_LEFT, BR_INSTA_LEFT) continue sur le serveur du jeu ; son
# résultat (0x04 de la passerelle, avec l'EXP) n'arrive qu'à sa fin. Relevé des 17-18/10 (24 360 résultats de parties quittées) :
# 124 s après le départ en médiane, 99 % en moins de 5 min, au plus 10 min 40 ; l'EXP vue sur les profils = la somme des
# résultats à 1,4 % près (une partie sans résultat n'a pas été créditée). Comptes d'une partie à la fois qui relancent
# une partie dans les 30 s après le départ : 60,6 % des parties quittées créditées, contre 75 à 85 % quand la suivante
# part plus tard (échantillons plus petits).
# MATCH_END_WAIT (réglage du site, หลังบ้าน → ตั้งค่าระบบ → การเล่นแมตช์) : le compte ne cherche pas de nouvelle partie
# tant qu'une partie qu'il a quittée n'a pas fini (résultat reçu), au plus MATCH_END_WAIT_MAX_MIN minutes après son
# départ ; ses parties en cours continuent. Le résultat arrive sur la connexion à la passerelle, gardée pendant
# l'attente (GATEWAY_STAY_ONLINE) ; il est aussi envoyé à la mort du joueur, parfois avant que le bot ne quitte.
MATCH_END_WAIT = 1
MATCH_END_WAIT_MAX_MIN = 6
LEFT_EARLY_CODES = frozenset({"BR_LEFT", "BR_LOW_HP", "BR_DIED_LEFT", "BR_INSTA_LEFT"})
# Fins de partie BR où le joueur local est MORT (déclenche le LogEvent EventTypeBRDeadInfo du vrai client).
BR_DEATH_REASONS = frozenset({"BR_DIED_LEFT", "BR_INSTA_LEFT", "PLAYER_DEAD"})
_left_waits: Dict[str, Dict[int, Tuple[float, float, Optional[int]]]] = {}   # compte -> partie -> (départ, fin d'attente, n°)
_results_seen: Dict[str, Dict[int, float]] = {}     # compte -> parties dont le résultat est arrivé (heure)
_RESULTS_KEPT = 30                                  # par compte
_RESULTS_ACCOUNTS_MAX = 20_000                      # comptes suivis (les plus anciens oubliés au-delà)
_left_wait_seq = 0                                  # clés des parties sans identifiant connu (négatives)


def _note_result(uid: str, match_id: int) -> None:
    """Résultat d'une partie reçu (passerelle 0x04) : la partie est finie pour le compte."""
    seen = _results_seen.get(uid)
    if seen is None:
        if len(_results_seen) >= _RESULTS_ACCOUNTS_MAX:
            for old in list(_results_seen)[:_RESULTS_ACCOUNTS_MAX // 4]:
                del _results_seen[old]
        seen = _results_seen[uid] = {}
    seen[match_id] = time.time()
    while len(seen) > _RESULTS_KEPT:
        seen.pop(next(iter(seen)))
    waits = _left_waits.get(uid)
    entry = waits.pop(match_id, None) if waits else None
    if entry is not None:
        if not waits:
            _left_waits.pop(uid, None)
        diag.event("MATCH", "end_wait_done", level="info", how="result", match_id=match_id, m=entry[2],
                   waited_s=round(time.time() - entry[0]), left=len(waits or ()))


def _left_wait_add(uid: str, match_id: Optional[int], match_index: Optional[int] = None) -> bool:
    """Partie quittée en cours : le compte attend sa fin avant une nouvelle partie (MATCH_END_WAIT). False : pas
    d'attente (réglage coupé, ou résultat déjà reçu)."""
    global _left_wait_seq
    if not MATCH_END_WAIT:
        return False
    now = time.time()
    if match_id and match_id in _results_seen.get(uid, {}):
        diag.event("MATCH", "end_wait_skip", level="debug", match_id=match_id, why="result_before_leave")
        return False
    _left_wait_seq += 1
    if _left_wait_seq % 1000 == 0:
        # attentes expirées de comptes qui ne cherchent plus (session finie) : jamais relues par _left_waiting
        for other in [u for u, w in _left_waits.items() if all(now >= e[1] for e in w.values())]:
            del _left_waits[other]
    if not match_id:
        match_id = -_left_wait_seq            # sans identifiant : seule la limite de temps la termine
    max_s = max(1, int(MATCH_END_WAIT_MAX_MIN)) * 60
    _left_waits.setdefault(uid, {})[match_id] = (now, now + max_s, match_index)
    diag.event("MATCH", "end_wait", level="debug", match_id=match_id if match_id > 0 else None, max_s=max_s,
               pending=len(_left_waits[uid]))
    return True


def _left_waiting(uid: str) -> bool:
    """Le compte a quitté une partie qui n'est pas encore finie sur le serveur (et l'attente n'a pas expiré)."""
    waits = _left_waits.get(uid)
    if not waits:
        return False
    if not MATCH_END_WAIT:                    # réglage coupé pendant l'attente : plus aucune attente
        _left_waits.pop(uid, None)
        return False
    now = time.time()
    for match_id, (left_at, until, index) in list(waits.items()):
        if now >= until:
            del waits[match_id]
            diag.event("MATCH", "end_wait_done", level="info", how="timeout",
                       match_id=match_id if match_id > 0 else None, m=index, waited_s=round(now - left_at),
                       left=len(waits))
    if not waits:
        _left_waits.pop(uid, None)
        return False
    return True


def _may_start(uid: str, panel: "_PanelMatches", active: Optional[int] = None) -> bool:
    """Le compte peut lancer une nouvelle partie : sa session l'autorise (objectif, parties simultanées, modes) et
    aucune partie qu'il a quittée n'attend encore sa fin sur le serveur (MATCH_END_WAIT)."""
    if active is None:
        active = panel.counters.get(uid, 0)
    return bot_state.can_start_match(uid, active, _by_mode(uid, panel)) and not _left_waiting(uid)


# ==================== PARTIES PROTÉGÉES ====================
# Références fortes : une partie protégée survit à la session (passerelle) qui l'a lancée.
_background_matches: Set[asyncio.Task] = set()
_match_owner: Dict[asyncio.Task, str] = {}     # partie protégée -> account_id du compte qui la joue

def _keep_running(task: asyncio.Task, owner: str = ""):
    _background_matches.add(task)
    _match_owner[task] = owner

    def _forget(t: asyncio.Task):
        _background_matches.discard(t)
        _match_owner.pop(t, None)

    task.add_done_callback(_forget)

async def stop_account_matches(account_id: Any) -> int:
    """Coupe les parties d'un compte (compte banni : elles ne rapportent plus rien et bloquent des places du panel)."""
    tasks = [t for t, owner in _match_owner.items() if owner == str(account_id) and not t.done()]
    for t in tasks:
        t.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    return len(tasks)

async def _stop_matches(play_matches: List[asyncio.Task]):
    """Arrêt de la passerelle : coupe les parties interruptibles, laisse finir les parties protégées (BR)."""
    running = [m for m in play_matches if not m.done()]
    play_matches.clear()
    kept = [m for m in running if m in _background_matches]
    cut = [m for m in running if m not in _background_matches]
    if kept:
        print_info(f"[FUNCTIONAL] {len(kept)} partie(s) en cours : elles continuent jusqu'à leur fin (pas d'abandon)")
    if cut:
        print_warning(f"[FUNCTIONAL] Cancelled — cancelling {len(cut)} UDP matches")
        for m in cut:
            m.cancel()
        await asyncio.gather(*cut, return_exceptions=True)

async def wait_background_matches(timeout: float, progress=None) -> int:
    """Arrêt du serveur : attend la fin des parties en cours (au plus `timeout` s) au lieu de les abandonner.
    `progress(en_cours, secondes_restantes)` est appelé toutes les 30 s. Retourne le nombre encore en cours."""
    deadline = time.time() + timeout
    reported = 0.0
    while True:
        running = [t for t in _background_matches if not t.done()]
        left = deadline - time.time()
        if not running or left <= 0:
            return len(running)
        if progress and time.time() - reported >= 30:
            reported = time.time()
            progress(len(running), left)
        await asyncio.wait(running, timeout=min(5.0, left))

async def stop_background_matches():
    """Arrêt du serveur : coupe aussi les parties protégées (avant la fermeture du stockage)."""
    tasks = [t for t in _background_matches if not t.done()]
    for t in tasks:
        t.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


# ==================== TOKEN CACHE ====================
# La mémoire fait foi : token_cache.json n'est relu que s'il a été modifié par quelqu'un d'autre (vérifié au plus
# toutes les TOKEN_CACHE_RECHECK_S), et réécrit au plus toutes les TOKEN_CACHE_SAVE_S par un thread (_DeferredSave).
# Supprimer le fichier à la main oublie toujours toutes les sessions gardées (login complet pour tous).
TOKEN_CACHE_SAVE_S = 3.0
TOKEN_CACHE_RECHECK_S = 2.0
_token_cache: Dict[str, Any] = {}
_token_cache_loaded = False
_token_cache_checked = 0.0

def _json_serializer(obj):
    if isinstance(obj, (bytes, bytearray)):
        return {"__bytes_hex__": bytes(obj).hex()}
    raise TypeError(f"Type {type(obj)} not serializable")

def _json_deserializer(obj):
    if isinstance(obj, dict):
        if "__bytes_hex__" in obj and len(obj) == 1:
            try:
                return bytes.fromhex(obj["__bytes_hex__"])
            except Exception:
                return b""
        return {k: _json_deserializer(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_deserializer(x) for x in obj]
    return obj

TOKEN_CACHE_KEEP_S = 12 * 3600      # sessions plus vieilles (token de jeu expiré, ~8 h) : retirées du fichier


def _token_cache_snapshot() -> Dict[str, Any]:
    # copie superficielle de chaque session : le thread d'écriture ne voit pas les modifications suivantes.
    # Sessions de plus de TOKEN_CACHE_KEEP_S oubliées : le fichier gardait toutes les sessions depuis le début
    # (2618 le 18/10, ~88 % mortes, 10,5 Mo réécrits à chaque sauvegarde groupée).
    limit = time.time() - TOKEN_CACHE_KEEP_S
    for k in [k for k, v in _token_cache.items() if isinstance(v, dict) and v.get("cached_at", 0) < limit]:
        _token_cache.pop(k, None)
    return {k: (dict(v) if isinstance(v, dict) else v) for k, v in _token_cache.items()}

_token_cache_saver = _DeferredSave(TOKEN_CACHE_FILE, TOKEN_CACHE_SAVE_S, _token_cache_snapshot,
                                   {"separators": (",", ":"), "default": _json_serializer}, "token_cache.json")


def _load_token_cache() -> Dict[str, Any]:
    """Sessions gardées (mémoire). Le fichier n'est relu que s'il a changé sur le disque sans nous."""
    global _token_cache, _token_cache_loaded, _token_cache_checked
    saver = _token_cache_saver
    now = time.time()
    if _token_cache_loaded and (saver.dirty or saver.saving or now - _token_cache_checked < TOKEN_CACHE_RECHECK_S):
        return _token_cache
    _token_cache_checked = now
    try:
        mtime = os.path.getmtime(TOKEN_CACHE_FILE)
    except OSError:
        if _token_cache_loaded and saver.mtime is not None:
            # fichier supprimé à la main : toutes les sessions gardées sont oubliées (login complet pour tous)
            _token_cache = {}
            saver.mtime = None
            diag.event("CACHE", "token_cache_removed", level="info", msg="token_cache.json ถูกลบ: ล้าง session ทั้งหมด")
        _token_cache_loaded = True
        return _token_cache
    if _token_cache_loaded and mtime == saver.mtime:
        return _token_cache
    t0 = time.perf_counter()
    try:
        with open(TOKEN_CACHE_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
        data = json.loads(content) if content else {}
        if not isinstance(data, dict):
            raise ValueError("Cache root must be dict")
        _token_cache = _json_deserializer(data)
        diag.event("CACHE", "token_cache_loaded", level="info", entries=len(_token_cache),
                   dur_ms=(time.perf_counter() - t0) * 1000)
    except Exception as e:
        print_error(f"Token cache corrupt → deleting: {e}")
        diag.event("CACHE", "token_cache_corrupt", level="error", code="CACHE_CORRUPT", exc=e)
        try:
            os.remove(TOKEN_CACHE_FILE)
        except Exception:
            pass
        _token_cache = {}
        mtime = None
    saver.mtime = mtime
    _token_cache_loaded = True
    return _token_cache


def flush_files():
    """Arrêt du serveur : écrit tout de suite token_cache.json et devices.json s'ils ont changé."""
    _token_cache_saver.flush()
    _devices_saver.flush()
    _rewards_saver.flush()

def cache_get(uid: str) -> Optional[Dict]:
    cache = _load_token_cache()
    entry = cache.get(str(uid))
    if not entry:
        return None
    if (time.time() - entry.get("cached_at", 0) > TOKEN_CACHE_TTL
            or not api_client.token_valid(entry.get("token"), TOKEN_EXPIRY_MARGIN)):
        print_info(f"[CACHE] UID {uid} expired. Re-login needed.")
        cache_invalidate(uid, "หมดอายุ (TOKEN_CACHE_TTL)")
        return None
    if str(entry.get("account_id", "")).isdigit():
        entry["account_id"] = int(entry["account_id"])
    if not isinstance(entry.get("login_payload_data"), (bytes, bytearray)):
        print_warning(f"[CACHE] UID {uid} missing payload → invalidating")
        cache_invalidate(uid, "ไม่มี login payload")
        return None
    if not _gateway_addr(entry.get("functional_addrs")):
        # session sans adresse de passerelle : chaque relance échouait aussitôt (boucle jusqu'au watchdog)
        print_warning(f"[CACHE] UID {uid} sans adresse de passerelle → invalidating")
        cache_invalidate(uid, "ไม่มีที่อยู่เกตเวย์")
        return None
    return entry

def _gateway_addr(value: Any) -> bool:
    """Adresse de passerelle utilisable (« hôte:port »)."""
    return isinstance(value, str) and value.count(":") == 1 and value.rsplit(":", 1)[1].isdigit()

def _invalidate_account_cache(account_data: Optional[Dict], reason: str = ""):
    """Oublie la session gardée d'un compte : le prochain login sera complet (MajorLogin + GetLoginData)."""
    if not account_data:
        return
    try:
        if account_data.get('auth_uid'):
            cache_invalidate(str(account_data['auth_uid']), reason)
        if account_data.get('auth_token'):
            cache_invalidate(f"tok_{account_data['auth_token'][:20]}", reason)
    except Exception:
        pass

def cache_set(uid: str, account_data: Dict):
    cache = _load_token_cache()
    entry = dict(account_data)
    entry["cached_at"] = time.time()
    cache[str(uid)] = entry
    _token_cache_saver.mark()       # écrit en arrière-plan, regroupé avec les autres logins
    print_success(f"[CACHE] Saved credentials for UID {uid}")

def cache_invalidate(uid: str, reason: str = ""):
    cache = _load_token_cache()
    if str(uid) in cache:
        del cache[str(uid)]
        _token_cache_saver.mark()
        # pas un avertissement : un nouveau login complet suit (raison dans le journal de diagnostic)
        print_info(f"[CACHE] Invalidated: {uid}{f' ({reason})' if reason else ''}")
        diag.event("CACHE", "invalidated", level="info", key=str(uid)[:24], reason=reason or None)

def cached_sessions() -> Dict[str, Dict]:
    """Sessions de token_cache.json, en lecture seule (sans invalidation : le token de jeu reste valable ~8 h
    après le délai de cache). Sert à la carte de profil (ffbot.profile_card)."""
    return _load_token_cache()


# ==================== ENCRYPTION & PROTOBUF ====================

async def aes_encrypt(payload, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(payload, AES.block_size))

PLAY_STORE_TIMEOUT_S = 30.0
PLAY_STORE_APP_ID = 'com.dts.freefireth'

# Page Play Store lue en IPv4 forcé (local_address 0.0.0.0) puis analysée par google_play_scraper. Avant : son
# urllib essayait l'IPv6 en premier, sans timeout ; l'IPv6 de la machine ne répond pas -> 120-170 s mesurées le
# 23/10 (contre 0,4 s en IPv4), donc TIMEOUT à chaque démarrage et logins bloqués.
_play_client = httpx.AsyncClient(
    transport=httpx.AsyncHTTPTransport(local_address="0.0.0.0"),
    timeout=PLAY_STORE_TIMEOUT_S,
    follow_redirects=True,
)

async def get_playstore_version():
    url = PlayFormats.Detail.build(app_id=PLAY_STORE_APP_ID, lang='hi', country='id')
    response = await asyncio.wait_for(_play_client.get(url), PLAY_STORE_TIMEOUT_S)
    response.raise_for_status()
    return play_parse_dom(dom=response.text, app_id=PLAY_STORE_APP_ID, url=url).get("version")

# Configuration de version (Play Store + ver.php) partagée par les logins : relue au plus toutes les 30 min,
# et la dernière connue sert encore si le Play Store ou ver.php ne répondent pas (un login de moins qui échoue).
# Configuration périmée mais encore valable (moins de VERSION_CONFIG_MAX_AGE) : servie tout de suite, relue en
# arrière-plan. Avant : chaque relecture (Play Store 23-54 s mesurées le 17/10) bloquait TOUS les logins complets.
VERSION_CONFIG_TTL = 1800
VERSION_CONFIG_MAX_AGE = 6 * 3600
_version_cache: Optional[Tuple[float, Tuple[str, str, str]]] = None
_version_lock = asyncio.Lock()
_version_refresh: Optional[asyncio.Task] = None

async def _refresh_version_config():
    global _version_cache
    async with _version_lock:
        if _version_cache and time.time() - _version_cache[0] < VERSION_CONFIG_TTL:
            return
        result = await _fetch_version_config()
        if result:
            _version_cache = (time.time(), result)

async def version_config():
    global _version_cache, _version_refresh
    cached = _version_cache
    if cached and time.time() - cached[0] < VERSION_CONFIG_TTL:
        return cached[1]
    if cached and time.time() - cached[0] < VERSION_CONFIG_MAX_AGE:
        if _version_refresh is None or _version_refresh.done():
            _version_refresh = asyncio.create_task(_refresh_version_config())
        return cached[1]
    async with _version_lock:
        if _version_cache and time.time() - _version_cache[0] < VERSION_CONFIG_TTL:
            return _version_cache[1]
        result = await _fetch_version_config()
        if result:
            _version_cache = (time.time(), result)
            return result
        if _version_cache and time.time() - _version_cache[0] < VERSION_CONFIG_MAX_AGE:
            print_warning("[LOGIN] Configuration de version indisponible : dernière configuration connue réutilisée")
            return _version_cache[1]
        return None

async def _fetch_version_config():
    t0 = time.perf_counter()
    try:
        app_version = await get_playstore_version()
    except Exception as e:
        print_error(f"[LOGIN] Version Play Store inaccessible : {e!r}"[:300])
        diag.event("LOGIN", "version_failed", level="error", code="VERSION_CONFIG", step="play_store",
                   err=diag.classify(e), msg=repr(e)[:300], dur_ms=(time.perf_counter() - t0) * 1000)
        return None
    # Paramètres du vrai client TH 1.132.13 (22/10) ; avant : lang=hi, region=BD, whitelist 1.3.0 (même
    # remote_version et server_url, seul le CDN répondu changeait).
    api_url = (
        "https://version.ggwhitehawk.com/live/ver.php"
        f"?version={app_version}"
        "&lang=en&device=android&channel=android"
        "&appstore=googleplay&region=TH"
        "&whitelist_version=1.8.0&whitelist_sp_version=1.0.0"
    )
    try:
        response = await client.get(api_url)
        response.raise_for_status()
        data = response.json()
        server_url = data.get("server_url")
        remote_version = data.get("remote_version")
        latest_release_version = data.get("latest_release_version")
        if not server_url or not remote_version or not latest_release_version:
            print_error(f"[LOGIN] Configuration de version incomplète : {str(data)[:160]}")
            diag.event("LOGIN", "version_failed", level="error", code="VERSION_CONFIG", step="ver.php",
                       msg=f"ไม่ครบ: {str(data)[:200]}")
            return None
        diag.event("LOGIN", "version_ok", level="info", app=app_version, release=latest_release_version,
                   dur_ms=(time.perf_counter() - t0) * 1000)
        return latest_release_version, remote_version, server_url
    except Exception as e:
        print_error(f"[LOGIN] Configuration de version (ver.php) inaccessible : {e!r}"[:300])
        diag.event("LOGIN", "version_failed", level="error", code="VERSION_CONFIG", step="ver.php",
                   err=diag.classify(e), msg=repr(e)[:300], dur_ms=(time.perf_counter() - t0) * 1000)
        return None

async def get_access_token(uid, password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    hdrs = {
        "Host": "100067.connect.garena.com",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-G998B Build/SP1A.210812.016)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close"
    }
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }
    last_error = ""
    last_code = None
    status = None
    t0 = time.perf_counter()
    attempt = 0
    for attempt in range(1, 6):
        try:
            response = await client.post(url, headers=hdrs, data=data)
            status = response.status_code
            last_error = f"HTTP {response.status_code} {' '.join(response.text.split())[:120]}"
            last_code = diag.classify(last_error)
            if response.status_code == 200:
                response_data = response.json()
                open_id = response_data.get("open_id")
                access_token = response_data.get("access_token")
                platform = response_data.get("platform", 4)
                if open_id and access_token:
                    diag.event("LOGIN", "token_grant", level="debug", attempts=attempt,
                               dur_ms=(time.perf_counter() - t0) * 1000)
                    return open_id, access_token, platform
                last_code = "HTTP_BAD_RESPONSE"
            if response.status_code == 429:
                # trop de requêtes : insister prolonge le refus. Le moteur met en pause TOUS les logins
                # (ffbot.engine.login_gate) puis réessaie ; ce n'est pas compté comme un échec du compte.
                break
        except Exception as e:
            last_error = repr(e)
            last_code = diag.classify(e)
        await asyncio.sleep(0.5)
    print_error(f"[LOGIN] Token invité (guest/token/grant) refusé pour l'UID {uid} : {last_error}"[:300])
    diag.event("LOGIN", "token_grant_failed", level="warning", code=last_code or "UNKNOWN", status=status,
               attempts=attempt, msg=last_error[:300], dur_ms=(time.perf_counter() - t0) * 1000)
    return None

async def parse_results(parsed_results):
    result_dict = {}
    for result in parsed_results:
        field_data = {"wire_type": result.wire_type}
        if result.wire_type == "varint":
            field_data["data"] = result.data
        elif result.wire_type == "string":
            field_data["data"] = result.data
        elif result.wire_type == "bytes":
            field_data["data"] = result.data
        elif result.wire_type == "length_delimited":
            field_data["data"] = await parse_results(result.data.results)
        result_dict[result.field] = field_data
    return result_dict

async def decode_protobuf(data):
    parsed_results = Parser().parse(data)
    parsed_results_dict = await parse_results(parsed_results)
    return json.dumps(parsed_results_dict)


import nexxthug_pb2

LOGIN_COUNTRY = (os.environ.get("LOGIN_COUNTRY", "TH").strip().upper() or "TH")   # champ 26 du MajorLogin


# GetLoginData du vrai client = corps du MajorLogin (refait 1 s plus tard) + 4 champs, dans l'ordre des numéros
# (6 logins sur 6 du relevé decoded_traffic.jsonl, 17-18/10) : 90 = ville, 91 = code de la province (12 = Nonthaburi,
# celle de « Pak Kret », position envoyée par UploadCoordinate), 99 = "0" au lieu de la plateforme, 103 = 1.
# Avant : le bot renvoyait le corps du MajorLogin tel quel.
GETLOGIN_CITY = "Pak Kret"
GETLOGIN_PROVINCE = "12"


def _pb_insert_raw(data: bytes, extra: Dict[int, bytes]) -> bytes:
    """Insère des champs protobuf déjà encodés (numéro -> octets, clé comprise) à leur place, dans l'ordre des
    numéros de champ comme le client (sérialisation standard)."""
    out, pending, i = bytearray(), sorted(extra.items()), 0
    while i < len(data):
        start = i
        key, i = _read_varint(data, i)
        if key is None:
            raise ValueError("protobuf illisible")
        num, wire = key >> 3, key & 7
        while pending and pending[0][0] < num:
            out += pending.pop(0)[1]
        if wire == 0:
            _, i = _read_varint(data, i)
        elif wire == 2:
            length, i = _read_varint(data, i)
            i += length or 0
        elif wire == 5:
            i += 4
        elif wire == 1:
            i += 8
        else:
            raise ValueError(f"wire {wire}")
        out += data[start:i]
    for _, raw in pending:
        out += raw
    return bytes(out)


async def build_majorlogin_payload(open_id, access_token, platform, client_version, device_info, newbie_choice: int = 0,
                                   getlogin: bool = False):
    """
    Aligné sur la capture réelle (proto JSON + DECRYPTED HEX).
    `newbie_choice` : seulement pour le premier login après MajorRegister (ffbot.guest_create), voir champ 85.
    `getlogin` : corps de GetLoginData (champs 90, 91, 99 et 103 du vrai client, voir GETLOGIN_CITY).

    ======================== EMPREINTE DU CLIENT — NE PAS CHANGER SANS TESTER ========================
    Une quinzaine de champs décrivent l'installation du jeu : gpu_version, 61 / 64 / 66, library_path, apk_info,
    92, encryption_key, total_storage, 102, 104, hot_update_urls (106/107) et client_version. Le serveur de
    connexion les valide ENSEMBLE : un jeu de valeurs complet et cohérent passe, un jeu mélangé ou inconnu se fait
    refuser d'un coup — HTTP 400 « BR_AUTH_ABNORMAL_GAME_CLIENT », pour TOUS les comptes à la fois (le jeton Garena,
    lui, est délivré normalement : rien à voir avec les identifiants ni avec un ban).

    Mesuré le 23/10 : les valeurs relevées sur le vrai client le 22/10 étaient refusées 3 comptes sur 3, dont un qui
    jouait la veille ; les valeurs d'avant (ci-dessous, copie C:\\Users\\f\\Downloads\\backup) répondaient HTTP 200 à
    la même minute, depuis la même machine, pour le même compte. Elles sont donc rétablies telles quelles.

    CONTRE-INTUITIF, et vérifié deux fois : recopier l'empreinte du VRAI client ne marche pas. Le 23/10 à 14:33 le
    MajorLogin du vrai client a été capturé et déchiffré en entier (journal « ssss », AES_KEY / AES_IV du module) ;
    les 13 champs ci-dessus ont été remplacés par ses valeurs exactes, au champ près (gpu_version 610.74, 61/64/66
    116285 / 122854, 73 = 3, chemin d'APK « e7iuj-rXMQmzkybPVOe-Sw== », 92 = 10190, encryption_key
    « KqsHTxiTMl8Q… », 102 = 1754104651…, 104 = 4141, 106 = dl.cdn + dl-core.cdn — les deux miroirs que le vrai
    client interroge vraiment —, 107 = « 1.bbb5085755cebdee », champ 95 retiré comme chez lui) : résultat HTTP 400
    BR_AUTH_ABNORMAL_GAME_CLIENT. Jeu remis comme ci-dessous : HTTP 200. Donc les deux jeux relevés sur le vrai
    client (22/10 et 23/10) sont refusés et seul l'ancien passe — l'hypothèse « il suffit de relever l'empreinte
    du moment » est fausse, et une empreinte fraîche est peut-être liée à l'installation vivante qui l'utilise.
    À ne pas refaire sans mesurer : les 13 champs ont déjà été recopiés d'une capture deux fois, pour rien.

    Avant de toucher à l'un de ces champs : relever le jeu COMPLET sur un vrai client, le poser en bloc, puis
    vérifier avec   python tools/exp_test.py --login-only --uid <uid> --password <mdp>
    Un HTTP 200 = accepté. Sinon revenir au jeu précédent : le bot ne peut plus se connecter du tout, donc ne joue
    plus aucune partie et ne gagne plus aucune EXP, et rien dans le jeu ne dit lequel des champs a déplu.
    ==================================================================================================
    """
    version_code = client_version

    game_data = nexxthug_pb2.thug4ff()

    # --- En-tête / identification ---
    game_data.timestamp      = str(datetime.now())[:-7]
    game_data.game_name      = "free fire"
    game_data.game_version   = 1
    game_data.version_code   = version_code           # ex: "1.132.8"

    # Appareil du compte (devices.json, un par compte) : identifiant Google (champ 19) et modèle (champ 25). Avant :
    # device_info était ignoré, TOUS les comptes se connectaient avec le même appareil (2618 sessions identiques).
    # Les autres champs restent ceux d'un client réel ; 57 (= MD5 de la signature de l'APK, identique chez tous les
    # joueurs) ne change pas.
    device = device_info if isinstance(device_info, dict) else {}
    model = " ".join(x for x in (str(device.get("brand") or "").lower(), str(device.get("model") or "")) if x)

    # --- OS / device ---
    game_data.os_info             = "Android OS 9 / API-28 (SP1A.210812.016/G998BXXU4BULF)"
    game_data.device_type         = "Handheld"
    game_data.device_form_factor  = "Handheld"
    game_data.device_model        = model or "samsung SM-G998B"
    # Champ 14 = DPI, champ 26 = pays (capture du vrai client du 15/10 : 14 = "240", 26 = "TH"). Les noms du proto
    # sont trompeurs : l'attribut « api » est le champ 14, « dpi » le champ 26. Avant : « dpi = 240 » mettait le DPI
    # dans le champ du pays et le champ 14 manquait. Corrigé et validé en direct le 15/10 (login accepté).
    game_data.api                 = "240"
    game_data.dpi                 = LOGIN_COUNTRY
    game_data.os_architecture     = "32"
    game_data.build_number        = "2019121229"

    # --- Réseau --- (opérateur thaïlandais du vrai client, comme les comptes TH ; avant : opérateur français)
    game_data.network_provider            = "TRUE-H"
    game_data.connection_type             = "WIFI"
    game_data.secondary_network_provider  = "TRUE-H"
    game_data.secondary_connection_type   = "WIFI"
    game_data.ip_address                  = "165.169.250.93"

    # --- CPU/GPU/RAM ---
    # mêmes valeurs que le RUDP_C2S_SYSTEM_INFO (1026) envoyé dans la partie : voir LOGIN_CPU_INFO
    game_data.cpu_info          = LOGIN_CPU_INFO
    game_data.total_ram         = LOGIN_TOTAL_RAM
    game_data.gpu_name          = "Adreno (TM) 540"
    game_data.gpu_version       = "OpenGL ES 3.2 (4.5.0 NVIDIA 596.36)"
    game_data.graphics_backend  = "OpenGLES2"
    game_data.max_texture_units = 4095
    game_data.rendering_api     = int(platform)     # entier du proto (un « 4 » texte levait TypeError)
    game_data.gpu_features      = '{"cur_rate":null,"support_etc2":false}'   # field 96

    # --- Écran ---
    game_data.screen_width  = 1600
    game_data.screen_height = 900

    # --- Locale / compte --- (champ 90 « city » : absent du vrai client, plus envoyé)
    game_data.language  = "en"
    user_id = str(device.get("unique_device_id") or "")
    game_data.user_id   = user_id if user_id.startswith("Google|") else "Google|c4d8782a-ea5d-43cc-9691-4c0fb66be40d"
    game_data.unique_id = "7428b253defc164018c604a1ebbfebdf" # field 57

    # --- Auth (issus du token endpoint) ---
    game_data.open_id      = open_id
    game_data.access_token = access_token
    # Champ 30 = 1 : envoyé par le vrai client à CHAQUE MajorLogin et GetLoginData (6/6 du relevé
    # decoded_traffic.jsonl du 17-18/10), absent du bot jusqu'ici.
    game_data.unknown_field_30 = 1

    # --- Plateforme (string côté serveur) ---
    game_data.platform_type = str(platform)   # field 23 = string
    game_data.field_99      = "0" if getlogin else str(platform)
    game_data.field_100     = str(platform)

    # --- Champs numériques hérités --- (voir « EMPREINTE DU CLIENT » plus haut : relevé du 23/10 14:33)
    # 60 / 65 / 67 = espace disque total du téléphone en Mo, 61 / 64 / 66 = ce qu'il en reste : ils bougent au fil
    # des téléchargements du jeu, le serveur ne vérifie donc pas une valeur exacte.
    game_data.field_60 = 128886
    game_data.field_61 = 115389
    game_data.field_62 = 7998
    game_data.field_63 = 5782
    game_data.field_64 = 121959
    game_data.field_65 = 128886
    game_data.field_66 = 121959
    game_data.field_67 = 128886
    # champs 70, 85, 89, 90, 95 et 98 : absents du vrai client (captures du 15/10 et du 23/10), plus envoyés
    game_data.field_73 = 1
    # Champ 85 = choix de l'écran d'accueil (3 = NewbieChoice_VETERAN), envoyé par le client au PREMIER login après
    # l'inscription (capture du 18/10). Le serveur fixe alors le compte en joueur expérimenté (GetLoginData champ 48 :
    # AbTestChoice type 1 = 3, plus de GetNewPlayerGoal) ; sans lui ce premier login le fixe en nouveau joueur (= 1),
    # définitivement (ni un ChooseNewbieChoice ni un champ 85 ultérieurs ne le changent, vérifié en direct).
    if newbie_choice:
        game_data.field_85 = newbie_choice

    # --- APK / libs --- (dossier d'installation de l'APK ; voir « EMPREINTE DU CLIENT » plus haut)
    game_data.library_path = "/data/app/com.dts.freefireth-8rKnVmL1K41kfEhZEf35zA==/lib/arm"
    game_data.field_76     = 1
    game_data.apk_info     = ("b8e0cd5e295eee42f5860d3c86e483dd|"
                              "/data/app/com.dts.freefireth-e7iuj-rXMQmzkybPVOe-Sw==/base.apk")
    game_data.field_78 = 3
    game_data.field_79 = 1

    # --- Champs bytes/obfusqués ---
    game_data.field_92      = 4528
    game_data.marketplace   = "android"
    game_data.encryption_key = ("KqsHTwLedr3dtLEWR8yCTMXtD+L7kqV4dI6m6F1j/Kjjexiqo4bQ2WOHRre6SnMV"
                                "Q8KHVdvMlGZ4GJVCibXLibS/gfVp2PxMgG9lA6TpTciXCFak")
    game_data.total_storage = 111107

    game_data.field_97  = 1

    # --- Nouveaux champs de la capture --- (voir « EMPREINTE DU CLIENT » plus haut)
    # 102 : lié à l'installation de l'APK (voir library_path).
    game_data.unknown_102    = bytes.fromhex(
        "44004640510f5f0553080150440a00410d486a08520f535873584603314d590059403b0e5263"
    )
    game_data.field_104      = 61270
    game_data.field_105      = 1
    # 106 + 107 vont ensemble : 106 = les deux miroirs CDN d'où le client télécharge les ressources hot-update
    # (relevé du 23/10 : dl.cdn et dl-core.cdn, ceux que le vrai client interroge vraiment, voir le journal « ss »)
    # suivis de l'empreinte du lot ; 107 = la version de ce lot.
    game_data.hot_update_urls = (
        "https://dl.bs.freefiremobile.com/live/ABHotUpdates/|"
        "https://core-bs.freefiremobile.com/live/ABHotUpdates/|"
        "9a9a493d643462570dc50320b28533d0"
    )
    game_data.client_version = "1.36b776e2570acf82"

    if getlogin:
        game_data.city = GETLOGIN_CITY                                              # champ 90
    payload = game_data.SerializeToString()
    if getlogin:
        # 91 et 103 n'existent pas dans nexxthug_pb2 : ajoutés encodés, à leur place
        province = GETLOGIN_PROVINCE.encode()
        payload = _pb_insert_raw(payload, {91: _varint(91 << 3 | 2) + _varint(len(province)) + province,
                                           103: _varint(103 << 3) + _varint(1)})
    return await aes_encrypt(payload, AES_KEY, AES_IV)

# ==================== DÉTECTION DE BAN (champ 13 de la réponse MajorLogin) ====================
def _read_varint(data, index):
    """Lit un varint à partir de `index` ; retourne (valeur, nouvel_index)."""
    shift = value = 0
    while index < len(data):
        b = data[index]
        index += 1
        value |= (b & 0x7F) << shift
        if not (b & 0x80):
            return value, index
        shift += 7
        if shift > 63:
            break
    return None, index


def recommend_regions(login_response: bytes) -> List[str]:
    """Champ 7 (répété) de proto.MajorLoginRes = régions proposées au compte (recommend_regions). Absent du schéma
    thunderFF_pb2, donc lu à la main sur les octets DÉJÀ décalés (après l'éventuel préfixe OB55 de 64 octets)."""
    out: List[str] = []
    i = 0
    while i < len(login_response):
        key, i = _read_varint(login_response, i)
        if key is None:
            break
        num, wire = key >> 3, key & 7
        if wire == 0:
            _, i = _read_varint(login_response, i)
        elif wire == 2:
            n, i = _read_varint(login_response, i)
            if n is None:
                break
            seg = login_response[i:i + n]
            i += n
            if num == 7:
                out.append(seg.decode("ascii", "ignore"))
        elif wire == 1:
            i += 8
        elif wire == 5:
            i += 4
        else:
            break
    return out


def _extract_ban_bytes(raw: bytes) -> Optional[bytes]:
    """Repère le tag du champ 13 (wire type 2 => 0x6A) et renvoie les octets du sous-message BanInfo."""
    if not raw:
        return None
    for i in range(len(raw)):
        if raw[i] != 0x6A:
            continue
        length, pos = _read_varint(raw, i + 1)
        if length is None or length <= 0 or length > 4096:
            continue
        end = pos + length
        if end > len(raw):
            continue
        return raw[pos:end]
    return None


def detect_ban(response_content: bytes) -> Optional[AccountBanned]:
    """Analyse la réponse MajorLogin d'un compte sans token : renvoie AccountBanned si un ban est trouvé, sinon None."""
    try:
        ban_bytes = _extract_ban_bytes(response_content)
        if not ban_bytes:
            return None
        info = ban_pb2.BanInfo()
        info.ParseFromString(ban_bytes)
        reason = info.reason or ""
        duration = int(info.duration_seconds or 0)
        timestamp = int(info.timestamp or 0)
        # Un BanInfo vide (tous champs à zéro) n'est pas un ban
        if not reason and duration == 0 and timestamp == 0:
            return None
        if duration > 0:
            d, h = duration // 86400, (duration % 86400) // 3600
            m = (duration % 3600) // 60
            parts = [f"{d}d" if d else "", f"{h}h" if (d or h) else "", f"{m}m"]
            remaining = " ".join(p for p in parts if p)
            label = f"แบนชั่วคราว (เหลืออีก {remaining})"
            return AccountBanned(label, permanent=False, duration_s=duration, reason=reason)
        return AccountBanned("แบนถาวร", permanent=True, duration_s=0, reason=reason)
    except Exception:
        return None


def _http_failure(stage: str, name: str, response, t0: float):
    """Réponse HTTP refusée d'une étape de login : code (HTTP_429, HTTP_5XX…), statut et début du contenu."""
    body = ""
    try:
        body = " ".join(response.text.split())[:160]
    except Exception:
        pass
    # le corps compte autant que le code : un 400 « BR_AUTH_ABNORMAL_GAME_CLIENT » n'est pas un 4xx quelconque
    # (voir LOGIN_CLIENT_REJECTED), et il touche tous les comptes à la fois
    diag.event(stage, name, level="warning", code=diag.classify(f"HTTP {response.status_code} {body}"),
               status=response.status_code, msg=body, dur_ms=(time.perf_counter() - t0) * 1000)
    # vers la session (runner.last_protocol_error) : un HTTP 429 / 5xx du serveur de connexion y est reconnu (pause
    # de tous les logins, pas compté comme échec du compte). Avant : seul le journal le voyait, et le compte finissait
    # en LOGIN_FAILED au bout de max_login_failures essais.
    print_error(f"[{stage}] {name} : HTTP {response.status_code} {body}"[:300])


def _login_ip_region(res) -> str:
    """Champ 4 du MajorLoginRes (ip_region : pays de l'IP vu par le serveur), absent de thunderFF_pb2 : relu dans les
    champs inconnus que le message garde à la sérialisation. "" si absent."""
    try:
        for num, wire, raw in _pb_raw_fields(res.SerializeToString()):
            if num == 4 and wire == 2:
                _, i = _read_varint(raw, 0)
                _, i = _read_varint(raw, i)
                return raw[i:].decode("ascii", "replace").strip().upper()
    except Exception:
        pass
    return ""


# Région annoncée dans le 448 (JOIN_MATCH_POST) : le client officiel IND y met le pays de son IP (MajorLogin champ 4)
# et non la région du compte (capture du 24/10 : compte IND joué depuis la Thaïlande -> « TH »). Les comptes TH
# envoient « TH » de toute façon ; les autres régions gardent la leur faute de capture.
JOIN_REGION_FROM_IP = frozenset({"IND"})


def _join_region(account_data: Optional[Dict], account_region) -> str:
    ip_region = str((account_data or {}).get("ip_region") or "").strip().upper()
    if ip_region and str(account_region or "").strip().upper() in JOIN_REGION_FROM_IP:
        return ip_region
    return account_region


async def send_majorlogin(data, release_version, server_url, details=None, require_region=True):
    """`details` (dict optionnel) : si fourni, on y met details["raw"] = les octets de la réponse déjà décalés
    (après le préfixe OB55), pour que l'appelant lise lui-même recommend_regions (voir ffbot.guest_create).
    `require_region` : par défaut on n'accepte la réponse que si lock_region (champ 2) ET token sont présents.
    Un compte neuf « région pas encore choisie » répond lock_region VIDE + token (JWT) + recommend_regions : pour
    ce cas (ffbot.guest_create) passer require_region=False, on accepte alors un token qui est bien un JWT (« eyJ »)."""
    t0 = time.perf_counter()

    def _accept(p) -> bool:
        tok = getattr(p, "token", "") or ""
        if require_region:
            return bool(getattr(p, "region", "") and tok)
        return bool(tok) and str(tok).startswith("eyJ")   # JWT valide même sans lock_region
    try:
        url = f"{server_url}MajorLogin"
        req_headers = headers.copy()
        req_headers["ReleaseVersion"] = release_version
        response = await client.post(url, headers=req_headers, data=data)
        if response.status_code != 200:
            _http_failure("LOGIN", "majorlogin_failed", response, t0)
            return None
        response_content = response.content
        if len(response_content) < 40:
            diag.event("LOGIN", "majorlogin_failed", level="warning", code="HTTP_BAD_RESPONSE",
                       size=len(response_content), msg=response_content.hex()[:120],
                       dur_ms=(time.perf_counter() - t0) * 1000)
            return None
        dur_ms = (time.perf_counter() - t0) * 1000

        # 1. Direct parse
        res_proto = thunderFF_pb2.MajorLoginRes()
        try:
            res_proto.ParseFromString(response_content)
            if _accept(res_proto):
                diag.event("LOGIN", "majorlogin", level="debug", parse="direct", dur_ms=dur_ms)
                if details is not None:
                    details["raw"] = response_content
                return res_proto
        except Exception:
            pass

        # 2. OB55 64-byte header offset check
        if len(response_content) > 64:
            try:
                res_proto = thunderFF_pb2.MajorLoginRes()
                res_proto.ParseFromString(response_content[64:])
                if _accept(res_proto):
                    diag.event("LOGIN", "majorlogin", level="debug", parse="offset64", dur_ms=dur_ms)
                    if details is not None:
                        details["raw"] = response_content[64:]
                    return res_proto
            except Exception:
                pass

        # 3. Dynamic offset search for OB55 compatibility
        for offset in range(min(128, len(response_content))):
            try:
                candidate = thunderFF_pb2.MajorLoginRes()
                candidate.ParseFromString(response_content[offset:])
                if _accept(candidate):
                    diag.event("LOGIN", "majorlogin", level="debug", parse=f"offset{offset}", dur_ms=dur_ms)
                    if details is not None:
                        details["raw"] = response_content[offset:]
                    return candidate
            except Exception:
                pass

        # Aucune adresse avec token : le compte est peut-être banni. On analyse les octets bruts
        # (indépendant du parsing protobuf, qui peut échouer sur une réponse de ban) avant d'abandonner.
        ban = detect_ban(response_content)
        if ban is not None:
            diag.event("LOGIN", "banned", level="warning", code="BANNED", permanent=ban.permanent,
                       ban_s=ban.duration_s, msg=f"{ban.label} {ban.reason}".strip())
            raise ban

        # Pas de token/region et pas de ban reconnu : échec de login explicite, avec le corps brut dans le journal
        # (hex + caractères lisibles) pour identifier la réponse. Avant : l'objet vide était rendu et GetLoginData
        # était appelé avec une URL vide (« ValueError: unknown url type: '/GetLoginData' ») — 5 essais puis compte
        # « ล้มเหลว », sans trace de ce que le serveur avait répondu (97-100 octets vus les 20-21/10).
        printable = "".join(chr(b) if 32 <= b < 127 else "." for b in response_content)
        diag.event("LOGIN", "majorlogin_no_token", level="warning", code="LOGIN_NO_TOKEN",
                   size=len(response_content), hex=response_content.hex()[:600], text=printable[:200],
                   msg="MajorLogin ไม่มี token/region", dur_ms=dur_ms)
        print_error(f"[LOGIN] MajorLogin ไม่ส่ง token/region ({len(response_content)} ไบต์) : {printable[:60]}"[:300])
        return None
    except AccountBanned:
        raise
    except Exception as e:
        diag.event("LOGIN", "majorlogin_failed", level="warning", exc=e, dur_ms=(time.perf_counter() - t0) * 1000)
        print_error(f"[LOGIN] MajorLogin : {e!r}"[:300])
        return None

async def send_getlogin(data, base_url, token, release_version, stage: str = "LOGIN"):
    t0 = time.perf_counter()
    try:
        if not base_url or not token:
            # garde-fou : sans URL/token (MajorLogin sans token), ne pas appeler « /GetLoginData » tout nu
            diag.event(stage, "getlogin_failed", level="warning", code="LOGIN_NO_TOKEN",
                       msg="ไม่มี URL/token จาก MajorLogin สำหรับ GetLoginData")
            print_error(f"[{stage}] GetLoginData : ไม่มี URL/token จาก MajorLogin")
            return None
        url = f"{base_url.rstrip('/')}/GetLoginData"
        req_headers = headers.copy()
        req_headers["ReleaseVersion"] = release_version
        req_headers['Authorization'] = f"Bearer {token}"
        req_headers['Host'] = "clientbp.ppmainecoonghj.com"
        response = await client.post(url, headers=req_headers, data=data)
        if response.status_code != 200:
            print_error(f"GetLoginData : HTTP {response.status_code}")    # login, ou relevé d'EXP
            _http_failure(stage, "getlogin_failed", response, t0)
            return None
        response_content = response.content
        diag.event(stage, "getlogin", level="debug", size=len(response_content),
                   dur_ms=(time.perf_counter() - t0) * 1000)

        res_proto = thunderFF_pb2.GetLoginDataRes()
        parsed_successfully = False
        try:
            res_proto.ParseFromString(response_content)
            if res_proto.functional_addrs or res_proto.informational_addrs:
                parsed_successfully = True
        except Exception:
            pass

        if not parsed_successfully:
            for offset in range(min(128, len(response_content))):
                try:
                    candidate = thunderFF_pb2.GetLoginDataRes()
                    candidate.ParseFromString(response_content[offset:])
                    if candidate.functional_addrs or candidate.informational_addrs:
                        res_proto = candidate
                        break
                except Exception:
                    pass

        dict_res = {}
        try:
            parsed = Parser().parse(response_content.hex())
            dict_res = await parse_results(parsed)
        except Exception:
            pass

        return res_proto, dict_res
    except Exception as e:
        print_error(f"GetLoginData : {e!r}")
        diag.event(stage, "getlogin_failed", level="warning", exc=e, dur_ms=(time.perf_counter() - t0) * 1000)
        return None

async def build_tcp_startup_packet(account_id, token, server_time, key, iv, region="BD", typ='OnLine'):
    uid_hex = f"{int(account_id):016x}"
    timestamp_hex = f"{int(server_time):08x}"
    encode_token = token.encode()
    encrypted_packet = (await aes_encrypt(encode_token, key, iv)).hex()
    encrypted_packet_length = f"{len(encrypted_packet) // 2:08x}"
    reg = str(region).upper() if region else "BD"
    # 2e octet : celui du script d'origine (BD 19, IND 14, sinon 15) ; 02 en TH avec GW_CLIENT_INIT (client officiel)
    rb = 0x02 if GW_CLIENT_INIT and reg == "TH" else (0x19 if reg == "BD" else (0x14 if reg == "IND" else 0x15))
    if typ == 'OnLine':
        return f"71{rb:02x}{uid_hex}{timestamp_hex}00000000{encrypted_packet_length}{encrypted_packet}"
    else:  # ChaT / Informational
        return f"92{rb:02x}{uid_hex}{timestamp_hex}{encrypted_packet_length}{encrypted_packet}"

async def send_keep_alive(region="BD"):
    """Maintien de connexion (2 octets) : « 02 02 » du client officiel TH (captures des 16 et 17/10, passerelle et
    chat), « 02 14 » du client officiel IND (24/10), voir GATEWAY_REGION_BYTE."""
    return bytes([0x02, gateway_region_byte(region)])

# Paquets StartMatch déchiffrés, un par mode. Champs de « main » (2) : 1 = cartes proposées, 2 = mode,
# 7 = IDC1-3 (région réécrite), 12 = bloc client (12.8 = version, réécrite).
#   Lone Wolf     : mode 43, carte 11 (paquet d'origine).
#   Battle Royale : mode 1, carte 1 ; capture du client officiel 1.132.9 (05/10, compte SAC).
#                   Le champ 12.1 (128 caractères) est arrivé tronqué d'un caractère à la copie :
#                   un « 0 » a été réinséré en 16e position pour que le paquet soit décodable.
#   Clash Squad   : mode 15, carte 1 ; capture du client officiel 1.132.9 (05/10, compte SAC, en-tête 0313).
_START_MATCH_LONE_WOLF = bytes.fromhex("080112800a0a010b102b3a110a044944433110aa011a064555524f50453a100a044944433210311a064555524f504540014a0801090a0b1219202758016291090a8001303838463832424630324139363736373032303130313030303030303030303030303136303030313030313530303032323246393745454530463030303030303436373632353134303030303030303030303030303030303030303030303030303030303030303030303030303066663030303030303030636163666131366410241afb02735d5e571400024a775d45414d1a041b1c001f11010449715f4243481a001e1d071c1703004b1a4066785c524570735c51486775421b5c5a4c07504042685a63610816054e19025e75196001477c015165406370195f5547404e4550640103020f1304064863754268676c755f65576e40467e5f0a417a4701026d675d6e73670b1108495a4c6a0b78470b740065645e525a057258425f584a447d4e6759440c11044e7c596d7f4b625f7d04055a47505c4e1d6b5b4107447d7201057d7f0f14084e430457674f7e517d72015172415d027473577c4d615f79535256780911030f4d5e027a797f614165067806505d53777750475e75064257076500460817014e741e7e5078487e7a7c465e7669767153497064605a7376677773550d160148037e18675966787f4c42607a645f577e7b441b460776026b18685d0b110205490060020f70676175654674706671797f41067346677c4e06585e780f15074c57047b40517075415f6364027259674b5b0166407f7340600407770a22047a5d5c52300b3a0a167305067162727516134208312e3133302e3232480350015ae90403626253513635686e556f4e36416456324b796f566c636f477776484f624e56526c4d727073504b4f43654177616848494176795556497273743752737149734a7a786b3247525268377a2f637664626d504f6a73552f79626d38547a4c69586d2f474351696d494b53486833447955726f39515152756c34545350626d6d624b7949565937545671577059455372323646572f59624578507338514f706d317372785455736c30796a434144444d4f34616a654b615753366361496c554b4963797a494e396d52516f715277687939797257476d337a644345337a6a61436f492f5a585233656f65365a42647a64677654636b6b665733356e4d4c6a6a565072564b6433523172756174394e50514150724a5546627859696c4c5a3859707336654d5447666b6649793574666a526c314d4648706b51774c6373374439656378566c41636f374e664f6d2b30654756466c4434744478706771385533595973587645384842502f70666c767a737138316a32524f4d7857437556445442492f684735625462773166456e4249725162762b636144775147696f74554e316d4c4b77734379456f4766706746614251457645672b736a764c4c78704743334c304a5344532f74526169504354553344374e6249306547516651622f5a466f4c36455630775a324d6f583932414c572f5049752f56634663584e70596b356f7966326151416a536971486a2f363276354843644f525551303578754e6171795251625653704654303137655237675255636b4966366c6f447476342b514e4a4670766d74757077707774396a5a5974437a4b56743657726d6e36785837706658456251555434684f3758a201050803108703a201050804108103a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815")
_START_MATCH_BR = bytes.fromhex("080112ab0b0a010110013a0e0a044944433110b8171a035341433a0e0a044944433210b8171a035341433a0e0a044944433310b8171a0353414340014a0f01030407090a0b1216191a201d2729580162920a0a80013038424633334234384233394630423030323033313530313131313130303030303037303030303330303644303032323833394433383334304432453243463134363736323531343131303130343036333865383438646330653734386333663661613034643831303030303030666630363036303430326361636661313664109f021ab9037e585852130902480458510d010604530f54570f000a0d04020f0709050d030c020c045703540b571707084f7d5c4443491002180710100903480756767007596142627e7e65494e70625870770e770c627b0a7b790b1a02447b5965517e51794c76677f765256747e4b5f78585c5a5b5556634f0f1750565d4c1e677f1d7f42440745646a664407434c574e5a4c64134b7c4f47016b7b7e52466a1e420f0d1b03074a4f5956447e665b68776e445a41524b017b784c79765a6a507b575b0a13004e4001691c536266186a0176476c534053437d5c49137c1f594140790c17054c13744c527f421740555f7f566846414a5e5a03040e644002465f700e1b08486669797e1b436d621750596e7b424b7a7373185269017f434a07000b1a02004d7a5c5879067a456918560251026a746179640a0001550774625d5509150a4f701a0553636b03704012015e055c610559471f590a7413771f60000511004a5f4a7f50437d697903656f0c4169687202634c511b4543047f74710a130a0248477e0513505d457e5f7e465d6c674a43410607407c0743507c4f70091405445d4245507b5e5f5f76425a47591d6d745041577d614f1d0d62634405220478565d5d300c3a0913510104067c6b171c4207312e3133322e39480350015aad05036262535136796c7a32673030416456324b796f566c545259504a79415968455968394a7256346e537a32595835514f6776586c4f6141706d74334c6869546c38464b4a783731704a323361724a33585172507847694b4a737a4f446547456a36457443786c6f424e744a336f484d654673315479786b714169665048674b774a6267524f41765756593476362b39332b4c354e43306e31485133396975466a5a4a55516c665a624645736244577257564e765479354d37467377574a4c6a654d70736c4e6e6b397179454a4b426c2b4f70386370652b6f306e6c4468345a305554355177734f3741516479676837424130374739617046696b465a77686c5975704b6f6d745277796e7878394349446d76666135662f5939554847347a6c794b4933496b6358677a594b7534305153327857363561746a30616f36572f303674667475736e33366d7a586941675a7a58695a507a2f2f5439617333424739576e79696f35756c426545376842382b65673137514942596e416a76774c4d79525a62784a4e316f44386b727267703072376a6936666f6a62624d7a445754662f43595658714c5364687a334a4c4732686939386c3959754b512b31693147542b6372656650733874542f396e7a626b4e6d4776613757714b7a68326f52546e4a49614134534b696c6551676d574f6f584d66346c4c75324b6e646a77613467384d6168535171437a6273484d466759494d2f476b53496f4d6d3058727a743143432f56786c39754e51332f6a5752684445747a514c6e743037656632614f4849375073453675547444634c6f4f52546d65674b4972576771357779613170444d4e5534717479623562484b35466d7475687653535934694539475576666f42476c7877594e426e73346a6c38417a6263386b3051334f79382b6a655a6b466d5463684e4e6f4459354b642b6b3da201050803108a03a201050804108703a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815aa0115615f31353537383038373630303234303631333532")
_START_MATCH_CLASH_SQUAD = bytes.fromhex("080112aa0b0a0101100f3a160a044944433110ffffffffffffffffff011a035341433a160a044944433210ffffffffffffffffff011a035341433a160a044944433310ffffffffffffffffff011a0353414340014a0f01030407090a0b1216191a201d2729580162f9090a8001303830333830313734383833393733423032303130303030303030303030303030303036303030313030303530303030343043413338333430463030303030303436373632353134303030303030303030303030303030303030303030303030303030303030303030303030303066663030303030303030636163666131366410381ab9037e585852130902480458510d010604530f54570f000a0d04020f0709050d030c020c045703540b571707084f7d5c4443491002180710100903480756767007596142627e7e65494e70625870770e770c627b0a7b790b1a02447b5965517e51794c76677f765256747e4b5f78585c5a5b5556634f0f1750565d4c1e677f1d7f42440745646a664407434c574e5a4c64134b7c4f47016b7b7e52466a1e420f0d1b03074a4f5956447e665b68776e445a41524b017b784c79765a6a507b575b0a13004e4001691c536266186a0176476c534053437d5c49137c1f594140790c17054c13744c527f421740555f7f566846414a5e5a03040e644002465f700e1b08486669797e1b436d621750596e7b424b7a7373185269017f434a07000b1a02004d7a5c5879067a456918560251026a746179640a0001550774625d5509150a4f701a0553636b03704012015e055c610559471f590a7413771f60000511004a5f4a7f50437d697903656f0c4169687202634c511b4543047f74710a130a0248477e0513505d457e5f7e465d6c674a43410607407c0743507c4f70091405445d4245507b5e5f5f76425a47591d6d745041577d614f1d0d62634405220478565d5d300c3a0913510104067c6b171c4207312e3133322e39480350015a9505036262535136787635707a6762416456324b796f566c56417276654f45575642464756755a41366675544a766e7176303156744f744a5779564b6b78497a436a76685731705873416535465544395a7142634f735a353747306a64542f33536d4e39696843366979387338713974464b72542b6169473644584a4830676c44485564304437444a4336465671596646514753567770695831392b413869647a4e6538325631427032356442473871447a645754447a684a365576596f3272623145425a44506643676c68326748795773784b6a6e56366847426c56376943614f34707a423257736c4b327a4e65527a46454c6b3875704c515635365a7062774834356d6a52443654667431454c6c3738736872704753746a3348727965634a7165734d6547646b356f6c355045325a526863357750564b693267546769712f556936307a4b70514837722b63775456575a42396f7939396f79724f394a646c775a646464424554784b31394135376e396d78573834335059684539352f304c4b676d4e614d426c336c496b6461754b325546786f63464a34382b396d3966704c486b6f504e5977706162685135544161344c34427359576872366c41702f675379512f2f48434b5a6d682f70464d514b7131546a4e4b6942366d39397478627a7a766a594b574e535645694a504e34334879494561764175545a6350726d6c6a57304f462b576a3277394234356e6f45456e75684f39384e576949366a35386c356a46557a35443738764f54387a6733477a44305767396f6676386a76664252426c4f6653366a4e776b6d6a6649784b777432504f4b6e4e7744754f4f7a51775537417946476658694b3375666543494d43416f78707268583544363635573779444746486a426f7079726e64306d665164557863a201050803108a03a201050804108703a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815aa0115615f31353537383038373630303234303631333532")
_START_MATCH_BR_EVOLUTION = bytes.fromhex("080112d10b120101185520032a02656e42150a044944433410ffffffffffffffffff011a024d4542150a044944433110ffffffffffffffffff011a024d4542150a044944433210ffffffffffffffffff011a024d4542150a044944433310ffffffffffffffffff011a024d454801520b0107090a0b12191a2027295801680172950a0a8001303830373830423736434643394241393032303130303030303030303030303030303036303030313030303530303030423430363141443230463030303030303436373632353134303030303030303030303030303030303030303030303030303030303030303030303030303066663030303030303030636163666131366410391ab9037f585e521b09034f0a51520c0100045b0f55500109090c04040f0f09040a0d05010d0451035c0b561009014c7c5c42434110031f09191308034e075e767100576841637e7865414e71655679740f770a62730a7a7e051301457b5f65597e507e427f647e7654567c7e4a5876515f5b5b53566b4f0e105e5f5e4d1e617f157f4343094c676b6642074b4c5649544567124b7a4f4f016a7c705b456b1e440f051b0200445a714d6067475c7b495f62555c097a6643130e66784c6a4277766b0a1b004f470f601f5262601862017740625a4352437b5c41137d18574843780c1105447c72517c5a484153795b170141726f037d4e404a70525f54046d7d0d1a084e00526d46554b49647b4278715f600542497c636f437f6f74597966051301014d7a4d727240640855080159007f425e755e4c6469604254666a54030e1b034c711a03536b6b02774e1b025f055a610d59461857037712771960080510074456497e50457d61790262610542686874026b4c501c4b4a077e74770a1b0a034f49770612505b45765f7f415365644b4347060f407d004d597f4e700f140d445c454b59785f5f59764a5a465e1364775141517d694f1c0a6c6a47042204765f5e5c300c3a081c0a6b527276141d4208312e3132322e3231480350015ab1050362625351363248756e415932416456324b796f566c6242694a766a52584f2b63595056656f5166322f6d42386a4962417065752b6c36756543536e55532f424463516c69564a384b7144383776344130542f2b42705951446e33496d58586a68316176567a65324b5a504e72764a64393335454a456343467872546b716b385634344a7563304a4775703555344e616a77693736775a4d4554386457644430525870337342612f51346f5a2b393133773568387a5972742f2b516e6f6b49596b4136415a4d31574b7a456d5261696b465a555662615a75673342555a6f647638466a7438556a5076396f3252764f3946694e662f516c4a53624d5744425862516e3066434d3067536e5562574d786b7934416943717a384d4b4567543242535a534f384b44516f5553556d795632737970436a4d617632504e66647857476730306b726f32627a6d4e6e63455061756e4e5452714f614377474e6d344b47325a5352666478446b322b45776e566479783537573548545a44415339694947424b6e4671693456474137365768455a34363032387a464746546d72416d796551506b4d6b6a5754336a36617a6a694b314f3055643069466d54644d73633067623472515938362f49527351796c664e617238782b556750526d7a4e634433503579326e5746626142794431394a6f54357a56554763462b514b64667832313655762b4d7a677a764147345276437736336c66414b73496a636c696c6e684c506b4868726339364f702b796450726d3556497a5968376a4e78764d68594a542f2b724646313142362f586231305a56765056724637704c4f47342b4d5470486e71756351527470582f31626e4c704b66514541547739446548594f6d63473770714e356d5849355166397a42714d4567763534387266537153657148442b37674b50736f64537546487147312f5576513d3d9801c902aa0104374f5219c201050803108a03c201050804108703c20105080510c001c20105081d10cc01c2010408161078c20105080e10af01c201020815")
_START_MATCH_PAYLOADS = {"lone_wolf": _START_MATCH_LONE_WOLF, "br": _START_MATCH_BR,
                         "clash_squad": _START_MATCH_CLASH_SQUAD, "br_evolution": _START_MATCH_BR_EVOLUTION}

# Paquets StartMatch par région dans match_packets.json ({"servers": {"<RÉGION>": {"<mode>": "<hex>"}}}) :
# si la région du compte y figure pour le mode cherché, on envoie SON paquet, au nom de sa région (liste IDC
# et en-tête de la région du compte). Sinon : gabarit intégré ci-dessus (_START_MATCH_PAYLOADS), recherche
# en BD comme fast-old-ui. "enabled": false coupe le fichier (tout repasse sur les gabarits intégrés).
# Le fichier est relu à chaud quand il change ; une entrée invalide est signalée une fois puis ignorée.
MATCH_PACKETS_FILE = os.path.join(_ROOT_DIR, "match_packets.json")
FALLBACK_SEARCH_REGION = "BD"   # région de recherche avec les gabarits intégrés (comportement d'origine)
# Recherche BR dans la région du compte au lieu de BD (gabarit intégré). StartMatch du client officiel TH déchiffré le
# 17/10 : UNE entrée IDC {IDC1, ping 4-5 ms, "TH"} (gabarit : IDC1-3 à 3000 ms, réécrites en BD), pas de champ 2.21
# (« a_1557808760024061352 », reste du gabarit), trame [03][02][longueur 4 octets] comme tous ses messages (le bot :
# 03 19 00 + 3 octets). Ainsi construit : 1 397 octets en clair -> 1 408 chiffrés, la taille du StartMatch du vrai
# client TH du 19/10 14:13. NATIVE_SEARCH (.env) : 0 = désactivé (recherche BD comme avant) ; 1 = tous les comptes des
# régions NATIVE_SEARCH_REGIONS ; sinon ID de jeu séparés par des virgules (essai sur quelques comptes).
_NATIVE_SEARCH = os.environ.get("NATIVE_SEARCH", "0").strip()
NATIVE_SEARCH_IDS = frozenset(x.strip() for x in _NATIVE_SEARCH.split(",")
                              if x.strip() and _NATIVE_SEARCH not in ("0", "1"))
NATIVE_SEARCH_REGIONS = frozenset({"TH", "IND"})

# ---------- réglages du jeu modifiables depuis la page (หลังบ้าน → ตั้งค่าระบบ) ----------
# Avant dans .env ; maintenant dans les réglages du site (site_settings.TUNABLE_KEYS), .env ne gardant que l'essentiel
# (port, base, comptes, workers…). Au 1er démarrage, une valeur encore écrite dans .env est reprise une fois
# (tunables_from_env) ; ensuite seule la page compte. Appliqués au processus principal (apply_server) et, avec chaque
# partie (opts["tunables"]), au worker qui la joue : effet immédiat pour les nouvelles parties.
# réglage -> (variable du module, conversion) ; « flag » : variable texte "1" / "0" (+ liste d'ID de test vidée)
_TUNABLES = {
    "br_leave_after_s": ("BR_LEAVE_AFTER_S", float, "BR_LEAVE_AFTER_S"),
    "br_leave_on_death": ("_LEAVE_ON_DEATH", "flag", "BR_LEAVE_ON_DEATH"),
    "br_leave_hp": ("BR_LEAVE_HP", int, "BR_LEAVE_HP"),
    "br_death_max_s": ("BR_DEATH_MAX_S", float, "BR_DEATH_MAX_S"),
    "br_insta_leave": ("_INSTA_LEAVE", "flag", "BR_INSTA_LEAVE"),
    "br_no_data_s": ("BR_NO_DATA_S", float, "BR_NO_DATA_S"),
    "br_no_data_kb": ("BR_NO_DATA_KB", int, "BR_NO_DATA_KB"),
    "native_search": ("_NATIVE_SEARCH", "flag", "NATIVE_SEARCH"),
    "udp_loading_end": ("UDP_LOADING_END", bool, "UDP_LOADING_END"),
    "udp_join_seq": ("UDP_JOIN_SEQ", bool, "UDP_JOIN_SEQ"),
    "udp_join_unrel": ("UDP_JOIN_UNREL", bool, "UDP_JOIN_UNREL"),
    "udp_join_replay": ("UDP_JOIN_REPLAY", bool, "UDP_JOIN_REPLAY"),
    "udp_state_sync": ("UDP_STATE_SYNC", bool, "UDP_STATE_SYNC"),
    "cs_chase": ("CS_CHASE", bool, "CS_CHASE"),
    "udp_time_sync": ("UDP_TIME_SYNC", bool, "UDP_TIME_SYNC"),
    "udp_quit_on_leave": ("UDP_QUIT_ON_LEAVE", bool, "UDP_QUIT_ON_LEAVE"),
    "udp_quit_grace_s": ("QUIT_GRACE_S", float, "UDP_QUIT_GRACE_S"),
    "udp_ack_delay_s": ("UDP_ACK_DELAY_S", float, "UDP_ACK_DELAY_S"),
    "join_token_split": ("JOIN_TOKEN_SPLIT", int, "JOIN_TOKEN_SPLIT"),
    "activity_lobby_calls": ("ACTIVITY_LOBBY_CALLS", bool, "ACTIVITY_LOBBY_CALLS"),
    "lobby_prematch_calls": ("LOBBY_PREMATCH_CALLS", bool, "LOBBY_PREMATCH_CALLS"),
    "activity_rewards_enabled": ("ACTIVITY_REWARDS_ENABLED", bool, "ACTIVITY_REWARDS_ENABLED"),
    "equip_character": ("EQUIP_CHARACTER", bool, "EQUIP_CHARACTER"),
    "gw_anticheat_report": ("GW_ANTICHEAT_REPORT", bool, "GW_ANTICHEAT_REPORT"),
    "gw_anticheat_oracle": ("GW_ANTICHEAT_ORACLE", str, "GW_ANTICHEAT_ORACLE"),
    "strip_device_session_key": ("STRIP_DEVICE_SESSION_KEY", bool, "STRIP_DEVICE_SESSION_KEY"),
    "cs_skill_unreliable": ("CS_SKILL_UNRELIABLE", bool, "CS_SKILL_UNRELIABLE"),
    # ajoutés le 08/11 (page Settings du Team Bot) : lus par les parties au fil de l'eau
    "cs_skill_test": ("CS_SKILL_TEST", bool, "CS_SKILL_TEST"),
    "cs_skill_relmatch": ("CS_SKILL_RELMATCH", bool, "CS_SKILL_RELMATCH"),
    "cs_skill_per_round": ("CS_SKILL_PER_ROUND", int, "CS_SKILL_PER_ROUND"),
    "cs_skill_every_s": ("CS_SKILL_EVERY_S", float, "CS_SKILL_EVERY_S"),
    "cs_drone_range_m": ("CS_DRONE_RANGE_M", float, "CS_DRONE_RANGE_M"),
    "cs_route": ("CS_ROUTE", bool, "CS_ROUTE"),
    "cs_walkmap": ("CS_WALKMAP", bool, "CS_WALKMAP"),
    "cs_loop_walk": ("CS_LOOP_WALK", bool, "CS_LOOP_WALK"),
    "cs_tp_ack": ("CS_TP_ACK", bool, "CS_TP_ACK"),
    "cs_pack": ("CS_PACK", bool, "CS_PACK"),
    "cs_straight": ("CS_STRAIGHT", bool, "CS_STRAIGHT"),
    "cs_wall_turn": ("CS_WALL_TURN", bool, "CS_WALL_TURN"),
    "cs_lane": ("CS_LANE", bool, "CS_LANE"),
    "cs_zone_first": ("CS_ZONE_FIRST", bool, "CS_ZONE_FIRST"),
    "cs_heal": ("CS_HEAL", bool, "CS_HEAL"),
    "cs_heal_hp": ("CS_HEAL_HP", int, "CS_HEAL_HP"),
    "cs_buy": ("CS_BUY", bool, "CS_BUY"),
    "cs_item_channel": ("CS_ITEM_CHANNEL", str, "CS_ITEM_CHANNEL"),
    "cs_foe_trace": ("CS_FOE_TRACE", bool, "CS_FOE_TRACE"),
    "udp_capture": ("UDP_CAPTURE", int, "UDP_CAPTURE"),
    "server_max_matches": ("SERVER_MAX_MATCHES", int, "SERVER_MAX_MATCHES"),
    "load_guard_lag_ms": ("LOAD_GUARD_LAG_MS", int, "LOAD_GUARD_LAG_MS"),
    "load_guard_resume_ms": ("LOAD_GUARD_RESUME_MS", int, "LOAD_GUARD_RESUME_MS"),
}
_TUNABLE_ID_LISTS = {"_LEAVE_ON_DEATH": "BR_LEAVE_ON_DEATH_IDS", "_INSTA_LEAVE": "BR_INSTA_LEAVE_IDS",
                     "_NATIVE_SEARCH": "NATIVE_SEARCH_IDS"}
# incrémenté quand apply_tunables change une valeur : les parties en cours relisent alors leurs réglages de départ
# (BR_LEAVE_*, voir _leave_plan) sans attendre la partie suivante
_TUNABLES_GEN = 0


def tunables() -> Dict[str, Any]:
    """Valeurs en service (réglage -> valeur), envoyées avec chaque partie au worker."""
    g = globals()
    return {key: (g[attr] == "1") if kind == "flag" else kind(g[attr]) for key, (attr, kind, _) in _TUNABLES.items()}


def tunables_from_env() -> Dict[str, Any]:
    """Réglages encore écrits dans .env (reprise unique au 1er démarrage, voir SiteSettings.init_server)."""
    cur = tunables()
    return {key: cur[key] for key, (_, _, env) in _TUNABLES.items() if os.environ.get(env, "").strip()}


def apply_tunables(values: Optional[Dict[str, Any]]) -> None:
    """Réglages de la page -> variables du module (processus principal ou worker). Appelé au lancement de chaque partie
    et, en direct, quand la page enregistre (worker : message « tunables », voir udp_workers)."""
    global _TUNABLES_GEN
    g = globals()
    changed = False
    for key, value in (values or {}).items():
        spec = _TUNABLES.get(key)
        if spec is None or value is None:
            continue
        attr, kind, _ = spec
        try:
            if kind == "flag":
                # inchangé : la liste d'ID de test éventuelle (.env) est gardée
                if (g[attr] == "1") != bool(value):
                    g[attr] = "1" if value else "0"
                    g[_TUNABLE_ID_LISTS[attr]] = frozenset()
                    changed = True
            else:
                new = kind(value)
                if g[attr] != new:
                    g[attr] = new
                    changed = True
        except (TypeError, ValueError):
            continue
    if changed:
        _TUNABLES_GEN += 1


def _leave_plan(mode: str, account_id: Any, owner_uid: Any) -> Tuple[float, bool, bool, int]:
    """Départ d'une partie BR d'après les réglages en service : (leave_after_s, death_watch, insta, leave_hp)."""
    is_br = mode in BR_MODES
    leave_after_s = 0.0 if mode in STAY_TO_END_MODES else BR_LEAVE_AFTER_S
    # départ après la mort (BR_LEAVE_ON_DEATH) : BR_DEATH_MAX_S devient le départ en vie de secours
    death_watch = is_br and mode not in STAY_TO_END_MODES and _leave_on_death(account_id, owner_uid)
    # « ตายปุ๊บออกปั๊บ » (BR_INSTA_LEAVE) : départ à l'annonce de la mort, pas à PV bas
    insta = is_br and mode not in STAY_TO_END_MODES and _insta_leave(account_id, owner_uid)
    leave_hp = 0 if insta else BR_LEAVE_HP
    if death_watch or insta:
        leave_after_s = BR_DEATH_MAX_S
    return leave_after_s, death_watch, insta, leave_hp


_match_packets_memo: Dict[str, Dict[str, bytes]] = {}
_match_packets_mtime: Optional[float] = None


def _load_match_packets() -> Dict[str, Dict[str, bytes]]:
    """match_packets.json -> {RÉGION: {mode: paquet}} validé (relu seulement si le fichier change)."""
    global _match_packets_memo, _match_packets_mtime
    try:
        mtime = os.path.getmtime(MATCH_PACKETS_FILE)
    except OSError:
        _match_packets_memo, _match_packets_mtime = {}, None
        return _match_packets_memo
    if mtime == _match_packets_mtime:
        return _match_packets_memo
    _match_packets_memo, _match_packets_mtime = {}, mtime
    try:
        with open(MATCH_PACKETS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        servers = data.get("servers") if isinstance(data, dict) else None
        if not isinstance(servers, dict):
            raise ValueError('clé "servers" absente')
    except Exception as e:
        print_error(f"match_packets.json illisible ({e}) : gabarits intégrés")
        return _match_packets_memo
    if data.get("enabled", True) is False:
        print_info("match_packets.json désactivé (\"enabled\": false) : gabarits intégrés")
        return _match_packets_memo
    packets: Dict[str, Dict[str, bytes]] = {}
    for server, modes in servers.items():
        if not isinstance(modes, dict):
            continue
        for mode, hx in modes.items():
            if mode not in _START_MATCH_PAYLOADS or not hx:
                continue
            try:
                payload = bytes.fromhex(str(hx).strip())
                thunderFF_pb2.StartMatch().ParseFromString(payload)
            except Exception as e:
                print_error(f"match_packets.json : paquet {server}/{mode} invalide ({e}), ignoré")
                continue
            packets.setdefault(str(server).strip().upper(), {})[mode] = payload
    _match_packets_memo = packets
    print_info("match_packets.json : " + (", ".join(f"{r} ({'/'.join(m)})" for r, m in packets.items()) or "aucun paquet"))
    return packets


def _pb_raw_fields(data: bytes):
    """Champs protobuf de `data` : [(numéro, type, octets du champ clé comprise)]."""
    i, out = 0, []
    while i < len(data):
        start = i
        key, i = _read_varint(data, i)
        if key is None:
            raise ValueError("StartMatch : varint invalide")
        wire = key & 7
        if wire == 0:
            _, i = _read_varint(data, i)
        elif wire == 2:
            ln, i = _read_varint(data, i)
            i += ln
        elif wire in (1, 5):
            i += 8 if wire == 1 else 4
        else:
            raise ValueError(f"StartMatch : type {wire}")
        out.append((key >> 3, wire, data[start:i]))
    return out


def _with_match_type(payload: bytes, match_type: int, maps: Optional[bytes] = None,
                     mode_id: Optional[int] = None) -> bytes:
    """StartMatch avec le champ 8 de « main » (2) remplacé par `match_type` et, si `maps` / `mode_id` sont donnés, la
    liste de cartes (champ 1) / le mode (champ 2) remplacés ; les autres champs octet pour octet (le schéma thunderFF
    ne les déclare pas)."""
    top = []
    for num, wire, raw in _pb_raw_fields(payload):
        if num == 2 and wire == 2:
            body = raw[len(_varint((2 << 3) | 2)):]
            _, body_start = _read_varint(body, 0)
            main, placed = [], False
            for n, w, r in _pb_raw_fields(body[body_start:]):
                if n == 1 and w == 2 and maps is not None:
                    r = _varint((1 << 3) | 2) + _varint(len(maps)) + maps
                if n == 2 and w == 0 and mode_id is not None:
                    r = _varint(2 << 3) + _varint(mode_id)
                if n == 8 and w == 0:
                    r, placed = _varint(8 << 3) + _varint(match_type), True
                elif n > 8 and not placed:
                    main.append(_varint(8 << 3) + _varint(match_type))
                    placed = True
                main.append(r)
            if not placed:
                main.append(_varint(8 << 3) + _varint(match_type))
            main_bytes = b"".join(main)
            raw = _varint((2 << 3) | 2) + _varint(len(main_bytes)) + main_bytes
        top.append(raw)
    return b"".join(top)


# Session key mismatch fix: the static device block (field 12 of StartMatch.main) carries an encrypted
# session key in sub-field 11 (661 bytes) from an old capture. The match server decrypts it and expects
# all RUDP after Thunder/Sharma to use THAT key. The bot encrypts with a different key -> mismatch ->
# server drops every packet after order 1. Stripping field 11 makes the server fall back to the match
# key (UDPSession::GetPayloadKey) for all RUDP, which is what the bot already uses.
STRIP_DEVICE_SESSION_KEY = os.environ.get("STRIP_DEVICE_SESSION_KEY", "1").strip().lower() not in ("0", "false", "no", "off")


def _strip_device_session_key(payload: bytes) -> bytes:
    """Remove field 11 (session key blob) from the device block (field 12) inside StartMatch.main."""
    top = []
    for num, wire, raw in _pb_raw_fields(payload):
        if num == 2 and wire == 2:
            tag = _varint((2 << 3) | 2)
            rest = raw[len(tag):]
            body_len, body_start = _read_varint(rest, 0)
            main_data = rest[body_start:body_start + body_len]
            main_parts = []
            for n, w, r in _pb_raw_fields(main_data):
                if n == 12 and w == 2:
                    dev_tag = _varint((12 << 3) | 2)
                    dev_rest = r[len(dev_tag):]
                    dev_len, dev_start = _read_varint(dev_rest, 0)
                    dev_data = dev_rest[dev_start:dev_start + dev_len]
                    dev_parts = [dr for dn, _, dr in _pb_raw_fields(dev_data) if dn != 11]
                    new_dev = b"".join(dev_parts)
                    r = _varint((12 << 3) | 2) + _varint(len(new_dev)) + new_dev
                main_parts.append(r)
            new_main = b"".join(main_parts)
            raw = _varint((2 << 3) | 2) + _varint(len(new_main)) + new_main
        top.append(raw)
    return b"".join(top)


def _start_match_payload(region, mode: str) -> Tuple[bytes, str, bool]:
    """(paquet déchiffré, région de recherche, vient du fichier ?) : paquet de la région du compte s'il est
    dans match_packets.json, sinon gabarit intégré et recherche en BD. Mode classé / d'événement : paquet du mode de
    base (RANKED_BASE_MODE / DERIVED_BASE_MODE), champ 8 de « main » au type de file du mode (RANKED_MATCH_TYPES),
    cartes et mode (team_mode) du mode."""
    base = RANKED_BASE_MODE.get(mode) or DERIVED_BASE_MODE.get(mode, mode)
    reg = str(region).strip().upper() if region else ""
    payload = _load_match_packets().get(reg, {}).get(base)
    if payload is not None:
        result = payload, reg, True
    else:
        result = _START_MATCH_PAYLOADS[base], FALLBACK_SEARCH_REGION, False
    if base != mode:
        mode_id, match_type, maps = team_mode(mode)
        result = (_with_match_type(result[0], match_type, maps, mode_id),) + result[1:]
    return result


def _native_search(account_id, region, mode: str) -> bool:
    """Recherche BR dans la région du compte (voir NATIVE_SEARCH) ?"""
    if _NATIVE_SEARCH in ("", "0") or (RANKED_BASE_MODE.get(mode) or DERIVED_BASE_MODE.get(mode, mode)) != "br":
        return False
    if str(region or "").strip().upper() not in NATIVE_SEARCH_REGIONS:
        return False
    return _NATIVE_SEARCH == "1" or str(account_id) in NATIVE_SEARCH_IDS


def _native_idc_pings(region: str) -> List[int]:
    """Pings des entrées IDC du StartMatch natif, comme le client officiel : TH = une seule (IDC1, 4-5 ms, 17/10) ;
    IND = deux (IDC1 73 ms, IDC2 97 ms : client IND joué depuis la Thaïlande, StartMatch déchiffré le 24/10)."""
    if str(region).upper() == "IND":
        return [random.randint(65, 85), random.randint(88, 106)]
    return [random.randint(4, 9)]


def _native_region_payload(packet: bytes, pings: List[int], region: str) -> bytes:
    """StartMatch sérialisé par thunderFF_pb2 -> celui du client officiel : une entrée {IDCn, ping ms, `region`} par
    ping de `pings` à la place des entrées IDC du gabarit, sans le champ 2.21, champs de « main » et de sa version (2.12) dans l'ordre
    croissant comme dans le gabarit (thunderFF_pb2 met en tête les champs qu'il connaît) ; le reste octet pour octet."""
    def body(raw: bytes) -> bytes:
        _, i = _read_varint(raw, 0)
        _, i = _read_varint(raw, i)
        return raw[i:]

    def ld(num: int, data: bytes) -> bytes:
        return _varint((num << 3) | 2) + _varint(len(data)) + data

    def ordered(data: bytes):
        return sorted(_pb_raw_fields(data), key=lambda f: f[0])     # tri stable : 7 et 20 répétés gardent leur ordre

    reg = region.encode()
    idcs = [ld(7, ld(1, f"IDC{n}".encode()) + _varint(2 << 3) + _varint(ping) + ld(3, reg))
            for n, ping in enumerate(pings, 1)]
    top = []
    for num, wire, raw in _pb_raw_fields(packet):
        if num == 2 and wire == 2:
            main, placed = [], False
            for n, w, r in ordered(body(raw)):
                if n == 7 and w == 2:
                    if not placed:
                        main.extend(idcs)
                        placed = True
                    continue
                if n == 21:
                    continue
                if n == 12 and w == 2:
                    r = ld(12, b"".join(f[2] for f in ordered(body(r))))
                main.append(r)
            raw = ld(2, b"".join(main))
        top.append(raw)
    return b"".join(top)


def _region_header(region):
    # En-tête par région, repris tel quel du script Battle Royale
    reg = str(region).upper() if region else "BD"
    return "031900" if reg == "BD" else ("031400" if reg == "IND" else "031500")


async def _send_start_match(mode, region, client_version, writer, key, iv, account_id=None):
    """Envoie le StartMatch du mode pour un compte de la région `region` ; renvoie (région de recherche,
    vient de match_packets.json ?)."""
    payload, search_region, from_file = _start_match_payload(region, mode)
    native = not from_file and _native_search(account_id, region, mode)
    if native:
        search_region = str(region).strip().upper()
    proto = thunderFF_pb2.StartMatch()
    proto.ParseFromString(payload)
    for entry in proto.main.region_list:
        entry.region = search_region
    if hasattr(proto.main, 'client_version'):
        proto.main.client_version.remote_version = client_version
    packet = proto.SerializeToString()
    if STRIP_DEVICE_SESSION_KEY:
        packet = _strip_device_session_key(packet)
    if native:
        packet = _native_region_payload(packet, _native_idc_pings(search_region), search_region)
        await gateway_send(writer, (0x03, packet), key, iv)
        return search_region, from_file
    encrypted_packet = (await aes_encrypt(packet, key, iv)).hex()
    packet_length = len(encrypted_packet) // 2
    hex_length = hex(packet_length)[2:]
    hex_length = hex_length if len(hex_length) > 1 else "0" + hex_length
    header = "031400" if mode == "lone_wolf" else _region_header(search_region)
    final_packet = header + "0" * (6 - len(hex_length)) + hex_length + encrypted_packet
    writer.write(bytes.fromhex(final_packet))
    await writer.drain()
    return search_region, from_file


async def start_game_lone_wolf(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("lone_wolf", region, client_version, writer, key, iv, account_id)

async def start_game_battle_royale(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("br", region, client_version, writer, key, iv, account_id)

async def start_game_clash_squad(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("clash_squad", region, client_version, writer, key, iv, account_id)

async def start_game_br_ranked(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("br_ranked", region, client_version, writer, key, iv, account_id)

async def start_game_br_ranked_rank(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("br_ranked_rank", region, client_version, writer, key, iv, account_id)

async def start_game_cs_ranked(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("cs_ranked", region, client_version, writer, key, iv, account_id)

async def start_game_big_head(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("big_head", region, client_version, writer, key, iv, account_id)

async def start_game_br_pony(region, client_version, writer, key, iv, account_id=None):
    return await _send_start_match("br_pony", region, client_version, writer, key, iv, account_id)

START_GAME_BY_MODE = {"lone_wolf": start_game_lone_wolf, "br": start_game_battle_royale,
                      "br_pony": start_game_br_pony,
                      "br_ranked": start_game_br_ranked, "br_ranked_rank": start_game_br_ranked_rank,
                      "clash_squad": start_game_clash_squad, "cs_ranked": start_game_cs_ranked,
                      "big_head": start_game_big_head}


async def has_ssan_zig(n):
    z = (n << 1) & 0xFFFFFFFFFFFFFFFF
    out = bytearray()
    while z >= 0x80:
        out.append((z & 0x7F) | 0x80)
        z >>= 7
    out.append(z)
    return bytes(out)

async def uleb_encode(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            break
    return bytes(out)

async def tea_enc(v0, v1, k0, k1, k2, k3):
    s = 0
    for _ in range(_ROUNDS):
        s = (s + _DELTA) & 0xFFFFFFFF
        v0 = (v0 + (((((v1 << 4) & 0xFFFFFFFF) + k0) & 0xFFFFFFFF ^
                      ((v1 + s) & 0xFFFFFFFF) ^
                      (((v1 >> 5) + k1) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        v1 = (v1 + (((((v0 << 4) & 0xFFFFFFFF) + k2) & 0xFFFFFFFF ^
                      ((v0 + s) & 0xFFFFFFFF) ^
                      (((v0 >> 5) + k3) & 0xFFFFFFFF)))) & 0xFFFFFFFF
    return v0, v1

async def tea_dec(v0, v1, k0, k1, k2, k3):
    s = (_DELTA * _ROUNDS) & 0xFFFFFFFF
    for _ in range(_ROUNDS):
        v1 = (v1 - (((((v0 << 4) & 0xFFFFFFFF) + k2) & 0xFFFFFFFF ^
                      ((v0 + s) & 0xFFFFFFFF) ^
                      (((v0 >> 5) + k3) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        v0 = (v0 - (((((v1 << 4) & 0xFFFFFFFF) + k0) & 0xFFFFFFFF ^
                      ((v1 + s) & 0xFFFFFFFF) ^
                      (((v1 >> 5) + k1) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        s = (s - _DELTA) & 0xFFFFFFFF
    return v0, v1

async def tea_cbc_encrypt(padded, key_bytes):
    # ffbot/udp_codec.py : TEA natif (ou Python optimisé), résultat identique à l'implémentation d'origine
    return udp_codec.tea_cbc_encrypt(bytes(padded), bytes(key_bytes))

async def build_padded(content):
    pad_len = (8 - (len(content) + 10) % 8) % 8
    return bytes([pad_len, 0, 0]) + b"\x00" * pad_len + content + b"\x00" * 7

async def encode_header(layout, send_option, cmd, order_id, flags, length, k, v80):
    out = bytearray()
    for code in layout:
        value = {0: send_option, 1: cmd, 2: order_id, 3: flags, 4: length}[code]
        if _FIELD_SIZES[code] == 1:
            out.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            out.append(v & 0xFF)
            out.append((v >> 8) & 0xFF)
    return bytes(out)

async def crc7_buff(crc, buf):
    c = crc & 0x7F
    for b in buf:
        c = CRC7_TABLE[((2 * (c & 0xFF)) ^ (b & 0xFF)) & 0xFF] & 0x7F
    return c & 0x7F

async def sv_frame(msg_key, layout, send_option, cmd, order_id, flags, content, key, encrypted=True):
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = await tea_cbc_encrypt(await build_padded(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0]) + await encode_header(layout, send_option, cmd, order_id, flags, len(body), k, v80)
    packet = bytearray(hdr + body)
    packet[1] = await crc7_buff(0, bytes(packet[2:])) & 0x7F
    return bytes(packet)

async def build_match_startup_packets(token, udp_key, match_code, account_id, block_val,
                                      server_ip="", region="BD", client_version="1.132.6",
                                      client_version_code="2019121229", access_token="",
                                      mode_id=43, map_id=11, ranked: Optional[str] = None):
    """`ranked` : mode classé joué (clé de RANKED_BASE_MODE), None pour une partie normale."""
    token = token.strip()
   
    udp_key = bytes.fromhex(udp_key)
    match_code = [int(ch) for ch in str(match_code).strip()]
    
    # Jeton découpé comme le client officiel (voir JOIN_TOKEN_SPLIT / JOIN_TOKEN_SECOND) : un 447 par morceau (n° d'ordre
    # 0, 1, 2…), le reste à la fin du 448 (n° d'ordre suivant). Avant : un seul 447 et tout le reste dans le 448 (3,4 à
    # 4 Ko) : le serveur ignorait la demande (pas de 130, PING seulement = MATCH_NO_DATA ; jetons de plus en plus longs
    # avec le niveau du compte).
    thunder_chunks, sharma_jwt = [], token
    while len(sharma_jwt) > JOIN_TOKEN_SPLIT:
        thunder_chunks.append(sharma_jwt[:JOIN_TOKEN_SPLIT])
        sharma_jwt = sharma_jwt[JOIN_TOKEN_SPLIT:]
    if len(sharma_jwt) > JOIN_TOKEN_SECOND:
        thunder_chunks.append(sharma_jwt[:JOIN_TOKEN_SECOND])
        sharma_jwt = sharma_jwt[JOIN_TOKEN_SECOND:]
    if not thunder_chunks:
        # jeton de 660 octets au plus (jamais relevé) : tout dans un seul 447, 448 sans jeton, comme avant
        thunder_chunks, sharma_jwt = [sharma_jwt], ""
    encoded_sharma_jwt = sharma_jwt.encode() if isinstance(sharma_jwt, str) else sharma_jwt

    # OB55 Sharma payload structure matching Wireshark capture
    reg = str(region).upper() if region else "BD"
    csoversea_block = bytes.fromhex(
        "ca0163736f7665727365612e7374726f6e67686f6c642e66726565666972656d6f62696c652e636f6d"
        "3b302e302e302e303b33342e3132362e37362e34353b33342e38372e3137372e31343b33342e38372e"
        "3137302e3233303b33352e3138352e3138332e35370000000000000100000000000000000000000001"
        "00000800000100000000000100"
    )

    # Partie classée : octets du 448 du client officiel du mode (RANKED_JOIN_TAILS), dont le type de file juste avant
    # l'heure de fin de bloc ; sans eux, le serveur répond par RUDP_JOIN_MATCH (100) puis ne laisse pas entrer le
    # joueur (pings seulement jusqu'à la borne, relevé en Ranked BR).
    if ranked:
        csoversea_block = csoversea_block.replace(_JOIN_TAIL_NORMAL, RANKED_JOIN_TAILS[RANKED_BASE_MODE[ranked]])
    # Fin de bloc : heure UTC en ticks .NET (zigzag varint) puis 02 00. Le bot envoyait toujours le 19/09/2026 10:08 ;
    # le client officiel, une heure récente : 10 s à 6 min avant le « match trouvé » (6 relevés du 17 au 19/10).
    csoversea_block += _varint(2 * _dotnet_ticks(time.time() - random.uniform(15.0, 240.0))) + b"\x02\x00"
    mid = bytes.fromhex('0000000001010101030101' if ranked else '0000000001000102030101')
    mid += await has_ssan_zig(len(reg)) + reg.encode()
    mid += bytes.fromhex('0001030003010004' if ranked else '0001030003000004')
    mid += await has_ssan_zig(len(client_version)) + client_version.encode()
    mid += await has_ssan_zig(len(client_version_code)) + client_version_code.encode()
    mid += csoversea_block
    
    clean_ip = server_ip.split(':')[0] if server_ip else "0.0.0.0"
    mid += await has_ssan_zig(len(clean_ip)) + clean_ip.encode()
    
    clean_acc_tok = access_token.strip() if access_token else ""
    if clean_acc_tok:
        mid += await has_ssan_zig(len(clean_acc_tok)) + clean_acc_tok.encode()
        
    mid += await has_ssan_zig(len(encoded_sharma_jwt)) + encoded_sharma_jwt
    
    tg_garena420 = (
        await uleb_encode(int(account_id)) +
        await uleb_encode(int(block_val)) +
        await uleb_encode(1) +
        await uleb_encode(int(mode_id)) +
        await uleb_encode(int(block_val)) +
        await uleb_encode(int(map_id)) +
        mid
    )
    
    # 447 : un paquet par morceau du jeton, séparés par des virgules (voir play_match_core) ; 448 : n° d'ordre suivant
    process = []
    for order, chunk in enumerate(thunder_chunks):
        encoded = chunk.encode() if isinstance(chunk, str) else chunk
        process.append((await sv_frame(0x5E, match_code, 2, 447, order, 1,
                                       await has_ssan_zig(len(encoded)) + encoded, udp_key)).hex())
    loading = await sv_frame(0x5A, match_code, 2, 448, len(process), 1, tg_garena420, udp_key)
    return ",".join(process), loading.hex()

async def produce_xor_key(secret_key):
    k = secret_key[0] if secret_key and len(secret_key) > 0 else 10
    return k, ((k << 8) | k) & 0xFFFF

async def parse_layout(layout):
    if isinstance(layout, str):
        return [int(ch) for ch in layout.strip()]
    return list(layout)

async def tea_cbc_decrypt(body, key_bytes):
    return udp_codec.tea_cbc_decrypt(bytes(body), bytes(key_bytes))

async def build_hello_packet(text, key, layout):
    data = text.encode("utf-8")
    if len(data) > 25:
        raise ValueError(f"Text is too long ({len(data)} bytes)")
    # longueur du texte sur 4 octets puis 9 zéros (client officiel : 0f + 15 caractères + 9 zéros pour
    # « 15609100584_213 », 10 + 16 + 9 sinon) ; le bot mettait toujours 10 et complétait à 29 octets, faux dès que le
    # texte n'a pas 16 caractères (identifiant de 10 chiffres, nombre de moins de 4 chiffres…)
    content = struct.pack("<I", len(data)) + data + b"\x00" * 9
    k, v80 = await produce_xor_key(key)
    layout = await parse_layout(layout)
    padded = await build_padded(content)
    enc_body = await tea_cbc_encrypt(padded, key)
    header_bytes = await encode_header(layout, 1, 1, 0, 1, len(enc_body), k, v80)
    packet = bytearray([0x63, 0x00]) + header_bytes + enc_body
    packet[1] = await crc7_buff(0, packet[2:]) & 0x7F
    return bytes(packet).hex()

async def classify(frame):
    cmd = frame["cmd"]
    msg_name = MESSAGE_ID_TO_NAME.get(cmd, f"UNKNOWN_{cmd}")
    if msg_name == "UDP_HELLO":
        return "HELLO"
    if msg_name == "UDP_ACK":
        return "ACK"
    if msg_name == "UDP_PING":
        return "PING"
    if msg_name == "RUDP_JOIN_MATCH":
        return "JOIN_MATCH"
    if msg_name.startswith("RUDP_"):
        return msg_name
    if msg_name.startswith("UDP_"):
        return msg_name
    return "DATA"

async def build_packet(msg_key, layout, send_option, cmd, order_id, flags, content, key, encrypted=True):
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = await tea_cbc_encrypt(await build_padded(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0])
    for code in layout:
        value = {0: send_option, 1: cmd, 2: order_id, 3: flags, 4: len(body)}[code]
        if _FIELD_SIZES[code] == 1:
            hdr.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            hdr.append(v & 0xFF)
            hdr.append((v >> 8) & 0xFF)
    packet = bytearray(hdr + body)
    packet[1] = await crc7_buff(0, bytes(packet[2:])) & 0x7F
    return bytes(packet)

async def layouts_from_mask(mask):
    ru = [int(c) for c in str(mask).strip()]
    nr = [c for c in ru if c != 2]
    return ru, nr

async def reply_for(frame, key, mask, ack_key=0x68, ping_key=0x6D, hello_key=0x5B, ack_style="short"):
    ru, nr = await layouts_from_mask(mask)
    typ = await classify(frame)
    if typ == "HELLO":
        if ack_style == "echo":
            content = frame["content"] if frame["content"] else b"\x10\x00\x00\x00"
            return typ, await build_packet(hello_key, nr, 1, 1, None, 1, content, key)
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, b"\x01\x00", key)
    if typ == "ACK":
        return typ, None      # un ACK ne s'accuse pas (le bot renvoyait le même ACK au serveur, voir UDP_ACK_DELAY_S)
    if typ == "PING":
        counter = _ping_counter(frame["content"] or b"")
        return typ, await build_packet(ping_key, nr, 0, 3, None, 0, counter + b"\x00\x00\x00", key, encrypted=False)
    if typ == "JOIN_MATCH":
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, b"\x02\x00", key)
    return typ, None

async def keepalive_ping(sock, ip, port, key_bytes, mask, stop_event, on_sent=None, on_tx=None, launch=None,
                         take=None):
    """PING de maintien toutes les PING_EVERY_S, comme le client officiel : ms depuis `launch` (lancement du jeu, voir
    _client_launch ; sans : maintenant) en zigzag varint + 00 00 00. Le 1er part PING_EVERY_S après le HELLO (client
    officiel : 0,97 s ; le bot l'envoyait avec le HELLO). `on_sent(compteur)` : varint noté par la partie, pour ne pas
    répondre à son écho (voir UDP_PING_DEDUP). `on_tx(paquet)` : capture (UDP_CAPTURE). `take()` : accusé groupé à
    joindre (en-tête étendu, comme le client officiel sur ses PING), None s'il n'y a rien à accuser."""
    nr = (await layouts_from_mask(mask))[1]
    loop = asyncio.get_event_loop()
    base = launch if launch is not None else time.time()
    while True:
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=PING_EVERY_S)
        except asyncio.TimeoutError:
            pass
        if stop_event.is_set():
            return
        # 1er octet tiré dans 0x64-0x6D comme tous les paquets du client officiel (3 parties du 19/10). Le bot tournait
        # sur 66 6D 69 6C 6B 6E 6F 70 : le serveur ignorait les PING en 6F et 70 (aucun écho, 2 sur 8, relevé 19/10)
        pk = random.randint(0x64, 0x6D)
        counter = _varint(2 * max(0, int((time.time() - base) * 1000)))     # zigzag d'un entier positif : x 2
        if on_sent is not None:
            on_sent(counter)
        pkt = udp_codec.build_packet(pk, nr, 0, 3, None, 0, counter + b"\x00\x00\x00", key_bytes, CRC7_TABLE,
                                     encrypted=False, ext=take() if take is not None else None)
        if on_tx is not None:
            on_tx(pkt)
        try:
            await loop.sock_sendto(sock, pkt, (ip, port))
        except Exception:
            _udp_stats.send_errors += 1

async def try_header(buf, layout, k, v80):
    off = 2
    out = {}
    for code in layout:
        size = _FIELD_SIZES[code]
        if off + size > len(buf):
            return None
        out[_FIELD_NAMES[code]] = (buf[off] ^ k) if size == 1 else ((buf[off] | (buf[off + 1] << 8)) ^ v80) & 0xFFFF
        off += size
    out["headerLen"] = off
    return out

async def oicq_unpad(padded):
    if not padded or len(padded) < 8:
        return None
    if not all(padded[-1 - i] == 0 for i in range(7)):
        return None
    pad_len = padded[0] & 0x07
    s = 3 + pad_len
    e = len(padded) - 7
    return padded[s:e] if s < e else b""

async def decode_packet(packet, key, mask=None):
    data = bytes(packet) if isinstance(packet, bytes) else bytes.fromhex(packet)
    if len(data) < 8:
        return None
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    crc_ok = (data[1] & 0x7F) == await crc7_buff(0, data[2:])
    candidates = []
    if mask:
        ru, nr = await layouts_from_mask(mask)
        layouts = [("RUDP", ru), ("nonRUDP", nr)]
    else:
        layouts = [("RUDP", list(p)) for p in itertools.permutations([0, 1, 2, 3, 4])]
        layouts += [("nonRUDP", list(p)) for p in itertools.permutations([0, 1, 3, 4])]
    for kind, layout in layouts:
        f = await try_header(data, layout, k, v80)
        if not f:
            continue
        if f["flags"] > 7 or f["sendOption"] > 7:
            continue
        if f["length"] != len(data) - f["headerLen"]:
            continue
        body = data[f["headerLen"]:f["headerLen"] + f["length"]]
        content = None
        padded = None
        if f["flags"] & 1:
            if len(body) < 8 or len(body) % 8 != 0:
                continue
            padded = await tea_cbc_decrypt(body, key)
            content = await oicq_unpad(padded)
            if content is None:
                continue
        else:
            content = body
        score = (1 if crc_ok else 0) + (1 if content is not None else 0)
        candidates.append({
            "kind": kind, "layout": layout, "headerLen": f["headerLen"],
            "msgKey": data[0], "cmd": f["cmd"], "flags": f["flags"],
            "sendOption": f["sendOption"], "orderId": f.get("orderId"),
            "length": f["length"], "content": content, "crcOk": crc_ok,
            "padded": padded, "score": score, "total": len(data),
        })
    if not candidates:
        return None
    candidates.sort(key=lambda c: (c["kind"] == "RUDP" or c["kind"] == "nonRUDP", c["score"]), reverse=True)
    return candidates[0]

async def peek_cmds(packet, key, mask):
    """Commandes possibles d'un paquet d'après son seul en-tête (mêmes contrôles que decode_packet, corps non
    déchiffré). Si aucune n'est utile, decode_packet ne peut pas renvoyer de paquet utile : on évite le TEA en
    Python pur (1 à 4 ms par paquet d'état), qui sature la boucle quand plusieurs parties BR tournent en parallèle."""
    data = bytes(packet)
    if len(data) < 8:
        return []
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    cmds = []
    for layout in await layouts_from_mask(mask):
        f = await try_header(data, layout, k, v80)
        if not f or f["flags"] > 7 or f["sendOption"] > 7 or f["length"] != len(data) - f["headerLen"]:
            continue
        if f["flags"] & 1 and (f["length"] < 8 or f["length"] % 8 != 0):
            continue
        cmds.append(f["cmd"])
    return cmds

def _varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)

def _mentions_account(content, *account_ids) -> bool:
    """Le paquet désigne-t-il l'un de ces comptes ? (identifiant en texte, varint, zigzag ou entier 64 bits)"""
    if not content:
        return False
    for acc in account_ids:
        try:
            acc = int(acc)
        except (TypeError, ValueError):
            continue
        if acc <= 0:
            continue
        patterns = [str(acc).encode(), _varint(acc), _varint(acc << 1),
                    acc.to_bytes(8, "little"), acc.to_bytes(8, "big")]
        if acc < 1 << 32:
            patterns += [acc.to_bytes(4, "little"), acc.to_bytes(4, "big")]
        if any(p in content for p in patterns):
            return True
    return False


# Réception UDP des parties : « transport » (rappel de la boucle, socket inscrite une fois : Linux) ou « reader »
# (une tâche par partie : Windows, où le transport Proactor cesse de lire après une erreur réseau).
# UDP_RX_MODE=auto (défaut : selon la boucle) | transport | reader.
UDP_RX_MODE = os.environ.get("UDP_RX_MODE", "auto").strip().lower()


def _udp_rx_transport(loop) -> bool:
    if UDP_RX_MODE in ("transport", "reader"):
        return UDP_RX_MODE == "transport"
    proactor = getattr(asyncio, "ProactorEventLoop", None)
    return not (proactor and isinstance(loop, proactor))


class _UdpRx(asyncio.DatagramProtocol):
    __slots__ = ("on_datagram", "on_error")

    def __init__(self, on_datagram, on_error):
        self.on_datagram = on_datagram
        self.on_error = on_error

    def datagram_received(self, data, addr):
        if data:
            self.on_datagram(data, addr)

    def error_received(self, exc):
        self.on_error(exc)


async def _udp_send_quietly(loop, sock, data: bytes, addr):
    try:
        await loop.sock_sendto(sock, data, addr)
    except Exception:
        _udp_stats.send_errors += 1


# Erreurs d'envoi passagères : WinError 10055 (WSAENOBUFS, tampons réseau du système pleins le temps d'une rafale,
# ex. 200 parties qui démarrent en une minute) et 10035 (WSAEWOULDBLOCK). Avant, la partie trouvée était perdue
# (bonjour non envoyé) ou bloquée 25 min (Sharma non envoyé, jamais renvoyé).
_TRANSIENT_SEND_ERRORS = frozenset({10055, 10035, 105, 11, 35})      # + ENOBUFS / EAGAIN (Linux, macOS)
_SEND_RETRY_DELAYS = (0.05, 0.1, 0.2, 0.4, 0.8)


async def _sendto_retry(loop, sock, data: bytes, addr):
    """Envoi d'un paquet de connexion à la partie : nouvel essai (≈1,5 s au total) sur erreur passagère."""
    for delay in _SEND_RETRY_DELAYS + (None,):
        try:
            return await loop.sock_sendto(sock, data, addr)
        except OSError as e:
            code = getattr(e, "winerror", None) or e.errno
            _udp_stats.send_errors += 1
            if delay is None or code not in _TRANSIENT_SEND_ERRORS:
                raise
            await asyncio.sleep(delay)


def _ping_reply(counter: bytes, key: bytes, lays) -> bytes:
    """Réponse à un PING (même paquet que reply_for) : compteur reçu + 3 zéros."""
    return udp_codec.build_packet(0x6D, lays[1], 0, 3, None, 0, counter + b"\x00\x00\x00", key, CRC7_TABLE,
                                  encrypted=False)


class _RudpAcker:
    """Accusés groupés (voir UDP_ACK_DELAY_S) : `note` à chaque message fiable du serveur ; `take` donne l'accusé à
    joindre au prochain paquet envoyé (None s'il n'y a rien à accuser) ; sinon `send_alone` part UDP_ACK_DELAY_S après
    le premier message non accusé. Accusé = plus grand n° reçu + 1, comme le client du jeu (et comme le bot accusait)."""
    __slots__ = ("loop", "send_alone", "traffic", "next", "pending", "handle")

    def __init__(self, loop, send_alone, traffic):
        self.loop = loop
        self.send_alone = send_alone
        self.traffic = traffic
        self.next: Optional[int] = None
        self.pending = False
        self.handle = None

    def note(self, order_id: int) -> None:
        n = (order_id + 1) & 0xFFFF
        if self.next is None or ((n - self.next) & 0xFFFF) < 0x8000:
            self.next = n
        self.pending = True
        if self.handle is None:
            self.handle = self.loop.call_later(UDP_ACK_DELAY_S, self._flush)

    def take(self) -> Optional[int]:
        if not self.pending:
            return None
        self.pending = False
        self.traffic.acks_piggy += 1
        return self.next

    def _flush(self) -> None:
        self.handle = None
        if self.pending:
            self.pending = False
            self.traffic.acks_sent += 1
            try:
                self.send_alone(self.next)
            except Exception:
                pass

    def close(self) -> None:
        if self.handle is not None:
            self.handle.cancel()
            self.handle = None


class _MatchTraffic:
    """Trafic d'une partie, pour le journal de fin : commandes reçues, PING / ACK (et échos de PING, voir
    UDP_PING_DEDUP), commandes notables (_UDP_WATCH_CMDS) et dernières commandes reçues avant le silence du serveur.
    Mis à jour à chaque paquet reçu : quelques opérations, rien n'est déchiffré pour ça."""
    __slots__ = ("t0", "last", "cmds", "watch", "tail", "seen", "ours", "ping_in", "ping_echo", "ping_ours",
                 "ping_reply", "ack_in", "ack_reply", "rel_in", "rel_dup", "rel_ids", "rel_so", "acks_sent",
                 "acks_piggy", "time_sync", "ack_next", "rel_out")

    def __init__(self, t0: float):
        self.t0 = t0
        self.last = 0.0                            # dernier paquet reçu
        self.cmds: Dict[int, int] = {}             # commande -> paquets reçus
        self.watch: Dict[int, List[float]] = {}    # commande notable -> [nombre, 1re réception, dernière] (s)
        self.tail: deque = deque(maxlen=12)        # (heure, commande) des derniers paquets hors PING / ACK
        self.seen: Dict[bytes, float] = {}         # compteur de PING -> dernier envoi / dernière réponse
        self.ours: Dict[bytes, None] = {}          # compteurs de nos PING de maintien
        self.ping_in = self.ping_echo = self.ping_ours = self.ping_reply = self.ack_in = self.ack_reply = 0
        # messages fiables (numéro d'ordre) : reçus, renvois (numéro déjà reçu), sendOption, accusés envoyés (seuls /
        # joints à un 2001 / 2000, voir UDP_ACK_DELAY_S)
        self.rel_in = self.rel_dup = self.acks_sent = self.acks_piggy = 0
        self.time_sync = 0                         # réponses à la synchro de l'heure (voir UDP_TIME_SYNC)
        self.rel_ids = bytearray(65536)
        self.rel_so: Dict[int, int] = {}
        # Messages fiables ENVOYÉS (447, 448, séquence d'entrée, 191) et plus grand « prochain numéro attendu » lu
        # dans un UDP_ACK du serveur : ack_next == rel_out = le serveur a tout accepté, ack_next < rel_out = il
        # attend encore un de nos messages (contenu refusé ou paquet perdu) et ne traite pas les suivants.
        self.rel_out = 0
        self.ack_next = -1

    def reliable(self, order_id: int, send_option: int) -> None:
        self.rel_in += 1
        if self.rel_ids[order_id]:
            self.rel_dup += 1
        else:
            self.rel_ids[order_id] = 1
        self.rel_so[send_option] = self.rel_so.get(send_option, 0) + 1

    def packet(self, cmd: int, now: float) -> None:
        self.last = now
        self.cmds[cmd] = self.cmds.get(cmd, 0) + 1
        if cmd in _UDP_WATCH_CMDS:
            w = self.watch.get(cmd)
            if w is None:
                self.watch[cmd] = [1, now - self.t0, now - self.t0]
            else:
                w[0] += 1
                w[2] = now - self.t0
        if cmd != 2 and cmd != 3:
            self.tail.append((now, cmd))

    def remember(self, counter: bytes, now: float) -> None:
        self.seen[counter] = now
        if len(self.seen) > 4096:
            for c in list(self.seen)[:2048]:
                del self.seen[c]

    def sent(self, counter: bytes) -> None:
        """Compteur d'un de nos PING de maintien (keepalive_ping)."""
        self.remember(counter, time.time())
        self.ours[counter] = None
        if len(self.ours) > 512:
            for c in list(self.ours)[:256]:
                del self.ours[c]

    def is_echo(self, counter: bytes, now: float) -> bool:
        t = self.seen.get(counter)
        return t is not None and now - t < PING_ECHO_WINDOW_S

    def summary(self, rx_packets: int) -> Dict[str, Any]:
        stay = self.last - self.t0 if self.last else 0.0
        top = sorted(self.cmds.items(), key=lambda kv: -kv[1])[:8]
        return {
            "stay_s": round(stay, 1) if self.last else None,
            "pps": round(rx_packets / stay) if stay >= 1 else None,
            "ping_in": self.ping_in, "ping_echo": self.ping_echo, "ping_ours": self.ping_ours,
            "ping_reply": self.ping_reply, "ack_in": self.ack_in, "ack_reply": self.ack_reply,
            "dedup": int(UDP_PING_DEDUP),
            "rel_in": self.rel_in, "rel_dup": self.rel_dup, "acks_sent": self.acks_sent,
            "acks_piggy": self.acks_piggy, "time_sync": self.time_sync,
            "rel_out": self.rel_out or None, "ack_next": self.ack_next if self.ack_next >= 0 else None,
            "rel_so": " ".join(f"{s}:{n}" for s, n in sorted(self.rel_so.items())) or None,
            "cmds": " ".join(f"{c}:{n}" for c, n in top) or None,
            "watch": " ".join(f"{c}x{w[0]}@{w[1]:.0f}-{w[2]:.0f}s" for c, w in sorted(self.watch.items())) or None,
            "tail": " ".join(f"{c}@-{self.last - t:.1f}" for t, c in self.tail) or None,
        }


class _MatchCapture:
    """Capture brute d'une partie pour analyser le protocole (voir UDP_CAPTURE) : une ligne JSON par paquet
    [secondes depuis le début, "in" | "out", hex]. Les FIRST premiers paquets sont écrits au fil de l'eau, les LAST
    derniers à la fin de la partie (avec le résumé du trafic)."""
    FIRST, LAST = 6000, 3000
    __slots__ = ("f", "t0", "n", "ring", "flushed", "path")

    def __init__(self, path: str, header: Dict[str, Any]):
        self.path = path
        self.f = open(path, "w", encoding="utf-8", buffering=1 << 16)
        self.f.write(json.dumps(header) + "\n")
        self.t0 = header["t0"]
        self.n = 0
        self.ring: deque = deque(maxlen=self.LAST)
        self.flushed = time.time()

    def add(self, direction: str, data: bytes) -> None:
        now = time.time()
        rec = [round(now - self.t0, 3), direction, bytes(data).hex()]
        self.n += 1
        if self.n > self.FIRST:
            self.ring.append(rec)
            return
        try:
            self.f.write(json.dumps(rec) + "\n")
            if now - self.flushed > 2.0:
                self.f.flush()
                self.flushed = now
        except Exception:
            pass

    def close(self, summary: Dict[str, Any]) -> None:
        try:
            if self.ring:
                self.f.write(json.dumps({"skipped": self.n - self.FIRST - len(self.ring)}) + "\n")
                for rec in self.ring:
                    self.f.write(json.dumps(rec) + "\n")
            self.f.write(json.dumps({"end": summary}) + "\n")
            self.f.close()
        except Exception:
            pass


_capture_left = UDP_CAPTURE      # captures restantes dans ce processus (principal ou worker)


def _capture_start(server: str, udp_key: str, match_code, account_id, owner_uid, match_index: int,
                   mode: str, rack: bool) -> Optional[_MatchCapture]:
    global _capture_left
    # BR, et Clash Squad avec CS_CHASE (corrections du serveur : bots coincés, essai du 25/10 22:23)
    if _capture_left <= 0 or mode not in BR_MODES and not (CS_CHASE and mode in CS_MODES):
        return None
    _capture_left -= 1
    try:
        folder = os.path.join(_ROOT_DIR, os.environ.get("DEBUG_LOG_DIR", "logs"), "capture")
        os.makedirs(folder, exist_ok=True)
        t0 = time.time()
        name = f"cap-{time.strftime('%Y%m%d-%H%M%S', time.localtime(t0))}-{owner_uid or account_id}-m{match_index}" \
               f"-p{os.getpid()}.jsonl"
        cap = _MatchCapture(os.path.join(folder, name),
                            {"t0": t0, "server": server, "udp_key": udp_key, "match_code": str(match_code),
                             "account_id": str(account_id), "owner_uid": str(owner_uid), "m": match_index,
                             "mode": mode, "rack": int(rack), "dedup": int(UDP_PING_DEDUP)})
        diag.event("MATCH", "capture", level="info", path=cap.path)
        return cap
    except Exception as e:
        diag.event("MATCH", "capture_failed", level="warning", exc=e)
        return None


def _rudp_ack_for(uid) -> bool:
    """Accuser les messages fiables pour ce compte ? (UDP_RUDP_ACK : 1 tous, 0 aucun, ab UID impairs)"""
    if UDP_RUDP_ACK == "1":
        return True
    if UDP_RUDP_ACK == "ab":
        s = str(uid or "")
        return bool(s) and s[-1].isdigit() and int(s[-1]) % 2 == 1
    return False


# ============================================================
# play_game — UDP MATCH (FIXED & DNS OPTIMIZED)
# ============================================================
# Parties UDP dans des processus « workers » (plusieurs cœurs, ffbot.udp_workers), posé par app.py selon UDP_WORKERS.
# None : parties jouées ici, sur la boucle principale (comportement d'origine).
_match_pool = None


def set_match_pool(pool) -> None:
    global _match_pool
    _match_pool = pool


def match_capacity() -> int:
    """Parties simultanées que les workers peuvent jouer sur tout le serveur (0 = pas de workers, pas de plafond)."""
    pool = _match_pool
    return pool.capacity() if pool is not None else 0


def apply_worker_stats(delta: Dict[str, int], by_cmd: Dict[int, int]) -> None:
    """Trafic UDP des parties jouées dans un worker, ajouté aux compteurs (page « Serveur », moniteur)."""
    for name, value in delta.items():
        if name in _UdpStats.COUNTERS:
            setattr(_udp_stats, name, getattr(_udp_stats, name) + value)
    for cmd, n in by_cmd.items():
        _udp_stats.by_cmd[cmd] = _udp_stats.by_cmd.get(cmd, 0) + n


async def play_game(server_ip_port, thunder, sharma, udp_key, match_code,
                    account_id, player_region, client_version, key, iv,
                    match_index: int, owner_uid=None, mode="lone_wolf", match_id: Optional[int] = None,
                    sysinfo: Optional[str] = None):
    """Partie trouvée, jouée en arrière-plan : dans un worker si disponible (UDP_WORKERS), sinon ici.
    La comptabilité reste ici, dans la tâche du compte (place du panel, fin de partie, état, journal).
    `match_id` : identifiant de la partie (5.1 du « match trouvé ») : attente de son résultat après un départ en cours
    de partie (MATCH_END_WAIT).
    `sysinfo` : contenu du RUDP_C2S_SYSTEM_INFO du compte (account_system_info), préparé ici parce que le worker
    n'a ni les comptes connectés ni le droit d'écrire devices.json."""
    match_start_time = time.time()
    # Compteurs indexés sur le compte propriétaire (celui qui a incrémenté _inc_match),
    # même si l'id renvoyé dans le paquet de match diffère.
    uid_str = str(owner_uid or account_id)
    # Panel du compte résolu dès le départ : le match libère sa place dans ce panel-là, même si la session
    # qui l'a lancé est terminée entre-temps (parties BR protégées).
    panel = _panel_matches(uid_str)
    # completed + cause de fin (reason : MATCH_END, HANDSHAKE_TIMEOUT… voir ffbot.diag), handshake_ms, rx_packets…
    state: Dict[str, Any] = {"completed": False, "reason": None}
    args = (server_ip_port, thunder, sharma, udp_key, match_code, account_id, player_region, client_version,
            key, iv, match_index, owner_uid, mode)
    # réglages du site lus par la partie elle-même (le worker n'a que les valeurs par défaut du module)
    opts = {"revive_check": bool(REVIVE_CHECK), "revive_wait_s": int(REVIVE_WAIT_S), "tunables": tunables(),
            "sysinfo": sysinfo}
    pool = _match_pool
    token = diag.bind(m=match_index)

    async def push_hp():
        # PV en direct de la partie (state["hp"], écrit par play_match_core ici ou reçu du worker) -> site
        last = None
        while True:
            hp = state.get("hp")
            if hp != last:
                last = hp
                bot_state.match_hp(uid_str, match_index, hp, mode)
            await asyncio.sleep(1.0)

    hp_task = asyncio.create_task(push_hp()) if mode in BR_MODES else None
    http_task = asyncio.create_task(_match_http_calls(uid_str, account_id, match_start_time)) \
        if MATCH_HTTP_CALLS and mode in BR_MODES else None
    try:
        if pool is not None and pool.available():
            match_key = id(asyncio.current_task())
            _udp_matches[match_key] = server_ip_port
            context = contextvars.copy_context()   # journal du worker -> compte de cette partie
            try:
                state["completed"] = await pool.run(
                    args, lambda level, msg: context.run(bot_state.log, msg, level),
                    on_diag=lambda rec, w=None: context.run(diag.ingest, rec, w=w), info=state,
                    on_live=lambda live: state.__setitem__("hp", live.get("hp")), opts=opts)
            finally:
                _udp_matches.pop(match_key, None)
        else:
            await play_match_core(*args, state=state, opts=opts)
        return f"match #{match_index} finished"
    except asyncio.CancelledError:
        state["reason"] = state.get("reason") or "CANCELLED"
        raise
    except Exception as e:
        state["reason"] = state.get("reason") or "MATCH_EXCEPTION"
        state["error"] = repr(e)[:300]
        diag.event("MATCH", "error", level="error", code="MATCH_EXCEPTION", exc=e, server=server_ip_port)
        raise
    finally:
        if hp_task is not None:
            hp_task.cancel()
            bot_state.match_hp(uid_str, match_index, None, mode)    # partie finie : plus de PV affichés
        if http_task is not None:
            http_task.cancel()
        await _finish_match(uid_str, panel, state["completed"], time.time() - match_start_time, mode, match_index,
                            state, server_ip_port, match_id)
        diag.unbind(token)


async def _finish_match(uid_str: str, panel: _PanelMatches, completed: bool, duration: float, mode: str,
                        match_index: int, info: Optional[Dict[str, Any]] = None, server: str = "",
                        match_id: Optional[int] = None):
    info = info or {}
    reason = info.get("reason") or ("MATCH_END" if completed else "UNKNOWN")
    # LogEvent EventTypeBRDeadInfo : à la mort du joueur en BR, comme le vrai client (fire-and-forget, jamais bloquant).
    if LOG_EVENTS and mode in BR_MODES and match_id and reason in BR_DEATH_REASONS:
        asyncio.create_task(_send_br_dead_event(uid_str, mode, match_id, info.get("map_id")))
    if MATCH_HTTP_CALLS and mode in BR_MODES and completed:
        asyncio.create_task(_match_end_http_calls(uid_str))
    try:
        bot_state.match_finished(uid_str, completed, duration, mode, reason)
    except Exception:
        pass
    # partie BR quittée en cours : elle continue sur le serveur, le compte attend sa fin (MATCH_END_WAIT) avant la
    # suivante. Enregistrée avant de libérer la place : la boucle du compte ne la voit jamais libre entre-temps.
    waiting_end = completed and mode in BR_MODES and reason in LEFT_EARLY_CODES and \
        _left_wait_add(uid_str, match_id, match_index)
    remaining = await _dec_match(uid_str, panel, mode)
    total = await _get_total_match_count(uid_str, panel)
    print_info(
        f"[MATCH #{match_index}] Closed. "
        f"UID active: {remaining} | Panel active: {total}"
    )
    if remaining == 0:
        _chat_rejoin_signal(uid_str)      # de retour au lobby : salon du chat rejoint, comme le client officiel
    msg = info.get("error") or ""
    if not completed and not msg:
        # résumé lisible d'une partie ratée : 0 paquet reçu = le serveur de partie n'a jamais répondu
        msg = (f"หลังเริ่ม {int(duration)} วินาที · ค้างที่ขั้น {info.get('ack_state') or '-'} · "
               f"ได้รับ {info.get('rx_packets') or 0} แพ็กเก็ต")
    # trafic (_MatchTraffic.summary) : stay_s = dernier paquet reçu (le serveur s'est tu ensuite), commandes reçues
    # (cmd:nombre), commandes notables (cmd x nombre @ 1re-dernière réception), 12 dernières commandes hors PING / ACK
    # (cmd @ -secondes avant le dernier paquet), PING reçus / échos (ping_ours : échos de nos PING de maintien).
    # rel_out / ack_next : messages fiables envoyés (447, 448, séquence d'entrée, 191) et dernier « prochain numéro
    # attendu » accusé par le serveur. Égaux = tout a été accepté ; ack_next plus petit = le serveur bloque sur un
    # de nos messages (refusé ou perdu) et ne traite aucun des suivants.
    diag.event("MATCH", "end", level="info" if completed else "warning", code=reason, ok=completed, mode=mode,
               server=server, dur_ms=round(duration * 1000), handshake_ms=info.get("handshake_ms"),
               rx=info.get("rx_packets"), rx_kb=round((info.get("rx_bytes") or 0) / 1024), stage=info.get("ack_state"),
               outage_s=info.get("outage_s"), w=info.get("worker"), left=remaining, panel_active=total,
               stay_s=info.get("stay_s"), pps=info.get("pps"), ping_in=info.get("ping_in"),
               ping_echo=info.get("ping_echo"), ping_ours=info.get("ping_ours"), ping_reply=info.get("ping_reply"),
               ack_in=info.get("ack_in"), ack_reply=info.get("ack_reply"), dedup=info.get("dedup"),
               rack=info.get("rack"), rel_in=info.get("rel_in"), rel_dup=info.get("rel_dup"),
               acks_sent=info.get("acks_sent"), acks_piggy=info.get("acks_piggy"), time_sync=info.get("time_sync"),
               rel_so=info.get("rel_so"), rel_out=info.get("rel_out"), ack_next=info.get("ack_next"),
               end_wait=1 if waiting_end else None, chase=info.get("chase"),
               cmds=info.get("cmds"), watch=info.get("watch"), tail=info.get("tail"), msg=msg)
    try:
        if remaining > 0:
            bot_state.update_status(uid_str, "IN_MATCH", remaining)
        elif waiting_end:
            bot_state.update_status(uid_str, "WAITING", 0, "MATCH_END_WAIT")
        else:
            bot_state.update_status(uid_str, "ONLINE", 0)
    except Exception:
        pass


async def _client_calls(uid_str: str, stage: str, bodies) -> None:
    """Requêtes HTTP du vrai client (api_client.client_calls) avec la session du compte ; jamais bloquant."""
    session = bot_state.account_credentials.get(uid_str)
    if not session or not api_client.token_valid(session.get("token")):
        diag.event("MATCH", "http_calls", level="warning", stage=stage, msg="ไม่มี session ของบัญชี")
        return
    try:
        res = await api_client.client_calls(session, bodies)
        failed = [f"{ep}: {err}" for ep, err in res if err]
        diag.event("MATCH", "http_calls", level="warning" if failed else "info", stage=stage,
                   ok=len(res) - len(failed), failed=len(failed), msg="; ".join(failed)[:300] or None)
    except Exception as e:
        diag.event("MATCH", "http_calls", level="warning", stage=stage, exc=e)


async def _match_http_calls(uid_str: str, account_id, started: float) -> None:
    """Pendant la partie (voir MATCH_HTTP_CALLS) : GetQuickMsgSettings à +3 s, icônes à +MATCH_ICON_CALL_S."""
    await asyncio.sleep(max(0.0, started + random.uniform(2.8, 3.6) - time.time()))
    await _client_calls(uid_str, "start", api_client.MATCH_START_BODIES)
    await asyncio.sleep(max(0.0, started + MATCH_ICON_CALL_S + random.uniform(0, 2) - time.time()))
    await _client_calls(uid_str, "icon", [("GetAccountExternalIconInfoByAccountIDs",
                                           api_client.match_icon_body(account_id))])


async def _match_end_http_calls(uid_str: str) -> None:
    """Fin de partie BR (voir MATCH_HTTP_CALLS) : ce que le vrai client envoie à sa mort, puis ~3 s après."""
    await _client_calls(uid_str, "end", api_client.MATCH_END_BODIES)
    await asyncio.sleep(random.uniform(2.8, 3.4))
    await _client_calls(uid_str, "after", api_client.MATCH_AFTER_BODIES)


async def _send_br_dead_event(uid_str: str, mode: str, match_id: int, map_id: Optional[int] = None) -> None:
    """Fire-and-forget : LogEvent EventTypeBRDeadInfo à la mort du joueur en BR, comme le vrai client.
    Le token du compte vient de bot_state.account_credentials. `map_id` : carte réelle de la partie si connue
    (info["map_id"]), sinon la carte par défaut du mode (MATCH_MODE_IDS). Jamais bloquant pour la boucle du compte."""
    try:
        session = bot_state.account_credentials.get(uid_str)
        if not session or not api_client.token_valid(session.get("token")):
            return
        if map_id is None:
            _, map_id = MATCH_MODE_IDS.get(mode, (1, 1))
        payload = api_client.br_dead_info_payload(match_id, map_id)
        ok = await api_client.log_event(session, "EventTypeBRDeadInfo", payload)
        diag.event("MATCH", "log_event", level="debug" if ok else "warning", ok=ok,
                   event="EventTypeBRDeadInfo", match_id=match_id, mode=mode)
    except Exception as e:
        diag.event("MATCH", "log_event", level="warning", ok=False, exc=e, match_id=match_id, mode=mode)


async def play_match_core(server_ip_port, thunder, sharma, udp_key, match_code,
                          account_id, player_region, client_version, key, iv,
                          match_index: int, owner_uid=None, mode="lone_wolf", state=None,
                          opts: Optional[Dict[str, Any]] = None):
    """La partie UDP elle-même (handshake, réponses, fin de partie), sans comptabilité : jouée ici ou dans un worker.
    `state["completed"]` : partie terminée normalement (à jour même si la tâche est annulée) ; `state["reason"]` :
    cause de la fin (MATCH_END, PLAYER_DEAD, IDLE_END, BR_LEFT, MAX_DURATION, HANDSHAKE_TIMEOUT, SOCKET_ERROR, OUTAGE_LOST,
    MATCH_EXCEPTION, CANCELLED), avec handshake_ms, rx_packets, rx_bytes, ack_state, outage_s et le trafic de la
    partie (_MatchTraffic.summary : commandes reçues, PING / échos, dernières commandes avant le silence).
    `opts` : réglages du site au lancement de la partie (revive_check, revive_wait_s : voir REVIVE_CHECK ; tunables :
    réglages du jeu de la page, voir apply_tunables ; sysinfo : contenu du RUDP_C2S_SYSTEM_INFO du compte, voir
    account_system_info et UDP_JOIN_SEQ)."""
    opts = opts or {}
    apply_tunables(opts.get("tunables"))      # worker : il n'a que les valeurs par défaut du module
    match_start_time = time.time()
    match_key = id(asyncio.current_task())
    ping_task = None
    state_task = None
    reader_task = None
    acker: Optional[_RudpAcker] = None
    rx_transport = None
    sock = None
    ping_stop = asyncio.Event()
    state_stop = asyncio.Event()      # fin des 2001 (embarquement, 1er 144, mort), voir UDP_STATE_SYNC
    completed_cleanly = False
    is_br = mode in BR_MODES
    # départ (BR_LEAVE_AFTER_S, BR_LEAVE_ON_DEATH, BR_INSTA_LEAVE, BR_LEAVE_HP) : relu en cours de partie si la page
    # change les réglages (tun_gen, voir _TUNABLES_GEN)
    leave_after_s, death_watch, insta, leave_hp = _leave_plan(mode, account_id, owner_uid)
    tun_gen = _TUNABLES_GEN
    # PV, corrections de position, morts et réanimation du joueur local (suivis dans on_datagram : les 144 sont des
    # paquets d'état, ils n'arrivent jamais dans la file de la partie) ; décisions de départ : life.step()
    life = _BrLife(death_watch or insta, bool(opts.get("revive_check", REVIVE_CHECK)),
                   float(opts.get("revive_wait_s", REVIVE_WAIT_S))) if is_br else None
    # Clash Squad : 2001 du joueur local en course vers l'adversaire (CS_CHASE), à la place de l'état immobile
    # d'UDP_STATE_SYNC
    # opts["cs_chase"] : choix de cette partie seule (équipes de test, ffbot.teamlab), sans toucher au réglage du site
    chase = _CsChase(match_start_time) if opts.get("cs_chase", CS_CHASE) and mode in CS_MODES else None
    if chase is not None:
        chase.seed = str(match_code)      # même graine pour toute l'équipe (choix de voie, voir CS_LANE)
        chase.replies_readable = bool(_load_session_key_for_login(str(owner_uid or account_id))
                                      or (_load_anticheat_replay() or {}).get("session_key"))
        if is_br:
            chase.br_mode = True          # BR : combat dès le départ (pas de préparation CS)
    cs_fight_at: Optional[float] = None   # first safe-zone change after prep (red circle), independent of CS_CHASE
    # compétence active (essai CS_SKILL_TEST) : envois [(heure, n° d'ordre)], 250 reçus, bilan ; Clash Squad seulement
    # (en BR, 248 toutes les ~13 s sans drone ni réponse : br_pony du 28/10 21:07, spawned=0 answered=0)
    skill_test = CS_SKILL_TEST and mode in CS_MODES
    skill = {"next": 0.0, "pending": [], "states": [], "sent": 0, "acked": 0, "answered": 0,
             "drones": [], "drone_orders": set(), "casts": [], "locks": [], "locked": 0, "last_lock": 0.0,
             "hits": 0, "hit_seen": set(), "ready_at": 0.0, "tracks": set(), "id_shift": 0, "mine": set(),
             "lock_off": False, "last_lock_id": None, "last_real_at": 0.0, "round_fired": 0, "retried": False,
             "drone_pos": {}, "locked_ids": set(), "drone_count": 0}
    # ทีมบอทของเราเจอกันเอง + ปิดระบบหาห้องทีละทีม (ffbot.teamlab) : กดโดรนทีละฝั่ง — ฝั่งที่ถือ "ตา" (drone_turn)
    # กดได้ฝั่งเดียว ส่งต่อให้ฝั่งถัดไปเมื่อโดรนลงดาเมจแล้ว ; drone_side = รหัสทีม (ฝั่ง) ของบอทตัวนี้
    drone_turn = opts.get("drone_turn")
    drone_side = opts.get("drone_side")

    def skill_hit(c: bytes, now: float) -> None:
        """2010 [victime, attaquant, arme, horloge, 0, dégâts] : dégâts de notre drone (arme CS_DRONE_WEAPON)."""
        v, i = [], 0
        while len(v) < 6:
            x, i = _read_varint(c, i)
            if x is None:
                return
            v.append(x)
        # 28/10 : เลิกปิดสกิลเมื่อเห็นดาเมจจากโดรน « ตัวอื่น » — เดิมเกิดจากเดาเลขผิด (วิธีนับเก่า) ไม่ใช่การแย่งโดรนจริง.
        # ตอนนี้เลขโดรนมาจาก 541 (match key) + จับคู่ตำแหน่งแรกกับตำแหน่งตัวเราเองตอนกด จึงถูกทุกครั้ง ไม่ต้องมี lock_off.
        if chase is None or v[1] != chase.ident() or v[2] != CS_DRONE_WEAPON or (v[0], v[3]) in skill["hit_seen"]:
            return
        skill["hit_seen"].add((v[0], v[3]))       # le même 2010 arrive parfois 2-3 fois
        skill["hits"] += 1
        diag.event("MATCH", "skill_hit", level="info", victim=hex(v[0]), dmg=v[5],
                   after_lock_s=round(now - skill["last_lock"], 2) if skill["last_lock"] else None)
        if drone_turn is not None:
            drone_turn.report_damage(drone_side, now)   # โดรนฝั่งนี้ลงดาเมจแล้ว : ส่งตาให้อีกฝั่ง (ทีละฝั่ง)
    if state is not None and is_br:
        state["hp"] = PLAYER_MAX_HP          # PV en direct (state["hp"]), envoyés au site par play_game
    max_duration, idle_timeout, handshake_timeout = MATCH_TIMING.get(mode, MATCH_TIMING["lone_wolf"])
    info: Dict[str, Any] = {"reason": None, "handshake_ms": None, "rx_packets": 0, "rx_bytes": 0,
                            "ack_state": "init", "outage_s": 0, "error": None}
    traffic = _MatchTraffic(match_start_time)
    rack = _rudp_ack_for(owner_uid or account_id)    # accuser les messages fiables du serveur (UDP_RUDP_ACK)
    capture = _capture_start(server_ip_port, udp_key, match_code, account_id, owner_uid, match_index, mode, rack)
    loop_errors = 0

    def cap_out(pkt) -> None:
        if capture is not None:
            capture.add("out", pkt)

    def loop_error(e: BaseException):
        """Erreur dans la boucle de la partie (envoi refusé par le système…) : la partie continue ; comptée et
        journalisée (la 1re, puis une sur 50), elle n'était jusqu'ici visible nulle part."""
        nonlocal loop_errors
        loop_errors += 1
        info["error"] = repr(e)[:300]
        if loop_errors == 1 or loop_errors % 50 == 0:
            diag.event("MATCH", "loop_error", level="warning", exc=e, count=loop_errors, stage=info["ack_state"])

    _udp_matches[match_key] = server_ip_port
    try:
        ip, port = server_ip_port.split(":")
        port = int(port)
        resolved_ip = await resolve_host_cloudflare(ip)

        loop = asyncio.get_event_loop()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        optimize_udp_socket(sock)
        sock.setblocking(False)

        udp_key_bytes = bytes.fromhex(udp_key)
        # STRIP_DEVICE_SESSION_KEY now controls ONLY field-11 removal from StartMatch (in
        # _send_start_match). The reliable RUDP key is ALWAYS the real session key when we have
        # one: past Sharma the server requires it and does NOT fall back to the match key
        # (empirical, see lines 750-761). Forcing rel_key=udp_key here drops every skill (ack_in=0).
        _sk_hex = _load_session_key_for_login(str(owner_uid or account_id))
        _sk_source = "session_keys"
        if not _sk_hex:
            _ac_replay = _load_anticheat_replay()
            _sk_hex = _ac_replay.get("session_key") if _ac_replay else None
            _sk_source = "replay"
        session_key_bytes = bytes.fromhex(_sk_hex) if _sk_hex else None
        rel_key = session_key_bytes or udp_key_bytes
        if session_key_bytes:
            diag.event("MATCH", "session_key", level="info", key=_sk_hex[:8] + "…", source=_sk_source, stripped=STRIP_DEVICE_SESSION_KEY)
        else:
            diag.event("MATCH", "session_key", level="warning", msg="no session key found; reliable RUDP falls back to match key — skills will not work")
        # texte du HELLO : « <id>_<nombre> », nombre tiré à chaque connexion comme le client officiel (6999, 213, 8852,
        # puis 6294 à la reconnexion de la même partie) ; le bot envoyait toujours _2585
        hello_text = f"{account_id}_{random.randint(0, 9999)}"
        hello_packet = await build_hello_packet(hello_text, udp_key_bytes, match_code)
        try:
            cap_out(bytes.fromhex(hello_packet))
            await _sendto_retry(loop, sock, bytes.fromhex(hello_packet), (resolved_ip, port))
        except OSError as e:
            # bonjour non envoyé (tampons réseau pleins…) : la partie n'est pas perdue, il est renvoyé toutes les 7 s
            # jusqu'au délai de connexion (avant : partie trouvée perdue en 10 ms, « MATCH_EXCEPTION »)
            loop_error(e)
        diag.event("MATCH", "udp_start", level="debug", server=server_ip_port, ip=resolved_ip, mode=mode)

        ack_state = info["ack_state"] = "waiting_for_hello_reply"
        thunder_sent = False
        sharma_sent = False
        sharma_at = 0.0            # Sharma (448) envoyé à… : origine des délais de la séquence d'entrée ci-dessous
        # Séquence d'entrée du client officiel (voir UDP_JOIN_SEQ) : (délai après le 448, clé de message, commande,
        # contenu), numéros d'ordre fiables contigus à partir de celui qui suit le 448. `sysinfo` : contenu du 1026
        # préparé par le processus principal (account_system_info) ; sans lui, le 1026 est sauté.
        sysinfo = opts.get("sysinfo")
        join_seq: List[Tuple[float, int, int, bytes]] = []
        if UDP_JOIN_REPLAY:
            # rejouer la séquence d'entrée capturée (body réels, y compris anti-triche) en non fiable + clé du match
            try:
                _rp = json.load(open(UDP_JOIN_REPLAY_FILE, encoding="utf-8"))
                for _e in sorted(_rp.get("entries", []), key=lambda x: float(x.get("delay_s", 0))):
                    join_seq.append((float(_e.get("delay_s", 0.0)), 0, int(_e["cmd"]),
                                     bytes.fromhex(_e.get("body_hex") or "")))
                diag.event("MATCH", "join_replay_load", level="info", n=len(join_seq),
                           src=os.path.basename(UDP_JOIN_REPLAY_FILE))
            except Exception as _err:
                diag.event("MATCH", "join_replay_err", level="warning", exc=_err)
        else:
            if UDP_JOIN_SEQ and sysinfo:
                join_seq.append((SYSTEM_INFO_DELAY_S, 0x60, RUDP_C2S_SYSTEM_INFO, bytes.fromhex(sysinfo)))
            if UDP_JOIN_SEQ:
                join_seq.append((LOADOUT_SLOT_DELAY_S, 0x5C, RUDP_SYNC_ALL_LOADOUT_SUPPORT_SLOT_STATE, b""))
            if UDP_LOADING_END:
                join_seq.append((LOADING_END_DELAY_S, 0x62, RUDP_C2S_LOADING_END, b""))
        join_seq_i = 0             # prochain message de la séquence à envoyer
        send_fail_since = 0.0      # envoi Thunder / Sharma en échec depuis… (0 = pas d'échec en cours)
        send_retry_at = 0.0        # prochain essai d'envoi après un échec
        last_hello_at = time.time()   # dernier HELLO envoyé (renvoyé toutes les 7 s tant que le serveur ne répond pas)
        join_delay = random.uniform(JOIN_DELAY_MIN_S, JOIN_DELAY_MAX_S)   # HELLO -> Thunder / Sharma (client officiel)
        join_match_received = False
        local_closed = False
        send_lock = asyncio.Lock()
        # Thunder = un 447 par morceau du jeton (n° 0…n-1, voir build_match_startup_packets), Sharma = n
        thunder_parts = [bytes.fromhex(p) for p in thunder.split(",") if p]
        reliable_order = len(thunder_parts) + 1   # prochain n d'ordre fiable C2S (apres Thunder et Sharma) : loading-end puis quit
        quit_sent = False          # RUDP_PLAYER_QUIT_REQ (191) deja envoye au depart BR (voir UDP_QUIT_ON_LEAVE)
        insta_at = 0.0             # mort annoncée (872 + 107) : silence depuis… (BR_INSTA_LEAVE), la partie s'arrête
        insta_info: Dict[str, Any] = {}

        ping_task = asyncio.create_task(
            keepalive_ping(sock, resolved_ip, port, udp_key_bytes, match_code, ping_stop, on_sent=traffic.sent,
                           on_tx=cap_out if capture is not None else None, launch=_client_launch(account_id),
                           take=lambda: acker.take() if acker is not None else None)
        )
        last_activity = time.time()
        MAX_IDLE_BEFORE_HELLO_RESEND = 7.0
        outage_since = 0.0     # partie gardée pendant une coupure réseau depuis… (0 = pas de coupure en cours)

        def keep_waiting(silence: float, limit: float) -> bool:
            """Serveur muet depuis `silence` s : rester tant que `limit` n'est pas dépassé, ou plus longtemps
            (OUTAGE_GRACE_S) si toutes les parties se taisent en même temps (coupure réseau, pas fin de partie)."""
            nonlocal outage_since
            if silence <= limit:
                return True
            if silence <= limit + OUTAGE_GRACE_S and _network_silent(match_key, server_ip_port):
                if not outage_since:
                    outage_since = time.time()
                    print_warning(f"[MATCH #{match_index}] [{MODE_TAGS.get(mode, mode)}] réseau muet depuis "
                                  f"{int(silence)}s sur toutes les parties : partie gardée (pas d'abandon)")
                    diag.event("MATCH", "network_silent", level="warning", code="NET_UNREACHABLE",
                               silence_s=round(silence), stage=info["ack_state"],
                               msg="ทุกแมตช์เงียบพร้อมกัน: น่าจะเน็ตหลุด เก็บแมตช์ไว้ก่อน (ไม่ทิ้งแมตช์)")
                return True
            return False

        def mark_handshake():
            # première réponse du serveur de partie : la connexion à la partie est établie
            if info["handshake_ms"] is None:
                info["handshake_ms"] = round((time.time() - match_start_time) * 1000)
                diag.event("MATCH", "handshake", level="info", dur_ms=info["handshake_ms"], server=server_ip_port)

        print_colored(
            f"🎮 [MATCH #{match_index}] [{MODE_TAGS.get(mode, mode)}] UDP started → {server_ip_port} (DNS: {resolved_ip})",
            Colors.MAGENTA
        )

        async def send_thunder_sharma_inline():
            """Thunder puis Sharma, à la suite, `join_delay` après le HELLO (voir JOIN_DELAY_MIN_S ; avant : 447 dès
            l'ACK du serveur, un accusé « 01 00 » de plus, puis 448 0,3 s après). Une partie manquante (envoi refusé par
            le système) est renvoyée au tour suivant : avant, un Sharma refusé n'était jamais renvoyé et la partie
            restait bloquée jusqu'à la borne de 25 min (puis comptée « terminée » à tort)."""
            nonlocal ack_state, thunder_sent, sharma_sent, sharma_at, send_fail_since, send_retry_at
            if sharma_sent or (send_fail_since and time.time() < send_retry_at):
                return
            if time.time() - last_hello_at < join_delay:
                return            # trop tôt : la boucle repasse ici (délai d'attente de la file raccourci d'autant)
            async with send_lock:
                if sharma_sent:
                    return
                try:
                    if not thunder_sent:
                        for part in thunder_parts:
                            cap_out(part)
                            await _sendto_retry(loop, sock, part, (resolved_ip, port))
                        thunder_sent = True
                        await asyncio.sleep(THUNDER_SHARMA_GAP_S)
                    cap_out(bytes.fromhex(sharma))
                    await _sendto_retry(loop, sock, bytes.fromhex(sharma), (resolved_ip, port))
                    sharma_sent = True
                    sharma_at = time.time()
                    traffic.rel_out = reliable_order      # Thunder (0…n-1) et Sharma (n) partis
                    ack_state = info["ack_state"] = "thunder_sharma_sent"
                    print_success(f"[MATCH #{match_index}] Thunder+Sharma sent!")
                    diag.event("MATCH", "joined", level="info" if send_fail_since else "debug",
                               dur_ms=(time.time() - match_start_time) * 1000,
                               retried_s=round(time.time() - send_fail_since, 1) if send_fail_since else None)
                    send_fail_since = 0.0
                except Exception as e:
                    first = not send_fail_since
                    send_retry_at = time.time() + SEND_RETRY_EVERY_S
                    if first:
                        send_fail_since = time.time()
                        print_error(f"[MATCH #{match_index}] send error: {e}")
                    # 1er échec, puis une ligne toutes les ~10 s tant que ça dure (nouvel essai à chaque tour)
                    diag.event("MATCH", "send_failed", level="warning" if first else "debug", code="UDP_SEND_FAILED",
                               exc=e, err=diag.classify(e), thunder=thunder_sent, sharma=sharma_sent,
                               failing_s=round(time.time() - send_fail_since, 1))

        # Réception : une tâche lit TOUS les datagrammes (sans asyncio.wait_for par paquet, coûteux à des milliers
        # de paquets/s) et ne réveille la partie que pour les paquets de contrôle ; les paquets d'état (l'essentiel
        # du trafic) ne coûtent qu'une lecture d'en-tête. Délais, renvois et fin de partie : inchangés.
        lays = udp_codec.layouts(match_code)
        udp_plan = udp_codec.plans(lays)
        udp_k = udp_key_bytes[0]
        udp_v80 = ((udp_k << 8) | udp_k) & 0xFFFF
        sess_k = session_key_bytes[0] if session_key_bytes else None
        sess_v80 = ((sess_k << 8) | sess_k) & 0xFFFF if sess_k is not None else None
        rx_queue: asyncio.Queue = asyncio.Queue(maxsize=512)
        rx = {"last": 0.0, "error_since": 0.0, "bye": 0.0, "match_end": 0.0}

        def fast_send(reply: bytes, addr) -> None:
            if capture is not None:
                capture.add("out", reply)
            try:
                sock.sendto(reply, addr)
            except BlockingIOError:
                loop.create_task(_udp_send_quietly(loop, sock, reply, addr))
            except OSError:
                _udp_stats.send_errors += 1     # réponse ACK / PING perdue (10055…) : comptée (page Serveur)
            _udp_stats.fast_replies += 1

        def send_ack_alone(value: int) -> None:
            fast_send(udp_codec.build_packet(0x68, lays[1], 0, 2, None, 1, struct.pack("<H", value),
                                             udp_key_bytes, CRC7_TABLE), (resolved_ip, port))

        if rack and UDP_ACK_DELAY_S > 0:
            acker = _RudpAcker(loop, send_ack_alone, traffic)

        def insta_quit(now: float, data: bytes, addr) -> None:
            """Mort annoncée (BR_INSTA_LEAVE) : silence immédiat, sans attendre le tour de boucle ; la partie s'arrête.
            Pas de 191 : le client officiel n'en envoie pas à la mort (captures du 21/10)."""
            nonlocal insta_at, quit_sent
            insta_at = now
            quit_sent = True          # (aucun 191 ne doit partir ensuite)
            sent = time.time()
            ping_stop.set()           # plus de PING ni d'état du joueur (le vrai client se tait dans la seconde)
            state_stop.set()
            if acker is not None:
                acker.close()
            last_st = max(life.sync_last, life.state_last)
            insta_info.update(react_ms=round((sent - now) * 1000, 2),
                              dead_ms=round((sent - last_st) * 1000) if last_st else None,
                              hp_est=life.hp, revive_offer=life._offered(now))
            if state is not None:
                state["hp"] = 0
            try:
                rx_queue.put_nowait((data, addr))     # réveille la boucle de la partie (fin aussitôt)
            except asyncio.QueueFull:
                pass

        def on_datagram(data: bytes, addr) -> None:
            """Un datagramme reçu (synchrone : appelé par la tâche de lecture ou par le transport UDP)."""
            nonlocal cs_fight_at
            global _udp_last_rx
            now = rx["last"] = _udp_last_rx = time.time()
            rx["error_since"] = 0.0
            _udp_stats.packets += 1
            _udp_stats.bytes += len(data)
            info["rx_packets"] += 1
            info["rx_bytes"] += len(data)
            if capture is not None:
                capture.add("in", data)
            first, cmd, send_option, order_id = udp_codec.scan(data, udp_k, udp_v80, udp_plan, _UDP_CONTROL_CMDS)
            if first is None and sess_k is not None:
                first, cmd, send_option, order_id = udp_codec.scan(data, sess_k, sess_v80, udp_plan, _UDP_CONTROL_CMDS)
            if insta_at:
                return        # mort annoncée (BR_INSTA_LEAVE) : plus de réponse, la partie s'arrête
            if chase is not None and first in _CS_CHASE_CMDS:
                # Clash Squad (CS_CHASE) : positions des joueurs (2001 / 2012, non chiffrés), dégâts (2010 : équipe
                # des victimes), manches (145 / 117, en-tête seul)
                if first in (UDP_PLAYER_STATE_SYNC, UDP_PLAYER_STATE_SYNC_V2, UDP_PLAYER_HURT):
                    fr = udp_codec.decode(data, udp_key_bytes, lays)
                    c = fr.get("content") if fr else None
                    if c is not None and first == UDP_PLAYER_HURT:
                        chase.on_hurt(bytes(c), now)
                        # dégâts infligés en direct (ffbot.teamlab, carte de l'équipe ; envoyés par le worker)
                        if state is not None:
                            state["dmg"], state["hits"] = chase.dmg_dealt, chase.hits_dealt
                        if skill_test:
                            skill_hit(bytes(c), now)
                    elif c is not None:
                        chase.on_state(first, bytes(c), now)
                elif first == RUDP_FORCE_SYNC_PLAYER_STATE:
                    chase.on_force(now)              # position imposée (contenu chiffré, l'en-tête suffit)
                else:
                    chase.on_round(first, now)
                    if first == RUDP_SAFE_ZONE_CHANGE:
                        # vraie zone : contenu du 117 (clé de session, sinon clé du match), voir _CsChase.on_zone
                        zc = _read_any_content(data, udp_key_bytes, session_key_bytes, lays)
                        if zc is None or not chase.on_zone(zc, now):
                            diag.event("MATCH", "cs_zone_unread", level="debug", have_session=bool(session_key_bytes))
            if chase is not None:
                # soin / achat d'arme : réponses du serveur (clé de session, voir CS_HEAL / CS_BUY) ; les 204 arrivent
                # souvent avec un en-tête étendu, que scan ne lit pas
                item_cmd = first if first is not None else _ext_cmd(data, udp_key_bytes, session_key_bytes, lays)
                if item_cmd in _CS_ITEM_CMDS:
                    ic = _read_any_content(data, udp_key_bytes, session_key_bytes, lays)
                    if ic is not None:
                        chase.on_item(item_cmd, ic, now)
            if cs_fight_at is None and mode in CS_MODES and first == RUDP_SAFE_ZONE_CHANGE \
                    and now - match_start_time >= CS_FIGHT_AFTER_S:
                cs_fight_at = now
                diag.event("MATCH", "cs_fight", level="info", after_s=round(now - match_start_time, 1))
            if skill_test and first == RUDP_SYNC_ACTIVE_SKILL_STATE:
                skill["states"].append(now)          # réponse du serveur à un 248 (le nôtre ou celui d'un autre)
            if skill_test and first == RUDP_SKILL_OBJECT_SPAWN and order_id not in skill["drone_orders"]:
                # 538 CREATE : เนื้อเป็น session key อ่านเลขไม่ได้ แต่ header+order อ่านได้ด้วย match key และ "มาถึงบอท
                # ครบทุกตัวแบบเรียงลำดับ" (reliable in) — ของเรามา ~0.05 วิ หลัง 248 ของเรา. นับเป็นเลขรันนิ่ง (เริ่ม 3).
                # ยืนยัน 28/10 23:18 : 538 ตัวที่ 4 = โดรน id 6 ตรงกับ 541. (โดรนเรา "ไม่" ถูกส่ง 541 กลับมา จึงต้องนับ 538)
                skill["drone_orders"].add(order_id)
                skill["drone_count"] += 1
                skill["drones"].append((now, CS_DRONE_FIRST_ID + skill["drone_count"] - 1))
            if skill_test and first == RUDP_DRONE_POS:
                # 541 (match key) : เลขโดรนจริงของเซิร์ฟ — โดรนที่เห็นมักเป็นของคนอื่น/ไกล (ของเราไม่ถูกส่ง 541). ใช้
                # คาลิเบรตการนับ : ถ้าเลขจริงสูงกว่าเลขที่นับล่าสุด = พลาดนับ 538 บางตัว → เลื่อน id_shift ให้ตรง.
                fr = udp_codec.decode(data, udp_key_bytes, lays)
                c = bytes(fr["content"]) if fr and fr.get("content") else b""
                did, _j = _read_varint(c, 0)
                if did is not None:
                    skill["last_real_at"] = now
                    counted_max = CS_DRONE_FIRST_ID + skill["drone_count"] - 1 + skill["id_shift"]
                    if did > counted_max:
                        skill["id_shift"] += did - counted_max
                        diag.event("MATCH", "skill_id_shift", level="info", shift=skill["id_shift"],
                                   drone=did, counted=skill["drone_count"])
                    if did not in skill["tracks"]:
                        skill["tracks"].add(did)
                        if did in skill["mine"]:
                            diag.event("MATCH", "skill_fly", level="info", drone=did,
                                       after_lock_s=round(now - skill["last_lock"], 2) if skill["last_lock"] else None)
            # (CS_CHASE : le client officiel reçoit aussi des 144 en Clash Squad, ses 2001 continuent)
            if UDP_STATE_SYNC and chase is None and not state_stop.is_set() and (
                    first in _BOARDING_CMDS or first == RUDP_FORCE_SYNC_PLAYER_STATE):
                # embarquement dans l'avion (944 / 1250) ou 1re correction du serveur (144) : plus d'état du joueur
                # (voir UDP_STATE_SYNC ; le client officiel se tait dès l'embarquement et ne reçoit jamais de 144)
                state_stop.set()
                diag.event("MATCH", "state_sync_stop", level="debug",
                           why="boarding" if first in _BOARDING_CMDS else "force_sync", cmd=first,
                           at_s=round(now - match_start_time, 1))
            if life is not None:
                # corrections de position, morts annoncées, offre / retour de réanimation (voir _BrLife)
                life.on_packet(first, cmd, now)
                if insta and first in (RUDP_DEAD, RUDP_MATCH_EVENT_ACHIEVEMENT) and life.own_death(now):
                    insta_quit(now, data, addr)
                    return
                if first == UDP_PLAYER_HURT:
                    # PV du joueur (affichés sur le site, départ BR_LEAVE_HP, mort crédible) : UDP_PLAYER_HURT
                    fr = udp_codec.decode(data, udp_key_bytes, lays)
                    hit = _hurt_info(bytes(fr["content"])) if fr and fr.get("content") is not None else None
                    if hit and life.on_hit(hit[0], hit[1], now) and state is not None and not life.examining():
                        state["hp"] = life.hp
                elif first in (UDP_PLAYER_STATE_SYNC, UDP_PLAYER_STATE_SYNC_V2):
                    # état d'un joueur envoyé par le serveur (« 00 02 <n°> », non chiffré) : le joueur local tant
                    # qu'il vit (n° appris, voir LOCAL_INDEX_VOTES). 2012 (V2) depuis 1.132.13, même format.
                    fr = udp_codec.decode(data, udp_key_bytes, lays)
                    c = fr.get("content") if fr else None
                    if c is not None and len(c) > 2 and c[0] == 0 and c[1] == 2 and c[2] < 0x80:
                        life.on_state(c[2], now)
            if cmd is not None or first is not None:
                traffic.packet(first if cmd is None else cmd, now)
            if first == UDP_BYEBYE:
                rx["bye"] = now           # le serveur ferme la session : la partie s'arrête au prochain tour de boucle
            elif first == RUDP_MATCH_END and not rx["match_end"]:
                rx["match_end"] = now
            if first == UDP_SYNC_SERVER_TIME and UDP_TIME_SYNC and ack_state == "thunder_sharma_sent":
                # synchro de l'heure (voir UDP_TIME_SYNC) : renvoi du compteur reçu, sans son dernier octet
                fr = udp_codec.decode(data, udp_key_bytes, lays)
                body = bytes(fr["content"]) if fr and fr.get("content") is not None else b""
                if len(body) >= 2:
                    fast_send(udp_codec.build_packet(0x66, lays[1], 0, UDP_SYNC_SERVER_TIME, None, 0, body[:-1],
                                                     udp_key_bytes, CRC7_TABLE, encrypted=False,
                                                     ext=acker.take() if acker is not None else None), addr)
                    traffic.time_sync += 1
            if order_id is not None and send_option and first not in _NO_ACK_CMDS:
                # message fiable du serveur : accusé de réception (prochain numéro attendu, N+1), sinon il est renvoyé
                # sans fin puis la connexion est coupée (UDP_BYEBYE, voir UDP_RUDP_ACK). Renvoi = nouvel accusé (le
                # nôtre a pu se perdre).
                traffic.reliable(order_id, send_option)
                if rack and ack_state == "thunder_sharma_sent":
                    if acker is not None:
                        acker.note(order_id)     # accusé groupé : joint au prochain 2001 / 2000, sinon seul (UDP_ACK_DELAY_S)
                    else:
                        fast_send(udp_codec.build_packet(0x68, lays[1], 0, 2, None, 1,
                                                         struct.pack("<H", (order_id + 1) & 0xFFFF),
                                                         udp_key_bytes, CRC7_TABLE), addr)
                        traffic.acks_sent += 1
            if cmd is None:
                return        # paquet d'état : rien à faire
            _udp_stats.control += 1
            _udp_stats.by_cmd[cmd] = _udp_stats.by_cmd.get(cmd, 0) + 1
            # ACK (partie lancée) et PING : l'essentiel des paquets de contrôle, une réponse fixe. Répondus ici,
            # sans file ni réveil de la partie (même paquet de réponse qu'avant, octet pour octet).
            if cmd == 3:
                frame = udp_codec.decode(data, udp_key_bytes, lays)
                if frame is not None and frame["cmd"] == 3:
                    _udp_stats.decoded += 1
                    traffic.ping_in += 1
                    counter = _ping_counter(frame["content"] or b"")
                    if traffic.is_echo(counter, now):
                        # écho d'un PING que l'on vient d'envoyer ou de répondre : y répondre relance la boucle
                        traffic.ping_echo += 1
                        if counter in traffic.ours:
                            traffic.ping_ours += 1
                        _udp_stats.ping_echoes += 1
                        if UDP_PING_DEDUP:
                            return
                    traffic.remember(counter, now)
                    fast_send(_ping_reply(counter, udp_key_bytes, lays), addr)
                    traffic.ping_reply += 1
                    return
            elif cmd == 2 and ack_state == "thunder_sharma_sent":
                # ACK du serveur (nos messages fiables) : compté, jamais accusé en retour (voir UDP_ACK_DELAY_S).
                # Son contenu est le PROCHAIN numéro d'ordre attendu : relevé (traffic.ack_next) pour savoir si le
                # serveur a bien accepté toute la séquence d'entrée. Quelques ACK par partie : le déchiffrement
                # ne pèse rien.
                traffic.ack_in += 1
                fr = udp_codec.decode(data, udp_key_bytes, lays)
                body = bytes(fr["content"]) if fr and fr.get("content") is not None else b""
                if len(body) >= 2:
                    traffic.ack_next = max(traffic.ack_next, body[0] | (body[1] << 8))
                return
            try:
                rx_queue.put_nowait((data, addr))
            except asyncio.QueueFull:
                _udp_stats.dropped += 1

        def on_rx_error(exc: Exception) -> None:
            # socket en erreur (coupure réseau : WinError 1236 / 10051, ENETUNREACH…)
            if not rx["error_since"]:
                rx["error_since"] = time.time()
                info["error"] = repr(exc)[:300]
                diag.event("MATCH", "socket_error", level="warning", exc=exc, stage=info["ack_state"])

        async def udp_reader():
            """Lecture par tâche (Windows : le transport UDP de la boucle Proactor cesse de lire après une erreur)."""
            while True:
                try:
                    data, addr = await loop.sock_recvfrom(sock, 65535)
                except asyncio.CancelledError:
                    raise
                except BlockingIOError:
                    await asyncio.sleep(0.05)
                    continue
                except OSError as e:
                    on_rx_error(e)
                    await asyncio.sleep(0.5)
                    continue
                except Exception:
                    await asyncio.sleep(0.5)
                    continue
                if data:
                    on_datagram(data, addr)

        if _udp_rx_transport(loop):
            # Linux : socket inscrite une fois pour toutes auprès du noyau (sock_recvfrom l'inscrit et la
            # désinscrit à CHAQUE paquet : 4 à 5 appels système par paquet), lecture par rappel.
            rx_transport, _ = await loop.create_datagram_endpoint(lambda: _UdpRx(on_datagram, on_rx_error), sock=sock)
        else:
            reader_task = asyncio.create_task(udp_reader())
        RX_WAIT_S = 1.5

        async def send_quit_request():
            # Sortie propre (markdown phase 5) : RUDP_PLAYER_QUIT_REQ (191) fiable. Le serveur repond 192
            # (RUDP_PLAYER_QUIT_RES -> OnQuitMatchToLobby) et finalise le resultat du joueur, au lieu d'un abandon
            # de socket. Contenu vide (payload C2S non capture) : a confirmer par la reception du 192 dans watch.
            nonlocal reliable_order
            try:
                pkt = udp_codec.build_packet(0x62, lays[0], 2, RUDP_PLAYER_QUIT_REQ, reliable_order, 1, b"",
                                             rel_key, CRC7_TABLE)
                reliable_order += 1
                traffic.rel_out = reliable_order
                cap_out(pkt)
                await _sendto_retry(loop, sock, pkt, (resolved_ip, port))
                diag.event("MATCH", "quit_request", level="info", order=reliable_order - 1)
            except Exception as e:
                loop_error(e)

        async def send_rel(cmd: int, content: bytes) -> None:
            """Soin, achat (voir CS_HEAL / CS_ITEM_CHANNEL) : fiable + clé de session comme le client officiel, ou, sans
            clé de session, non fiable avec la clé du match comme le drone (CS_SKILL_UNRELIABLE)."""
            nonlocal reliable_order
            unrel = CS_ITEM_CHANNEL == "unrel" or (CS_ITEM_CHANNEL == "auto" and not session_key_bytes)
            if unrel:
                pkt = udp_codec.build_packet(random.randint(0x64, 0x6D), lays[1], 0, cmd, None, 0, content,
                                             udp_key_bytes, CRC7_TABLE, encrypted=False)
            else:
                pkt = udp_codec.build_packet(random.randint(0x5A, 0x63), lays[0], 2, cmd, reliable_order, 1, content,
                                             rel_key, CRC7_TABLE)
                reliable_order += 1
                traffic.rel_out = reliable_order
            cap_out(pkt)
            await _udp_send_quietly(loop, sock, pkt, (resolved_ip, port))

        async def send_skill_msg(cmd: int, content: bytes) -> int:
            """248 / 543 (CS_SKILL_TEST) : reliable + clé du match si CS_SKILL_RELMATCH (test 28/10, comme Thunder/Sharma),
            sinon non fiable + clé du match si CS_SKILL_UNRELIABLE (n° d'ordre -1), sinon fiable + clé de session."""
            nonlocal reliable_order
            if CS_SKILL_RELMATCH:
                # reliable + match key (so=2, flags=1, chiffré clé du match) — comme 447/448 ; teste si le serveur crée
                # le drone sur ce canal (unreliable ne le créait pas). n° d'ordre fiable consommé.
                pkt = udp_codec.build_packet(random.randint(0x5A, 0x63), lays[0], 2, cmd, reliable_order, 1, content,
                                             udp_key_bytes, CRC7_TABLE)
                order = reliable_order
                reliable_order += 1
                traffic.rel_out = reliable_order
            elif CS_SKILL_UNRELIABLE:
                pkt = udp_codec.build_packet(random.randint(0x64, 0x6D), lays[1], 0, cmd, None, 0, content,
                                             udp_key_bytes, CRC7_TABLE, encrypted=False)
                order = -1
            else:
                pkt = udp_codec.build_packet(random.randint(0x5A, 0x63), lays[0], 2, cmd, reliable_order, 1, content,
                                             rel_key, CRC7_TABLE)
                order = reliable_order
                reliable_order += 1
                traffic.rel_out = reliable_order
            cap_out(pkt)
            await _udp_send_quietly(loop, sock, pkt, (resolved_ip, port))
            return order

        while not local_closed:
            info["ack_state"] = ack_state
            if tun_gen != _TUNABLES_GEN:
                # réglages changés sur la page pendant la partie : suivis tout de suite
                tun_gen = _TUNABLES_GEN
                leave_after_s, death_watch, insta, leave_hp = _leave_plan(mode, account_id, owner_uid)
                if life is not None:
                    life.watch = death_watch or insta
                diag.event("MATCH", "settings_live", level="info", leave_after_s=leave_after_s, leave_hp=leave_hp,
                           death_watch=death_watch, insta=insta, at_s=round(time.time() - match_start_time))
            if insta_at:
                # mort annoncée, silence depuis la lecture du paquet (BR_INSTA_LEAVE)
                diag.event("MATCH", "insta_leave", level="info", at_s=round(insta_at - match_start_time, 2),
                           **insta_info)
                completed_cleanly = True
                info["reason"] = "BR_INSTA_LEFT"
                info.update(insta_info)
                break
            if life is not None:
                # PV bas, mort du joueur, réanimation (voir _BrLife) : une décision par tour, journalisée
                leave = None
                for _ in range(3):
                    act = life.step(time.time(), leave_hp)
                    if act is None:
                        break
                    kind, data = act
                    at_s = round(time.time() - match_start_time)
                    if kind == "low_hp":
                        # PV presque épuisés (zone / tirs) : départ en vie avant la mort (mourir = 0 EXP), voir BR_LEAVE_HP
                        diag.event("MATCH", "low_hp", level="info", at_s=at_s, **data)
                        leave = "BR_LOW_HP"
                        break
                    if kind == "death" or (kind == "dead" and data.pop("new", False)):
                        # le joueur vient de mourir (plus de correction de position + RUDP_DEAD au même moment) ; avec
                        # REVIVE_CHECK : mort crédible d'après les PV, attente si une réanimation est proposée
                        if state is not None:
                            state["hp"] = 0
                        diag.event("MATCH", "own_death", level="info", died_s=round(life.death_t - match_start_time),
                                   at_s=at_s, **data)
                    if kind == "doubt":
                        # silence des corrections au moment d'une mort, mais PV encore hauts : pas une mort, on reste
                        diag.event("MATCH", "death_doubt", level="info", at_s=at_s, **data)
                    elif kind in ("revived", "alive"):
                        # de retour en jeu (réanimé : PV pleins ; sinon mort vue à tort) : la partie continue
                        if state is not None:
                            state["hp"] = life.hp
                        diag.event("MATCH", kind, level="info", at_s=at_s, revivals=life.revivals, **data)
                    elif kind == "dead":
                        # toujours mort : départ, partie terminée sans « ABANDONED » (voir BR_LEAVE_ON_DEATH)
                        if data.get("waited_s"):
                            diag.event("MATCH", "dead_leave", level="info", at_s=at_s, **data)
                        leave = "PLAYER_DEAD" if data.get("src") == "packet" else "BR_DIED_LEFT"
                        break
                if leave:
                    if leave == "BR_LOW_HP" and UDP_QUIT_ON_LEAVE and not quit_sent:
                        # départ EN VIE : 191 comme le joueur qui quitte par le menu (capture du 16/10)
                        quit_sent = True
                        await send_quit_request()
                        await asyncio.sleep(QUIT_GRACE_S)
                    # mort (PLAYER_DEAD / BR_DIED_LEFT) : silence, comme le client officiel (captures du 21/10 : aucun
                    # 191 après la mort, EXP reçue à la mort, UDP_BYEBYE du serveur ~55 s plus tard)
                    quit_sent = True
                    completed_cleanly = True
                    info["reason"] = leave
                    break
            if is_br and BR_NO_DATA_S and sharma_sent and time.time() - match_start_time > BR_NO_DATA_S \
                    and info["rx_bytes"] < BR_NO_DATA_KB * 1024:
                # rejointe mais le serveur n'envoie que des PING (le joueur n'est pas dans la partie) : 0 EXP en
                # restant, partie ratée, le compte en cherche une autre (voir BR_NO_DATA_S)
                diag.event("MATCH", "no_game_data", level="warning", code="MATCH_NO_DATA",
                           rx_kb=round(info["rx_bytes"] / 1024, 1), rx=info["rx_packets"],
                           at_s=round(time.time() - match_start_time))
                info["reason"] = "MATCH_NO_DATA"
                break
            if is_br and leave_after_s and sharma_sent and time.time() - match_start_time > leave_after_s \
                    and not (life is not None and life.examining()):
                # (mort en cours de vérification : c'est elle qui décide du départ)
                # BR : départ volontaire en cours de partie, la seule façon d'être crédité d'EXP (voir BR_LEAVE_AFTER_S)
                if UDP_QUIT_ON_LEAVE and not quit_sent:
                    # sortie propre comme le vrai client (markdown phase 5) : 191 -> le serveur repond 192 et
                    # finalise le resultat, au lieu de fermer la socket net ; QUIT_GRACE_S pour laisser repondre
                    quit_sent = True
                    await send_quit_request()
                    await asyncio.sleep(QUIT_GRACE_S)
                completed_cleanly = True
                info["reason"] = "BR_LEFT"
                break
            if time.time() - match_start_time > max_duration:
                # BR : borne de sécurité au-delà d'une partie complète, comptée comme terminée (comme le script BR)…
                # seulement si le joueur a bien rejoint la partie (Sharma envoyé) : sinon ce n'est pas une partie jouée
                completed_cleanly = is_br and sharma_sent
                info["reason"] = "MAX_DURATION"
                break
            if rx["bye"] and rx["last"] > rx["bye"]:
                # paquets reçus après le « BYEBYE » : faux BYEBYE (voir BYE_CONFIRM_S), la partie continue
                diag.event("MATCH", "bye_ignored", level="info", after_s=round(time.time() - match_start_time, 1))
                rx["bye"] = 0.0
            if rx["bye"] and time.time() - rx["bye"] >= BYE_CONFIRM_S:
                # le serveur a fermé la session (UDP_BYEBYE) : rien ne viendra plus, inutile d'attendre 60 s de silence.
                # Partie jouée si le joueur l'avait rejointe (Sharma envoyé), sinon refusée par le serveur.
                completed_cleanly = sharma_sent
                info["reason"] = "SERVER_BYE"
                print_info(f"[MATCH #{match_index}] UDP_BYEBYE du serveur après {int(time.time() - match_start_time)}s")
                break
            if rx["match_end"] and time.time() - rx["match_end"] > MATCH_END_GRACE_S and sharma_sent:
                completed_cleanly = True
                info["reason"] = "MATCH_END"
                break
            # Connexion à la partie pas encore établie : délais vérifiés à CHAQUE tour. Le serveur peut envoyer des
            # paquets d'état sans arrêt (plus d'un million en 25 min) : la branche « délai dépassé » plus bas n'est
            # alors jamais atteinte, et la partie restait bloquée jusqu'à la borne de 25 min (relevé du 14/10).
            if ack_state == "waiting_for_hello_reply":
                now_t = time.time()
                if not keep_waiting(now_t - match_start_time, handshake_timeout):
                    print_warning(f"[MATCH #{match_index}] Handshake timeout")
                    info["reason"] = "HANDSHAKE_TIMEOUT"
                    break
                if now_t - last_hello_at > MAX_IDLE_BEFORE_HELLO_RESEND:
                    last_hello_at = now_t
                    try:
                        pkt = await build_hello_packet(hello_text, udp_key_bytes, match_code)
                        cap_out(bytes.fromhex(pkt))
                        await _sendto_retry(loop, sock, bytes.fromhex(pkt), (resolved_ip, port))
                    except Exception as e:
                        loop_error(e)
            if ack_state == "ready_to_send_thunder" and not sharma_sent:
                # Thunder / Sharma : premier envoi, ou nouvel essai après un refus du système (WinError 10055…)
                if send_fail_since and time.time() - send_fail_since > SEND_GIVE_UP_S:
                    print_warning(f"[MATCH #{match_index}] envoi Thunder/Sharma impossible depuis "
                                  f"{int(SEND_GIVE_UP_S)}s : partie perdue")
                    info["reason"] = "UDP_SEND_FAILED"
                    break
                await send_thunder_sharma_inline()
            while sharma_sent and join_seq_i < len(join_seq) \
                    and time.time() - sharma_at >= join_seq[join_seq_i][0]:
                # séquence d'entrée (1026, 1446, 899) : messages fiables à la suite, n° d'ordre contigus après le 448
                _, msg_key, seq_cmd, seq_body = join_seq[join_seq_i]
                join_seq_i += 1
                if UDP_JOIN_UNREL or UDP_JOIN_REPLAY:
                    # non fiable + clé du match (comme le 248) : le canal fiable+session cale, on tente de se faire
                    # compter comme « chargé » (899) autrement. n° d'ordre -1 (pas d'accusé), en-tête plage non fiable.
                    pkt = udp_codec.build_packet(random.randint(0x64, 0x6D), lays[1], 0, seq_cmd, None, 0, seq_body,
                                                 udp_key_bytes, CRC7_TABLE, encrypted=False)
                    cap_out(pkt)
                    await _udp_send_quietly(loop, sock, pkt, (resolved_ip, port))
                    diag.event("MATCH", "join_seq", level="debug", cmd=seq_cmd, order=-1, via="unrel/match",
                               at_s=round(time.time() - sharma_at, 2))
                    continue
                pkt = udp_codec.build_packet(msg_key, lays[0], 2, seq_cmd, reliable_order, 1, seq_body,
                                             rel_key, CRC7_TABLE)
                reliable_order += 1
                traffic.rel_out = reliable_order
                cap_out(pkt)
                await _udp_send_quietly(loop, sock, pkt, (resolved_ip, port))
                diag.event("MATCH", "join_seq", level="debug", cmd=seq_cmd, order=reliable_order - 1, via="rel/session",
                           at_s=round(time.time() - sharma_at, 2))
            if chase is not None and sharma_sent:
                # soin et achat d'arme (CS_HEAL / CS_BUY) : horloge du match comme le 2001 (cs_state_loop)
                now_i = time.time()
                if state is not None and chase.idx is not None:
                    # PV du bot en direct pour le site (200 - dégâts reçus dans la manche, recalés par le 310 du soin)
                    state["hp"] = max(0, PLAYER_MAX_HP - chase.hp_lost) if chase.alive else 0
                    state["heals"] = chase.heals_ok
                    state["heals_sent"] = chase.heals
                    state["confirmed"] = chase.replies_readable
                    state["healing"] = now_i < chase.healing_until
                for item_cmd, item_body in chase.item_actions(now_i, int((now_i - match_start_time) * 1000)
                                                              + CS_TIME_OFFSET_MS):
                    await send_rel(item_cmd, item_body)
                    diag.event("MATCH", "cs_item_send", level="info", cmd=item_cmd, body=item_body.hex(),
                               via="unrel/match" if CS_ITEM_CHANNEL == "unrel" or (
                                   CS_ITEM_CHANNEL == "auto" and not session_key_bytes) else "rel/session")
            if skill_test and sharma_sent:
                # compétence active (CS_SKILL_TEST) : 248 en combat, puis bilan une seconde après chaque envoi
                now_s = time.time()
                for sent_at, order in [p for p in skill["pending"] if now_s - p[0] >= 1.0]:
                    skill["pending"].remove((sent_at, order))
                    acked = order >= 0 and traffic.ack_next > order
                    # réponse au nôtre : < 10 ms chez le vrai client ; le 250 va à tous (compétences des autres), une
                    # fenêtre d'1 s en comptait un d'un autre joueur, arrivé 0,83 s après (essai du 25/10 23:02)
                    answered = any(sent_at <= t <= sent_at + 0.05 for t in skill["states"])
                    skill["acked"] += acked
                    skill["answered"] += answered
                    if not answered:
                        # refusé (rechargement, mort…) : nouvel essai bien avant la fin des 61 s
                        skill["next"] = min(skill["next"], sent_at + CS_SKILL_RETRY_S)
                    diag.event("MATCH", "skill_result", level="info", order=order, acked=acked, answered=answered,
                               ack_next=traffic.ack_next, rel_out=reliable_order)
                    if state is not None:
                        state.setdefault("skill_log", []).append({"order": order, "acked": acked, "answered": answered})
                # โดรนของเรา = 538 ตัวแรกที่มาหลัง 248 ของเรา (ภายใน CS_DRONE_PICK_S ; จริง ~0.05 วิ). เก็บเลขที่นับไว้ แล้ว
                # ส่ง 543 ล็อกศัตรูที่ +CS_DRONE_LOCK_S (ให้โดรนบินออกไปก่อน เหมือน client จริง). เลขจริง = นับ + id_shift
                # (คาลิเบรตจาก 541). โดรนของเราไม่ส่ง 541 กลับมาให้บอท จึงใช้การนับ 538 (ที่มาครบ) ไม่ใช่ตำแหน่ง 541.
                for sent_at in [t for t in skill["casts"] if now_s - t >= CS_DRONE_PICK_S]:
                    skill["casts"].remove(sent_at)
                    mine = [d for d in skill["drones"] if sent_at < d[0] <= sent_at + CS_DRONE_PICK_S]
                    if mine:
                        skill["locks"].append((sent_at + CS_DRONE_LOCK_S, mine[0][1]))   # (เวลาล็อก, เลขนับดิบของโดรนเรา)
                    elif chase is not None and not skill["retried"] and skill["round_fired"] == chase.rounds:
                        # กดแล้วไม่มี 538 ตามมาเลย = เซิร์ฟไม่รับการกด → ลองใหม่ที่ช่องตัวเอง
                        skill["retried"] = True
                        skill["round_fired"] = chase.rounds - 1
                        skill["next"] = sent_at + CS_SKILL_RETRY_S
                    diag.event("MATCH", "skill_drone", level="info",
                               drone=(mine[0][1] + skill["id_shift"]) if mine else None,
                               spawned=len(mine), seen=skill["drone_count"])
                for lock_at, raw_id in [lk for lk in skill["locks"] if now_s >= lk[0]]:
                    skill["locks"].remove((lock_at, raw_id))
                    foe = chase.nearest_foe(now_s) if chase is not None and chase.pos is not None else None
                    if foe is None and chase is not None and chase.last_attacker_id is not None and chase.pos is not None:
                        att = chase.last_attacker_id
                        if att in chase.players:
                            _, ax, ay, az = chase.players[att]
                            foe = (math.hypot(ax - chase.pos[0], az - chase.pos[2]), att, ax, ay, az)
                        else:
                            foe = (0.0, att, chase.pos[0], chase.pos[1], chase.pos[2])
                    if foe is None:
                        diag.event("MATCH", "skill_lock", level="info", drone=None, target=None)
                        continue
                    _foe_id = chase.ident_of(foe[1])
                    # เลขโดรนจริง ≥ เลขที่นับ (บอทไม่ได้รับ 538 ของโดรนศัตรู → นับขาด). กวาดยิง 543 [นับ .. นับ+SPAN]
                    # เป้าเดียวกัน ; เซิร์ฟบังคับเฉพาะโดรนที่เราเป็นเจ้าของ เลขอื่นถูกเมิน (ปลอดภัย ไม่แย่งของคนอื่น).
                    hi = raw_id + max(CS_DRONE_ID_SPAN, skill["id_shift"] + 5)
                    order = None
                    for cand in range(raw_id, hi + 1):
                        order = await send_skill_msg(RUDP_DRONE_TARGET,
                                                     cs_drone_target_content(cand, _foe_id, foe[2:]))
                    drone = raw_id + skill["id_shift"]
                    skill["mine"].add(drone)
                    skill["locked"] += 1
                    skill["last_lock"], skill["last_lock_id"] = now_s, drone
                    diag.event("MATCH", "skill_lock", level="info", drone_lo=raw_id, drone_hi=hi,
                               target=hex(_foe_id), dist_m=round(foe[0], 1), order=order,
                               team_guess=int(chase.team_for(foe[1]) is None))
                st = chase.step_last if chase is not None else None
                _alive = chase.alive if chase is not None else True
                _fight = (chase.fight if chase is not None else cs_fight_at is not None) \
                    if mode in CS_MODES else True
                _ident = chase.ident() if chase is not None else 0x1000001
                # โดรน : ศัตรูใกล้สุดอยู่ในระยะ (CS_DRONE_RANGE_M) ตั้งแต่วงแดงเปิด ; ทีมของเป้า (ident ใน 543) ใช้ที่รู้
                # ตอนล็อก — ก่อนดาเมจแรกยังไม่รู้ จึงเดาตาม n° (team_guess ใน skill_lock)
                _foe = chase.nearest_foe(now_s) if chase is not None and chase.pos is not None else None
                _urgent = False
                if chase is not None and chase.skill_urgent:
                    _urgent = True
                    chase.skill_urgent = False
                    if skill["next"] > now_s:
                        skill["next"] = now_s
                    if _foe is None and chase.last_attacker_id is not None and chase.pos is not None:
                        att = chase.last_attacker_id
                        if att in chase.players:
                            _, ax, ay, az = chase.players[att]
                            _foe = (math.hypot(ax - chase.pos[0], az - chase.pos[2]), att, ax, ay, az)
                if _alive and _fight and not skill["next"]:
                    skill["next"] = now_s + CS_SKILL_FIRST_S          # ครั้งแรก : หลังเริ่มสู้
                # un seul drone par partie, dans la 1re manche (voir CS_DRONE_ROUNDS)
                # (ก) กดทุกรอบทันที (ไม่รอ 541) รอบละครั้ง ; เลขรอบหลังอาจเพี้ยน lock_off จะหยุดเอง
                _ready = _alive and _fight and now_s >= skill["next"] and (
                    drone_turn is None or drone_turn.may_cast(drone_side, now_s)) and (
                    chase is None or ((_foe is not None and _foe[0] <= CS_DRONE_RANGE_M or _urgent)
                                      and chase.rounds <= CS_DRONE_ROUNDS
                                      and (not CS_SKILL_PER_ROUND or chase.rounds > skill["round_fired"])))
                if not _ready:
                    skill["ready_at"] = 0.0
                elif not skill["ready_at"]:
                    # บอทในทีมมักพร้อมพร้อมกัน (เริ่มรอบ / เห็นศัตรู / คูลดาวน์ครบพร้อมกัน) : 538 มาพร้อมกันแยกไม่ออก
                    # (27/10 20:08 รอบ 2-3 : 3 ตัวกดในวินาทีเดียวกัน ไม่มีตัวไหนล็อก) → ช่องตาม n° นับจากวงแดงเปิด
                    # (CS_SKILL_SLOTS) : ช่องถัดไปของตัวเองที่ยังไม่ผ่าน
                    _slot = (chase.idx - 1) % CS_SKILL_SLOTS if chase is not None and chase.idx \
                        else random.randrange(CS_SKILL_SLOTS)
                    _base = (chase.fight_at if chase is not None else cs_fight_at) or now_s
                    _cycle = CS_SKILL_SLOTS * CS_SKILL_SLOT_S
                    _first = _base + _slot * CS_SKILL_SLOT_S
                    skill["ready_at"] = _first + max(0, math.ceil((now_s - _first) / _cycle)) * _cycle
                if _ready and now_s >= skill["ready_at"]:
                    skill["ready_at"] = 0.0
                    # (ทิศของโดรนมาจากเป้าใน 543 ไม่ใช่ทิศที่หันหน้า : บอทหันตามทางที่เดินเสมอ)
                    if st is not None:
                        pos, vel, _ = st
                    else:
                        pos, vel = (0.0, 0.0, 0.0), (0, 0, 0)
                    # เล็งโดรนไป "ที่ศัตรูใกล้สุด" เหมือน client จริง (จุดเล็งห่างตัว 12–87 ม. ไปทางศัตรู : แคป 28/10).
                    # บั๊กเดิม : ใส่ตำแหน่งตัวเอง (ห่าง 0.0 ม.) → โดรนพุ่งใส่เท้าตัวเอง ไม่ไปหาศัตรู. pos (ตำแหน่งเราเอง)
                    # ยังเก็บไว้จับคู่ 541 ของโดรนเรา (โดรนออกจากตัวเราเสมอ ไม่ใช่จากจุดเล็ง).
                    _aim = tuple(_foe[2:5]) if _foe is not None and len(_foe) >= 5 else pos
                    # order -1 = non fiable (pas d'accusé) : résultat d'après le 250 (« answered »)
                    order = await send_skill_msg(RUDP_USE_ACTIVE_SKILL, cs_skill_content(_ident, CS_SKILL_ID, _aim, vel))
                    skill["pending"].append((now_s, order))
                    skill["casts"].append(now_s)               # เวลา cast ; โดรนเรา = 538 ตัวแรกที่มาหลังเวลานี้
                    if chase is not None:
                        skill["round_fired"] = chase.rounds       # กดแล้วรอบนี้ (กดได้รอบละครั้ง)
                    skill["sent"] += 1
                    skill["next"] = now_s + CS_SKILL_EVERY_S
                    diag.event("MATCH", "skill_sent", level="info", order=order, skill=CS_SKILL_ID,
                               ident=hex(_ident), via="rel/match" if CS_SKILL_RELMATCH else
                               "unrel/match" if CS_SKILL_UNRELIABLE else "rel/session",
                               foe_m=round(_foe[0], 1) if _foe is not None else None)
            if (UDP_STATE_SYNC or chase is not None) and sharma_sent and state_task is None \
                    and not state_stop.is_set() and time.time() - sharma_at >= STATE_SYNC_START_S:
                if chase is not None:
                    state_task = asyncio.create_task(cs_state_loop(sock, (resolved_ip, port), udp_key_bytes, lays,
                                                                   state_stop, match_start_time, chase,
                                                                   on_tx=cap_out if capture is not None else None,
                                                                   acker=acker))
                else:
                    state_task = asyncio.create_task(state_sync_loop(sock, (resolved_ip, port), udp_key_bytes, lays,
                                                                     state_stop, match_start_time,
                                                                     on_tx=cap_out if capture is not None else None,
                                                                     acker=acker,
                                                                     ident=life.state_id if life is not None else None))
            try:
                wait_s = RX_WAIT_S
                if ack_state == "ready_to_send_thunder" and not sharma_sent:
                    # Thunder / Sharma dus join_delay après le HELLO : réveil à ce moment-là même sans paquet
                    wait_s = max(0.01, min(RX_WAIT_S, join_delay - (time.time() - last_hello_at)))
                elif sharma_sent:
                    # séquence d'entrée et départ des 2001 : réveil à l'heure dite même sans paquet reçu (0,1 à
                    # 0,4 s les séparent, un tour de boucle dure RX_WAIT_S — ils arrivaient jusqu'ici en retard)
                    due = [join_seq[join_seq_i][0]] if join_seq_i < len(join_seq) else []
                    if (UDP_STATE_SYNC or chase is not None) and state_task is None and not state_stop.is_set():
                        due.append(STATE_SYNC_START_S)
                    if skill_test:
                        # โดรน (CS_SKILL_TEST) : เลือก 538 ของเรา และล็อกเป้า (543) ตรงเวลา ไม่ใช่ช้าไปถึง RX_WAIT_S
                        due += [t + CS_DRONE_PICK_S - sharma_at for t in skill["casts"]]
                        due += [lk[0] - sharma_at for lk in skill["locks"]]
                        if skill["ready_at"]:
                            due.append(skill["ready_at"] - sharma_at)
                    if due:
                        wait_s = max(0.01, min(RX_WAIT_S, min(due) - (time.time() - sharma_at)))
                try:
                    response, server_addr = await asyncio.wait_for(rx_queue.get(), timeout=wait_s)
                except asyncio.TimeoutError:
                    response = None
                if rx["last"] > last_activity:
                    last_activity = rx["last"]
                if outage_since and rx["last"] > outage_since:
                    print_info(f"[MATCH #{match_index}] serveur de nouveau joignable après "
                               f"{int(rx['last'] - outage_since)}s de coupure : la partie continue")
                    info["outage_s"] += int(rx["last"] - outage_since)
                    diag.event("MATCH", "network_back", level="info", outage_s=int(rx["last"] - outage_since))
                    outage_since = 0.0
                if response is None:
                    if time.time() - rx["last"] < RX_WAIT_S:
                        continue      # paquets d'état reçus entre-temps : le serveur n'est pas muet
                    raise asyncio.TimeoutError
                frame = udp_codec.decode(response, udp_key_bytes, lays)
                if frame is None and session_key_bytes:
                    frame = udp_codec.decode(response, session_key_bytes, lays)
                if frame:
                    _udp_stats.decoded += 1
                    ptype = await classify(frame)

                    if frame['cmd'] == RUDP_DEAD and is_br and life is not None and life.revive_check \
                            and _mentions_account(frame['content'], account_id, owner_uid):
                        # mort du compte lisible : vérifiée comme les autres (réanimation proposée -> attente)
                        life.packet_death(time.time())
                        continue
                    if frame['cmd'] == RUDP_MATCH_END or (
                            frame['cmd'] == RUDP_DEAD and is_br
                            and _mentions_account(frame['content'], account_id, owner_uid)):
                        print_success(
                            f"[MATCH #{match_index}] Completed (cmd {frame['cmd']})"
                        )
                        completed_cleanly = True
                        info["reason"] = "MATCH_END" if frame['cmd'] == RUDP_MATCH_END else "PLAYER_DEAD"
                        local_closed = True
                        continue

                    if frame['cmd'] == 101:
                        # ancien accusé fixe (numéro 1) : remplacé par l'accusé du vrai numéro d'ordre (UDP_RUDP_ACK)
                        if not rack:
                            try:
                                ack_pkt = await build_packet(
                                    0x68, lays[1],
                                    0, 2, None, 1, b"\x01\x00", udp_key_bytes
                                )
                                cap_out(ack_pkt)
                                await loop.sock_sendto(sock, ack_pkt, server_addr)
                            except Exception:
                                pass
                        continue

                    if ptype in ["ACK", "PING", "HELLO", "JOIN_MATCH"]:
                        # Connexion comme le client officiel (capture du 21/10) : HELLO -> le serveur répond ACK « 01 00 »
                        # puis son HELLO (même texte, dernier octet 01) -> notre accusé « 01 00 » du HELLO ; Thunder /
                        # Sharma partent join_delay après notre HELLO (send_thunder_sharma_inline). Avant : un accusé
                        # de plus en réponse à l'ACK du serveur, et chaque ACK reçu ensuite renvoyé tel quel.
                        if ptype == "HELLO":
                            # HELLO du serveur (fiable, n° 0) : accusé à chaque réception (renvoyé si le nôtre se perd)
                            mark_handshake()
                            typ, reply = await reply_for(
                                frame, udp_key_bytes, match_code, ack_style="short"
                            )
                            if reply:
                                cap_out(reply)
                                await _sendto_retry(loop, sock, reply, server_addr)
                            if ack_state == "waiting_for_hello_reply":
                                ack_state = "ready_to_send_thunder"
                        elif ptype == "ACK":
                            # ACK du serveur (notre HELLO, puis Thunder / Sharma) : rien à répondre
                            if ack_state == "waiting_for_hello_reply":
                                mark_handshake()
                                ack_state = "ready_to_send_thunder"
                        elif ptype == "PING":
                            # (rare : PING non répondu par la tâche de lecture) même règle d'écho que là-bas
                            counter = _ping_counter(frame["content"] or b"")
                            if not (UDP_PING_DEDUP and traffic.is_echo(counter, time.time())):
                                traffic.remember(counter, time.time())
                                typ, reply = await reply_for(frame, udp_key_bytes, match_code)
                                if reply:
                                    cap_out(reply)
                                    await loop.sock_sendto(sock, reply, server_addr)
                        elif ptype == "JOIN_MATCH" and not join_match_received:
                            join_match_received = True
                            if not rack:
                                # ancien accusé fixe « 02 00 » ; avec UDP_RUDP_ACK l'accusé groupé (vrai n° d'ordre,
                                # voir _RudpAcker) suffit, comme le client officiel (« f2 00 » 86 ms après la rafale)
                                typ, reply = await reply_for(frame, udp_key_bytes, match_code)
                                if reply:
                                    cap_out(reply)
                                    await loop.sock_sendto(sock, reply, server_addr)
            except asyncio.TimeoutError:
                if rx["error_since"]:
                    # socket en erreur : on attend le retour du réseau, mais pas indéfiniment (sinon la place du
                    # panel reste prise jusqu'à la borne de durée)
                    if time.time() - last_activity > max(idle_timeout, handshake_timeout) + OUTAGE_GRACE_S:
                        print_warning(f"[MATCH #{match_index}] socket UDP en erreur depuis trop longtemps : partie perdue")
                        info["reason"] = "SOCKET_ERROR"
                        break
                # connexion (hello, accusé, Thunder / Sharma) : gérée en haut de la boucle, à chaque tour
                if ack_state == "thunder_sharma_sent":
                    if not keep_waiting(time.time() - last_activity, idle_timeout):
                        if outage_since:
                            # gardée pendant la coupure, mais le serveur ne répond plus : partie perdue, pas « terminée »
                            print_warning(f"[MATCH #{match_index}] serveur muet après la coupure réseau : partie perdue")
                            info["reason"] = "OUTAGE_LOST"
                        else:
                            print_success(f"[MATCH #{match_index}] Finished naturally")
                            completed_cleanly = True
                            info["reason"] = "IDLE_END"
                        break
                continue
            except Exception as e:
                loop_error(e)
                await asyncio.sleep(0.5)
                continue

            if ack_state == "ready_to_send_thunder" and not sharma_sent:
                await send_thunder_sharma_inline()

        return f"match #{match_index} finished"
    except asyncio.CancelledError:
        info["reason"] = info["reason"] or "CANCELLED"
        raise
    except Exception as e:
        print_error(f"[MATCH #{match_index}] error: {e}")
        info["reason"] = "MATCH_EXCEPTION"
        info["error"] = repr(e)[:300]
        diag.event("MATCH", "exception", level="error", code="MATCH_EXCEPTION", exc=e, server=server_ip_port,
                   stage=info["ack_state"])
        return f"match #{match_index} error"
    finally:
        _udp_matches.pop(match_key, None)
        if info["reason"] is None:
            task = asyncio.current_task()
            info["reason"] = "CANCELLED" if task is not None and task.cancelling() else "UNKNOWN"
        info.update(traffic.summary(info["rx_packets"]))
        info["rack"] = int(rack)
        if chase is not None:
            info["chase"] = chase.summary()
            try:
                await cs_walk_save()             # carte des passages (CS_WALKMAP), écrite dans un thread
            except Exception:
                pass
        if skill_test:
            info["skill"] = (f"sent={skill['sent']} acked={skill['acked']} answered_250={skill['answered']} "
                             f"drones_seen={len(skill['drones'])} id_shift={skill['id_shift']} lock_off={int(skill['lock_off'])} "
                             f"locked_543={skill['locked']} hits_w61={skill['hits']} "
                             f"ack_next={traffic.ack_next} rel_out={traffic.rel_out}")
        if capture is not None:
            capture.close({k: v for k, v in info.items() if v is None or isinstance(v, (bool, int, float, str))})
        if state is not None:
            state.update(info)
            state["completed"] = completed_cleanly
        ping_stop.set()
        if acker is not None:
            acker.close()             # plus d'accusé seul après la fin de la partie (socket fermée)
        if reader_task:
            reader_task.cancel()
            try:
                await reader_task
            except (asyncio.CancelledError, Exception):
                pass
        if rx_transport:
            rx_transport.close()      # ferme aussi la socket
            sock = None
        for task in (ping_task, state_task):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        if sock:
            try:
                sock.close()
            except Exception:
                pass


# ==================== RÉSULTATS DE PARTIE (passerelle) ====================
# La passerelle envoie au client des messages protobuf EN CLAIR : [type 1 octet][00][longueur 3 octets][protobuf]
# (le « match trouvé » est le type 0x03 ; seuls les envois du client sont chiffrés). Capture du 16/10 (1.132.11) :
#   0x04 résultat d'une partie du compte : 5.2 = identifiant de la partie (= 5.1 du « match trouvé », block_val),
#        5.7.1 = EXP gagnée, 5.7.8 -> 5.7.9 = EXP avant -> après, 5.7.6 -> 5.7.7 = niveau, 5.7.13 = or,
#        5.7.10 -> 5.7.11 = pts de rang avant -> après, 5.7.19 = position BR (capture 22/10 1.132.13) ;
#   0x0b niveau / EXP du compte : 5.2 -> 5.3 = niveau, 5.4 = EXP.
# Envoyés à la mort du joueur pour la partie en cours, et quelques minutes après la fin sur le serveur pour une partie
# quittée (relevé : +349 et +292 EXP pour deux parties br_ranked_rank du bot, ~3 min après leur coupure). Le bot les
# recevait sans les lire : son EXP n'était connue qu'au relevé du profil (panel à « +0 EXP » alors que l'EXP rentrait).
GW_MATCH_RESULT = 0x04
GW_LEVEL_EXP = 0x0B

# Messages du client officiel vers la passerelle et le chat, déchiffrés le 17/10 (clé ak / aiv du MajorLogin de la même
# session, capture 21:35 du compte 9240504956) : [type][02][longueur 4 octets][AES], contenu {1: requête, 2: paramètres}.
# Réponse de la passerelle (0x03, champ 4) : 11 = recherche acceptée, 5 = match trouvé, 14 = recherche annulée ; un
# StartMatch renvoyé pendant la recherche reçoit un accusé sans champ 4 (ignoré : le client officiel n'en envoie qu'un).
# Essai du 17/10 sur le compte de test : annulation -> 4=14 tout de suite, aucun match en 25 s, puis nouvelle recherche
# acceptée sur la même connexion. Non repris : 0x1d (données du SDK anti-triche : modèle, signature de l'APK…) et 0x28
# (rapports de sécurité chiffrés, 2+2 par session en 1.132.13, ~6,6 Ko en match ; cause probable du 0 EXP depuis 1.132.13),
# ni 0x03 {1: 7} (liste des modes, contient un bloc de sécurité).
GW_CANCEL_SEARCH = (0x03, b"\x08\x02")                         # {1: 2} -> 0x03 4=14
GW_SPECIAL_MODES = (0x0e, b"\x08\x20")                         # {1: 32} -> 0x0e 4=32, après la connexion
CHAT_JOIN_CHANNEL = (0x12, bytes.fromhex("0803120610051a02656e"))   # {1: 3, 2: {2: 5, 3: "en"}} -> 0x12 4=5
CHAT_HELLO = (0x1e, bytes.fromhex("08031200"))                 # {1: 3, 2: ""}, ~5 s après la connexion au chat
# De retour au lobby après chaque partie, le client officiel rejoint le salon (CHAT_JOIN_CHANNEL -> 0x12 4=5, nouveau
# n° de salon : 1003 puis 1006, capture du 21/10) ~10 s après avoir quitté la partie ; le bot ne le faisait qu'à la
# connexion. Non repris : le 0x12 envoyé en entrant dans la partie (réponse 4=7 {1: 1003, 2: 5, 3: "default"}, contenu
# chiffré jamais déchiffré) et la liste des modes 0x03 {1: 7} redemandée (bloc de sécurité).
CHAT_REJOIN_DELAY_S = (3.0, 8.0)
_chat_rejoin: Dict[str, asyncio.Event] = {}


def _chat_rejoin_signal(uid: str) -> None:
    """Dernière partie du compte finie (retour au lobby) : sa connexion « chat » rejoint le salon (informational)."""
    ev = _chat_rejoin.get(str(uid))
    if ev is not None:
        ev.set()


GW_SEARCH_ACCEPTED, GW_SEARCH_CANCELLED = 11, 14
CANCEL_ACK_TIMEOUT_S = 3.0     # annulation sans 4=14 : connexion coupée (ancien moyen d'annuler)
GATEWAY_DEAD_S = 40.0          # recherche acceptée : connexion tenue pour morte sans rien reçu (maintien compris) en 40 s
SEARCH_REQUEUE_S = 240.0       # recherche acceptée sans match depuis 4 min : annulée puis relancée (même connexion)

# ---------- Équipe (passerelle, messages 0x05) ----------
# Capture du 25/10 16:52 (client officiel TH 1.132.13 : création d'une équipe, départ, puis entrée dans une autre par
# son code). Réponses de la passerelle en clair : [0x05] {1: compte, 2: 5, 4: type, 5: équipe} ;
#   4 = 1 : équipe créée (état de l'équipe), 4 = 6 : équipe rejointe par son code, 4 = 13 : départ ({1, 2 : compte}) ;
#   5.1 = chef, 5.2 = région, 5.4 = places - 1 (3 : 4 joueurs), 5.6 = membres [{1: compte, 2: pseudo, 3: région,
#   5: niveau…}], 5.7 = cartes, 5.8 = mode, 5.10 = type de file (15 / 6 : CS Rank), 5.11 = CODE de l'équipe (7
#   chiffres, celui que le jeu affiche), 5.17 = n° du salon.
# Les demandes du client (création et entrée) sont chiffrées AES-CBC avec la clé du login (ak / aiv du MajorLogin),
# départ : 16 octets chiffrés. La capture du 25/10 17:22 a enfin été déchiffrée (clé relue dans le MajorLogin de
# l'HTTPS, compte 11541917801) : création = op 1 (~1 385 octets en clair), entrée = op 4 (~1 420). Chacune porte un
# bloc « device » (champ 14 en création, 9 en entrée) IDENTIQUE à celui du StartMatch (champ 12, voir _START_MATCH_*) :
# empreinte matérielle (.1), blob XOR (.3), blob chiffré de session (.11), version du client (.8). Les anciens
# team_*_msg bâtis à la main ne faisaient que ~40 octets (forme {1: op, 2: {…}} des clients non officiels), d'où le
# refus « Abnormal Data » du serveur. On renvoie donc les demandes RÉELLES telles quelles (_TEAM_*_PLAIN, bloc device
# statique comme _START_MATCH_*), en ne réécrivant que le code de l'équipe à l'entrée.
# Réponses de la passerelle (en clair) : 4 = 1 création, 4 = 6 entrée, 4 = 18 réglage (op 17), 4 = 13 départ (op 7).
# L'op 17 règle l'équipe : 2.1 = compte, 2.3 = places - 1, 2.4 = mode, 2.5 = cartes, 2.8 = type de file, 2.18 = 42.
# Refus : {1: compte, 2: 5, 3: code} sans champ 4 (79 : entrée dans une équipe dissoute, 2 : départ hors équipe).
# Essai du 25/10 18:20 (tools/team_test.py, 4 comptes TH neufs) : création + réglage + 3 entrées -> équipe 4/4
# (chaque entrée diffusée à tous les membres, 4 = 6). Les MÊMES demandes faites par 4 autres comptes (essais de
# 17:03 à 18:17) : « Abnormal Data » (4 = 102, {1: 71}) à chaque entrée — refus lié aux comptes, pas à la demande.
# Départs tous en même temps : chef parti, ceux des membres refusés (code 76), puis 4 = 56 (nouveau chef, nouveau
# code) et 4 = 8 ; les membres doivent partir avant le chef.
GW_TEAM = 0x05
TEAM_CREATED, TEAM_JOINED, TEAM_LEFT, TEAM_SETTINGS = 1, 6, 13, 18
TEAM_MEMBER_LEFT = 8          # un membre est parti (5.1 = lui), diffusé à tous, lui compris ; le chef reçoit 13
TEAM_SIZE_MAX = 4

# Demandes réelles du client officiel TH 1.132.13 (capture déchiffrée du 25/10 17:22). Bloc device statique : accepté
# tel quel par le serveur, comme le StartMatch (champ 12 de _START_MATCH_*, lui aussi figé d'une autre session). La
# région (IDC, champ 8.3 / 11.3 = "TH") et la version (bloc device .8 = "1.132.13") ne sont PAS réécrites ici : à
# valider sur comptes TH 1.132.13 ; généraliser ensuite comme _send_start_match le fait pour le StartMatch.
_TEAM_CREATE_PLAIN = bytes.fromhex(
    "080112e40a1205010304161d180f20032a02656e42150a044944433110ffffffffffffffffff011a0254484806520f01030407090a0b1216"
    "191a201d27295801680172e2090a800130383037383042314146463331303738303230313030303030303030303030303030303630303031"
    "3030303530303030464443303233373730463030303030303436373632353134303030303030303030303030303030303030303030303030"
    "3030303030303030303030303030666630303030303030306361636661313664100b1ab90377585d551b060145035557040103035b00575a"
    "080d0c040407080f060600040104050452045c04541a000549745c4144411f0115001d1600034d005e79730a5e6c446b7e7b624141736f5f"
    "7d7107770965730578740c17044d7b5c62597152744b7b61767657517c7148527f555a535b50516b400c1a575b5b451e6278157041490048"
    "62636641004b4354435d41621a4b79484f0e6876795f40631e47080514000a4d736c4662627a6c721a545d6501755f6b1b5001675a4b5f76"
    "7d7e7c0d1b0f4d4d06641a5a62631f620e754a6b5e465a43785b411c7f125e4c46700c1202441c77415572441e40505877596b4b46475853"
    "0301096c4f014b587d0812084d457a61706a740757580161415275754a4b72525e68667d7070526c0c1704094d487f17630755770251426b"
    "65695a7165631a420c54695e7b6b596004120749791a00546b64007d471f07570559660d5644125e07721a771a67080a120d4d524c765046"
    "7a61760068680147606877056b435216424e027674740d1b0501454073031a50584276507d4b5a6161434344010f4f7f0a445d7a46700c13"
    "0d4b5e4f425d7d575f5a714a5544541a60725941527a69401e00656e420c22047f5b5b54300c3a09146b7967587d6311154208312e313332"
    "2e3133480350015afd0403626253513678386363534d50416456324b796f566c664b314a523937346737676d37597656413976797a59616e"
    "2b31666b4e475074507969614d2f446966465873697a4d397741324d3843374b76734b61315a4f312b3042566e38785a444f516274357a56"
    "536e6b594571717052762b5837626c4275524e6f63774e6f57567536497a724f544c724d677a7179416f616f4b45565779364f794135316d"
    "4246396f4259572f6a776961785942396d7371516b39794264375567715532616a4f575a53374935486b5832594a4d37636d5a747262446f"
    "3355636a3965634f33702b31366c763557537248684d58394279536d736f4b77787875685259556f324b63644e53384955504b324f556351"
    "6a3879312b443733563570724b7871446761306c41502b666e53584e707a37536b455344395032557871714250307937434d496a4c626141"
    "346c4b4a5732646a4931482f534f4e5838587167337a42497831517935343969376733653836683533636c5578436a72624b793974325546"
    "345771774367646a656a50735a6751656733424578755569665562654b626d514d524450456b71584e6e2b6d36664344734865544b305733"
    "37493673743666594f57794a564b5954382b6e527872556b4d49534c7a4d674e434f506b71597372664d7047756d79702f463630706f4163"
    "587852616d68504548366349476d4531505869644c764b59714958332b73647765556e6e73465151347a304a434d45653136543530766371"
    "545579774a4b6d33564e425173594256526a4e756e6b68595672312f683748394169446b78397736454f434b772f735879617a6873376272"
    "524648635a7967554d45756266456a63575965626937324c68684744773d3d9801c402a0012aaa0104374f5219c201050803108a03c20105"
    "0804108703c20105080510c001c20105081d10cc01c2010408161078c20105080e10af01c201020815")
_TEAM_JOIN_PLAIN = bytes.fromhex(
    "080412870b220f01030407090a0b1216191a201d27292a0732343739303539300640014a920a0a8001303830373830423141464633313037"
    "3830323031303030303030303030303030303030363030303130303035303030304644433032333737304630303030303034363736323531"
    "3430303030303030303030303030303030303030303030303030303030303030303030303030306666303030303030303063616366613136"
    "6410371ab90377585d551b060145035557040103035b00575a080d0c040407080f060600040104050452045c04541a000549745c4144411f"
    "0115001d1600034d005e79730a5e6c446b7e7b624141736f5f7d7107770965730578740c17044d7b5c62597152744b7b61767657517c7148"
    "527f555a535b50516b400c1a575b5b451e627815704149004862636641004b4354435d41621a4b79484f0e6876795f40631e47080514000a"
    "4d736c4662627a6c721a545d6501755f6b1b5001675a4b5f767d7e7c0d1b0f4d4d06641a5a62631f620e754a6b5e465a43785b411c7f125e"
    "4c46700c1202441c77415572441e40505877596b4b464758530301096c4f014b587d0812084d457a61706a740757580161415275754a4b72"
    "525e68667d7070526c0c1704094d487f17630755770251426b65695a7165631a420c54695e7b6b596004120749791a00546b64007d471f07"
    "570559660d5644125e07721a771a67080a120d4d524c7650467a61760068680147606877056b435216424e027674740d1b0501454073031a"
    "50584276507d4b5a6161434344010f4f7f0a445d7a46700c130d4b5e4f425d7d575f5a714a5544541a60725941527a69401e00656e420c22"
    "047f5b5b54300c3a09146b7967587d6311154208312e3133322e3133480350015aad0503626253513639456d2b2b6f31416456324b796f56"
    "6c527239487331414c596e2b414c35587a376d5257745a554a4279756f63696c4e352b4645366a3234597a582f51504f6f754f3646306e56"
    "505468546e3837545372396876482f5964443550786b4d447876593753456538496f31385364716931746f4d4a6d646741762b683675687a"
    "795a423777657641504f6e7035424446705a53325a3149455034435a7578396e6e77784158623675484d4b2b443355334c476c7458577572"
    "742b634b6236503366564b32376a452f6630625749704b7252716a6b59627630367545453837397332644d69796376356e6b6c364365786c"
    "61515a7547503858795856794930333175397a51646c41666a646d4576464c7269424c6577486f514e63437173574a636773365964457356"
    "4f4a49333170725647534f514754496d4e6f432f75722f615455506d6c64547034466f41553073656d397430514d34585350737235467634"
    "73674d766e68364c357a513151723543466f324e34524a4263554758485a6e64676b44484e56377861464b78736536556b4b694e6f656147"
    "392f56676c4875677344325a695875334c78484a6f575a424f332b52592f7946566d7a7a6d626276642f49646e3435586157463256324c58"
    "4a54752f686257695833424465583142556f306848716b36722f486954454a454a36766e643943556538487862396764452f4146776b4e53"
    "6347355a54503157797551482b6666554f4459317857683075517667307645717a456a69673045414535595a3063526a45764454666b4362"
    "4349514b6d5a6d477049694d79564d307151305239326a7245416b7662446b32766d4b4c78302f2f4e4574303161464e3049652f47484750"
    "3379774f45616c2b364c4266736e6d6f346d744b6a50426f7956326a536342776c55625535484e58766b4f4a5636302b5a0c0a0449444331"
    "10051a0254486a02656e820104374f5219a201050803108a03a201050804108703a20105080510c001a20105081d10cc01a2010408161078"
    "a20105080e10af01a201020815da0104081e1004")


def team_join_set_code(code: str, level: Optional[int] = None) -> bytes:
    """Réécrit le champ 2.5 (code de l'équipe) du gabarit d'entrée et recalcule la longueur du champ 2. `level` :
    niveau du compte qui entre, à la place de celui du compte de la capture (2.27.1 = 30, champ absent de la
    création)."""
    code_b = str(code).encode()
    top = bytearray()
    for num, wire, raw in _pb_raw_fields(_TEAM_JOIN_PLAIN):
        if num == 2 and wire == 2:
            body = _pb_ld_body(raw)
            nb = bytearray()
            for n2, w2, r2 in _pb_raw_fields(body):
                if n2 == 5 and w2 == 2:
                    r2 = _pb_ld(5, code_b)
                elif n2 == 27 and w2 == 2 and level:
                    old = _pb_fields(_pb_ld_body(r2))
                    r2 = _pb_ld(27, _pb_encode({1: int(level), 2: _pb_int(old, 2) or 4}))
                nb += r2
            raw = _pb_ld(2, bytes(nb))
        top += raw
    return bytes(top)


def _pb_encode(fields: Dict[int, Any]) -> bytes:
    """Protobuf de {numéro: valeur} : int -> varint, str / bytes -> octets, dict -> message imbriqué."""
    out = bytearray()
    for num, value in fields.items():
        if isinstance(value, int):
            out += _varint(num << 3) + _varint(value)
            continue
        if isinstance(value, dict):
            data = _pb_encode(value)
        else:
            data = value.encode() if isinstance(value, str) else bytes(value)
        out += _varint((num << 3) | 2) + _varint(len(data)) + data
    return bytes(out)


def _pb_ld(num: int, data: bytes) -> bytes:
    """Un champ protobuf « length-delimited » (wire 2) : clé + longueur + octets."""
    return _varint((num << 3) | 2) + _varint(len(data)) + data


def _pb_ld_body(raw: bytes) -> bytes:
    """Corps d'un champ wire 2 brut (clé + longueur retirées), tel que rendu par _pb_raw_fields."""
    _, i = _read_varint(raw, 0)
    ln, i = _read_varint(raw, i)
    return raw[i:i + ln]


def team_create_msg(client_version: str, mode: Optional[str] = None) -> Tuple[int, bytes]:
    """Création d'une équipe : le compte en devient le chef (réponse 4 = 1, code en 5.11). Demande réelle du client
    officiel (_TEAM_CREATE_PLAIN, bloc device statique) : une équipe CS Rank (2.3 = 15, 2.9 = 6). `mode` =
    "clash_squad" : équipe CS normale comme le client officiel la crée (capture du 26/10 00:57, chef TH déchiffré avec
    la clé du MajorLogin : 2.2 = 01, 2.8 = IDC1 au ping réel, 2.9 = 1, pas de 2.20) — le gabarit Rank réglé ensuite en
    15/1 par team_settings_msg faisait refuser la recherche du chef (team_start_msg, code 9, essais du 26/10 00:47-00:50).
    `mode` = "cs_ranked" : le gabarit Rank avec la carte 1 seule (2.2 = 01), comme les équipes Rank des clients
    officiels (équipe TH du 25/10 18:23 menée par un joueur : 5.1.7 = 01 dans l'état d'équipe 4 = 10, recherche
    acceptée ; capture ME de la même équipe) — avec les 5 cartes du gabarit (01 03 04 16 1d), la recherche du chef bot
    était refusée (0x03 {2: 3, 3: 48}, essai du 26/10 07:29, FF-glory).
    `mode` = "big_head" (DERIVED_BASE_MODE vers "clash_squad") : équipe normale comme "clash_squad", mode 2.3 du mode
    (Big Head : 16 ; état d'équipe du client officiel du 28/10 20:02 : 5.8 = 16, 5.10 = 1, 5.7 = 01). Les autres modes
    `mode` = "iron_cage_dual" / "iron_cage_duo" (IRON_CAGE_MODES) : équipe normale en mode 43, carte 11 seule,
    2 places (2.4 = 1), plus 2.22 = 1 pour Dual (captures ME du 29/10, voir DERIVED_BASE_MODE).
    Les autres modes (BR et leurs dérivés, dont "br_pony") : gabarit tel quel, réglé ensuite par team_settings_msg.
    `client_version` gardé pour la signature (le gabarit porte déjà sa version)."""
    iron_cage = mode in IRON_CAGE_MODES
    br_evo = mode == "br_evolution"
    cs_derived = DERIVED_BASE_MODE.get(mode) == "clash_squad" or iron_cage or br_evo
    if mode not in ("clash_squad", "cs_ranked") and not cs_derived:
        return GW_TEAM, _TEAM_CREATE_PLAIN
    normal = mode != "cs_ranked"
    full_team = mode in IRON_CAGE_FULL_TEAM
    top = bytearray()
    for num, wire, raw in _pb_raw_fields(_TEAM_CREATE_PLAIN):
        if num == 2 and wire == 2:
            nb = bytearray()
            for n2, w2, r2 in _pb_raw_fields(_pb_ld_body(raw)):
                if full_team and n2 > 22:
                    nb += _varint(22 << 3) + _varint(1)      # Dual : 2.22 = 1, entre 2.21 et les 2.24
                    full_team = False
                if n2 == 2 and w2 == 2:
                    # cartes : la carte 1 seule (CS normal et CS Rank), la carte 11 seule en Iron Cage
                    r2 = _pb_ld(2, MODE_MAPS[mode] if iron_cage else b"\x01")
                elif n2 == 3 and w2 == 0 and cs_derived:
                    r2 = _varint(3 << 3) + _varint(MATCH_MODE_IDS[mode][0])
                elif n2 == 4 and w2 == 0 and iron_cage:
                    r2 = _varint(4 << 3) + _varint(1)        # places - 1 : 2v2
                elif normal and n2 == 8 and w2 == 2:
                    r2 = _pb_ld(8, _pb_encode({1: "IDC1", 2: _native_idc_pings("TH")[0], 3: "TH"}))
                elif normal and n2 == 9 and w2 == 0:
                    r2 = _varint((9 << 3) | 0) + _varint(1)  # type de file : normal (6 = Rank)
                elif normal and n2 == 20:
                    continue
                nb += r2
            raw = _pb_ld(2, bytes(nb))
        top += raw
    return GW_TEAM, bytes(top)


def mode_for_match(mode_id: int, match_type: int, map_id: Optional[int] = None) -> str:
    """Mode du bot pour une partie qu'il n'a pas cherchée lui-même (lancée par le chef de son équipe), d'après le
    « match trouvé » (5.7 = mode, 5.8 = type de file, 5.6 = carte). Essai du 25/10 18:25 : CS Rank = 15 / 6.
    BR normal sur la carte de "br_pony" (MODE_MAPS) : "br_pony"."""
    if mode_id == 85:
        return "br_evolution"
    if mode_id == 15:
        return "cs_ranked" if match_type == RANKED_MATCH_TYPES["cs_ranked"] else "clash_squad"
    if mode_id == 43:
        return "lone_wolf"
    if mode_id == MATCH_MODE_IDS["big_head"][0]:
        return "big_head"
    if match_type == RANKED_MATCH_TYPES["br_ranked"]:
        return "br_ranked"
    return "br_pony" if map_id is not None and map_id in MODE_MAPS["br_pony"] else "br"


def team_mode(mode: str) -> Tuple[int, int, bytes]:
    """(mode, type de file, cartes) d'une équipe qui joue `mode` (voir MATCH_MODE_IDS, RANKED_MATCH_TYPES, MODE_MAPS)."""
    return (MATCH_MODE_IDS.get(mode, (1, 1))[0], RANKED_MATCH_TYPES.get(mode, 1),
            RANKED_MAPS.get(mode) or MODE_MAPS.get(mode, b"\x01"))


def team_settings_msg(account_id, size: int, mode: str) -> Tuple[int, bytes]:
    """Réglage de l'équipe du chef `account_id` : `size` places (1 à TEAM_SIZE_MAX), mode de jeu `mode` (réponse
    4 = 18). Champs alignés sur la demande réelle (op 17) : 2.18 = 42 (le client officiel n'envoie pas 2.13)."""
    mode_id, match_type, maps = team_mode(mode)
    return GW_TEAM, _pb_encode({1: 17, 2: {1: int(account_id), 2: 1, 3: int(size) - 1, 4: mode_id, 5: maps,
                                          8: match_type, 18: 42}})


def team_join_msg(code: str, client_version: str, level: Optional[int] = None) -> Tuple[int, bytes]:
    """Entrée dans l'équipe de code `code` (réponse 4 = 6). Demande réelle du client officiel (_TEAM_JOIN_PLAIN,
    bloc device statique), seuls le code (champ 2.5) et le niveau (2.27.1, si `level`) sont réécrits.
    `client_version` gardé pour la signature."""
    return GW_TEAM, team_join_set_code(code, level)


def team_start_msg(account_id, region) -> Tuple[int, bytes]:
    """Le chef lance la recherche de son équipe (op 9, mode et cartes déjà réglés par team_settings_msg) : réponses
    0x05 4 = 10 à tous puis 0x03 4 = 11 (« recherche lancée »). Capture du 26/10 00:43 (chef, client TH) : un 0x05 de
    32 octets chiffrés juste avant ces réponses ; structure {1: 9, 2: {1: compte, 7: {IDC, ping, région}}} des bots
    publics (GG.GLORY start_match_team : 24 octets en clair -> 32 chiffrés). Le StartMatch (0x03) du chef, lui, ne
    lance qu'une recherche solo (essai du 26/10 00:39 : seul le chef a trouvé une partie). IDC : comme le StartMatch
    natif (_native_idc_pings)."""
    return GW_TEAM, _pb_encode({1: 9, 2: {1: int(account_id), 7: {1: "IDC1", 2: _native_idc_pings(region)[0],
                                                                  3: str(region).upper()}}})


def team_ready_msg(account_id) -> Tuple[int, bytes]:
    """« Prêt » d'un membre (op 15 : {1: compte, 2: 1}, GG.GLORY ready_for_game), envoyé par chacun avant le
    team_start_msg du chef : sans lui, le chef seul a reçu un refus code 9 (essai du 26/10 00:47)."""
    return GW_TEAM, _pb_encode({1: 15, 2: {1: int(account_id), 2: 1}})


def team_leave_msg(account_id) -> Tuple[int, bytes]:
    """Départ de l'équipe (réponse 4 = 13)."""
    return GW_TEAM, _pb_encode({1: 7, 2: {1: int(account_id)}})


def team_info(body: bytes) -> Optional[Dict[str, Any]]:
    """Message 0x05 de la passerelle -> {kind (champ 4), leader, code, size, members: [(compte, pseudo)], mode,
    match_type} ; refus : {kind: None, error: code} ; None s'il est illisible."""
    top = _pb_fields(body)
    kind = _pb_int(top, 4)
    if kind is None:
        error = _pb_int(top, 3)
        return {"kind": None, "error": error} if error is not None else None
    t = _pb_msg(top, 5)
    members = []
    for raw in t.get(6, []):
        if isinstance(raw, bytes):
            m = _pb_fields(raw)
            name = m.get(2, [b""])[0]
            members.append((_pb_int(m, 1), name.decode("utf-8", "replace") if isinstance(name, bytes) else ""))
    code = t.get(11, [None])[0]
    slots = _pb_int(t, 4)
    return {"kind": kind, "leader": _pb_int(t, 1), "code": code.decode("ascii", "replace") if isinstance(code, bytes)
            else None, "size": slots + 1 if slots is not None else None, "members": members,
            "mode": _pb_int(t, 8), "match_type": _pb_int(t, 10)}


async def gateway_send(writer, msg: Tuple[int, bytes], key, iv):
    """Envoie un message du client officiel (voir GW_CANCEL_SEARCH…) : [type][02][longueur 4 octets][AES], 02 = octet
    de la région de la connexion (GATEWAY_REGION_BYTE)."""
    typ, plain = msg
    enc = await aes_encrypt(plain, key, iv)
    writer.write(bytes([typ, _gateway_writer_byte.get(writer, 0x02)]) + len(enc).to_bytes(4, "big") + enc)
    await asyncio.wait_for(writer.drain(), timeout=3)


class _GatewayFrames:
    """Découpe ce que la passerelle envoie en messages [type][00][longueur 3 octets][corps] : un read() peut en contenir
    plusieurs, ou un morceau. Flux désynchronisé (2e octet non nul, longueur aberrante) : tampon vidé."""
    MAX_LEN = 1 << 20

    def __init__(self):
        self.buf = b""

    def feed(self, data: bytes) -> List[Tuple[int, bytes]]:
        self.buf += data
        out = []
        while len(self.buf) >= 5:
            typ, flag, ln = self.buf[0], self.buf[1], int.from_bytes(self.buf[2:5], "big")
            if flag or ln > self.MAX_LEN:
                self.buf = b""
                break
            if len(self.buf) < 5 + ln:
                break
            out.append((typ, self.buf[5:5 + ln]))
            self.buf = self.buf[5 + ln:]
        return out


def _pb_fields(data: bytes) -> Dict[int, list]:
    """Protobuf sans schéma : {champ: [valeurs]} (varint -> int, longueur -> octets) ; {} si illisible."""
    out: Dict[int, list] = {}
    i, n = 0, len(data)
    while i < n:
        key, i = _read_varint(data, i)
        if key is None or not key >> 3:
            return {}
        wire = key & 7
        if wire == 0:
            v, i = _read_varint(data, i)
            if v is None:
                return {}
        elif wire == 2:
            ln, i = _read_varint(data, i)
            if ln is None or i + ln > n:
                return {}
            v, i = data[i:i + ln], i + ln
        elif wire in (1, 5):
            size = 8 if wire == 1 else 4
            v, i = data[i:i + size], i + size
        else:
            return {}
        out.setdefault(key >> 3, []).append(v)
    return out


def _pb_int(fields: Dict[int, list], num: int) -> Optional[int]:
    v = fields.get(num, [None])[0]
    return v if isinstance(v, int) else None


def _pb_msg(fields: Dict[int, list], num: int) -> Dict[int, list]:
    v = fields.get(num, [None])[0]
    return _pb_fields(v) if isinstance(v, bytes) else {}


_anticheat_replay: Optional[Dict[str, Any]] = None

def _replay_blob_is_plaintext(blob: bytes) -> bool:
    """Check if a 0x28 replay blob is plaintext protobuf (not gateway-encrypted).
    Plaintext starts with a valid protobuf tag (field 1, varint) and has non-16-aligned size.
    Encrypted data is always 16-aligned and starts with random bytes."""
    if len(blob) < 4:
        return False
    tag = blob[0]
    wire_type = tag & 7
    field_num = tag >> 3
    if field_num == 1 and wire_type == 0 and blob[1] < 0x80:
        return True
    return len(blob) % 16 != 0


def _load_anticheat_replay() -> Optional[Dict[str, Any]]:
    global _anticheat_replay
    if _anticheat_replay is not None:
        return _anticheat_replay if _anticheat_replay.get("loaded") else None
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "anticheat_replay.json")
    try:
        with open(p, encoding="utf-8") as f:
            raw = json.load(f)
        init_0x28 = [bytes.fromhex(e["hex"]) for e in raw.get("anticheat_0x28", [])[:2]]
        match_0x28 = [bytes.fromhex(e["hex"]) for e in raw.get("anticheat_0x28", [])[2:4]]
        init_0x1d = [bytes.fromhex(e["hex"]) for e in raw.get("sdk_0x1d", [])[:1]]
        match_0x1d = [(e["t"], bytes.fromhex(e["hex"])) for e in raw.get("sdk_0x1d", [])[1:]]
        encrypted_warning = False
        for blob in init_0x28 + match_0x28:
            if blob and not _replay_blob_is_plaintext(blob):
                encrypted_warning = True
                break
        if encrypted_warning:
            print_error("[ANTICHEAT] anticheat_replay.json contains ENCRYPTED blobs (not plaintext protobuf). "
                        "gateway_send will double-encrypt them → server rejects. "
                        "Re-generate with: python tools/update_anticheat_replay.py <capture>_gateway.jsonl")
            diag.event("ANTICHEAT", "replay_encrypted_warning", level="error",
                       msg="replay blobs appear encrypted, will be double-encrypted by gateway_send")
        session_key = raw.get("session_key")
        _anticheat_replay = {"loaded": True, "init_0x28": init_0x28, "match_0x28": match_0x28,
                             "init_0x1d": init_0x1d, "match_0x1d": match_0x1d,
                             "session_key": session_key}
        diag.event("ANTICHEAT", "replay_loaded", level="info",
                   init_0x28=len(init_0x28), match_0x28=len(match_0x28), match_0x1d=len(match_0x1d),
                   plaintext=not encrypted_warning, session_key=bool(session_key))
        return _anticheat_replay
    except FileNotFoundError:
        _anticheat_replay = {"loaded": False}
        return None
    except Exception as e:
        _anticheat_replay = {"loaded": False}
        diag.event("ANTICHEAT", "replay_load_error", level="warning", err=str(e)[:200])
        return None


_gw_logged_types: Dict[str, set] = {}


def _load_session_key_for_login(garena_id: str) -> Optional[str]:
    """Look up the session key from captures/session_keys.json by login:{garena_id}.
    Returns hex string or None."""
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "captures", "session_keys.json")
    try:
        with open(p, encoding="utf-8") as f:
            store = json.load(f)
        return store.get(f"login:{garena_id}")
    except Exception:
        return None


# ==================== ORACLE BRIDGE ====================
_oracle_client: Optional[httpx.AsyncClient] = None

def _oracle_url() -> str:
    return GW_ANTICHEAT_ORACLE

async def _oracle_post(path: str, payload: dict, timeout: float = 5.0) -> Optional[dict]:
    global _oracle_client
    url = _oracle_url()
    if not url:
        return None
    if _oracle_client is None:
        _oracle_client = httpx.AsyncClient(timeout=timeout)
    try:
        r = await _oracle_client.post(f"{url}{path}", json=payload)
        return r.json()
    except Exception as e:
        diag.event("ORACLE", "error", level="warning", path=path, err=str(e)[:120])
        return None

async def _oracle_feed(body_hex: str, data_type: int) -> bool:
    result = await _oracle_post("/feed", {"hex": body_hex, "type": data_type})
    return result.get("ok", False) if result else False

async def _oracle_captured() -> List[dict]:
    result = await _oracle_post("/captured", {})
    return result.get("reports", []) if result else []

async def _oracle_health() -> bool:
    url = _oracle_url()
    if not url:
        return False
    try:
        global _oracle_client
        if _oracle_client is None:
            _oracle_client = httpx.AsyncClient(timeout=3.0)
        r = await _oracle_client.get(f"{url}/health")
        return r.json().get("ok", False)
    except Exception:
        return False

async def _oracle_feed_server_msg(uid_str: str, typ: int, body: bytes) -> None:
    """Feed incoming server 0x1d/0x28 to the oracle SDK."""
    if typ == 0x1d:
        fields = _pb_fields(body)
        inner = _pb_msg(fields, 5)
        payload = inner.get(2, [None])[0]
        if isinstance(payload, bytes) and len(payload) > 100:
            ok = await _oracle_feed(payload.hex(), 29)
            diag.event("ORACLE", "feed_0x1d", level="info", uid=uid_str,
                       payload_len=len(payload), ok=ok)
    elif typ == 0x28:
        fields = _pb_fields(body)
        code = _pb_int(fields, 4)
        inner = _pb_msg(fields, 5)
        payload = inner.get(1, [None])[0]
        if isinstance(payload, bytes) and len(payload) > 0:
            ok = await _oracle_feed(payload.hex(), 40)
            diag.event("ORACLE", "feed_0x28", level="info", uid=uid_str,
                       code=code, payload_len=len(payload), ok=ok)
        elif body and len(body) > 4:
            ok = await _oracle_feed(body.hex(), 40)
            diag.event("ORACLE", "feed_0x28_raw", level="info", uid=uid_str,
                       code=code, body_len=len(body), ok=ok)


def _gw_log_type(uid_str: str, typ: int, body: bytes) -> None:
    """Log incoming gateway message types we don't normally process (0x1d, 0x28, etc.)."""
    seen = _gw_logged_types.setdefault(uid_str, set())
    extra: Dict[str, Any] = {"len": len(body)}
    if typ == 0x28:
        fields = _pb_fields(body)
        code = _pb_int(fields, 4)
        extra["code"] = code
    first = typ not in seen
    if first:
        seen.add(typ)
    diag.event("GATEWAY", "msg_in", level="info" if first else "debug",
               type=f"0x{typ:02x}", first=first or None, **extra)


def _gateway_message(uid_str: str, typ: int, body: bytes, found: Dict[int, Tuple[str, int, float]]) -> None:
    """Message de la passerelle (voir _GatewayFrames) : résultat de partie / niveau-EXP -> journal + profil du compte
    (EXP du panel à jour dès que le serveur la crédite). `found` : parties trouvées, par identifiant."""
    if typ not in (GW_MATCH_RESULT, GW_LEVEL_EXP):
        return
    res = _pb_msg(_pb_fields(body), 5)
    if typ == GW_LEVEL_EXP:
        bot_state.update_profile(uid_str, level=_pb_int(res, 3), exp=_pb_int(res, 4))
        return
    stats = _pb_msg(res, 7)
    gain, gold = _pb_int(stats, 1), _pb_int(stats, 13)
    lv0, lv1, exp0, exp1 = (_pb_int(stats, n) for n in (6, 7, 8, 9))
    rk0, rk1, pos = _pb_int(stats, 10), _pb_int(stats, 11), _pb_int(stats, 19)
    match_id = _pb_int(res, 2)
    if match_id:
        _note_result(uid_str, match_id)      # partie finie pour le compte (fin de l'attente MATCH_END_WAIT)
    if exp1 is None:
        return
    mode, index, found_at = found.get(match_id, (None, None, None))
    rank_str = f", แรงค์ {rk0}->{rk1}" if rk1 is not None else ""
    pos_str = f" #{pos}" if pos is not None else ""
    print_success(f"[RESULT] {uid_str} แมตช์ {match_id}"
                  f"{f' (#{index} {MODE_TAGS.get(mode, mode)})' if mode else ''}{pos_str} : +{gain} EXP ({exp0} -> {exp1}), "
                  f"เลเวล {lv0} -> {lv1}{rank_str}")
    diag.event("MATCH", "result", level="info", match_id=match_id, mode=mode, m=index,
               after_found_s=round(time.time() - found_at) if found_at else None,
               exp_gain=gain, exp_before=exp0, exp=exp1, lv=f"{lv0}->{lv1}", gold=gold,
               rank_before=rk0, rank_after=rk1, position=pos)
    bot_state.update_profile(uid_str, exp=exp0)          # référence de la session si l'EXP n'était pas encore connue
    bot_state.update_profile(uid_str, level=lv1, exp=exp1)


# ============================================================
# 🔥 functional_lone_wolf — TRUE Parallel + Smart Cache + DNS
#    Utilisé pour les trois modes (Lone Wolf, Battle Royale, Clash Squad)
# ============================================================
async def functional_lone_wolf(addrs, starter_packet, account_region, client_version,
                                key, iv, account_id="", account_data=None,
                                max_reconnects=10):
    reconnects = 0
    ip, port = addrs.split(":")
    play_matches: List[asyncio.Task] = []
    no_response_count = 0
    search_attempts = 0
    last_start_time = 0.0
    search_mode = "lone_wolf"   # mode de la dernière recherche envoyée (le match trouvé est joué dans ce mode)
    uid_str = str(account_id)

    consecutive_parse_failures = 0
    gateway_rejects = 0          # connexions fermées par le serveur juste après l'envoi du token, sans réponse

    current_token = starter_packet
    current_key = key
    current_iv = iv
    current_account_data = account_data
    panel = _panel_matches(uid_str)   # état des matchs du panel de ce compte (indépendant des autres panels)
    found_matches: Dict[int, Tuple[str, int, float]] = {}   # id de partie -> (mode, n°, trouvée à) pour les résultats
    gw_frames = _GatewayFrames()
    # connexion à la passerelle : gardée d'une recherche à l'autre et pendant l'attente avec GATEWAY_STAY_ONLINE
    reader: Optional[asyncio.StreamReader] = None
    writer: Optional[asyncio.StreamWriter] = None
    token_sent_at = None
    got_data = False
    last_keepalive = 0.0
    presence_fails = 0             # connexions « présence » (attente) coupées ou refusées de suite
    presence_retry_at = 0.0        # prochaine connexion « présence » permise (monotonic) après ces échecs
    presence_since = 0.0
    presence_rejects = 0           # connexions « présence » fermées juste après le token sans message (session refusée)
    gw_last_rx = 0.0               # dernière donnée reçue de la passerelle, réponses au maintien comprises (monotonic)
    search_accepted_at = 0.0       # recherche en cours acceptée par le serveur (0x03 4=11) depuis… (0 = aucune)
    special_modes_sent = False     # GW_SPECIAL_MODES : une fois par session, comme le client officiel après le login
    oracle_poll_at = 0.0           # next oracle poll time (monotonic)

    async def _oracle_on_frames(frames_list):
        """Oracle mode: feed server 0x1d/0x28, poll for captured reports, send them."""
        nonlocal oracle_poll_at
        ourl = _oracle_url()
        if not ourl or not _gw_open():
            return
        for gt, gb in frames_list:
            if gt in (0x1d, 0x28):
                await _oracle_feed_server_msg(uid_str, gt, gb)
        now = time.monotonic()
        if now < oracle_poll_at:
            return
        oracle_poll_at = now + 1.5
        reports = await _oracle_captured()
        for rep in reports:
            try:
                body = bytes.fromhex(rep["hex"])
                await gateway_send(writer, (0x28, body), current_key, current_iv)
                diag.event("ORACLE", "sent", level="info", uid=uid_str,
                           type="0x28", len=len(body))
            except Exception as e:
                diag.event("ORACLE", "send_error", level="warning", err=str(e)[:120])

    def _gw_open() -> bool:
        return writer is not None and not writer.is_closing()

    async def _gw_close():
        nonlocal reader, writer
        w, reader, writer = writer, None, None
        if w is not None:
            try:
                w.close()
                await w.wait_closed()
            except Exception:
                pass

    async def _gw_keepalive():
        """« 02 02 » toutes les GATEWAY_KEEPALIVE_S, comme le client officiel (recherche comme attente)."""
        nonlocal last_keepalive
        t = time.monotonic()
        if _gw_open() and t - last_keepalive >= GATEWAY_KEEPALIVE_S:
            last_keepalive = t
            writer.write(gateway_keepalive(writer))
            await asyncio.wait_for(writer.drain(), timeout=3)

    async def _gw_connect():
        """Nouvelle connexion avec la session gardée (token_cache) : token, puis maintien. Session expirée :
        ConnectionError « Cache expired » (nouveau login)."""
        nonlocal reader, writer, gw_frames, token_sent_at, got_data, last_keepalive, search_accepted_at, gw_last_rx
        nonlocal current_account_data, current_key, current_iv, current_token, special_modes_sent
        await _gw_close()
        token_sent_at, got_data, search_accepted_at = None, False, 0.0
        gw_last_rx = time.monotonic()
        if current_account_data:
            fresh = None
            if current_account_data.get('auth_type') == 'guest' and current_account_data.get('auth_uid'):
                fresh = cache_get(str(current_account_data['auth_uid']))
            elif current_account_data.get('auth_type') == 'token' and current_account_data.get('auth_token'):
                fresh = cache_get(f"tok_{current_account_data['auth_token'][:20]}")

            if fresh:
                current_account_data = fresh
                current_key = fresh['aes_ak']
                current_iv = fresh['iv_i']
                current_token = await build_tcp_startup_packet(
                    fresh['account_id'],
                    fresh['token'],
                    fresh['server_time'],
                    current_key,
                    current_iv,
                    region=fresh.get('region', account_region),
                    typ='OnLine'
                )
            else:
                print_info(f"[FUNCTIONAL] Cache miss for {uid_str} → re-login needed")
                _invalidate_account_cache(current_account_data, "session หมดอายุระหว่างเล่น")
                raise ConnectionError("Cache expired, triggering fresh login")

        resolved_ip = await resolve_host_cloudflare(ip)
        # délais explicites : sans eux, une passerelle muette bloquait jusqu'au délai du système (~21 s,
        # WinError 121) et des centaines de connexions en attente s'accumulaient
        reader, writer = await asyncio.wait_for(asyncio.open_connection(resolved_ip, int(port)),
                                                GATEWAY_CONNECT_TIMEOUT_S)
        gateway_bind_region(writer, account_region)
        gw_frames = _GatewayFrames()      # nouveau flux : messages découpés depuis son début

        raw_sock = writer.get_extra_info('socket')
        if raw_sock:
            optimize_tcp_socket(raw_sock)

        writer.write(bytes.fromhex(current_token))
        await asyncio.wait_for(writer.drain(), GATEWAY_WRITE_TIMEOUT_S)
        token_sent_at = time.time()

        # Send initial keepalive pulse right after connecting in OB55
        try:
            if GW_CLIENT_INIT:
                # début de session du client officiel (voir GW_CLIENT_INIT) : 0x28 / 0x1d au lieu du maintien
                init_0x28 = _gw_client_init_0x28() if GW_CLIENT_INIT_0x28 else []
                if init_0x28:
                    await asyncio.sleep(random.uniform(0.06, 0.12))
                    await gateway_send(writer, (0x28, init_0x28[0]), current_key, current_iv)
                await asyncio.sleep(random.uniform(0.65, 0.8))
                for body in init_0x28[1:]:
                    await gateway_send(writer, (0x28, body), current_key, current_iv)
                await gateway_send(writer, (0x1d, _GW_SDK_INIT_0x1D), current_key, current_iv)
                diag.event("GATEWAY", "client_init", level="info", uid=uid_str, init_0x28=len(init_0x28))
            else:
                init_ka = await send_keep_alive(account_region)
                if init_ka and writer and not writer.is_closing():
                    writer.write(init_ka)
                    await asyncio.wait_for(writer.drain(), timeout=3)
            last_keepalive = time.monotonic()
            if not special_modes_sent:
                special_modes_sent = True
                await gateway_send(writer, GW_SPECIAL_MODES, current_key, current_iv)
            if _oracle_url():
                oracle_ok = await _oracle_health()
                diag.event("GATEWAY", "anticheat_init", level="info" if oracle_ok else "warning",
                           uid=uid_str, mode="oracle", oracle_ok=oracle_ok)
                oracle_poll_at = 0.0
            elif GW_ANTICHEAT_REPORT:
                replay = _load_anticheat_replay()
                if replay and replay.get("init_0x28"):
                    await asyncio.sleep(random.uniform(0.1, 0.3))
                    await gateway_send(writer, (0x28, replay["init_0x28"][0]), current_key, current_iv)
                    if replay.get("init_0x1d"):
                        await asyncio.sleep(random.uniform(0.05, 0.15))
                        await gateway_send(writer, (0x1d, replay["init_0x1d"][0]), current_key, current_iv)
                    if len(replay["init_0x28"]) > 1:
                        await asyncio.sleep(random.uniform(0.2, 0.4))
                        await gateway_send(writer, (0x28, replay["init_0x28"][1]), current_key, current_iv)
                    diag.event("GATEWAY", "anticheat_init", level="info", uid=uid_str, mode="replay")
                else:
                    diag.event("GATEWAY", "anticheat_skip", level="warning", uid=uid_str, reason="no_replay_data")
        except Exception:
            pass
        return resolved_ip

    async def _idle_wait(seconds: float) -> bool:
        """Pause sans recherche. GATEWAY_STAY_ONLINE : passerelle gardée (rouverte au besoin) pendant la pause, avec
        le maintien du client officiel et les messages lus (résultats de partie) : le compte reste en ligne dans le
        jeu. Sinon : pause hors ligne. False : session expirée, nouveau login à faire."""
        nonlocal got_data, presence_fails, presence_retry_at, presence_since, presence_rejects, gw_last_rx
        end = time.monotonic() + seconds
        if GATEWAY_STAY_ONLINE and not _gw_open() and time.monotonic() >= presence_retry_at:
            try:
                await _gw_connect()
                presence_since = time.monotonic()
                diag.event("GATEWAY", "connected", level="info", addr=addrs, idle=True, fails=presence_fails or None)
                bot_state.gateway_connected(uid_str)
            except ConnectionError as e:
                if "Cache expired" in str(e):
                    await _gw_close()
                    return False
                presence_fails += 1
            except Exception as e:
                presence_fails += 1
                diag.event("GATEWAY", "presence_error", level="debug", code=diag.classify(e), msg=str(e)[:200],
                           fails=presence_fails)
            if not _gw_open():
                await _gw_close()
                # un peu de hasard : après une coupure de la passerelle, les comptes n'y reviennent pas tous ensemble
                presence_retry_at = time.monotonic() + min(GATEWAY_BACKOFF_MAX_S, 2.0 ** presence_fails) \
                    * random.uniform(0.8, 1.2)
        while True:
            left = end - time.monotonic()
            if left <= 0:
                return True
            if not _gw_open():
                await asyncio.sleep(left)
                return True
            if time.monotonic() - gw_last_rx > GATEWAY_DEAD_S:
                # plus rien reçu, maintien compris : connexion morte sans fermeture, rouverte (sinon la recherche
                # suivante partait dessus et attendait ~40 s pour rien)
                diag.event("GATEWAY", "presence_dead", level="debug", silent_s=round(time.monotonic() - gw_last_rx))
                await _gw_close()
                presence_retry_at = time.monotonic() + random.uniform(0, 1.0)
                continue
            data, err = None, None
            try:
                await _gw_keepalive()
                data = await asyncio.wait_for(reader.read(8192), timeout=min(left, 1.0))
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                err = e
            if not data:
                # fermée par le serveur pendant l'attente : rouverte au prochain tour, plus tard si ça se répète
                lasted = time.monotonic() - presence_since
                presence_fails = 0 if lasted > 60 else presence_fails + 1
                presence_retry_at = time.monotonic() + (min(GATEWAY_BACKOFF_MAX_S, 2.0 ** presence_fails)
                                                        * random.uniform(0.8, 1.2) if presence_fails
                                                        else random.uniform(0, 1.0))
                diag.event("GATEWAY", "presence_closed", level="debug", code=diag.classify(err) if err else "GW_CLOSED",
                           msg=str(err)[:200] if err else None, connected_s=round(lasted), fails=presence_fails)
                rejected = not got_data and lasted < GATEWAY_REJECT_WINDOW_S
                await _gw_close()
                if rejected:
                    # session gardée refusée (fermée juste après le token, sans rien envoyer) : nouveau login au bout
                    # de quelques refus, comme pour la recherche (avant : reconnexion sans fin pendant l'attente)
                    presence_rejects += 1
                    if presence_rejects >= GATEWAY_REJECTS_BEFORE_RELOGIN:
                        diag.event("GATEWAY", "rejected_relogin", level="warning", code="GW_REJECTED",
                                   rejects=presence_rejects, idle=True)
                        _invalidate_account_cache(current_account_data, "เกตเวย์ไม่รับ session ซ้ำ")
                        return False
                continue
            gw_last_rx = time.monotonic()
            frames = gw_frames.feed(data)
            if any(t < 0x80 for t, _ in frames):
                got_data = True           # vrai message du serveur (les réponses au maintien ne prouvent rien)
                presence_rejects = 0
            for gw_type, gw_body in frames:
                if gw_type not in (GW_MATCH_RESULT, GW_LEVEL_EXP) and gw_type < 0x80:
                    _gw_log_type(uid_str, gw_type, gw_body)
                _gateway_message(uid_str, gw_type, gw_body, found_matches)
            await _oracle_on_frames(frames)

    try:
        while True:
            panel.searching.discard(uid_str)
            panel.waiting.discard(uid_str)
            if not await _ready_to_search(uid_str, panel):
                # limite du panel atteinte (ou recherche non autorisée) : on attend HORS LIGNE qu'une place se libère
                reported = 0.0
                wait_started = time.time()
                reason = _slot_block_reason(uid_str, panel)
                # partie en cours, ou partie quittée pas encore finie (MATCH_END_WAIT) : attente normale
                wait_level = "debug" if reason in _QUIET_WAIT_CODES else "info"
                diag.event("SLOT", "wait", level=wait_level, code=reason, mine=panel.counters.get(uid_str, 0),
                           panel_active=panel.active, searching=len(panel.searching), starved=len(panel.starved),
                           limit=_panel_limit(uid_str))
                try:
                    while not await _ready_to_search(uid_str, panel):
                        mine = panel.counters.get(uid_str, 0)
                        allowed = _may_start(uid_str, panel, mine)
                        # partage équitable : sans partie en cours et autorisé à chercher -> passe avant les comptes
                        # du panel qui jouent déjà (voir _fair_share_yield)
                        if mine == 0 and allowed:
                            panel.starved.add(uid_str)
                        else:
                            panel.starved.discard(uid_str)
                        # attend une place alors que sa session l'autorise à jouer : compte pour la part du panel
                        # (partage des places du serveur entre panels, voir _over_share)
                        if allowed:
                            panel.waiting.add(uid_str)
                        else:
                            panel.waiting.discard(uid_str)
                        if time.time() - reported >= WAITING_STATUS_EVERY_S:
                            reported = time.time()
                            now_reason = _slot_block_reason(uid_str, panel)
                            if now_reason != reason:
                                # la raison change pendant l'attente (partie terminée, mais serveur plein…) : avant,
                                # seule la première était journalisée (souvent « partie en cours », niveau détail)
                                if now_reason not in _QUIET_WAIT_CODES:
                                    wait_level = "info"
                                diag.event("SLOT", "wait_reason", level=wait_level, code=now_reason, prev=reason,
                                           waited_s=round(time.time() - wait_started), panel_active=panel.active,
                                           share=_panel_shares.get(panel.key))
                                reason = now_reason
                            bot_state.update_status(uid_str, "WAITING", mine, reason)
                        if not await _idle_wait(1.0):
                            # session gardée expirée pendant l'attente : nouveau login (le compte reste en ligne)
                            diag.event("GATEWAY", "session_expired", level="info", code="CACHE_EXPIRED", idle=True)
                            bot_state.gateway_error(uid_str, "Cache expired, triggering fresh login")
                            return
                finally:
                    panel.starved.discard(uid_str)
                    panel.waiting.discard(uid_str)
                diag.event("SLOT", "wait_end", level=wait_level, code=reason,
                           dur_ms=round((time.time() - wait_started) * 1000))
            # Place réservée tout de suite, sans attente depuis la vérification : les autres comptes du panel la
            # voient prise et restent hors ligne. Avant, une place libérée faisait connecter TOUS les comptes en
            # attente pour un seul gagnant ; les autres restaient connectés sans rien chercher jusqu'à la coupure
            # « Gateway idle timeout » (40 s), puis le watchdog les relançait (logins en rafale, HTTP 429).
            panel.searching.add(uid_str)

            phase = "connect"              # connect -> session (token envoyé) : nom de l'étape en cas d'erreur
            t_conn = time.perf_counter()
            search_started = 0.0           # premier StartMatch de cette connexion (durée de la recherche)
            search_sent = 0                # StartMatch envoyés sur cette connexion
            conn_mode: Optional[str] = None   # mode cherché sur cette connexion (choisi au 1er StartMatch)
            pause_s = 0.0                  # pause avant la recherche suivante (partie trouvée, paquet illisible)
            offline_s = 0.0                # début de cette pause hors ligne (partie trouvée : GATEWAY_FOUND_RECONNECT_S)
            cancel_sent_at = 0.0           # annulation demandée (attente du 4=14), puis attente d'une place en ligne
            cancel_queued = False          # annulation demandée avant le 4=11 : envoyée à son arrivée
            cancel_why: Optional[str] = None   # raison de l'annulation (FAIR_SHARE, NOT_READY, REQUEUE…)
            search_accepted_at = 0.0       # nouvelle recherche (connexion gardée ou non)
            try:
                if _gw_open():
                    # connexion gardée pendant l'attente (GATEWAY_STAY_ONLINE) : la recherche part dessus
                    phase = "session"
                else:
                    resolved_ip = await _gw_connect()
                    phase = "session"
                    print_success(f"[FUNCTIONAL] TCP Gateway Connected for UID: {uid_str} (DNS: {resolved_ip})")
                    diag.event("GATEWAY", "connected", level="info", addr=addrs,
                               dur_ms=round((time.perf_counter() - t_conn) * 1000), retry=reconnects)
                    bot_state.gateway_connected(uid_str)
                reconnects = 0
                no_response_count = 0
                last_start_time = 0.0

                async def cancel_search(why: str, now_accepted: bool = False):
                    """Annule la recherche comme le client officiel (GW_CANCEL_SEARCH) : la connexion reste ouverte,
                    la boucle attend le 4=14 (un match trouvé juste avant l'annulation est joué normalement).
                    Recherche pas encore acceptée (4=11) : annulation envoyée à son arrivée. Envoyée avant, le serveur
                    l'ignore (17/10-18/10 : 1 507 annulations sans réponse sur 1 512, toutes dans les 2 s suivant le
                    StartMatch, accepté ~60 ms après)."""
                    nonlocal cancel_sent_at, cancel_queued, cancel_why
                    if not now_accepted:
                        cancel_why = why
                        cancel_sent_at = time.time()       # demande d'annulation (délai CANCEL_ACK_TIMEOUT_S)
                        if not search_accepted_at:
                            cancel_queued = True
                            return
                    cancel_queued = False
                    try:
                        await gateway_send(writer, GW_CANCEL_SEARCH, current_key, current_iv)
                    except Exception as e:
                        diag.event("SEARCH", "cancel_failed", level="warning", code=diag.classify(e), why=why)
                        raise

                async def send_start_match():
                    nonlocal search_attempts, last_start_time, search_mode, search_started, search_sent, conn_mode
                    # Mode du panel ; en Lone Wolf, un compte sous le niveau 3 joue en BR jusqu'à y arriver. Plusieurs
                    # modes à la fois (mode_mix) : un mode qui a encore de la place pour ce compte. Choisi au 1er
                    # StartMatch de la connexion puis gardé pour les renvois : le match trouvé est toujours celui du
                    # mode cherché (avant, le mode était relu à chaque renvoi).
                    if conn_mode is None:
                        conn_mode = bot_state.game_mode(uid_str, _by_mode(uid_str, panel))
                        if conn_mode is None:
                            return          # tous les modes du compte sont pleins : rien à chercher
                        if conn_mode not in START_GAME_BY_MODE:
                            conn_mode = "lone_wolf"
                    search_mode = conn_mode
                    panel.searching.add(uid_str)
                    search_attempts += 1
                    # Région du compte : choisit son paquet dans match_packets.json (sinon gabarit intégré, recherche BD)
                    current_region = (current_account_data or {}).get('region') or account_region
                    tag = MODE_TAGS.get(search_mode, search_mode)
                    print_info(f"[{tag}] Sending StartMatch #{search_attempts} account region: {current_region}")
                    try:
                        await asyncio.sleep(random.uniform(0.3, 0.6))
                        search_region, from_file = await START_GAME_BY_MODE[search_mode](
                            current_region, client_version, writer,
                            current_key, current_iv, account_id
                        )
                        source = f"match_packets.json [{search_region}]" if from_file else f"gabarit intégré [{search_region}]"
                        print_success(f"[{tag}] StartMatch packet sent ({source})")
                        search_sent += 1
                        if not search_started:
                            search_started = time.time()
                            diag.event("SEARCH", "start", level="info", mode=search_mode, region=current_region,
                                       search_region=search_region, packet="file" if from_file else "builtin",
                                       mine=panel.counters.get(uid_str, 0), panel_active=panel.active)
                        else:
                            diag.event("SEARCH", "resend", level="debug", n=search_sent, mode=search_mode)
                        active = await _get_match_count(uid_str, panel)
                        try:
                            bot_state.update_status(uid_str, "SEARCHING", active)
                        except Exception:
                            pass
                    except Exception as e:
                        print_error(f"start_game ({tag}) error: {e}")
                        diag.event("SEARCH", "send_failed", level="warning", code="GW_SEND_FAILED", exc=e,
                                   err=diag.classify(e), mode=search_mode)
                    last_start_time = asyncio.get_running_loop().time()

                if (_may_start(uid_str, panel, await _get_match_count(uid_str, panel))
                        and await _has_match_slot(uid_str, panel)):
                    await send_start_match()

                while True:
                    play_matches[:] = [m for m in play_matches if not m.done()]

                    active_count = await _get_match_count(uid_str, panel)
                    try:
                        # un seul StartMatch par recherche : l'état « recherche » ne vient plus des renvois
                        bot_state.update_status(
                            uid_str,
                            "IN_MATCH" if active_count else
                            ("SEARCHING" if search_sent and not cancel_sent_at else "ONLINE"),
                            active_count
                        )
                    except Exception:
                        pass
                    # connecté sans recherche en cours alors que sa session l'autorise à jouer : attend une place, comme
                    # les comptes hors ligne (partage équitable : vu par _fewest_waiting avec ses parties en cours)
                    if uid_str not in panel.searching and _may_start(uid_str, panel, active_count):
                        panel.waiting.add(uid_str)
                    else:
                        panel.waiting.discard(uid_str)

                    if cancel_sent_at and time.time() - cancel_sent_at > CANCEL_ACK_TIMEOUT_S:
                        # annulation sans réponse : connexion coupée (annule à coup sûr), rouverte pendant l'attente
                        diag.event("SEARCH", "cancel_timeout", level="warning", code="GW_NO_CANCEL_ACK",
                                   searches=search_sent, never_accepted=cancel_queued or None)
                        await _gw_close()
                        break

                    if not cancel_sent_at and _fair_share_yield(uid_str, panel):
                        # partage équitable : un compte du panel se connecte encore ou attend avec moins de parties
                        # en cours que celui-ci -> il libère sa place (recherche en cours abandonnée) et attend
                        diag.event("SLOT", "yield", level="info", code="FAIR_SHARE", mine=active_count,
                                   starved=len(panel.starved), newcomers=_panel_newcomers.get(panel.key, 0),
                                   fewest=panel.fewest, searching_s=round(time.time() - search_started)
                                   if search_started else 0)
                        if search_sent and GATEWAY_STAY_ONLINE:
                            await cancel_search("FAIR_SHARE")   # annulée comme dans le jeu, connexion gardée
                        else:
                            if search_sent or not GATEWAY_STAY_ONLINE:
                                await _gw_close()               # ancien comportement : annulée en coupant
                            break

                    if (search_sent and not cancel_sent_at and GATEWAY_STAY_ONLINE
                            and not _may_start(uid_str, panel, active_count)):
                        # le compte n'a plus le droit de chercher (arrêt demandé, objectif atteint, partie quittée
                        # pas encore finie…) : recherche annulée tout de suite. Avant : une recherche acceptée
                        # continuait jusqu'au match trouvé.
                        diag.event("SEARCH", "dropped", level="info", searches=search_sent,
                                   code="MATCH_END_WAIT" if _left_waiting(uid_str) else "ACCOUNT_LIMIT")
                        await cancel_search("NOT_READY")

                    if (search_accepted_at and not cancel_sent_at
                            and time.time() - search_accepted_at > SEARCH_REQUEUE_S):
                        # acceptée depuis trop longtemps sans match (le serveur trouve en 121 s au plus, 18/10) :
                        # annulée puis relancée sur la même connexion. Avant : rien ne la relançait, le compte
                        # restait « en recherche » tant qu'il avait des parties en cours (SEARCH_TIMEOUT sinon).
                        diag.event("SEARCH", "requeue", level="info", waited_s=round(time.time() - search_accepted_at))
                        await cancel_search("REQUEUE")

                    now = asyncio.get_running_loop().time()
                    # Un seul StartMatch par recherche, comme le client officiel ; renvoyé seulement s'il n'a pas été
                    # accepté (0x03 4=11) dans start_interval_s. Avant : renvoyé toutes les 3 s (accusés ignorés).
                    if (not search_accepted_at and not cancel_sent_at
                            and now - last_start_time >= bot_state.tuning(uid_str, "start_interval_s", START_MATCH_INTERVAL)
                            and _may_start(uid_str, panel, active_count)
                            and await _has_match_slot(uid_str, panel)):
                        await send_start_match()

                    try:
                        await _gw_keepalive()
                        data = await asyncio.wait_for(reader.read(8192), timeout=0.5)
                    except asyncio.TimeoutError:
                        no_response_count += 1
                        # recherche acceptée : le serveur se tait jusqu'au match trouvé (32 s dans le jeu le 17/10) ;
                        # la connexion n'est tenue pour morte que si plus rien n'arrive, maintien compris
                        dead = time.monotonic() - gw_last_rx > GATEWAY_DEAD_S
                        if no_response_count > 80 and (dead or not search_accepted_at) and not cancel_sent_at:
                            if not await _ready_to_search(uid_str, panel):
                                # connecté sans pouvoir chercher (limite du panel réduite, protection anti-saturation…) :
                                # rien n'est en panne, on attend une place (en ligne avec GATEWAY_STAY_ONLINE)
                                diag.event("SLOT", "quiet_disconnect", level="info",
                                           code=_slot_block_reason(uid_str, panel), mine=active_count,
                                           searches=search_sent)
                                if search_sent and GATEWAY_STAY_ONLINE and not dead:
                                    await cancel_search("NOT_READY")
                                    continue
                                if search_sent or not GATEWAY_STAY_ONLINE:
                                    await _gw_close()
                                break
                            print_warning(f"[FUNCTIONAL] Gateway silent ({uid_str}). Reconnecting...")
                            raise ConnectionError("Gateway idle timeout")
                        continue

                    if not data:
                        raise ConnectionError("Connection closed by server")

                    hex_data = data.hex()
                    packet_length = len(data)
                    gw_last_rx = time.monotonic()
                    frames = gw_frames.feed(data)
                    # les réponses au maintien (type >= 0x80, 1 octet) ne comptent pas comme réponse : une passerelle
                    # qui ne fait que les renvoyer reste « silencieuse » (Gateway idle timeout) comme avant, et une
                    # session refusée (fermée juste après le token) reste reconnue comme telle (GW_REJECTED)
                    if not frames or any(t < 0x80 for t, _ in frames):
                        no_response_count = 0
                        got_data = True
                        gateway_rejects = 0
                    for gw_type, gw_body in frames:
                        if gw_type not in (GW_MATCH_RESULT, GW_LEVEL_EXP) and gw_type < 0x80:
                            _gw_log_type(uid_str, gw_type, gw_body)
                        _gateway_message(uid_str, gw_type, gw_body, found_matches)
                    await _oracle_on_frames(frames)
                    codes03 = [_pb_int(_pb_fields(b), 4) for t, b in frames if t == 0x03]
                    if GW_SEARCH_ACCEPTED in codes03 and search_sent and not search_accepted_at:
                        search_accepted_at = time.time()
                        diag.event("SEARCH", "accepted", level="debug",
                                   dur_ms=round((time.time() - search_started) * 1000) if search_started else None)
                        if cancel_queued:
                            await cancel_search("QUEUED", now_accepted=True)
                    if (GW_SEARCH_CANCELLED in codes03 and cancel_sent_at
                            and not any(t == 0x03 and len(b) >= 295 for t, b in frames)):
                        # annulation acceptée (et pas de match trouvé dans la même lecture) : attente d'une place,
                        # connexion gardée (le compte reste en ligne)
                        diag.event("SEARCH", "cancelled", level="info", searches=search_sent, why=cancel_why,
                                   ack_ms=round((time.time() - cancel_sent_at) * 1000),
                                   searching_s=round(time.time() - search_started) if search_started else 0)
                        search_accepted_at = 0.0
                        if cancel_why == "REQUEUE":
                            # relance sur la même connexion : nouveau StartMatch au prochain tour
                            cancel_sent_at, cancel_why, last_start_time = 0.0, None, 0.0
                            continue
                        break
                    # « match trouvé » / « recherche acceptée » (type 0x03) lus dans le message entier : avec le maintien
                    # périodique, la réponse du serveur (6 octets) peut arriver collée devant dans la même lecture
                    msgs03 = [b for t, b in frames if t == 0x03]
                    if msgs03:
                        body03 = max(msgs03, key=len)
                        hex_data = (b"\x03\x00" + len(body03).to_bytes(3, "big") + body03).hex()
                        packet_length = 5 + len(body03)
                    elif frames or gw_frames.buf:
                        # rien pour la recherche dans cette lecture, ou message encore incomplet : le « match trouvé »
                        # (jusqu'à 5 Ko le 17/10) arrive parfois en plusieurs lectures ; lu en entier à la suivante.
                        # Avant : le début était pris pour un match trouvé illisible (GW_BAD_PACKET, match perdu).
                        hex_data, packet_length = "", 0

                    if hex_data.startswith("0300") and 10 < packet_length < 30:
                        print_info("Match starting, please wait...")
                        diag.event("SEARCH", "match_starting", level="debug", size=packet_length)
                        continue

                    if hex_data.startswith("0300") and packet_length >= 300:
                        print_colored("=" * 60, Colors.GREEN)
                        print_colored(f"MATCH FOUND! Loading...", Colors.GREEN)
                        print_colored("=" * 60, Colors.GREEN)

                        try:
                            res = json.loads(await decode_protobuf(hex_data[10:]))
                            token = None
                            udp_key = None
                            match_code = None
                            server_ip_port = None
                            match_account_id = None
                            block_val = None

                            if '42' in res and 'data' in res['42']:
                                match_code = res['42']['data']
                            if '5' in res and 'data' in res['5']:
                                res_field5 = res['5']['data']
                                server_ip_port = res_field5.get('2', {}).get('data')
                                udp_key = res_field5.get('3', {}).get('data')
                                token = res_field5.get('4', {}).get('data')
                                if '42' in res_field5:
                                    match_code = res_field5['42']['data']
                            if '1' in res and 'data' in res['1']:
                                match_account_id = res['1']['data']
                            if '5' in res and 'data' in res['5']:
                                block_val = res['5']['data'].get('1', {}).get('data')

                            effective_acc_id = match_account_id or account_id or "BD_BOT"

                            if token and udp_key and match_code and server_ip_port:
                                acc_tok = ""
                                if current_account_data:
                                    acc_tok = current_account_data.get('access_token', '') or ""
                                mode_id, map_id = MATCH_MODE_IDS.get(search_mode, MATCH_MODE_IDS["lone_wolf"])
                                if search_mode in SERVER_MAP_MODES:
                                    # BR / Clash Squad : mode et carte choisis par le serveur (5.7 / 5.8 du match trouvé)
                                    res_field5 = res.get('5', {}).get('data') or {}
                                    mode_id = _proto_int(res_field5.get('7', {}).get('data'), mode_id)
                                    map_id = _proto_int(res_field5.get('8', {}).get('data'), map_id)
                                    if search_mode in RANKED_BASE_MODE or search_mode in DERIVED_BASE_MODE:
                                        # classé / dérivé : le client officiel annonce la carte choisie dans la liste
                                        # (5.6), pas 5.8 (Ranked BR du 16/10 : 5.6 = 29, 5.8 = 2 -> 29 dans le 448 ;
                                        # BR Pony du 28/10 : 5.6 = 29, 5.8 = 1 -> 29)
                                        map_id = _proto_int(res_field5.get('6', {}).get('data'), map_id)
                                thunder, sharma = await build_match_startup_packets(
                                    token, udp_key, match_code, effective_acc_id, block_val or 0,
                                    server_ip=server_ip_port,
                                    region=_join_region(current_account_data, account_region),
                                    client_version=client_version,
                                    access_token=acc_tok,
                                    mode_id=mode_id,
                                    map_id=map_id,
                                    ranked=search_mode if search_mode in RANKED_BASE_MODE else None
                                )

                                match_index = await _inc_match(uid_str, panel, search_mode)
                                panel.searching.discard(uid_str)
                                bot_state.match_started(uid_str, match_index, server_ip_port, search_mode)
                                total = await _get_total_match_count(uid_str, panel)
                                match_id = _proto_int(block_val, 0)   # 5.1 = id de la partie (résultat 0x04 : 5.2)
                                if match_id:
                                    found_matches[match_id] = (search_mode, match_index, time.time())
                                    if len(found_matches) > 300:
                                        found_matches.pop(next(iter(found_matches)))
                                diag.event("SEARCH", "found", level="info", m=match_index, server=server_ip_port,
                                           mode=search_mode, mode_id=mode_id, map_id=map_id, searches=search_sent,
                                           dur_ms=round((time.time() - search_started) * 1000) if search_started
                                           else None, mine=match_index, panel_active=total, match_id=match_id or None,
                                           token_len=len(token), join_parts=thunder.count(",") + 1)
                                print_colored(
                                    f"🚀 [MATCH #{match_index}] UDP starting → {server_ip_port} (background)",
                                    Colors.CYAN
                                )
                                print_success(
                                    f"[FUNCTIONAL] UDP task started. "
                                    f"UID active: {match_index} | Panel: {total}"
                                )

                                new_match = asyncio.create_task(
                                    play_game(
                                        server_ip_port,
                                        thunder,
                                        sharma,
                                        udp_key,
                                        match_code,
                                        effective_acc_id,
                                        "BD",
                                        client_version,
                                        current_key,
                                        current_iv,
                                        match_index=match_index,
                                        owner_uid=uid_str,
                                        mode=search_mode,
                                        match_id=match_id or None,
                                        # appareil du compte -> RUDP_C2S_SYSTEM_INFO de la partie (UDP_JOIN_SEQ)
                                        sysinfo=account_system_info(current_account_data)
                                    )
                                )
                                play_matches.append(new_match)
                                if search_mode in UNINTERRUPTIBLE_MODES:
                                    _keep_running(new_match, uid_str)

                                consecutive_parse_failures = 0

                                # Anti-cheat: keep the gateway open during match for 0x28/0x1d.
                                # Oracle mode: poll oracle for SDK-generated reports.
                                # Replay mode: send pre-captured data at fixed timings.
                                _ac_detached = False
                                _use_oracle = bool(_oracle_url())
                                _use_replay = not _use_oracle and GW_ANTICHEAT_REPORT
                                if _use_oracle or _use_replay:
                                    _ac_w, _ac_r = writer, reader
                                    _ac_k, _ac_v = current_key, current_iv
                                    _ac_gf = gw_frames
                                    writer, reader = None, None
                                    gw_frames = _GatewayFrames()
                                    _ac_detached = True

                                    if _use_oracle:
                                        async def _ac_oracle_send(_w, _r, _k, _v, _gf, _mt):
                                            sent_count = 0
                                            ka_t = time.monotonic()
                                            poll_t = 0.0
                                            try:
                                                while not _mt.done():
                                                    if time.monotonic() - ka_t >= GATEWAY_KEEPALIVE_S:
                                                        ka_t = time.monotonic()
                                                        _w.write(gateway_keepalive(_w))
                                                        await asyncio.wait_for(_w.drain(), timeout=3)
                                                    try:
                                                        d = await asyncio.wait_for(_r.read(8192), timeout=0.5)
                                                        if d:
                                                            svr_frames = _gf.feed(d)
                                                            for gt, gb in svr_frames:
                                                                _gateway_message(uid_str, gt, gb, found_matches)
                                                                if gt in (0x1d, 0x28):
                                                                    await _oracle_feed_server_msg(uid_str, gt, gb)
                                                        elif d == b"":
                                                            break
                                                    except asyncio.TimeoutError:
                                                        pass
                                                    except Exception:
                                                        break
                                                    now = time.monotonic()
                                                    if now >= poll_t:
                                                        poll_t = now + 1.5
                                                        reports = await _oracle_captured()
                                                        for rep in reports:
                                                            try:
                                                                body = bytes.fromhex(rep["hex"])
                                                                await gateway_send(_w, (0x28, body), _k, _v)
                                                                sent_count += 1
                                                                diag.event("ORACLE", "match_sent", level="info",
                                                                           uid=uid_str, type="0x28",
                                                                           len=len(body), n=sent_count)
                                                            except Exception:
                                                                pass
                                                # final poll after match
                                                reports = await _oracle_captured()
                                                for rep in reports:
                                                    try:
                                                        body = bytes.fromhex(rep["hex"])
                                                        await gateway_send(_w, (0x28, body), _k, _v)
                                                        sent_count += 1
                                                    except Exception:
                                                        pass
                                            except Exception as e:
                                                diag.event("ANTICHEAT", "oracle_match_error", level="warning",
                                                           err=str(e)[:200])
                                            finally:
                                                try:
                                                    _w.close()
                                                    await _w.wait_closed()
                                                except Exception:
                                                    pass
                                                diag.event("ANTICHEAT", "match_done", level="info",
                                                           mode="oracle", sent=sent_count)

                                        asyncio.create_task(_ac_oracle_send(
                                            _ac_w, _ac_r, _ac_k, _ac_v, _ac_gf, new_match))

                                    else:
                                        _ac_replay = _load_anticheat_replay()
                                        if not (_ac_replay and (_ac_replay.get("match_0x28") or _ac_replay.get("match_0x1d"))):
                                            writer, reader = _ac_w, _ac_r
                                            gw_frames = _ac_gf
                                            _ac_detached = False
                                        else:
                                            async def _ac_match_send(_w, _r, _k, _v, _gf, _mt, _rp):
                                                t0 = time.monotonic()
                                                m_0x1d = _rp.get("match_0x1d", [])
                                                m_0x28 = _rp.get("match_0x28", [])
                                                si, s3, s4 = 0, False, False
                                                ka_t = time.monotonic()
                                                try:
                                                    while not _mt.done():
                                                        if time.monotonic() - ka_t >= GATEWAY_KEEPALIVE_S:
                                                            ka_t = time.monotonic()
                                                            _w.write(gateway_keepalive(_w))
                                                            await asyncio.wait_for(_w.drain(), timeout=3)
                                                        try:
                                                            d = await asyncio.wait_for(_r.read(8192), timeout=0.5)
                                                            if d:
                                                                for gt, gb in _gf.feed(d):
                                                                    _gateway_message(uid_str, gt, gb, found_matches)
                                                            elif d == b"":
                                                                break
                                                        except asyncio.TimeoutError:
                                                            pass
                                                        except Exception:
                                                            break
                                                        el = time.monotonic() - t0
                                                        if si < len(m_0x1d):
                                                            nxt = 15.0 + si * 8.5
                                                            if el >= nxt:
                                                                await gateway_send(_w, (0x1d, m_0x1d[si][1]), _k, _v)
                                                                si += 1
                                                        if not s3 and m_0x28 and el >= 70.0:
                                                            await gateway_send(_w, (0x28, m_0x28[0]), _k, _v)
                                                            s3 = True
                                                            diag.event("ANTICHEAT", "match_0x28", level="info",
                                                                       n=3, at_s=round(el))
                                                    if len(m_0x28) > 1:
                                                        await gateway_send(_w, (0x28, m_0x28[1]), _k, _v)
                                                        s4 = True
                                                        diag.event("ANTICHEAT", "match_0x28", level="info",
                                                                   n=4, at_s=round(time.monotonic() - t0))
                                                    try:
                                                        d = await asyncio.wait_for(_r.read(8192), timeout=2)
                                                        if d:
                                                            for gt, gb in _gf.feed(d):
                                                                _gateway_message(uid_str, gt, gb, found_matches)
                                                    except Exception:
                                                        pass
                                                except Exception as e:
                                                    diag.event("ANTICHEAT", "match_error", level="warning",
                                                               err=str(e)[:200])
                                                finally:
                                                    try:
                                                        _w.close()
                                                        await _w.wait_closed()
                                                    except Exception:
                                                        pass
                                                    diag.event("ANTICHEAT", "match_done", level="info",
                                                               sent_0x1d=si, sent_0x28_3=s3, sent_0x28_4=s4)

                                            asyncio.create_task(_ac_match_send(
                                                _ac_w, _ac_r, _ac_k, _ac_v, _ac_gf, new_match, _ac_replay))

                                if not _ac_detached:
                                    await _gw_close()
                                pause_s = bot_state.tuning(uid_str, "relaunch_delay_s", NEW_MATCH_DELAY)
                                offline_s = min(pause_s, GATEWAY_FOUND_RECONNECT_S)
                                print_info(
                                    f"[{'ONLINE' if GATEWAY_STAY_ONLINE else 'OFFLINE'}] {pause_s}s "
                                    f"{'online' if GATEWAY_STAY_ONLINE else 'offline'} → reload token → new StartMatch"
                                )
                                reconnects = 0
                                break

                            else:
                                consecutive_parse_failures += 1
                                print_warning(
                                    f"[FUNCTIONAL] Non-match big packet "
                                    f"(#{consecutive_parse_failures}/{MAX_CONSECUTIVE_PARSE_FAILURES}) "
                                    f"→ reconnecting"
                                )
                                missing = [k for k, v in (("token", token), ("udp_key", udp_key),
                                                          ("match_code", match_code), ("server", server_ip_port))
                                           if not v]
                                diag.event("SEARCH", "bad_packet", level="warning", code="GW_BAD_PACKET",
                                           size=packet_length, missing=",".join(missing),
                                           n=consecutive_parse_failures, head=hex_data[:40])

                                if consecutive_parse_failures >= MAX_CONSECUTIVE_PARSE_FAILURES:
                                    print_error(
                                        f"[FUNCTIONAL] {MAX_CONSECUTIVE_PARSE_FAILURES}x parse failures "
                                        f"→ invalidating cache for fresh login"
                                    )
                                    _invalidate_account_cache(current_account_data, "แพ็กเก็ตแมตช์ผิดรูปแบบซ้ำ")
                                    consecutive_parse_failures = 0

                                await _gw_close()
                                pause_s = NON_MATCH_RECONNECT_DELAY
                                break

                        except Exception as e:
                            print_error(f"[FUNCTIONAL] Match packet error: {e}")
                            consecutive_parse_failures += 1
                            diag.event("SEARCH", "packet_error", level="warning", code="GW_PARSE_ERROR", exc=e,
                                       tb=True, size=packet_length, n=consecutive_parse_failures, head=hex_data[:40])
                            if consecutive_parse_failures >= MAX_CONSECUTIVE_PARSE_FAILURES:
                                _invalidate_account_cache(current_account_data, "ถอดรหัสแพ็กเก็ตแมตช์ไม่ได้ซ้ำ")
                                consecutive_parse_failures = 0
                            await _gw_close()
                            pause_s = NON_MATCH_RECONNECT_DELAY
                            break

                    if 30 <= packet_length <= 40:
                        continue

                if pause_s:
                    # pause avant la recherche suivante (partie trouvée, paquet illisible) : connecté avec
                    # GATEWAY_STAY_ONLINE (passerelle rouverte après offline_s), hors ligne sinon
                    if offline_s:
                        await asyncio.sleep(offline_s)
                    if not await _idle_wait(pause_s - offline_s):
                        raise ConnectionError("Cache expired, triggering fresh login")

            except asyncio.CancelledError:
                await _stop_matches(play_matches)
                raise
            except Exception as e:
                code = diag.classify(e)
                if phase == "connect" and code == "TIMEOUT":
                    code = "NET_TIMEOUT"            # délai de connexion TCP dépassé (GATEWAY_CONNECT_TIMEOUT_S)
                err_text = str(e) or type(e).__name__
                if "Cache expired" in err_text:
                    print_info(f"[FUNCTIONAL] Session expirée ({uid_str}) : nouveau login")   # routine, pas une panne
                else:
                    print_error(f"[FUNCTIONAL] TCP state ({uid_str}): {err_text}")
                bot_state.gateway_error(uid_str, err_text)

                play_matches[:] = [m for m in play_matches if not m.done()]

                await _gw_close()

                if "Cache expired" in err_text:
                    print_info(f"[FUNCTIONAL] Triggering re-login for {uid_str}")   # routine (session de 2 h)
                    diag.event("GATEWAY", "session_expired", level="info", code="CACHE_EXPIRED")
                    break

                after_s = round(time.time() - token_sent_at, 1) if token_sent_at is not None else None
                # Session gardée refusée par la passerelle (connexion fermée juste après le token, sans réponse) :
                # au bout de quelques refus de suite, login complet au lieu de reboucler sur la même session.
                # Le silence d'une passerelle (attente d'une place de match) n'est pas un refus.
                rejected = (token_sent_at is not None and not got_data
                            and time.time() - token_sent_at < GATEWAY_REJECT_WINDOW_S)
                if rejected:
                    gateway_rejects += 1
                    if gateway_rejects >= GATEWAY_REJECTS_BEFORE_RELOGIN:
                        print_warning(f"[FUNCTIONAL] Passerelle : session refusée {gateway_rejects} fois de suite "
                                      f"({uid_str}) → nouveau login")
                        diag.event("GATEWAY", "rejected_relogin", level="warning", code="GW_REJECTED",
                                   rejects=gateway_rejects, err=code, after_s=after_s, msg=err_text[:300])
                        _invalidate_account_cache(current_account_data, "เกตเวย์ไม่รับ session ซ้ำ")
                        break

                reconnects += 1
                delay = min(GATEWAY_BACKOFF_MAX_S, 2.0 ** (reconnects - 1)) * random.uniform(0.8, 1.2)
                name = ("connect_failed" if phase == "connect" else
                        {"GW_IDLE": "idle_timeout", "GW_CLOSED": "closed_by_server"}.get(code, "session_error"))
                diag.event("GATEWAY", name, level="warning", code="GW_REJECTED" if rejected else code,
                           err=code if rejected else None, msg=err_text[:300], addr=addrs, after_s=after_s,
                           got_data=got_data, searches=search_sent, retry=reconnects,
                           retry_in_s=round(delay, 1), rejects=gateway_rejects or None)
                if reconnects > max_reconnects:
                    print_error("[FUNCTIONAL] Max reconnects reached, retrying...")
                    reconnects = 0
                    await asyncio.sleep(3)
                    continue

                await asyncio.sleep(delay)

    except asyncio.CancelledError:
        await _stop_matches(play_matches)
        raise
    finally:
        panel.searching.discard(uid_str)
        panel.waiting.discard(uid_str)
        if writer is not None:
            writer.close()          # connexion gardée (GATEWAY_STAY_ONLINE) : fermée avec la session


async def informational(addrs, starter_packet, key, iv, region="BD", max_reconnects=3, uid=None):
    """Connexion « chat » du compte : salon du lobby rejoint à la connexion et après chaque partie (`uid` :
    _chat_rejoin_signal depuis _finish_match), 0x1e ~5 s après, maintien toutes les GATEWAY_KEEPALIVE_S."""
    reconnects = 0
    ip, port = addrs.split(":")
    failures = 0
    rejoin = asyncio.Event()
    if uid is not None:
        _chat_rejoin[str(uid)] = rejoin
    while True:
        writer = None
        ping_task = None
        connected_at = None
        try:
            resolved_ip = await resolve_host_cloudflare(ip)
            reader, writer = await asyncio.wait_for(asyncio.open_connection(resolved_ip, int(port)),
                                                    GATEWAY_CONNECT_TIMEOUT_S)
            gateway_bind_region(writer, region)

            raw_sock = writer.get_extra_info('socket')
            if raw_sock:
                optimize_tcp_socket(raw_sock)

            writer.write(bytes.fromhex(starter_packet))
            await asyncio.wait_for(writer.drain(), GATEWAY_WRITE_TIMEOUT_S)
            connected_at = time.time()
            reconnects = 0

            # Initial keepalive right after connecting (pas chez le client officiel, voir GW_CLIENT_INIT)
            try:
                init_ka = None if GW_CLIENT_INIT else await send_keep_alive(region)
                if init_ka and writer and not writer.is_closing():
                    writer.write(init_ka)
                    await asyncio.wait_for(writer.drain(), timeout=3)
            except Exception:
                pass

            # comme le client officiel (17/10) : salon du lobby rejoint aussitôt, puis 0x1e {1: 3} ~5 s après
            rejoin.clear()
            try:
                await gateway_send(writer, CHAT_JOIN_CHANNEL, key, iv)
            except Exception:
                pass

            async def info_keepalive():
                ka_bytes = await send_keep_alive(region)
                await asyncio.sleep(5)
                try:
                    await gateway_send(writer, CHAT_HELLO, key, iv)
                except Exception:
                    return
                next_ka = time.time() + GATEWAY_KEEPALIVE_S - 5
                rejoin_at = 0.0           # salon à rejoindre à… (0 = rien à faire), voir CHAT_REJOIN_DELAY_S
                while True:
                    due = min(next_ka, rejoin_at) if rejoin_at else next_ka
                    try:
                        await asyncio.wait_for(rejoin.wait(), timeout=max(0.05, due - time.time()))
                    except asyncio.TimeoutError:
                        pass
                    if rejoin.is_set():
                        rejoin.clear()
                        rejoin_at = time.time() + random.uniform(*CHAT_REJOIN_DELAY_S)
                    now = time.time()
                    try:
                        if rejoin_at and now >= rejoin_at:
                            rejoin_at = 0.0
                            if writer and not writer.is_closing():
                                await gateway_send(writer, CHAT_JOIN_CHANNEL, key, iv)
                                diag.event("GATEWAY", "chat_rejoin", level="debug")
                        if now >= next_ka:
                            next_ka = now + GATEWAY_KEEPALIVE_S
                            if writer and not writer.is_closing():
                                writer.write(ka_bytes)
                                await writer.drain()
                    except Exception:
                        break

            ping_task = asyncio.create_task(info_keepalive())

            while True:
                data = await reader.read(8192)
                if not data:
                    raise ConnectionError("Connection closed")
        except asyncio.CancelledError:
            if uid is not None and _chat_rejoin.get(str(uid)) is rejoin:
                _chat_rejoin.pop(str(uid), None)
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            raise
        except Exception as e:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            # connexion « chat » (informational) : sans effet sur les parties, journal de détail seulement
            failures = 0 if connected_at and time.time() - connected_at > 60 else failures + 1
            diag.event("GATEWAY", "chat_error", level="debug", code=diag.classify(e), msg=str(e)[:200],
                       connected_s=round(time.time() - connected_at) if connected_at else None, failures=failures)
            reconnects += 1
            if reconnects > max_reconnects:
                await asyncio.sleep(min(GATEWAY_BACKOFF_MAX_S, 3.0 * failures))
                reconnects = 0
            else:
                await asyncio.sleep(1)


# ==================== ACCOUNT PROCESSORS ====================

def _register_credentials(account_data: Dict):
    try:
        acc_id = str(account_data['account_id'])
        bot_state.account_credentials[acc_id] = account_data
        if account_data.get('auth_uid'):
            bot_state.account_credentials[str(account_data['auth_uid'])] = account_data
        if account_data.get('auth_token'):
            bot_state.account_credentials[f"tok_{account_data['auth_token'][:20]}"] = account_data
    except Exception:
        pass


# ==================== RELEVÉ DU PROFIL (EXP / niveau) ====================
# GetPlayerPersonalShow (ffbot.api_client.account_profile) : simple lecture du profil avec le token de la session.
# GetLoginData fait partie du login (le client officiel ne l'appelle qu'à la connexion) : il ne sert plus que de
# secours, après plusieurs échecs de suite de GetPlayerPersonalShow, au plus une fois par GETLOGIN_FALLBACK_MIN_S.
PROFILE_MIN_INTERVAL_S = 8.0        # relevés rapprochés d'un même compte (fins de matchs groupées) : dernier résultat
GETLOGIN_FALLBACK_AFTER = 3         # échecs consécutifs de GetPlayerPersonalShow avant le secours GetLoginData
GETLOGIN_FALLBACK_MIN_S = 900       # au plus un GetLoginData de secours toutes les 15 min par compte


class _ProfileReads:
    """Relevés de profil d'un compte : un seul à la fois, dernier résultat, échecs consécutifs."""
    __slots__ = ("lock", "at", "data", "failures", "getlogin_at")

    def __init__(self):
        self.lock = asyncio.Lock()
        self.at = 0.0
        self.data: Optional[Dict[str, Any]] = None
        self.failures = 0
        self.getlogin_at = 0.0

_profile_reads: Dict[str, _ProfileReads] = {}


async def _profile_from_getlogin(account_data: Dict) -> Optional[Dict[str, Any]]:
    """Secours : profil lu dans la réponse de GetLoginData (niveau, EXP, likes, pseudo ; pas d'avatar ni de bannière)."""
    url = account_data.get('server_url')
    token = account_data.get('token')
    release_version = account_data.get('release_version')
    payload = account_data.get('login_payload_data')
    if not (url and token and release_version and payload):
        return None
    res = await send_getlogin(payload, url, token, release_version, stage="EXP")
    if not res:
        return None
    res_proto, dict_res = res
    return {
        "account_id": str(account_data['account_id']),
        "nickname": res_proto.nickname or get_proto_field(dict_res, 4, ""),
        "region": "",
        "level": _proto_int(get_proto_field(dict_res, 6), 0),
        "exp": _proto_int(get_proto_field(dict_res, 7), 0),
        "likes": _proto_int(get_proto_field(dict_res, 8), 0),
        "head_pic": "",
        "banner_id": "",
        "source": "getlogin",
    }


async def fetch_account_profile(account_data: Optional[Dict], allow_getlogin: bool = True) -> Optional[Dict[str, Any]]:
    """Profil d'un compte en session (niveau, EXP, likes, pseudo, avatar, bannière), sans rien transmettre au moteur.

    GetPlayerPersonalShow d'abord ; GetLoginData seulement après GETLOGIN_FALLBACK_AFTER échecs de suite.
    Deux relevés à moins de PROFILE_MIN_INTERVAL_S d'écart renvoient le même résultat. None si indisponible.
    """
    if not account_data or not account_data.get('token') or not account_data.get('account_id'):
        return None
    acc_id = str(account_data['account_id'])
    reads = _profile_reads.get(acc_id)
    if reads is None:
        reads = _profile_reads[acc_id] = _ProfileReads()
    async with reads.lock:
        if reads.data and time.time() - reads.at < PROFILE_MIN_INTERVAL_S:
            return reads.data
        data = None
        t0 = time.perf_counter()
        try:
            data = await api_client.account_profile(account_data)
            diag.event("EXP", "profile", level="debug", lv=data.get("level"), exp=data.get("exp"),
                       dur_ms=(time.perf_counter() - t0) * 1000)
        except api_client.GameApiError as e:
            reads.failures += 1
            if reads.failures == 1 or reads.failures == GETLOGIN_FALLBACK_AFTER:
                print_warning(f"[EXP-REFRESH] GetPlayerPersonalShow ({acc_id}) : {e}"[:300])
            # chaque échec est compté (code) ; écrit dans le fichier au 1er puis tous les 3 échecs de suite
            diag.event("EXP", "profile_failed", level="warning" if reads.failures % 3 == 1 else "debug",
                       code=diag.classify(str(e)), status=e.status, failures=reads.failures, msg=str(e)[:300],
                       dur_ms=(time.perf_counter() - t0) * 1000)
            if (allow_getlogin and reads.failures >= GETLOGIN_FALLBACK_AFTER
                    and time.time() - reads.getlogin_at >= GETLOGIN_FALLBACK_MIN_S):
                reads.getlogin_at = time.time()
                print_warning(f"[EXP-REFRESH] {acc_id} : {reads.failures} échecs de suite → relevé de secours par GetLoginData")
                data = await _profile_from_getlogin(account_data)
        else:
            if reads.failures >= GETLOGIN_FALLBACK_AFTER:
                print_info(f"[EXP-REFRESH] {acc_id} : GetPlayerPersonalShow de nouveau disponible")
            reads.failures = 0
        if data:
            reads.data, reads.at = data, time.time()
        return data


async def refresh_account_profile(account_data_or_uid: Any) -> Optional[Dict[str, Any]]:
    """Relève le profil d'un compte en session et le transmet au moteur (EXP, niveau, carte de profil)."""
    try:
        if isinstance(account_data_or_uid, str):
            account_data = bot_state.account_credentials.get(str(account_data_or_uid))
        else:
            account_data = account_data_or_uid
        data = await fetch_account_profile(account_data)
        if not data:
            return None
        acc_id = str(account_data['account_id'])
        bot_state.update_profile(acc_id, level=data.get('level'), exp=data.get('exp'), likes=data.get('likes'),
                                 nickname=data.get('nickname'), profile=data)
        print_info(f"[EXP-REFRESH] UID {acc_id} -> Level: {data.get('level')}, EXP: {data.get('exp')}")
        return data
    except Exception as e:
        print_error(f"refresh_account_profile error: {e}")
        diag.event("EXP", "refresh_error", level="error", exc=e)
        return None


async def process_account_uid_pass(uid: str, password: str) -> Optional[Dict]:
    cached = cache_get(uid)
    if cached:
        print_success(f"[CACHE HIT] UID {uid} loaded from token_cache.json (no login)")
        diag.event("LOGIN", "cache_hit", level="info", age_min=round((time.time() - cached.get("cached_at", 0)) / 60))
        acc_id = str(cached['account_id'])
        bot_state.register_account(
            uid=acc_id,
            nickname=cached.get('nickname', f"Player_{acc_id}"),
            region=cached.get('region', 'BD'),
            level=cached.get('level', 1),
            exp=cached.get('exp', 0),
            likes=cached.get('likes', 0)
        )
        _register_credentials(cached)
        return cached

    print_info(f"[LOGIN] Full login for UID {uid}...")
    t0 = time.perf_counter()
    try:
        verconfig_res = await version_config()
        if verconfig_res is None:
            return None
        release_version, client_version, server_url = verconfig_res

        tokengrant_response = await get_access_token(uid, password)
        if tokengrant_response is None:
            return None
        open_id, access_token, platform = tokengrant_response

        # 🔥 1ta id 1ta Device Injection
        device_info = get_device_for_account(uid)

        login_payload_data = await build_majorlogin_payload(open_id, access_token, platform, client_version, device_info)
        majorlogin_response = await send_majorlogin(login_payload_data, release_version, server_url)
        if majorlogin_response is None:
            return None
        # corps propre à GetLoginData (voir GETLOGIN_CITY), gardé pour le relevé de secours par GetLoginData
        login_payload_data = await build_majorlogin_payload(open_id, access_token, platform, client_version, device_info,
                                                            getlogin=True)
        getlogin_result = await send_getlogin(login_payload_data, majorlogin_response.url, majorlogin_response.token, release_version)
        if getlogin_result is None:
            return None
        res_proto, dict_res = getlogin_result

        acc_id = str(majorlogin_response.account_id)
        level = int(get_proto_field(dict_res, 6, 1))
        exp = int(get_proto_field(dict_res, 7, 0))
        likes = int(get_proto_field(dict_res, 8, 0))
        nickname = res_proto.nickname or get_proto_field(dict_res, 4, f"Player_{acc_id}")
        region = majorlogin_response.region or get_proto_field(dict_res, 3, "BD")

        bot_state.register_account(uid=acc_id, nickname=nickname, region=region, level=level, exp=exp, likes=likes)

        account_data = {
            'account_id': majorlogin_response.account_id,
            'nickname': nickname,
            'region': region,
            'level': level,
            'exp': exp,
            'likes': likes,
            'open_id': open_id,
            'access_token': access_token,
            'platform': str(platform),
            'token': majorlogin_response.token,
            'server_time': majorlogin_response.server_time,
            'aes_ak': majorlogin_response.aes_ak,
            'iv_i': majorlogin_response.iv_i,
            'ip_region': _login_ip_region(majorlogin_response),   # 448 des comptes IND, voir _join_region
            'functional_addrs': res_proto.functional_addrs or get_proto_field(dict_res, 14),
            'informational_addrs': res_proto.informational_addrs or get_proto_field(dict_res, 32),
            'release_version': release_version,
            'client_version': client_version,
            'server_url': majorlogin_response.url,
            'login_payload_data': login_payload_data,
            'auth_type': 'guest',
            'auth_uid': uid,
            'auth_password': password,
            # appareil déclaré au MajorLogin : repris tel quel dans le 1026 de chaque partie (account_system_info)
            'device_id': device_info.get('unique_device_id')
        }
        if not _gateway_addr(account_data['functional_addrs']):
            print_error(f"[LOGIN] GetLoginData sans adresse de passerelle pour l'UID {uid} : nouvel essai au prochain login")
            diag.event("LOGIN", "no_gateway", level="warning", code="LOGIN_NO_GATEWAY",
                       addr=str(account_data['functional_addrs'])[:60], dur_ms=(time.perf_counter() - t0) * 1000)
            return None
        _register_credentials(account_data)
        cache_set(uid, account_data)
        asyncio.create_task(_send_check_hack_behavior(account_data, acc_id))
        diag.event("LOGIN", "ok", level="info", gid=acc_id, region=region, lv=level,
                   gateway=account_data['functional_addrs'], dur_ms=round((time.perf_counter() - t0) * 1000))
        return account_data
    except AccountBanned:
        raise
    except Exception as e:
        print_error(f"process_account_uid_pass error: {e}")
        diag.event("LOGIN", "error", level="error", exc=e, dur_ms=(time.perf_counter() - t0) * 1000)
        return None


async def _send_check_hack_behavior(session: dict, acc_id: str) -> None:
    """Fire-and-forget : CheckHackBehavior ~2 s après GetLoginData (comme le vrai client)."""
    await asyncio.sleep(2.0)
    ok = await api_client.check_hack_behavior(session)
    diag.event("LOGIN", "check_hack", level="debug" if ok else "warning",
               ok=ok, gid=acc_id)
    if ok:
        print_info(f"[LOGIN] CheckHackBehavior OK ({acc_id})")
    else:
        print_warning(f"[LOGIN] CheckHackBehavior ล้มเหลว ({acc_id})")


async def process_account_token(access_token: str) -> Optional[Dict]:
    cache_key = f"tok_{access_token[:20]}"
    cached = cache_get(cache_key)
    if cached:
        print_success(f"[CACHE HIT] Token {access_token[:10]}... loaded from cache")
        diag.event("LOGIN", "cache_hit", level="info", age_min=round((time.time() - cached.get("cached_at", 0)) / 60))
        acc_id = str(cached['account_id'])
        bot_state.register_account(
            uid=acc_id,
            nickname=cached.get('nickname', f"Player_{acc_id}"),
            region=cached.get('region', 'BD'),
            level=cached.get('level', 1),
            exp=cached.get('exp', 0),
            likes=cached.get('likes', 0)
        )
        _register_credentials(cached)
        return cached

    print_info("[LOGIN] Full login with Access Token...")
    t0 = time.perf_counter()
    try:
        verconfig_res = await version_config()
        if verconfig_res is None:
            return None
        release_version, client_version, server_url = verconfig_res

        import requests
        url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
        hdrs = {
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "close",
            "Content-Type": "application/x-www-form-urlencoded",
            "Host": "100067.connect.garena.com",
            "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)"
        }
        resp = await asyncio.to_thread(requests.get, url, headers=hdrs, timeout=10)
        data = resp.json()

        if 'error' in data:
            diag.event("LOGIN", "token_inspect_failed", level="warning",
                       code=diag.classify(f"HTTP {resp.status_code}") if resp.status_code != 200 else "HTTP_4XX",
                       status=resp.status_code, msg=str(data)[:200], dur_ms=(time.perf_counter() - t0) * 1000)
            print_error(f"[LOGIN] inspect_token : HTTP {resp.status_code} {str(data)[:200]}")   # vers la session
            return None

        open_id = data.get('open_id')
        # entier, comme le login UID + mot de passe (get_access_token) : avant, str(platform) faisait échouer TOUS les
        # logins par token (« rendering_api » est un entier du proto : TypeError dans build_majorlogin_payload)
        try:
            platform = int(data.get('platform') or 4)
        except (TypeError, ValueError):
            platform = 4

        if not open_id:
            diag.event("LOGIN", "token_inspect_failed", level="warning", code="HTTP_BAD_RESPONSE",
                       status=resp.status_code, msg=f"ไม่มี open_id: {str(data)[:160]}")
            return None

        # 🔥 1ta id 1ta Device Injection (using unique open_id as the key)
        device_info = get_device_for_account(open_id)

        login_payload_data = await build_majorlogin_payload(open_id, access_token, platform, client_version, device_info)
        if not login_payload_data:
            return None

        majorlogin_response = await send_majorlogin(login_payload_data, release_version, server_url)
        if majorlogin_response is None:
            return None

        # corps propre à GetLoginData (voir GETLOGIN_CITY), gardé pour le relevé de secours par GetLoginData
        login_payload_data = await build_majorlogin_payload(open_id, access_token, platform, client_version,
                                                            device_info, getlogin=True)
        getlogin_result = await send_getlogin(
            login_payload_data,
            majorlogin_response.url,
            majorlogin_response.token,
            release_version
        )
        if getlogin_result is None:
            return None

        res_proto, dict_res = getlogin_result
        acc_id = str(majorlogin_response.account_id)
        level = int(get_proto_field(dict_res, 6, 1))
        exp = int(get_proto_field(dict_res, 7, 0))
        likes = int(get_proto_field(dict_res, 8, 0))
        nickname = res_proto.nickname or get_proto_field(dict_res, 4, f"Player_{acc_id}")
        region = majorlogin_response.region or get_proto_field(dict_res, 3, "BD")

        bot_state.register_account(uid=acc_id, nickname=nickname, region=region, level=level, exp=exp, likes=likes)

        account_data = {
            'account_id': majorlogin_response.account_id,
            'nickname': nickname,
            'region': region,
            'level': level,
            'exp': exp,
            'likes': likes,
            'open_id': open_id,
            'access_token': access_token,
            'token': majorlogin_response.token,
            'server_time': majorlogin_response.server_time,
            'aes_ak': majorlogin_response.aes_ak,
            'iv_i': majorlogin_response.iv_i,
            'ip_region': _login_ip_region(majorlogin_response),   # 448 des comptes IND, voir _join_region
            'functional_addrs': res_proto.functional_addrs or get_proto_field(dict_res, 14),
            'informational_addrs': res_proto.informational_addrs or get_proto_field(dict_res, 32),
            'release_version': release_version,
            'client_version': client_version,
            'server_url': majorlogin_response.url,
            'login_payload_data': login_payload_data,
            'platform': str(platform),
            'auth_type': 'token',
            'auth_token': access_token,
            # appareil déclaré au MajorLogin : repris tel quel dans le 1026 de chaque partie (account_system_info)
            'device_id': device_info.get('unique_device_id')
        }
        if not _gateway_addr(account_data['functional_addrs']):
            print_error("[LOGIN] GetLoginData sans adresse de passerelle (token) : nouvel essai au prochain login")
            diag.event("LOGIN", "no_gateway", level="warning", code="LOGIN_NO_GATEWAY",
                       addr=str(account_data['functional_addrs'])[:60], dur_ms=(time.perf_counter() - t0) * 1000)
            return None
        _register_credentials(account_data)
        cache_set(cache_key, account_data)
        asyncio.create_task(_send_check_hack_behavior(account_data, acc_id))
        diag.event("LOGIN", "ok", level="info", gid=acc_id, region=region, lv=level,
                   gateway=account_data['functional_addrs'], dur_ms=round((time.perf_counter() - t0) * 1000))
        return account_data
    except AccountBanned:
        raise
    except Exception as e:
        print_error(f"process_account_token error: {e}")
        diag.event("LOGIN", "error", level="error", exc=e, dur_ms=(time.perf_counter() - t0) * 1000)
        return None


async def run_account_worker(account_data: Dict, label: str):
    acc_id = str(account_data['account_id'])
    informational_task = None
    exp_task = None
    reward_task = None
    if not _gateway_addr(account_data.get('functional_addrs')):
        print_error(f"[FUNCTIONAL] Session sans adresse de passerelle pour {label} → nouveau login")
        diag.event("GATEWAY", "no_address", level="warning", code="LOGIN_NO_GATEWAY",
                   addr=str(account_data.get('functional_addrs'))[:60])
        _invalidate_account_cache(account_data, "session ไม่มีที่อยู่เกตเวย์")
        return
    try:
        reg = account_data.get('region', 'BD')
        tcp_packet_online = await build_tcp_startup_packet(
            account_data['account_id'],
            account_data['token'],
            account_data['server_time'],
            account_data['aes_ak'],
            account_data['iv_i'],
            region=reg,
            typ='OnLine'
        )

        tcp_packet_chat = await build_tcp_startup_packet(
            account_data['account_id'],
            account_data['token'],
            account_data['server_time'],
            account_data['aes_ak'],
            account_data['iv_i'],
            region=reg,
            typ='ChaT'
        )

        informational_task = asyncio.create_task(
            informational(
                account_data['informational_addrs'],
                tcp_packet_chat,
                account_data['aes_ak'],
                account_data['iv_i'],
                region=reg,
                uid=str(account_data['account_id'])
            )
        )

        async def exp_refresher():
            # Relevé GetPlayerPersonalShow (pas GetLoginData) : un premier peu après la connexion (avatar et
            # bannière de la carte de profil, EXP de départ à jour), puis toutes les exp_refresh_s.
            await asyncio.sleep(5)
            while True:
                fresh = bot_state.account_credentials.get(acc_id)
                if fresh:
                    await refresh_account_profile(fresh)
                await asyncio.sleep(bot_state.tuning(acc_id, "exp_refresh_s", 90))

        exp_task = asyncio.create_task(exp_refresher())
        reward_task = asyncio.create_task(claim_activity_rewards(acc_id)) \
            if ACTIVITY_REWARDS and ACTIVITY_REWARDS_ENABLED else None
        if EQUIP_CHARACTER:
            # personnage du guide du nouveau joueur, avant la première recherche (voir EQUIP_CHARACTER)
            await _equip_character(account_data, acc_id)
        if LOBBY_PREMATCH_CALLS:
            # lobby ouvert comme le vrai client, avant la première recherche (voir LOBBY_PREMATCH_CALLS)
            t0 = time.perf_counter()
            try:
                results = await api_client.match_lobby_calls(account_data)
                failed = [f"{ep}: {err}" for ep, err in results if err]
                diag.event("LOBBY", "prematch_calls", level="warning" if failed else "info",
                           ok=len(results) - len(failed), failed=len(failed),
                           msg="; ".join(failed)[:300] or None, dur_ms=(time.perf_counter() - t0) * 1000)
            except Exception as e:
                diag.event("LOBBY", "prematch_failed", level="warning", exc=e,
                           dur_ms=(time.perf_counter() - t0) * 1000)

        functional_task = asyncio.create_task(
            functional_lone_wolf(
                account_data['functional_addrs'],
                tcp_packet_online,
                account_data['region'],
                account_data['client_version'],
                account_data['aes_ak'],
                account_data['iv_i'],
                account_id=acc_id,
                account_data=account_data
            )
        )

        await functional_task

    except asyncio.CancelledError:
        raise
    except Exception as e:
        print_error(f"run_account_worker error for {label}: {e}")
        diag.event("SESSION", "worker_error", level="error", code="CRASH", exc=e, tb=True)
    finally:
        for t in (informational_task, exp_task, reward_task):
            if t and not t.done():
                t.cancel()
        for t in (informational_task, exp_task, reward_task):
            if t:
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass

